<?php

add_action( 'wp_enqueue_scripts', 'hyd_css' );
/**
* Checks the settings for the link color color, primary color, and header
* If any of these value are set the appropriate CSS is output
*
* @since 1.0.0
*/
function hyd_css() {

$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

$color_smallnav = get_theme_mod( 'hyd_smallnav_color', hyd_customizer_get_default_smallnav_color() );
$color_smallnavlink = get_theme_mod( 'hyd_smallnavlink_color', hyd_customizer_get_default_smallnavlink_color() );
$color_navigation = get_theme_mod( 'hyd_navigation_color', hyd_customizer_get_default_navigation_color() );
$color_navlink = get_theme_mod( 'hyd_navlink_color', hyd_customizer_get_default_navlink_color() );
$color_navhover = get_theme_mod( 'hyd_navhover_color', hyd_customizer_get_default_navhover_color() );
$color_imagefont = get_theme_mod( 'hyd_imagefont_color', hyd_customizer_get_default_imagefont_color() );
$color_homegrid = get_theme_mod( 'hyd_homegrid_color', hyd_customizer_get_default_homegrid_color() );
$color_optin = get_theme_mod( 'hyd_optin_color', hyd_customizer_get_default_optin_color() );
$color_optinfont = get_theme_mod( 'hyd_optinfont_color', hyd_customizer_get_default_optinfont_color() );
$color_accenttext = get_theme_mod( 'hyd_accenttext_color', hyd_customizer_get_default_accenttext_color() );
$color_primarylink = get_theme_mod( 'hyd_primarylink_color', hyd_customizer_get_default_primarylink_color() );
$color_primaryhover = get_theme_mod( 'hyd_primaryhover_color', hyd_customizer_get_default_primaryhover_color() );
$color_portfolio = get_theme_mod( 'hyd_portfolio_color', hyd_customizer_get_default_portfolio_color() );
$color_footer = get_theme_mod( 'hyd_enewsbackground_color', hyd_customizer_get_default_enewsbackground_color() );
$color_totop = get_theme_mod( 'hyd_totop_color', hyd_customizer_get_default_totop_color() );
$color_blueblock = get_theme_mod( 'hyd_blueblock_color', hyd_customizer_get_default_blueblock_color() );
$color_grayblock = get_theme_mod( 'hyd_grayblock_color', hyd_customizer_get_default_grayblock_color() );
$color_shareicons = get_theme_mod( 'hyd_shareicons_color', hyd_customizer_get_default_shareicons_color() );
$color_socialicons = get_theme_mod( 'hyd_socialicons_color', hyd_customizer_get_default_socialicons_color() );
$color_button = get_theme_mod( 'hyd_button_color', hyd_customizer_get_default_button_color() );
$color_buttonhover = get_theme_mod( 'hyd_buttonhover_color', hyd_customizer_get_default_buttonhover_color() );
$color_sidetab = get_theme_mod( 'hyd_sidetab_color', hyd_customizer_get_default_sidetab_color() );
$color_sidetabicon = get_theme_mod( 'hyd_sidetabicon_color', hyd_customizer_get_default_sidetabicon_color() );

$opts = apply_filters( 'hyd_images', array( '1', '2', '3','4' ) );

$settings = array();

foreach( $opts as $opt ){
$settings[$opt]['image'] = preg_replace( '/^https?:/', '', get_option( $opt .'-hyd-image', sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $opt ) ) );
}

$css = '';

foreach ( $settings as $section => $value ) {

$background = $value['image'] ? sprintf( 'background-image: url(%s);', $value['image'] ) : '';

if( is_front_page() ) {
$css .= ( ! empty( $section ) && ! empty( $background ) ) ? sprintf( '.front-page .image-section-%s { %s }', $section, $background ) : '';
}

}

$css .= ( hyd_customizer_get_default_smallnav_color() !== $color_smallnav ) ? sprintf( '

.front-page .small-wrap,
.small-wrap {
background: %1$s;
}

.site-footer {
border-bottom: 20px solid %1$s;
}

', $color_smallnav ) : '';

$css .= ( hyd_customizer_get_default_smallnavlink_color() !== $color_smallnavlink ) ? sprintf( '

.nav-small .simple-social-icons ul li a,
.nav-small .genesis-nav-menu a {
color: %1$s !important;
}

.nav-small {
color: %1$s;
}

', $color_smallnavlink ) : '';

$css .= ( hyd_customizer_get_default_navigation_color() !== $color_navigation ) ? sprintf( '


.site-header,
.site-header.light,
.nav-primary .genesis-nav-menu.responsive-menu {
background: %1$s;
}

@media only screen and (max-width: 960px) {
.genesis-nav-menu .sub-menu {
background-color: %1$s;
}
}

', $color_navigation ) : '';


$css .= ( hyd_customizer_get_default_navlink_color() !== $color_navlink ) ? sprintf( '

.genesis-nav-menu a,
.responsive-menu-icon,
.responsive-menu-icon::before,
.site-header.light .nav-primary a, .site-header.light .nav-secondary a,
.genesis-nav-menu.responsive-menu > .menu-item-has-children:before,
.nav-secondary .genesis-nav-menu.responsive-menu > .menu-item-has-children:before {
color: %1$s;
}

@media only screen and (max-width: 960px) {

.site-header.light .nav-primary .sub-menu a,
.site-header.light .nav-secondary .sub-menu a {
color: %1$s;
}
}

', $color_navlink ) : '';

$css .= ( hyd_customizer_get_default_navhover_color() !== $color_navhover ) ? sprintf( '

.genesis-nav-menu a:hover {
color: %1$s;
}

@media only screen and (max-width: 960px) {
.site-header.light .nav-primary a:hover,
.site-header.light .nav-secondary a:hover {
color: %1$s;
}
}

', $color_navhover ) : '';


$css .= ( hyd_customizer_get_default_imagefont_color() !== $color_imagefont ) ? sprintf( '

.front-page .image-section h1,
.front-page #home-full .text-box h1,
.front-page .image-section h2,
.front-page #home-full .text-box h2,
.front-page .image-section h3,
.front-page #home-full .text-box h3,
.front-page .image-section h4,
.front-page #home-full .text-box h4,
.front-page .home-split .button,
.front-page .image-section .button,
.front-page .text-box .button {
color: %1$s;
}

.front-page .home-split .button,
.front-page .image-section .button,
.front-page .text-box .button {
border: 3px solid %1$s;
}

', $color_imagefont ) : '';

$css .= ( hyd_customizer_get_default_homegrid_color() !== $color_homegrid ) ? sprintf( '

.front-page .home-grid .widget-title,
.front-page .home-grid .entry-title a  {
color: %1$s;
}

.front-page .home-grid .entry-title a  {
border: 3px solid %1$s;
}

.front-page #home-one .widget-title:after,
.front-page #home-three .widget-title:before,
.front-page #home-two .widget:nth-child(1) .widget-title:before,
.front-page #home-two .widget:nth-child(2) .widget-title:after  {
background: %1$s;
}

', $color_homegrid ) : '';


$css .= ( hyd_customizer_get_default_optin_color() !== $color_optin ) ? sprintf( '

.front-page .home-optin {
background: %1$s;
}

', $color_optin ) : '';

$css .= ( hyd_customizer_get_default_optinfont_color() !== $color_optinfont ) ? sprintf( '

.front-page .home-optin .enews-widget,
.front-page .home-optin .enews-widget p,
.front-page .home-optin .enews-widget .widget-title {
color: %1$s;
}

', $color_optinfont ) : '';

$css .= ( hyd_customizer_get_default_accenttext_color() !== $color_accenttext ) ? sprintf( '

.accent-text h1,
.front-page .accent-text h1 {
color: %1$s;
}

', $color_accenttext ) : '';


$css .= ( hyd_customizer_get_default_primarylink_color() !== $color_primarylink ) ? sprintf( '

.nav-primary .sub-menu a:hover,
.nav-secondary .sub-menu a:hover,
.site-header.light .nav-primary .sub-menu a:hover,
.site-header.light .nav-secondary .sub-menu a:hover,
a,
.name {
color: %1$s;
}

.woocommerce span.onsale {
background-color: %1$s !important;
}

.footer-widgets .simple-social-icons ul li a:hover,
.footer-widgets .simple-social-icons ul li a:focus,
.side-container .simple-social-icons ul li a:hover,
.side-container .simple-social-icons ul li a:focus,
.sidebar .simple-social-icons ul li a:hover,
.sidebar .simple-social-icons ul li a:focus {
color: %1$s !important;
border: 2px solid %1$s !important;
}

', $color_primarylink ) : '';


$css .= ( hyd_customizer_get_default_primaryhover_color() !== $color_primaryhover ) ? sprintf( '

.genesis-nav-menu .sub-menu a,
a:hover,
.description {
color: %1$s;
}

.woocommerce .woocommerce-message::before,
.woocommerce .woocommerce-info::before,
.woocommerce div.product p.price,
.woocommerce div.product span.price,
.woocommerce ul.products li.product .price,
.woocommerce form .form-row .required {
color: %1$s !important;
}

', $color_primaryhover ) : '';

$css .= ( hyd_customizer_get_default_portfolio_color() !== $color_portfolio ) ? sprintf( '


ul.filter a.active,
ul.filter a:hover {
background-color: %1$s;
}

', $color_portfolio ) : '';

$css .= ( hyd_customizer_get_default_enewsbackground_color() !== $color_footer ) ? sprintf( '


.sidebar .enews,
.side-container .enews-widget {
background: %1$s;
}

.widget-below-content .enews-widget input,
.footer-widgets .enews input#subbox {
border-bottom: 3px solid %1$s;
}

', $color_footer ) : '';

$css .= ( hyd_customizer_get_default_shareicons_color() !== $color_shareicons ) ? sprintf( '

.share-after::before,
.sharrre .share,
.sharrre:hover .share {
color: %1$s;
}

.content .share-filled .facebook .count,
.content .share-filled .facebook .count:hover,
.content .share-filled .googlePlus .count,
.content .share-filled .googlePlus .count:hover,
.content .share-filled .linkedin .count,
.content .share-filled .linkedin .count:hover,
.content .share-filled .pinterest .count,
.content .share-filled .pinterest .count:hover,
.content .share-filled .stumbleupon .count,
.content .share-filled .stumbleupon .count:hover,
.content .share-filled .twitter .count,
.content .share-filled .twitter .count:hover {
color: %1$s;
border: 1px solid %1$s;
}

.nc_socialPanel.swp_d_fullColor .googlePlus,
body .nc_socialPanel.swp_o_fullColor:hover .googlePlus,
html body .nc_socialPanel.swp_i_fullColor .googlePlus:hover,
.nc_socialPanel.swp_d_fullColor .twitter, body .nc_socialPanel.swp_o_fullColor:hover .twitter, html body .nc_socialPanel.swp_i_fullColor .twitter:hover,
.nc_socialPanel.swp_d_fullColor .swp_fb, body .nc_socialPanel.swp_o_fullColor:hover .swp_fb, html body .nc_socialPanel.swp_i_fullColor .swp_fb:hover,
.nc_socialPanel.swp_d_fullColor .linkedIn, body .nc_socialPanel.swp_o_fullColor:hover .linkedIn, html body .nc_socialPanel.swp_i_fullColor .linkedIn:hover,
.nc_socialPanel.swp_d_fullColor .nc_pinterest, body .nc_socialPanel.swp_o_fullColor:hover .nc_pinterest, html body .nc_socialPanel.swp_i_fullColor .nc_pinterest:hover,
.nc_socialPanel.swp_d_fullColor .swp_stumbleupon, body .nc_socialPanel.swp_o_fullColor:hover .swp_stumbleupon, html body .nc_socialPanel.swp_i_fullColor .swp_stumbleupon:hover {
background-color: %1$s !important;
}

', $color_shareicons ) : '';

$css .= ( hyd_customizer_get_default_socialicons_color() !== $color_socialicons ) ? sprintf( '

.sidebar .simple-social-icons ul li a,
.footer-widgets .simple-social-icons ul li a,
.site-footer .simple-social-icons ul li a,
.side-container .simple-social-icons ul li a  {
color: %1$s !important;
border: 2px solid %1$s !important;
}

', $color_socialicons ) : '';

$css .= ( hyd_customizer_get_default_button_color() !== $color_button ) ? sprintf( '

button,
input[type="button"],
input[type="reset"],
input[type="submit"],
.button,
.pricing-table a.button,
.front-page .home-welcome .button,
.front-page .soliloquy-container .soliloquy-caption a.soliloquy-button,
a.more-link,
.more-from-category a  {
background: %1$s;
border: 1px solid %1$s;
}

.circle-button,
.home-welcome .button {
border: 3px solid %1$s;
}

.circle-button {
color: %1$s;
}

.woocommerce #respond input#submit,
.woocommerce a.button,
.woocommerce button.home-grid,
.woocommerce input.button,
.woocommerce #respond input#submit.alt,
.woocommerce a.button.alt,
.woocommerce button.button.alt,
.woocommerce input.button.alt {
background: %1$s !important;
border: 1px solid %1$s !important;
}

.archive-pagination .active a {
border-bottom: 2px solid %1$s;
}

.enews-widget input[type="submit"] {
  background: %1$s !important;
  border: 1px solid %1$s !important;
}

', $color_button ) : '';

$css .= ( hyd_customizer_get_default_buttonhover_color() !== $color_buttonhover ) ? sprintf( '

button:hover,
input:hover[type="button"],
input:hover[type="reset"],
input:hover[type="submit"],
.button:hover,
.pricing-table a.button:hover,
.front-page .soliloquy-container .soliloquy-caption a.soliloquy-button:hover,
a.more-link:hover,
.more-from-category a:hover {
background: %1$s;
border: 1px solid %1$s;
}

.circle-button:hover,
.front-page .home-welcome .button:hover {
border: 3px solid %1$s;
background: %1$s;
}

.woocommerce #respond input#submit:hover,
.woocommerce a.button:hover,
.woocommerce button.button:hover,
.woocommerce input.button:hover,
.woocommerce #respond input#submit.alt:hover,
.woocommerce a.button.alt:hover,
.woocommerce button.button.alt:hover,
.woocommerce input.button.alt:hover  {
background-color: %1$s !important;
border: 1px solid %1$s !important;
}

.archive-pagination li a:hover {
border: 2px solid %1$s;
}

.previous,
.prev-next-navigation .next  {
border-bottom: 3px solid %1$s;
}

.enews-widget input[type="submit"]:hover {
  background: %1$s !important;
  border: 1px solid %1$s !important;
}

', $color_buttonhover ) : '';

$css .= ( hyd_customizer_get_default_totop_color() !== $color_totop ) ? sprintf( '

.to-top {
background-color: %1$s;
}

', $color_totop ) : '';

$css .= ( hyd_customizer_get_default_blueblock_color() !== $color_blueblock ) ? sprintf( '

.blueblock {
background: %1$s;
}

', $color_blueblock ) : '';

$css .= ( hyd_customizer_get_default_grayblock_color() !== $color_grayblock ) ? sprintf( '

.grayblock {
background: %1$s;
}

', $color_grayblock ) : '';
$css .= ( hyd_customizer_get_default_sidetab_color() !== $color_sidetab ) ? sprintf( '

.side-content button,
.side-content-icon button,
.side-content button:hover,
.side-content-icon button:hover {
background: %1$s;
}

', $color_sidetab ) : '';
$css .= ( hyd_customizer_get_default_sidetabicon_color() !== $color_sidetabicon ) ? sprintf( '

.side-content button,
.side-content-icon button,
.side-content button:hover,
.side-content-icon button:hover {
color: %1$s;
}

', $color_sidetabicon ) : '';

if( $css ){
wp_add_inline_style( $handle, $css );
}
}
