<?php

function hyd_customizer_get_default_smallnav_color() {
return '#cddfe6';
}
function hyd_customizer_get_default_smallnavlink_color() {
return '#222';
}
function hyd_customizer_get_default_navigation_color() {
return '#fff';
}
function hyd_customizer_get_default_navlink_color() {
return '#222';
}
function hyd_customizer_get_default_navhover_color() {
return '#b99d58';
}
function hyd_customizer_get_default_imagefont_color() {
return '#fff';
}
function hyd_customizer_get_default_homegrid_color() {
return '#fff';
}
function hyd_customizer_get_default_optin_color() {
return '#cddfe6';
}
function hyd_customizer_get_default_optinfont_color() {
return '#222';
}
function hyd_customizer_get_default_accenttext_color() {
return '#ddc885';
}
function hyd_customizer_get_default_button_color() {
return '#222';
}
function hyd_customizer_get_default_buttonhover_color() {
return '#cddfe6';
}
function hyd_customizer_get_default_primarylink_color() {
return '#b99d58';
}
function hyd_customizer_get_default_primaryhover_color() {
return '#cddfe6';
}
function hyd_customizer_get_default_portfolio_color() {
return '#ccc';
}
function hyd_customizer_get_default_enewsbackground_color() {
return '#cddfe6';
}
function hyd_customizer_get_default_shareicons_color() {
return '#cddfe6';
}
function hyd_customizer_get_default_socialicons_color() {
return '#222';
}
function hyd_customizer_get_default_totop_color() {
return '#cddfe6';
}
function hyd_customizer_get_default_blueblock_color() {
return '#cddfe6';
}
function hyd_customizer_get_default_grayblock_color() {
return '#f9f9f9';
}
function hyd_customizer_get_default_sidetab_color() {
return '#fff';
}
function hyd_customizer_get_default_sidetabicon_color() {
return '#b99d58';
}



add_action( 'customize_register', 'hyd_customizer_register' );
/**
* Register settings and controls with the Customizer.
*
* @since 1.0.0
*
* @param WP_Customize_Manager $wp_customize Customizer object.
*/
function hyd_customizer_register() {

/**
* Customize Background Image Control Class
*
* @package WordPress
* @subpackage Customize
* @since 3.4.0
*/
class Child_hyd_Image_Control extends WP_Customize_Image_Control {

/**
* Constructor.
*
* If $args['settings'] is not defined, use the $id as the setting ID.
*
* @since 3.4.0
* @uses WP_Customize_Upload_Control::__construct()
*
* @param WP_Customize_Manager $manager
* @param string $id
* @param array $args
*/
public function __construct( $manager, $id, $args ) {
$this->statuses = array( '' => __( 'No Image', 'hyd' ) );

parent::__construct( $manager, $id, $args );

$this->add_tab( 'upload-new', __( 'Upload New', 'hyd' ), array( $this, 'tab_upload_new' ) );
$this->add_tab( 'uploaded',   __( 'Uploaded', 'hyd' ),   array( $this, 'tab_uploaded' ) );

if ( $this->setting->default )
$this->add_tab( 'default',  __( 'Default', 'hyd' ),  array( $this, 'tab_default_background' ) );

// Early priority to occur before $this->manager->prepare_controls();
add_action( 'customize_controls_init', array( $this, 'prepare_control' ), 5 );
}

/**
* @since 3.4.0
* @uses WP_Customize_Image_Control::print_tab_image()
*/
public function tab_default_background() {
$this->print_tab_image( $this->setting->default );
}

}

global $wp_customize;

$images = apply_filters( 'hyd_images', array( '1', '2', '3', '4') );

$wp_customize->add_section( 'hyd-settings', array(
'description' => __( 'Customize the image sections on the homepage. Recommended Image size listed in Widget.', 'hyd' ),
'title'    => __( 'Image Sections', 'hyd' ),
'priority' => 35,
) );

foreach( $images as $image ){

$wp_customize->add_setting( $image .'-hyd-image', array(
'default'  => sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $image ),
'type'     => 'option',
) );

$wp_customize->add_control( new Child_hyd_Image_Control( $wp_customize, $image .'-hyd-image', array(
'label'    => sprintf( __( 'Image Section %s :', 'hyd' ), $image ),
'section'  => 'hyd-settings',
'settings' => $image .'-hyd-image',
'priority' => $image+1,
) ) );

}
$wp_customize->add_setting(
'hyd_smallnav_color',
array(
'default'           => hyd_customizer_get_default_smallnav_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_smallnavlink_color',
array(
'default'           => hyd_customizer_get_default_smallnavlink_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);

$wp_customize->add_setting(
'hyd_navigation_color',
array(
'default'           => hyd_customizer_get_default_navigation_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_navlink_color',
array(
'default'           => hyd_customizer_get_default_navlink_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_navhover_color',
array(
'default'           => hyd_customizer_get_default_navhover_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_imagefont_color',
array(
'default'           => hyd_customizer_get_default_imagefont_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_homegrid_color',
array(
'default'           => hyd_customizer_get_default_homegrid_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_optin_color',
array(
'default'           => hyd_customizer_get_default_optin_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_optinfont_color',
array(
'default'           => hyd_customizer_get_default_optinfont_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_accenttext_color',
array(
'default'           => hyd_customizer_get_default_accenttext_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_primarylink_color',
array(
'default'           => hyd_customizer_get_default_primarylink_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_primaryhover_color',
array(
'default'           => hyd_customizer_get_default_primaryhover_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_portfolio_color',
array(
'default'           => hyd_customizer_get_default_portfolio_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_enewsbackground_color',
array(
'default'           => hyd_customizer_get_default_enewsbackground_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_shareicons_color',
array(
'default'           => hyd_customizer_get_default_shareicons_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_socialicons_color',
array(
'default'           => hyd_customizer_get_default_socialicons_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_button_color',
array(
'default'           => hyd_customizer_get_default_button_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_buttonhover_color',
array(
'default'           => hyd_customizer_get_default_buttonhover_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_totop_color',
array(
'default'           => hyd_customizer_get_default_totop_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_blueblock_color',
array(
'default'           => hyd_customizer_get_default_blueblock_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_grayblock_color',
array(
'default'           => hyd_customizer_get_default_grayblock_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_sidetab_color',
array(
'default'           => hyd_customizer_get_default_sidetab_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_setting(
'hyd_sidetabicon_color',
array(
'default'           => hyd_customizer_get_default_sidetabicon_color(),
'sanitize_callback' => 'sanitize_hex_color',
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_smallnav_color',
array(
'description' => __( 'Change the default color for your Small Navigation.', 'hyd' ),
'label'       => __( 'Small Nav Bar', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_smallnav_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_smallnavlink_color',
array(
'description' => __( 'Change the default font color in the Small Nav.', 'hyd' ),
'label'       => __( 'Font Color Small Nav', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_smallnavlink_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_navigation_color',
array(
'description' => __( 'Change the default color for your primary navigation.', 'hyd' ),
'label'       => __( 'Navigation', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_navigation_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_navlink_color',
array(
'description' => __( 'Change the link color in the navigation', 'hyd' ),
'label'       => __( 'Navigation Link Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_navlink_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_navhover_color',
array(
'description' => __( 'Change the link hover color in the navigation', 'hyd' ),
'label'       => __( 'Navigation Hover Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_navhover_color',
)
)
);

$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_imagefont_color',
array(
'description' => __( 'Change the font color of the Image sections', 'hyd' ),
'label'       => __( 'Image Section font Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_imagefont_color',
)
)
);

$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_homegrid_color',
array(
'description' => __( 'Change the font and button color on the grid', 'hyd' ),
'label'       => __( 'Grid Font & Button Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_homegrid_color',
)
)
);

$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_optin_color',
array(
'description' => __( 'Change the Optin Color', 'hyd' ),
'label'       => __( 'Optin Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_optin_color',
)
)
);

$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_optinfont_color',
array(
'description' => __( 'Optin Font Color', 'hyd' ),
'label'       => __( 'Optin Font Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_optinfont_color',
)
)
);

$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_accenttext_color',
array(
'description' => __( 'Change the gold of the Accent Text', 'hyd' ),
'label'       => __( 'Accent Text', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_accenttext_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_portfolio_color',
array(
'description' => __( 'Change filter button color on the portfolio page', 'hyd' ),
'label'       => __( 'Portfolio Filter', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_portfolio_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_enewsbackground_color',
array(
'description' => __( 'Change the blue of the e-News optin', 'hyd' ),
'label'       => __( 'Enews Blue Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_enewsbackground_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_primarylink_color',
array(
'description' => __( 'Change the primary link color', 'hyd' ),
'label'       => __( 'Primary Link Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_primarylink_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_primaryhover_color',
array(
'description' => __( 'Change the sites primary hover color', 'hyd' ),
'label'       => __( 'Hover Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_primaryhover_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_shareicons_color',
array(
'description' => __( 'Change the color of the Share Icons on blog posts', 'hyd' ),
'label'       => __( 'Share Icons on Posts', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_shareicons_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_socialicons_color',
array(
'description' => __( 'Change the color of the social icons - Sidebar, Footer, in content', 'hyd' ),
'label'       => __( 'Social Icons', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_socialicons_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_button_color',
array(
'description' => __( 'Change the black button color', 'hyd' ),
'label'       => __( 'Button Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_button_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_buttonhover_color',
array(
'description' => __( 'Change the blue hover color', 'hyd' ),
'label'       => __( 'Button Hover Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_buttonhover_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_totop_color',
array(
'description' => __( 'Change the back to top button color', 'hyd' ),
'label'       => __( 'To Top Button Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_totop_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_blueblock_color',
array(
'description' => __( 'Change the blue block color', 'hyd' ),
'label'       => __( 'Blue Block Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_blueblock_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_grayblock_color',
array(
'description' => __( 'Change the gray block color', 'hyd' ),
'label'       => __( 'Gray Block Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_grayblock_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_sidetab_color',
array(
'description' => __( 'Change the Side Tab color', 'hyd' ),
'label'       => __( 'Side Tab Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_sidetab_color',
)
)
);
$wp_customize->add_control(
new WP_Customize_Color_Control(
$wp_customize,
'hyd_sidetabicon_color',
array(
'description' => __( 'Change the Side Tab icon color', 'hyd' ),
'label'       => __( 'Side Tab Icon Color', 'hyd' ),
'section'     => 'colors',
'settings'    => 'hyd_sidetabicon_color',
)
)
);
//* Add front page setting to the Customizer
$wp_customize->add_section( 'hyd_blog_section', array(
'title'    => __( 'Front Page Content Settings', 'hyd' ),
'description' => __( 'Choose if you would like to display the content section below widget sections on the front page.', 'hyd' ),
'priority' => 75.01,
));

//* Add front page setting to the Customizer
$wp_customize->add_setting( 'hyd_blog_setting', array(
'default'           => 'true',
'capability'        => 'edit_theme_options',
'type'              => 'option',
));

$wp_customize->add_control( new WP_Customize_Control(
$wp_customize, 'hyd_blog_control', array(
'label'       => __( 'Front Page Content Section Display', 'hyd' ),
'description' => __( 'Show or Hide the content section. The section will display on the front page by default.', 'hyd' ),
'section'     => 'hyd_blog_section',
'settings'    => 'hyd_blog_setting',
'type'        => 'select',
'choices'     => array(
'false'   => __( 'Hide content section', 'hyd' ),
'true'    => __( 'Show content section', 'hyd' ),
),
))
);

$wp_customize->add_setting( 'hyd_blog_text', array(
'default'           => __( 'New on the Blog', 'hyd' ),
'capability'        => 'edit_theme_options',
'sanitize_callback' => 'wp_kses_post',
'type'              => 'option',
));

$wp_customize->add_control( new WP_Customize_Control(
$wp_customize, 'hyd_blog_text_control', array(
'label'      => __( 'Blog Section Heading Text', 'hyd' ),
'description' => __( 'Choose the heading text you would like to display above posts on the front page.<br /><br />This text will show when displaying posts and using widgets on the front page.', 'hyd' ),
'section'    => 'hyd_blog_section',
'settings'   => 'hyd_blog_text',
'type'       => 'text',
))
);

}
