<?php
/**
* @package      Hello Beauty
* @link         https://helloyoudesigns.com
* @author       Hello You Designs
* @copyright    Copyright (c) 2017, Hello You Designs
* @license      GPL-2.0+
*/

//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Add Image upload and Color select to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Include Customizer CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'hyd_scripts_styles' );
function hyd_scripts_styles() {

wp_enqueue_style( 'hyd-google-fonts', '//fonts.googleapis.com/css?family=Montserrat:400,700|Poppins|Trirong', array());
wp_enqueue_style( 'ionicons', '//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css', array());
wp_enqueue_style( 'dashicons' );
wp_enqueue_script( 'global-script', get_bloginfo( 'stylesheet_directory' ) . '/js/nav.js', array( 'jquery' ), '1.0.0' );
wp_enqueue_script( 'localScroll', get_stylesheet_directory_uri() . '/js/jquery.localScroll.min.js', array( 'scrollTo' ), '1.2.8b', true );
wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );
wp_enqueue_script( 'hyd-fadeup-script', get_stylesheet_directory_uri() . '/js/fadeup.js', array( 'jquery' ), '1.0.0', true );
wp_enqueue_script( 'match-height', get_stylesheet_directory_uri() . '/js/jquery.matchHeight-min.js', array( 'jquery' ), '1.0.0', true );
wp_enqueue_script( 'match-height-init', get_stylesheet_directory_uri() . '/js/matchheight-init.js', array( 'match-height' ), '1.0.0', true );
}

// Load Font Awesome
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );
function enqueue_font_awesome() {
wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
}

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add new featured image size
add_image_size( 'featured-image', 1000, 1500, TRUE );
add_image_size( 'video-featured', 1000, 550, TRUE );


//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
'width'           => 700,
'height'          => 350,
'header-selector' => '.site-title a',
'header-text'     => false,
) );

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Rename menus
add_theme_support( 'genesis-menus', array(
'primary' => __( 'Left Navigation Menu', 'hyd' ),
'secondary' => __( 'Right Navigation Menu', 'hyd' ),
'small' => __( 'Small Menu', 'hyd' )
) );

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_header', 'genesis_do_nav', 12 );

remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_header', 'genesis_do_subnav', 12 );

//* Remove output of primary navigation right extras
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );

//* small Menu
add_action( 'genesis_before_header', 'hyd_small_menu', 7 );
function hyd_small_menu() {
echo '<div class="small-wrap">';
printf( '<nav %s>', genesis_attr( 'nav-small' ) );
wp_nav_menu( array(
'theme_location' => 'small',
'container'      => false,
'depth'          => 1,
'fallback_cb'    => false,
'menu_class'     => 'genesis-nav-menu',
) );
echo '</nav></div>';
}

//* Reduce the small navigation menu to one level depth
add_filter( 'wp_nav_menu_args', 'hyd_small_menu_args' );
function hyd_small_menu_args( $args ){
if( 'small' != $args['theme_location'] ){
return $args;
}
$args['depth'] = 1;
return $args;
}

//Add Fancy Search Box
add_action( 'wp_enqueue_scripts', 'custom_enqueue_scripts_styles' );
function custom_enqueue_scripts_styles() {
wp_enqueue_script( 'global', get_bloginfo( 'stylesheet_directory' ) . '/js/global.js', array( 'jquery' ), '1.0.0', true );
}

add_filter( 'wp_nav_menu_items', 'theme_menu_extras', 10, 2 );
function theme_menu_extras( $menu, $args ) {
if ( 'small' !== $args->theme_location )
return $menu;
$menu .= '<li class="search"><a id="main-nav-search-link" class="icon-search"></a><div class="search-div">' . get_search_form( false ) . '</div></li>';
return $menu;
}

//* Add widget to small navigation
add_filter( 'genesis_nav_items', 'hyd_social_icons', 9, 2 );
add_filter( 'wp_nav_menu_items', 'hyd_social_icons', 9, 2 );

function hyd_social_icons($menu, $args) {
$args = (array)$args;
if ( 'small' !== $args['theme_location'] )
return $menu;
ob_start();
genesis_widget_area('nav-social-menu');
$social = ob_get_clean();
return $menu . $social;
}

//* Remove the post date
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );

//* Relocate the post image
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 1 );

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'hyd_read_more_link' );
function hyd_read_more_link() {
return '... <a class="more-link" href="' . get_permalink() . '">READ <em>the</em> POST</a>';
}

//* Customize the video Output
remove_action( 'genesis_entry_content', 'gfv_video_image', 0 );
add_action( 'genesis_entry_header', 'gfv_video_image', 0 );

add_action( 'gfv_remove_post_image', 'hyd_remove_post_image' );
function hyd_remove_post_image(){
remove_action( 'genesis_entry_header', 'genesis_do_post_image', 1 );
}

add_action( 'gfv_add_post_image', 'hyd_add_post_image' );
function hyd_add_post_image(){
add_action( 'genesis_entry_header', 'genesis_do_post_image', 1 );
}

add_action( 'pre_get_posts', 'add_video_to_posts', 1 );
function add_video_to_posts() {
remove_action( 'pre_get_posts', 'gfv_hide_video_on_post', 10 ) ;
}


//* Setup widget counts
function hyd_count_widgets( $id ) {
global $sidebars_widgets;
if ( isset( $sidebars_widgets[ $id ] ) ) {
return count( $sidebars_widgets[ $id ] );
}
}

//* Flexible widget classes
function hyd_widget_area_class( $id ) {
$count = hyd_count_widgets( $id );
$class = '';
if( $count == 1 ) {
$class .= ' widget-full';
} elseif( $count % 3 == 1 ) {
$class .= ' widget-thirds';
} elseif( $count % 4 == 1 ) {
$class .= ' widget-fourths';
} elseif( $count % 2 == 0 ) {
$class .= ' widget-halves uneven';
} else {
$class .= ' widget-halves even';
}
return $class;
}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'hyd_comments_gravatar' );
function hyd_comments_gravatar( $args ) {
$args['avatar_size'] = 96;
return $args;
}

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'hyd_author_box_gravatar' );
function hyd_author_box_gravatar( $size ) {
return 150;
}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'hyd_remove_comment_form_allowed_tags' );
function hyd_remove_comment_form_allowed_tags( $defaults ) {
$defaults['comment_notes_after'] = '';
return $defaults;
}

//* Hooks Widget Area below Content
add_action( 'genesis_after_content', 'hyd_widget_below_content'  );
function hyd_widget_below_content() {
if ( ! is_front_page() ) {
genesis_widget_area( 'widget-below-content', array(
'before' => '<div class="widget-below-content widget-area"><div class="wrap">',
'after'  => '</div></div>',
) );

}}

//* Genesis Previous/Next Post Post Navigation
add_action( 'genesis_entry_footer', 'hyd_prev_next_post_nav' );
function hyd_prev_next_post_nav() {
if ( is_single() ) {
echo '<div class="prev-next-navigation">';
previous_post_link( '<div class="previous">%link</div>', 'Previous' );
next_post_link( '<div class="next">%link</div>', 'Next' );
echo '</div><!-- .prev-next-navigation -->';
}
}

//* Edit width of tiled gallery
if ( ! isset( $content_width ) )
$content_width = 1100;


//* Customize the entire footer
remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'genesis_footer', 'hyd_custom_footer' );
function hyd_custom_footer() {

if(is_active_sidebar('social-footer')){
echo '<div class="social-footer">';
dynamic_sidebar('social-footer');
echo '</div>';
}
echo '<div class="creds"><p>';
echo 'Copyright &copy; ';
echo date('Y');
echo ' &middot; ';
echo get_bloginfo( 'name' );
echo ' &middot; <a target="_blank" href="https://helloyoudesigns.com">Hello You Designs</a>';
echo '</p></div>';

}

// Add To Top button
add_action( 'genesis_before', 'genesis_to_top');
function genesis_to_top() {
echo '<a href="#0" class="to-top" title="Back To Top">Top</a>';
}

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Add Gallery Support for WooCommerce

add_action( 'after_setup_theme', 'hyd_setup' );
function hyd_setup() {
add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );
}

//* Remove Related Products
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Change number or products per row to 3
add_filter( 'loop_shop_per_page', 'new_loop_shop_per_page', 20 );
function new_loop_shop_per_page( $cols ) {
$cols = 9;
return $cols;
}

add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
function loop_columns() {
return 3; // 3 products per row
}
}

//* Add walker class that displays menu item descriptions
function be_add_description( $item_output, $item ) {
$description = $item->post_content;
if (' ' !== $description )
return preg_replace( '/(<a.*?>[^<]*?)</', '$1' . '<span class="sub">' . $description . '</span><', $item_output);
else
return $item_output;
}
add_filter( 'walker_nav_menu_start_el', 'be_add_description', 10, 2 );

add_filter('widget_text', 'do_shortcode');


//* Hooks widget area before footer
add_action( 'genesis_before_footer', 'hyd_social_bar');
function hyd_social_bar() {{
genesis_widget_area( 'social-bar', array(
'before' => '<div class="social-bar widget-area"><div class="social-wrap">',
'after'  => '</div></div>',
) );
}}

//* Hook after post widget after the entry content
add_action( 'genesis_after_entry_content', 'hyd_signature', 10 );
function hyd_signature() {
if ( is_singular( 'post' ) )
genesis_widget_area( 'signature', array(
'before' => '<div class="signature widget-area">',
'after'  => '</div>',
) );
}

//* Adds custom excerpt field for the reward style addition
add_post_type_support('post', 'excerpt');
add_action ( 'genesis_after_entry_content', 'hyd_show_page_excerpt' );
function hyd_show_page_excerpt() {
$post = get_post( get_the_ID() );
$the_excerpt = $post->post_excerpt;
if ( is_page() || empty( $the_excerpt ) )
return;
echo $the_excerpt;
}

/*
Adds an affiliate disclaimer
--------------------------------------- */
add_action( 'genesis_before_entry_content', 'function_name', 12 );
function function_name() {
    $value = get_post_meta( get_the_ID(), 'affiliate', true );
      if ( ! empty( $value ) ) {
    echo '<div class="hyd-affiliate">'. $value .'</div>';
    }
}

//* Add side content if active
add_action( 'genesis_after_header', 'hyd_side_content_output' );
function hyd_side_content_output() {
$button = '<button class="side-content-toggle"><i class="icon ion-ios-close-empty"></i> <span class="screen-reader-text">' . __( 'Hide side Content', 'hyd' ) . '</span></button>';
if ( is_active_sidebar( 'side-content' ) ) {
echo '<div class="side-content-icon"><button class="side-content-toggle"><i class="icon ion-arrow-right-c"></i> <span class="screen-reader-text">' . __( 'Show side Content', 'hyd' ) . '</span></button></div>';
}
genesis_widget_area( 'side-content', array(
'before' => '<div class="side-content"><div class="side-container"><div class="widget-area">' . $button . '<div class="wrap">',
'after'  => '</div></div></div></div>'
));
}

//* Register widget areas

genesis_register_sidebar( array(
'id'            => 'home-full',
'name'          => __( 'Full Width', 'hyd' ),
'description'   => __( 'This is a full width Image Section above the home grid - 2000pxW x 800pxH or taller', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'            => 'home-one',
'name'          => __( 'Home Grid 1', 'hyd' ),
'description'   => __( 'Grid section 1 - Image 650pxW x 1000pxH', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'          => 'home-two',
'name'        => __( 'Home Grid 2', 'hyd' ),
'description' => __( 'Grid Section 2 -2 Images 700pxW x 500pxH or 1 700pxW x 1000pxW', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'           => 'home-three',
'name'         => __( 'Home Grid 3', 'hyd' ),
'description'  => __( 'Grid Section 3 - Image 650pxW x 1000pxH', 'hyd' ),
) );
genesis_register_sidebar( array(
	'id'           => 'home-optin',
	'name'         => __( 'Home Optin', 'hyd' ),
	'description'  => __( 'This is the Optin section on the homepage', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'            => 'home-flexible',
'name'          => __( 'Home Flexible', 'hyd' ),
'description'   => __( 'Solid white section below the home grid.  - Flexible Layout', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'           => 'image-section-1',
'name'         => __( 'Image Section 1', 'hyd' ),
'description'  => __( 'This is the first image section.  Change the image in the customizer. 2000x1080px', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'           => 'home-welcome',
'name'         => __( 'Home Welcome', 'hyd' ),
'description'  => __( 'This is the home Welcome widget area on the home page. - Image size 1000pxW x 1000pxH or taller', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'			=> 'home-split-1',
'name'			=> 'Split 1',
'description'	=> 'Chang Image 2 in Customizer - Size 2000pxW by 1000pxH'
) );
genesis_register_sidebar( array(
'id'			=> 'home-split-2',
'name'			=> 'Split 2',
'description'	=> 'Chang Image 3 in Customizer - Size 2000pxW by 1000pxH'
) );
genesis_register_sidebar( array(
'id'          => 'home-flexible-2',
'name'        => __( 'Home Flexible-2', 'hyd' ),
'description' => __( 'Flexible Widget Area', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'           => 'image-section-4',
'name'         => __( 'Image Section 4', 'hyd' ),
'description'  => __( 'This is second full width image section.  Change Image 4 in the customizer. 2000x1080px', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'          => 'home-close',
'name'        => __( 'Home Close', 'hyd' ),
'description' => __( 'This is the last white section before the blog/footer on the homepage', 'hyd' ),
) );

genesis_register_sidebar( array(
'id'            => 'widget-below-content',
'name'          => __( 'Widget Below Content', 'hyd' ),
'description'   => __( 'This widget area appears below the content on interior pages and posts.', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'			=> 'blog-slider',
'name'			=> __( 'Blog Slider', 'hyd' ),
'description'	=> __( 'Slider on Blog Template', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'			=> 'blog-featured',
'name'			=> __( 'Blog Featured', 'hyd' ),
'description'	=> __( 'Feature your posts, or pages - 1/3rd widgets', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'          => 'signature',
'name'        => __( 'Signature', 'hyd' ),
'description' => __( 'This is the signature bar that shows under each post.', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'			=> 'portfolioblurb',
'name'			=> __( 'Portfolio Blurb', 'hyd' ),
'description'	=> __( 'Add a CTA or other message to your Portfolio Archive page.', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'          	=> 'nav-social-menu',
'name'        	=> __( 'Top Social Menu', 'hyd' ),
'description' 	=> __( 'Add social icons to the small menu bar', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'          => 'social-bar',
'name'        => __( 'Social Bar', 'hyd' ),
'description' => __( 'This is the full width Social Bar below the footer.', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'			=> 'social-footer',
'name'			=> __( 'Site Credits Widget', 'hyd' ),
'description'	=> __( 'Add social icons, a custom menu, or even a short blurb to the left of the site credits', 'hyd' ),
) );
genesis_register_sidebar( array(
'id'          => 'side-content',
'name'        => __( 'Side Widget', 'hyd' ),
'description' => __( 'This is the side widget.  Add an optin, social icons, or an important message', 'hyd' ),
) );
