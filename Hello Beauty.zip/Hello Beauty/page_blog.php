<?php
/**
* @package      Hello Beauty
* @link         https://helloyoudesigns.com
* @author       Hello You Designs
* @copyright    Copyright (c) 2017, Hello You Designs
* @license      GPL-2.0+
*/

/*
Template Name: Blog Page
*/

//* Add the blog slider widget
add_action( 'genesis_before_content', 'hyd_blog_slider_before_content', 5 );
function hyd_blog_slider_before_content() {
	if ( get_query_var( 'paged' ) >= 1 )
		return;
	genesis_widget_area( 'blog-slider', array(
	'before' => '<div class="blog-slider">',
	'after'  => '</div>',
	) );
}

//* Add blog featured section
add_action( 'genesis_before_content', 'hyd_blog_featured_before_content', 6 );
function hyd_blog_featured_before_content() {
	if ( get_query_var( 'paged' ) >= 1 )
		return;
	genesis_widget_area( 'blog-featured', array(
	'before' => '<div id="blog-featured">',
	'after'  => '</div>',
	) );
}





genesis();
