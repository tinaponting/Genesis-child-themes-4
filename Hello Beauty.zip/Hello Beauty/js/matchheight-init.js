jQuery(function( $ ){

	$('.hyd-archive .content .entry, .front-page .content .entry, .journal .entry, .category-index .featured-content .entry, .footer-widgets-1 .widget, .footer-widgets-3 .widget, .woocommerce ul.cart_list li, .woocommerce ul.product_list_widget li, .woocommerce ul.products li.product, .woocommerce-page ul.products li.product, .image-section-2 .widget-area, .image-section-3 .widget-area').matchHeight();

});
