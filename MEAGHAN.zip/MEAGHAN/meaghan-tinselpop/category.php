<?php

/**
* @package Hello Beautiful
* @author  TinselPop
* @license GPL-2.0+
* @link    http://www.tinselpop.com/
*/








//* Run the Genesis loop
genesis();