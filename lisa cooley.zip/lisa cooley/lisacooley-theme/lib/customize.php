<?php
/**
 * WAT Design Express.
 *
 * This file adds the Customizer.
 *
 * @author  WAT Design Express
 * @link    http://www.watdesignexpress.com/
 */

add_action( 'customize_register', 'wat_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 2.2.3
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function wat_customizer_register( $wp_customize ) {
// Color
	$wp_customize->add_section( 'wat_color_section' , array(
   		'title'      => 'Custom Colors',
   		'description'=> 'Change the color of certain elements like texts, text links, hover color of linked titles, hover color of menu items, etc.'
	) );
	// Body
	$wp_customize->add_setting(
		'background_color',
		array(
			'default'           => '#FFFFFF'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'background_color',
			array(
				'label'       => 'Body Color',
				'section'     => 'wat_color_section',
				'settings'    => 'background_color',
			)
		)
	);
	//Slider background color
	$wp_customize->add_setting(
		'slider_bg_color',
		array(
			'default'           => '#e2e2e1'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'slider_bg_color',
			array(
				'label'       => 'Slider Background Color',
				'section'     => 'wat_color_section',
				'settings'    => 'slider_bg_color',
			)
		)
	);
	//Text color
	$wp_customize->add_setting(
		'text_color',
		array(
			'default'           => '#242323'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'text_color',
			array(
				'label'       => 'Text Color',
				'section'     => 'wat_color_section',
				'settings'    => 'text_color',
			)
		)
	);
	//Sub text color
	$wp_customize->add_setting(
		'sub_text_color',
		array(
			'default'           => '#5D5C5C'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'sub_text_color',
			array(
				'label'       => 'Sub Text Color',
				'section'     => 'wat_color_section',
				'settings'    => 'sub_text_color',
			)
		)
	);
	//Top menu background color
	$wp_customize->add_setting(
		'top_menu_background_color',
		array(
			'default'           => '#F7F6F6'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'top_menu_background_color',
			array(
				'label'       => 'Top Nav Bar Background Color',
				'section'     => 'wat_color_section',
				'settings'    => 'top_menu_background_color',
			)
		)
	);

	//Top menu text color
	$wp_customize->add_setting(
		'top_menu_text_color',
		array(
			'default'           => '#333'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'top_menu_text_color',
			array(
				'label'       => 'Top Nav Bar Text Color',
				'section'     => 'wat_color_section',
				'settings'    => 'top_menu_text_color',
			)
		)
	);
	//Top menu background hover color
	$wp_customize->add_setting(
		'top_menu_hover_background_color',
		array(
			'default'           => '#95A787'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'top_menu_hover_background_color',
			array(
				'label'       => 'Top Nav Bar Hover Color',
				'section'     => 'wat_color_section',
				'settings'    => 'top_menu_hover_background_color',
			)
		)
	);
	
	//Top menu text hover color
	$wp_customize->add_setting(
		'top_menu_hover_text_color',
		array(
			'default'           => '#fff'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'top_menu_hover_text_color',
			array(
				'label'       => 'Top Nav Bar Text Hover Color',
				'section'     => 'wat_color_section',
				'settings'    => 'top_menu_hover_text_color',
			)
		)
	);
	//Text link color
	$wp_customize->add_setting(
		'text_link_color',
		array(
			'default'           => '#242323'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'text_link_color',
			array(
				'label'       => 'Text Link Color',
				'section'     => 'wat_color_section',
				'settings'    => 'text_link_color',
			)
		)
	);	

	//Text link hover color
	$wp_customize->add_setting(
		'text_link_hover_color',
		array(
			'default'           => '#95A787'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'text_link_hover_color',
			array(
				'label'       => 'Text Link Hover Color',
				'section'     => 'wat_color_section',
				'settings'    => 'text_link_hover_color',
			)
		)
	);	
	//Button background color
	$wp_customize->add_setting(
		'button_background_color',
		array(
			'default'           => '#fff'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'button_background_color',
			array(
				'label'       => 'Button Background Color',
				'section'     => 'wat_color_section',
				'settings'    => 'button_background_color',
			)
		)
	);
	//Button text color
	$wp_customize->add_setting(
		'button_text_color',
		array(
			'default'           => '#95A787'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'button_text_color',
			array(
				'label'       => 'Button Text Color',
				'section'     => 'wat_color_section',
				'settings'    => 'button_text_color',
			)
		)
	);
	//Button hover background color
	$wp_customize->add_setting(
		'button_hover_background_color',
		array(
			'default'           => '#95A787'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'button_hover_background_color',
			array(
				'label'       => 'Button Hover Background Color',
				'section'     => 'wat_color_section',
				'settings'    => 'button_hover_background_color',
			)
		)
	);
	//Button text color
	$wp_customize->add_setting(
		'button_hover_text_color',
		array(
			'default'           => '#fff'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'button_hover_text_color',
			array(
				'label'       => 'Button Hover Text Color',
				'section'     => 'wat_color_section',
				'settings'    => 'button_hover_text_color',
			)
		)
	);
	//Footer background color
	$wp_customize->add_setting(
		'footer_background_color',
		array(
			'default'           => '#F7F6F6'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_background_color',
			array(
				'label'       => 'Footer Background Color',
				'section'     => 'wat_color_section',
				'settings'    => 'footer_background_color',
			)
		)
	);
	//Footer text color
	$wp_customize->add_setting(
		'footer_text_color',
		array(
			'default'           => '#242323'
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'footer_text_color',
			array(
				'label'       => 'Footer Text Color',
				'section'     => 'wat_color_section',
				'settings'    => 'footer_text_color',
			)
		)
	);	
// Header banner section
	$wp_customize->add_section( 'wat_header_banner_section' , array(
   		'title'      => 'Header Background Image',
   		'description'=> 'This is the background image of your header, not your logo.',
   		'priority'   => 3,
	) );
	$wp_customize->add_setting(
        'banner_set'  ,
		array( 'default' => '',
		'sanitize_callback' => 'esc_url_raw' ,
		)
    );
    $wp_customize->add_setting(
        'margin_top_set'  ,
		array( 'default' => '3',
		'sanitize_callback' => 'wat_sanitize_number' ,
		)
    );	
    $wp_customize->add_setting(
        'margin_bottom_set'  ,
		array( 'default' => '3',
		'sanitize_callback' => 'wat_sanitize_number' ,
		)
    );
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'banner_set',
			array(
				'label'      => 'Upload background image to the header',
				'section'    => 'wat_header_banner_section',
				'settings'   => 'banner_set',
				'priority'	 => 1
			)
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'margin_bottom_set',
			array(
				'label'      => 'Specify logo bottom margin (%)',
				'section'    => 'wat_header_banner_section',
				'settings'   => 'margin_bottom_set',
				'type' 		 => 'text',
				'priority'	 => 3
			)
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'margin_top_set',
			array(
				'label'      => 'Specify logo top margin (%)',
				'section'    => 'wat_header_banner_section',
				'settings'   => 'margin_top_set',
				'type' 		 => 'text',
				'priority'	 => 2
			)
		)
	);
// General Settings
	$wp_customize->add_section( 'wat_general_section' , array(
   		'title'      => 'General Settings',
   		'description'=> '',
	) );
	$wp_customize->add_setting(
		'sticky_menu_set',
		array(
			'default' => 'none' ,
		)
	);	
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'sticky_menu_set',
			array(
				'label'          => 'Sticky menu options',
				'section'        => 'wat_general_section',
				'settings'       => 'sticky_menu_set',
				'type'           => 'radio',
				'priority'	 => 1,
				'choices'        => array(
					'none'	=> 'None',
					'primary'   => 'Primary Menu',
					'secondary'  => 'Secondary Menu',
				)
			)
		)
	);
	$wp_customize->add_setting(
		'readmore_set',
		array(
			'default' => 'Read more »' ,
			'sanitize_callback' => 'wat_sanitize_text',
		)
	);
	$wp_customize->add_setting(
		'featured_img_set',
		array(
			'default' => 'disable' ,
		)
	);
	$wp_customize->add_setting(
		'copyright_set',
		array(
			'default' => 'COPYRIGHT © 2018' ,
			'sanitize_callback' => 'wat_sanitize_text',
		)
	);	
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'featured_img_set',
			array(
				'label'          => 'Display featured image on single post',
				'section'        => 'wat_general_section',
				'settings'       => 'featured_img_set',
				'type'           => 'radio',
				'priority'	 => 2,
				'choices'        => array(
					'enable'	=> 'Enable',
					'disable'   => 'Disable',
				)
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'readmore_set',
			array(
				'label'      => 'Change your "Read More" text',
				'section'    => 'wat_general_section',
				'settings'   => 'readmore_set',
				'type'		 => 'text',
				'priority'	 => 3
			)
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'copyright_set',
			array(
				'label'      => 'Change your footer credit',
				'section'    => 'wat_general_section',
				'settings'   => 'copyright_set',
				'type'		 => 'text',
				'priority'	 => 4
			)
		)
	);		
// Homepage Settings
	$wp_customize->add_section( 'wat_homepage_section' , array(
   		'title'      => 'Homepage Settings',
   		'description'=> 'This is where to customize your homepage. Open the homepage if you want to see the changes live in action.',
	) );
   	$wp_customize->add_setting(
        'homepage_blog_set',
        array(
            'default'     => 'enable' ,
        )
    );
   	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'homepage_blog_set',
			array(
				'label'          => 'Display posts on Homepage',
				'section'        => 'wat_homepage_section',
				'settings'       => 'homepage_blog_set',
				'type'           => 'radio',
				'priority'	 => 1,
				'choices'        => array(
					'enable'  => 'Enable',
		        	'disable'   => 'Disable',
				)
			)
		)
	);
	$wp_customize->add_setting(
        'homepage_layout_set',
        array(
            'default'     => 'content-sidebar' ,
            'sanitize_callback' => 'wat_sanitize_layout_placement',
        )
    );
	$wp_customize->add_setting(
		'homepage_numpost_set',
		array(
			'default' => '9' ,
			'sanitize_callback' => 'wat_sanitize_number',
		)
	);
	$wp_customize->add_setting(
        'homepage_hide_text_grid_set',
        array(
            'default'     => false ,
            'sanitize_callback' => 'wat_sanitize_checkbox',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'homepage_layout_set',
			array(
				'label'          => 'Homepage Layout Options',
				'section'        => 'wat_homepage_section',
				'settings'       => 'homepage_layout_set',
				'type'           => 'radio',
				'priority'	 => 2,
				'choices'        => array(
					'full-width'  => 'Full Width',
		        	'content-sidebar'   => 'Content/Sidebar',
		        	'sidebar-content'   => 'Sidebar/Content',
				)
			)
		)
	);

	$wp_customize->add_setting(
        'homepage_content_style_firstpost_set',
        array(
            'default'     => 'excerpt' ,
            'sanitize_callback' => 'wat_sanitize_content_style_firstpost',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'homepage_content_style_firstpost_set',
			array(
				'label'          => 'Content Style For The First Post Options',
				'section'        => 'wat_homepage_section',
				'settings'       => 'homepage_content_style_firstpost_set',
				'type'           => 'radio',
				'priority'	 => 3,
				'choices'        => array(
    				'as-following-posts'   => 'As following posts',					
					'full'   => 'Full post',
					'excerpt'  => 'Excerpt',
    				'list'   => 'List',
				)
			)
		)
	);

	$wp_customize->add_setting(
        'homepage_content_style_followingposts_set',
        array(
            'default'     => 'excerpt' ,
            'sanitize_callback' => 'wat_sanitize_content_style_followingposts',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'homepage_content_style_followingposts_set',
			array(
				'label'          => 'Content Style For Following Posts Options',
				'section'        => 'wat_homepage_section',
				'settings'       => 'homepage_content_style_followingposts_set',
				'type'           => 'radio',
				'priority'	 => 4,
				'choices'        => array(
					'full'   => 'Full',
					'excerpt'  => 'Excerpt',
    				'list'   => 'List',
    				'grid'   => 'Grid'
				)
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'homepage_hide_text_grid_set',
			array(
				'label'      => 'Hide excerpts of posts in grid style',
				'section'    => 'wat_homepage_section',
				'settings'   => 'homepage_hide_text_grid_set',
				'type'		 => 'checkbox',
				'priority'	 => 5,
			)
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'homepage_numpost_set',
			array(
				'label'      => 'Number of posts per page',
				'section'    => 'wat_homepage_section',
				'settings'   => 'homepage_numpost_set',
				'type'		 => 'text',
				'priority'	 => 6,
			)
		)
	);

// Category Settings
	$wp_customize->add_section( 'wat_category_section' , array(
   		'title'      => 'Category Settings',
   		'description'=> 'This is where to customize your category page. Open any category page if you want to see the changes live in action.',
	) );

	$wp_customize->add_setting(
        'category_layout_set',
        array(
            'default'     => 'content-sidebar' ,
            'sanitize_callback' => 'wat_sanitize_layout_placement',
        )
    );
	$wp_customize->add_setting(
		'category_numpost_set',
		array(
			'default' => '9' ,
			'sanitize_callback' => 'wat_sanitize_number',
		)
	);
	$wp_customize->add_setting(
        'category_hide_text_grid_set',
        array(
            'default'     => false ,
            'sanitize_callback' => 'wat_sanitize_checkbox',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'category_layout_set',
			array(
				'label'          => 'Category Layout Options',
				'section'        => 'wat_category_section',
				'settings'       => 'category_layout_set',
				'type'           => 'radio',
				'priority'	 => 1,
				'choices'        => array(
					'full-width'  => 'Full Width',
		        	'content-sidebar'   => 'Content/Sidebar',
		        	'sidebar-content'   => 'Sidebar/Content',
				)
			)
		)
	);
	
	$wp_customize->add_setting(
        'category_content_style_firstpost_set',
        array(
            'default'     => 'excerpt' ,
            'sanitize_callback' => 'wat_sanitize_content_style_firstpost',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'category_content_style_firstpost_set',
			array(
				'label'          => 'Content Style For The First Post Options',
				'section'        => 'wat_category_section',
				'settings'       => 'category_content_style_firstpost_set',
				'type'           => 'radio',
				'priority'	 => 2,
				'choices'        => array(
    				'as-following-posts'   => 'As following posts',					
					'full'   => 'Full post',
					'excerpt'  => 'Excerpt',
    				'list'   => 'List',
				)
			)
		)
	);

	$wp_customize->add_setting(
        'category_content_style_followingposts_set',
        array(
            'default'     => 'excerpt' ,
            'sanitize_callback' => 'wat_sanitize_content_style_followingposts',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'category_content_style_followingposts_set',
			array(
				'label'          => 'Content Style For Following Posts Options',
				'section'        => 'wat_category_section',
				'settings'       => 'category_content_style_followingposts_set',
				'type'           => 'radio',
				'priority'	 => 3,
				'choices'        => array(
					'full'   => 'Full',
					'excerpt'  => 'Excerpt',
    				'list'   => 'List',
    				'grid'   => 'Grid'
				)
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'category_hide_text_grid_set',
			array(
				'label'      => 'Hide excerpts of posts in grid style',
				'section'    => 'wat_category_section',
				'settings'   => 'category_hide_text_grid_set',
				'type'		 => 'checkbox',
				'priority'	 => 4,
			)
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'category_numpost_set',
			array(
				'label'      => 'Number of posts per page',
				'section'    => 'wat_category_section',
				'settings'   => 'category_numpost_set',
				'type'		 => 'text',
				'priority'	 => 3
			)
		)
	);
// Archives Settings
	$wp_customize->add_section( 'wat_archives_section' , array(
   		'title'      => 'Archives Settings',
   		'description'=> 'This is where to customize your archive page. Open any archive page if you want to see changes live in action.',
	) );

	$wp_customize->add_setting(
        'archives_layout_set',
        array(
            'default'     => 'content-sidebar' ,
            'sanitize_callback' => 'wat_sanitize_layout_placement',
        )
    );

	$wp_customize->add_setting(
		'archives_numpost_set',
		array(
			'default' => '9' ,
			'sanitize_callback' => 'wat_sanitize_number',
		)
	);

	$wp_customize->add_setting(
        'archives_hide_text_grid_set',
        array(
            'default'     => false ,
            'sanitize_callback' => 'wat_sanitize_checkbox',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'archives_layout_set',
			array(
				'label'          => 'Archives Layout Options',
				'section'        => 'wat_archives_section',
				'settings'       => 'archives_layout_set',
				'type'           => 'radio',
				'priority'	 => 1,
				'choices'        => array(
					'full-width'  => 'Full Width',
		        	'content-sidebar'   => 'Content/Sidebar',
		        	'sidebar-content'   => 'Sidebar/Content',
				)
			)
		)
	);

	$wp_customize->add_setting(
        'archives_content_style_firstpost_set',
        array(
            'default'     => 'excerpt' ,
            'sanitize_callback' => 'wat_sanitize_content_style_firstpost',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'archives_content_style_firstpost_set',
			array(
				'label'          => 'Content Style For The First Post Options',
				'section'        => 'wat_archives_section',
				'settings'       => 'archives_content_style_firstpost_set',
				'type'           => 'radio',
				'priority'	 => 2,
				'choices'        => array(
    				'as-following-posts'   => 'As following posts',					
					'full'   => 'Full post',
					'excerpt'  => 'Excerpt',
    				'list'   => 'List',
				)
			)
		)
	);

	$wp_customize->add_setting(
        'archives_content_style_followingposts_set',
        array(
            'default'     => 'excerpt' ,
            'sanitize_callback' => 'wat_sanitize_content_style_followingposts',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'archives_content_style_followingposts_set',
			array(
				'label'          => 'Content Style For Following Posts Options',
				'section'        => 'wat_archives_section',
				'settings'       => 'archives_content_style_followingposts_set',
				'type'           => 'radio',
				'priority'	 => 3,
				'choices'        => array(
					'full'   => 'Full',
					'excerpt'  => 'Excerpt',
    				'list'   => 'List',
    				'grid'   => 'Grid'
				)
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'archives_hide_text_grid_set',
			array(
				'label'      => 'Hide excerpts of posts in grid style',
				'section'    => 'wat_archives_section',
				'settings'   => 'archives_hide_text_grid_set',
				'type'		 => 'checkbox',
				'priority'	 => 4,
			)
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'archives_numpost_set',
			array(
				'label'      => 'Number of posts per page',
				'section'    => 'wat_archives_section',
				'settings'   => 'archives_numpost_set',
				'type'		 => 'text',
				'priority'	 => 3
			)
		)
	);
// Blog Page Settings
	$wp_customize->add_section( 'wat_blog_section' , array(
   		'title'      => 'Blog Page Settings',
   		'description'=> 'These settings apply to any page that uses the "Blog" page template, except the homepage and post archive pages.',
	) );
	$wp_customize->add_setting(
		'blog_numpost_set',
		array(
			'default' => '9' ,
			'sanitize_callback' => 'wat_sanitize_number',
		)
	);
	$wp_customize->add_setting(
        'blog_content_style_firstpost_set',
        array(
            'default'     => 'excerpt' ,
            'sanitize_callback' => 'wat_sanitize_content_style_firstpost',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'blog_content_style_firstpost_set',
			array(
				'label'          => 'Content Style For The First Post Options',
				'section'        => 'wat_blog_section',
				'settings'       => 'blog_content_style_firstpost_set',
				'type'           => 'radio',
				'priority'	 => 1,
				'choices'        => array(
    				'as-following-posts'   => 'As following posts',					
					'full'   => 'Full post',
					'excerpt'  => 'Excerpt',
    				'list'   => 'List',
				)
			)
		)
	);

	$wp_customize->add_setting(
        'blog_content_style_followingposts_set',
        array(
            'default'     => 'excerpt' ,
            'sanitize_callback' => 'wat_sanitize_content_style_followingposts',
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'blog_content_style_followingposts_set',
			array(
				'label'          => 'Content Style For Following Posts Options',
				'section'        => 'wat_blog_section',
				'settings'       => 'blog_content_style_followingposts_set',
				'type'           => 'radio',
				'priority'	 => 2,
				'choices'        => array(
					'full'   => 'Full',
					'excerpt'  => 'Excerpt',
    				'list'   => 'List',
    				'grid'   => 'Grid'
				)
			)
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control(
			$wp_customize,
			'blog_numpost_set',
			array(
				'label'      => 'Number of posts per page',
				'section'    => 'wat_blog_section',
				'settings'   => 'blog_numpost_set',
				'type'		 => 'text',
				'priority'	 => 3
			)
		)
	);
// Parallax Setting
	$wp_customize->add_section( 'section_parallax' , array(
		'title'      => 'Parallax Settings',
		'description'=> '',
	) );

	// Settings parallax front 1
		$wp_customize->add_setting(
	        'parallax_style_wat_1',
	        array(
	            'default'     => 'none' ,
	        )
	    );

	// Parallax Effect front 1
		$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'parallax_style_wat',
				array(
					'label'          => 'Parallax effect - Front Page 1',
					'section'        => 'section_parallax',
					'settings'       => 'parallax_style_wat_1',
					'type'           => 'select',
					'priority'	 => 1,
					'choices'        => array(
						'none'  => 'None',
        				'translate'   => 'Fade in up',
        				'rotate'   => 'Rotate',
        				'scale'   => 'Scale',
					)
				)
			)
		);
	// Settings parallax front 2
		$wp_customize->add_setting(
	        'parallax_style_wat_2',
	        array(
	            'default'     => 'none' ,
	        )
	    );

	// Parallax Effect front 2
		$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'parallax_style_wat_2',
				array(
					'label'          => 'Parallax effect - Front Page 2',
					'section'        => 'section_parallax',
					'settings'       => 'parallax_style_wat_2',
					'type'           => 'select',
					'priority'	 => 2,
					'choices'        => array(
						'none'  => 'None',
        				'translate'   => 'Fade in up',
        				'rotate'   => 'Rotate',
        				'scale'   => 'Scale',
					)
				)
			)
		);		

	// Settings parallax front 3
		$wp_customize->add_setting(
	        'parallax_style_wat_3',
	        array(
	            'default'     => 'none' ,
	        )
	    );

	// Parallax Effect front 3
		$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'parallax_style_wat_3',
				array(
					'label'          => 'Parallax effect - Front Page 3',
					'section'        => 'section_parallax',
					'settings'       => 'parallax_style_wat_3',
					'type'           => 'select',
					'priority'	 => 3,
					'choices'        => array(
						'none'  => 'None',
        				'translate'   => 'Fade in up',
        				'rotate'   => 'Rotate',
        				'scale'   => 'Scale',
					)
				)
			)
		);	
	// Settings parallax front 4
		$wp_customize->add_setting(
	        'parallax_style_wat_4',
	        array(
	            'default'     => 'none' ,
	        )
	    );

	// Parallax Effect front 4
		$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'parallax_style_wat_4',
				array(
					'label'          => 'Parallax effect - Front Page 4',
					'section'        => 'section_parallax',
					'settings'       => 'parallax_style_wat_4',
					'type'           => 'select',
					'priority'	 => 4,
					'choices'        => array(
						'none'  => 'None',
        				'translate'   => 'Fade in up',
        				'rotate'   => 'Rotate',
        				'scale'   => 'Scale',
					)
				)
			)
		);
	// Settings parallax front 5
		$wp_customize->add_setting(
	        'parallax_style_wat_5',
	        array(
	            'default'     => 'none' ,
	        )
	    );

	// Parallax Effect front 5
		$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'parallax_style_wat_5',
				array(
					'label'          => 'Parallax effect - Front Page 5',
					'section'        => 'section_parallax',
					'settings'       => 'parallax_style_wat_5',
					'type'           => 'select',
					'priority'	 => 5,
					'choices'        => array(
						'none'  => 'None',
        				'translate'   => 'Fade in up',
        				'rotate'   => 'Rotate',
        				'scale'   => 'Scale',
					)
				)
			)
		);							
	// Settings time duration
		$wp_customize->add_setting(
	        'parallax_time',
	        array(
	            'default'     => '1' ,
	        )
	    );
	// Controller time duration effects
		$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize,
				'parallax_time',
				array(
					'label'          => 'Time duration - Parallax effect',
					'section'        => 'section_parallax',
					'settings'       => 'parallax_time',
					'type'           => 'text',
					'priority'	 => 6,
				)
			)
		);

// Sanitize Functions
	function wat_sanitize_text( $str ) {
		return sanitize_text_field( $str );
	} 
	function wat_sanitize_number( $int ) {
		return intval( $int );
	}
	function wat_sanitize_checkbox( $input ) {
	    if ( $input == 1 )
	        return 1;
	    else
	        return '';
	}
	function wat_sanitize_layout_placement( $input ) {
    $valid = array(
			'full-width'  => 'Full Width',
        	'content-sidebar'   => 'Content/Sidebar',
        	'sidebar-content'   => 'Sidebar/Content',
	    );
	 
	    if ( array_key_exists( $input, $valid ) )
	        return $input;
	    else
	        return '';
	}
	function wat_sanitize_html( $input ) {
	$allowed_html = array(
		'p'       => array(
			'class' => array(),
			'id'    => array(),
		),
		'br'      => array(),
		'em'      => array(),
		'address' => array(),
		'strong'  => array(),
		'ul'      => array(
			'class' => array(),
			'id'    => array(),
		),
		'li'      => array(
			'class' => array(),
			'id'    => array(),
		),
		'a'       => array(
			'href'   => array(),
			'class'  => array(),
			'id'     => array(),
			'target' => array(),
		),
		'button'  => array(
			'class' => array(),
			'id'    => array(),
		),
		'abbr'    => array(
			'title' => array(),
		),
	);

	$string = force_balance_tags( $input );
	return wp_kses( $string, $allowed_html );
	}
}

function wat_sanitize_content_style_firstpost( $input ) {
$valid = array(
    	'as-following-posts'   => 'As following posts',	
    	'full'   => 'Full',
		'excerpt'  => 'Excerpt',
    	'list'   => 'List'
    );
 
    if ( array_key_exists( $input, $valid ) )
        return $input;
    else
        return '';
}

function wat_sanitize_content_style_followingposts( $input ) {
$valid = array(
    	'full'   => 'Full',
		'excerpt'  => 'Excerpt',
    	'list'   => 'List',
		'grid'   => 'Grid',
    );
 
    if ( array_key_exists( $input, $valid ) )
        return $input;
    else
        return '';
}


// Remove customizer settings
add_action( 'customize_register', 'wat_remove_customize_section', 20 );
function wat_remove_customize_section( $wp_customize ) {
    $wp_customize->remove_section( 'genesis_archives' );
    $wp_customize->remove_section( 'genesis_layout' );
    $wp_customize->remove_section( 'genesis_breadcrumbs' );
    $wp_customize->remove_section( 'static_front_page' );
}