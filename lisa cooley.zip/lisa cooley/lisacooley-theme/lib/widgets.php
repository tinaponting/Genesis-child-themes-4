<?php
/**
 * @link         http://watdesignexpress.com/
 * @author       WAT Design Express
 */

genesis_register_sidebar( array(
	'id'          => 'front-page-1',
	'name'        => __( 'Front Page 1', 'wat' ),
	'description' => __( 'This is the 1st section on the front page .', 'wat' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-2',
	'name'        => __( 'Front Page 2', 'wat' ),
	'description' => __( 'This is the 2nd section on the front page.', 'wat' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-3',
	'name'        => __( 'Front Page 3', 'wat' ),
	'description' => __( 'This is the 3rd section on the front page.', 'wat' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-4',
	'name'        => __( 'Front Page 4', 'wat' ),
	'description' => __( 'This is the 4th section on the front page.', 'wat' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-5',
	'name'        => __( 'Front Page 5', 'wat' ),
	'description' => __( 'This is the 5th section on the front page.', 'wat' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'nav-social-menu',
	'name'        	=> __( 'Nav Social Menu', 'wat' ),
	'description' 	=> __( 'This section will show when primary menu is used.', 'wat' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'category-index',
	'name'        	=> __( 'Category Index', 'wat' ),
	'description' 	=> __( 'This section will show in a certain page using the category index template.', 'wat' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'after-first-post',
	'name'        	=> __( 'After First Post', 'wat' ),
	'description' 	=> __( 'This section will show after first post in home/archive/category/blog page.', 'wat' ),
) );
genesis_register_sidebar( array(
	'id'          	=> 'slider-category',
	'name'        	=> __( 'Top Category Page', 'wat' ),
	'description' 	=> __( 'This section will show on the top of category page.', 'wat' ),
) );