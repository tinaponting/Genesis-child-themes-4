<?php
if ( is_active_sidebar( 'after-first-post' ) )
	dynamic_sidebar( 'after-first-post' );
?>