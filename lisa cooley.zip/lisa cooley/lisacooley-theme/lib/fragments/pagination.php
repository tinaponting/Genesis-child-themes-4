<div class="navigation"><p><?php posts_nav_link(' ','<div class="nav-newer">&laquo; NEWER POSTS</div>','<div class="nav-older">OLDER POSTS &raquo;</div>'); ?></p></div>
