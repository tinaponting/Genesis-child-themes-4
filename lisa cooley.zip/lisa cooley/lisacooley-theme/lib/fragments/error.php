<?php if( is_search() ) { ?>
	<h2 class="404 page-title">Not Found</h2>
	<p class="aligncenter">Sorry, no post matched your search. Try looking for something else.</p>
<?php } else { ?>
	<h2 class="404 page-title">Not Found</h2>
	<p class="aligncenter">Oops, no page was found.</p>
<?php } ?>