<div class="comments-more">
	<?php if ( comments_open() ) : ?><a href="<?php echo get_permalink(); ?>#respond">
	<?php comments_number(__('Leave a Comment'), __('1 Comment'), __('% Comments')); ?></a><?php endif; ?>
</div>