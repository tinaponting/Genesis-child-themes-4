<?php
/**
 * @author WAT Design Express
 * @link   https://www.watdesignexpress.com/
 **/

// Style First Post
function run_content_style_for_firstpost($style) {
	if( 'as-following-posts' != $style ) {
		the_post();
		if ( 'full' == $style )
			get_template_part('templates/partials/content-style-full');
		elseif ( 'excerpt' == $style )
			get_template_part('templates/partials/content-style-excerpt');
		elseif ( 'list' == $style )
			get_template_part('templates/partials/content-style-list');

		get_template_part('lib/fragments/after-first-post');
	}
}

// Style Full
function run_content_style_full($ignore_firstpost) {
	$count = 0;
	while (have_posts()) : the_post();
		$count++;
		get_template_part('templates/partials/content-style-full');
		if($count == 1 && !$ignore_firstpost)
			get_template_part('lib/fragments/after-first-post');
	endwhile;		
}
// Style Excerpt
function run_content_style_excerpt($ignore_firstpost) {
	$count = 0;
	while (have_posts()) : the_post();
		$count++;
		get_template_part('templates/partials/content-style-excerpt');
		if($count == 1 && !$ignore_firstpost)
			get_template_part('lib/fragments/after-first-post');
	endwhile;
}
// Style List
function run_content_style_list($ignore_firstpost) {
	$count = 0;
	while (have_posts()) : the_post();
		$count++;
		get_template_part('templates/partials/content-style-list');
		if($count == 1 && !$ignore_firstpost)
			get_template_part('lib/fragments/after-first-post');
	endwhile;
}

// Style Grid
function run_content_style_grid($ignore_firstpost) {
	$count = 0;
	while (have_posts()) : the_post();
		$count++;
		get_template_part('templates/partials/content-style-grid');
		if($count == 3 && !$ignore_firstpost)
			get_template_part('lib/fragments/after-first-post');
		if($count % 3 == 0)
			echo '<div class="clear"></div>';
	endwhile;		
}