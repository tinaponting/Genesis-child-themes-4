<?php
/**
 *
 * @author  WAT Design Express
 * @link    https://www.watdesignexpress.com/
 */

add_action( 'wp_enqueue_scripts', 'wat_custom_color_css' );
/**
* If any of these value are set the appropriate CSS is output.
*
* @since 2.2.3
*/
function wat_custom_color_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
	$bg_header = get_theme_mod( 'banner_set' );
	$margin_top = get_theme_mod( 'margin_top_set', 3 );
	$margin_bottom = get_theme_mod( 'margin_bottom_set', 3 );

	$body_color = get_theme_mod( 'background_color','fff' );

	$slider_bg_color = get_theme_mod( 'slider_bg_color','#E2E1E1' );

	$text_color = get_theme_mod( 'text_color','#242323' );
	$sub_text_color = get_theme_mod( 'sub_text_color','#5D5C5C' );

	$top_menu_background_color = get_theme_mod( 'top_menu_background_color','#F7F6F6' );
	$top_menu_text_color = get_theme_mod( 'top_menu_text_color','#333' );

	$top_menu_hover_background_color = get_theme_mod( 'top_menu_hover_background_color','#95A787' );
	$top_menu_hover_text_color = get_theme_mod( 'top_menu_hover_text_color','#fff' );

	$text_link_color = get_theme_mod( 'text_link_color','#242323' );
	$text_link_hover_color = get_theme_mod( 'text_link_hover_color','#95A787' );

	$button_background_color = get_theme_mod( 'button_background_color','#fff' );
	$button_text_color = get_theme_mod( 'button_text_color','#95A787' );
	$button_hover_background_color = get_theme_mod( 'button_hover_background_color','#95A787' );
	$button_hover_text_color = get_theme_mod( 'button_hover_text_color','#fff' );

	$footer_background_color = get_theme_mod( 'footer_background_color','#F7F6F6' );
	$footer_text_color = get_theme_mod( 'footer_text_color','#242323' );
	$parallax_time = get_theme_mod( 'parallax_time','1' );

	$css = '';
	$css .= sprintf( '
		.parallax .para-front-page-1, .parallax .para-front-page-2, .parallax .para-front-page-3
, .parallax .para-front-page-4, .parallax .para-front-page-5 {
			-webkit-animation-duration: %ss !important;
    		animation-duration: %ss !important;
	}
	', $parallax_time, $parallax_time );
	$css .= sprintf( '
		.site-header {
			background: url(%s) no-repeat center center;
			background-size: contain;
		}
		', $bg_header );
	$css .= sprintf( '
		.site-header > .wrap {
			margin-top: %s;
			margin-bottom: %s;
		}
		', $margin_top.'%' , $margin_bottom.'%' );	
	//Body
	$css .= sprintf( '
		body, .entry, .sidebar .widget,
		.after-entry, .author-box, .footer-widgets, 
		.comment-respond, .entry-comments, .entry-pings,
		.nav-secondary, .flexslider, .enews-title, .input, .social-share [class*="fa fa-"] {
			background: #%s;
		}
		', $body_color );
	$css .= sprintf( '
	.social-share [class*="fa fa-"] {
		border-color: #%s;
	}
		', $body_color );
	// Slider background color
	$css .= sprintf( '
		.genesis_responsive_slider .slide-excerpt {
			background: %s !important;
		}
		', $slider_bg_color );

	//Text color
	$css .= sprintf( '
		body,
		.site-description, .menu-toggle, .title-ins,
		.footer-widget-area .enews .widget-title,
		.menu-toggle, .sub-menu-toggle, .sidebar .featuredpage p, .front-page .enews p,
		.style-excerpt h2.post-title a, .style-full h2.post-title a, .style-list h2.post-title a,
		.style-grid h2.post-title a,
		.entry-title a, .genesis_responsive_slider #genesis-responsive-slider h2 a {
			color: %s !important;
		}
		', $text_color );
	//Sub text color
	$css .= sprintf( '
	.style-excerpt .post-meta, .style-full .post-meta, .style-list .post-meta, .style-single .post-meta,
	.style-excerpt .post-meta a, .style-full .post-meta a, .style-list .post-meta a,
	.style-excerpt .social-share, .style-full .social-share, .style-list .social-share,
	.style-grid .wrap-date-cate, .style-grid .meta-category a,
	.style-list .post-content .read-more a,
	.style-excerpt .read-more a, .style-full .read-more a,
	.enews-text-1, .enews-text-2, .enews-text-3,
	.style-single .meta-category a {
			color: %s !important;
		}
		', $sub_text_color );
	//Top bar menu background
	$css .= sprintf( '
		.nav-primary, .sidebar .enews-widget .enews input, .sidebar .enews-widget .enews input:focus,
		.genesis-nav-menu .sub-menu a, .menu-toggle, .menu-toggle:hover, .menu-toggle:focus, .sub-menu-toggle, .sub-menu-toggle:hover {
			background: %s !important;
		}
		', $top_menu_background_color );
	$css .= sprintf( '
		 .genesis-nav-menu a:hover {
			color: %s !important;
		}
		', $top_menu_hover_text_color );
	//Top bar menu text
	$css .= sprintf( '
		.genesis-nav-menu a, .sidebar .enews-widget .enews input::placeholder, .genesis-nav-menu .search-form input[type="search"], .genesis-nav-menu .search-form input[type="search"]::placeholder, .sidebar .enews-widget .enews input, .sidebar .enews-widget .enews input:focus {
			color: %s !important;
		}
		', $top_menu_text_color );

	//Top bar hover menu background
	$css .= sprintf( '
		 .genesis-nav-menu .sub-menu a:hover {
			background: %s !important;
			color: %s !important;
		}
		', $top_menu_hover_background_color, $top_menu_hover_text_color );
	$css .= sprintf( '
		 .genesis-nav-menu a:hover,
		 .menu-toggle:focus, .sub-menu-toggle:hover, .sub-menu-toggle:focus {
			color: %s !important;
		}
		', $text_link_hover_color );
	//Text link color
	$css .= sprintf( '
		a {
			color: %s;
		}
		', $text_link_color );
	//Text link color hover
	$css .= sprintf( '
		.style-excerpt .post-meta a:hover, .style-full .post-meta a:hover, .style-list .post-meta a:hover, .style-single .post-meta a:hover, .style-grid .meta-category a:hover {
			color: %s !important;
			border-bottom: 1px solid %s !important;
		}
		', $text_link_hover_color, $text_link_hover_color );
	$css .= sprintf( '
		.site-title a, .site-title a:focus, .site-title a:hover,
		.style-excerpt h2.post-title a:hover, .style-full h2.post-title a:hover, .style-list h2.post-title a:hover,
		.style-grid h2.post-title a:hover,
		.style-excerpt .post-meta a:hover, .style-full .post-meta a:hover, .style-list .post-meta a:hover,
		.style-grid .meta-category a:hover,
		.style-list .post-content .read-more a:hover,
		.style-excerpt .read-more a:hover, .style-full .read-more a:hover,
		.entry-title a:hover, .style-single h1.post-title,
		.style-single .meta-category a:hover, .site-footer .genesis-nav-menu a:hover,
		.genesis_responsive_slider #genesis-responsive-slider h2 a:hover {
			color: %s !important;
		}
		', $text_link_hover_color );

	$css .= sprintf( '
		a:hover, .archive-description .entry-title, .archive-title, .author-box-title,
		.pagetitle, .page-title {
			color: %s;
		}
		', $text_link_hover_color );
	//Button background color % text button color
	$css .= sprintf( '
		input[type="button"]:focus,
		input[type="reset"]:focus,
		input[type="submit"]:focus,
		.archive-pagination li a:focus,
		.archive-pagination .active a,
		.button:focus,
		.front-page .featuredpage .read-more,
		.category-index .more-from-category a,
		.sidebar .featuredpage .read-more,
		button, input[type="button"], input[type="reset"], input[type="submit"], .button,
		.comment-reply a,
		.slide-excerpt-border a.read-more {
			background: %s !important;
			color: %s !important;
			border: 1px solid %s !important;
		}
		', $button_background_color, $button_text_color, $button_text_color );

	$css .= sprintf( '
		.social-share [class*="fa fa-"] {
			color: %s !important;
		}
		', $sub_text_color );

	$css .= sprintf( '
		.to-top {
			background: %s;
			color: %s;
		}
		', $button_hover_background_color, $button_text_color );

	$css .= sprintf( '
		.pagination .nav-links .page, .pagination .nav-links .page-numbers {
			color: %s;
			border-color: %s;
		}
		', $button_text_color, $button_text_color );

	$css .= sprintf( '
		.pagination .nav-links .page-numbers:hover {
			color: %s;
			background: %s;
			border-color: %s;
		}
		', $button_hover_text_color, $button_hover_background_color, $button_hover_background_color );

	/** Button sidebar - enews, search ***/
	$css .= sprintf( '	
		.sidebar .enews-widget form,
		.sidebar .widget_search input[type="search"] {
			border: 1px solid %s !important;
		}
		', $button_hover_background_color );

	$css .= sprintf( '	
		.sidebar .enews-widget input[type="submit"],
		.sidebar .widget_search input[type="submit"] {
			background: %s !important;
			color: %s !important;
			border: 1px solid %s !important;
		}
		', $button_hover_background_color, $button_hover_text_color, $button_hover_background_color );
				
	//Button hover background color % text hover button color
	$css .= sprintf( '
		button:hover,
		input[type="button"]:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		.archive-pagination li a:hover,
		.archive-pagination .active a:hover,
		.button:hover,
		.sidebar .enews-widget input[type="submit"]:hover,
		.front-page .featuredpage .read-more:hover,
		.category-index .more-from-category a:hover,
		.sidebar .featuredpage .read-more:hover,
		button:hover, input[type="button"]:hover, input[type="reset"]:hover, input[type="submit"]:hover,
		.front-page .enews-widget input[type="submit"]:hover,
		.comment-reply a:hover,
		.footer-widget-area .enews input[type="submit"]:hover,
		.social-share [class*="fa fa-"]:hover,
		.slide-excerpt-border a.read-more:hover {
			background: %s !important;
			color: %s !important;
			border: 1px solid %s !important;
		}
		', $button_hover_background_color, $button_hover_text_color, $button_hover_background_color );	
	//Footer background color
	$css .= sprintf( '
		.site-footer {
			background: %s !important;
		}
		', $footer_background_color );	
	//Footer text color
	$css .= sprintf( '
		.site-footer p, .site-footer .genesis-nav-menu a {
			color: %s !important;
		}
		', $footer_text_color );

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}
