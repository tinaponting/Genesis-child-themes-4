<?php
/**
 * @link         https://watdesignexpress.com/
 * @author       WAT Design Express
 **/

// Add widget support for homepage.
add_action( 'genesis_meta', 'wat_front_page' );
function wat_front_page() {
	// Add body class
	add_filter( 'body_class', 'wat_homepage_body_class' );
	
	// Force content layout
	if ( 'full-width' == get_theme_mod( 'homepage_layout_set' ) ) :
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
	elseif ( 'content-sidebar' == get_theme_mod( 'homepage_layout_set' ) ) :
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );
	elseif ( 'sidebar-content' == get_theme_mod( 'homepage_layout_set' ) ) :
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_sidebar_content' );
	endif;

	// Add widgets on homepage
	add_action( 'genesis_before_content_sidebar_wrap', 'wat_homepage_widgets' );
}

// Add body class to the head
function wat_homepage_body_class( $classes ) {
	$classes[] = 'front-page';
	return $classes;
}

// Check parallax effect
function check_parallax( $style, $number_front ) {
	if ( get_theme_mod( ''.$style.'','none') == 'none' )
		return;
	else
		return 'para-front-page-'. $number_front;
}

// Add widgets on homepage
function wat_homepage_widgets() {

	if ( get_query_var( 'paged' ) >= 2 )
		return;

	genesis_widget_area( 'front-page-1', array(
		'before' => '<div id="front-page-1" class="front-page-1 margin-front"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_wat_1', '1') .'">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-2', array(
		'before' => '<div id="front-page-2" class="front-page-2 margin-front"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_wat_2', '2') .'">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-3', array(
		'before' => '<div id="front-page-3" class="front-page-3 margin-front"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_wat_3', '3') .'">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-4', array(
		'before' => '<div id="front-page-4" class="front-page-4 margin-front"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_wat_4', '4') .'">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-5', array(
		'before' => '<div id="front-page-5" class="front-page-5 margin-front"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_wat_5', '5') .'">',
		'after'  => '</div></div></div>',
	) );
}

add_action( 'genesis_loop', 'wat_genesis_home_loop' );
function wat_genesis_home_loop() {
	$style_firstpost = get_theme_mod( 'homepage_content_style_firstpost_set','excerpt' );

	$style = get_theme_mod( 'homepage_content_style_followingposts_set','excerpt' );

	$ignore_firstpost = $style_firstpost != "as-following-posts";
	
	if ( get_theme_mod( 'homepage_blog_set','enable' ) == 'enable' ) {
		if (have_posts()) :
			run_content_style_for_firstpost($style_firstpost);

			if ( 'full' == $style )
				run_content_style_full($ignore_firstpost);
			elseif ( 'excerpt' == $style )
				run_content_style_excerpt($ignore_firstpost);
			elseif ( 'list' == $style )
				run_content_style_list($ignore_firstpost);
			elseif ( 'grid' == $style )
				run_content_style_grid($ignore_firstpost);

			the_posts_pagination();
		else: get_template_part('lib/fragments/error');
		endif;
		wp_reset_query();
	}
}
genesis();
