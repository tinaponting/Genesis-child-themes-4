<?php
remove_action(	'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_before_loop','title_search' );
function title_search() {
	echo '<h1 class="page-title">Search</h1>';
}
genesis();
?>