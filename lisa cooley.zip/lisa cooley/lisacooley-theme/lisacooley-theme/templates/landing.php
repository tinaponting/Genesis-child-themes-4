<?php
/**
 * @link         https://watdesignexpress.com/
 * @author       WAT Design Express
 */

/*
Template Name: Landing
*/

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );
//* Remove widget above footer
remove_action( 'genesis_before_footer', 'wat_widget_below_footer', 10 ); 
//* Remove site footer widgets
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
//* Remove widget above content
remove_action( 'genesis_after_header', 'wat_widget_above_content' );
//* Remove site footer elements
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );

add_action( 'genesis_loop', 'wat_genesis_landing_loop' );
function wat_genesis_landing_loop() {
	if (have_posts()) : while (have_posts()) : the_post(); ?>
	<div id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
			<h1 class="page-title landing-title"><?php the_title(); ?></h1>
			<div class="content-landing page-content">
			<?php the_content(); ?>
			</div>
	</div>
	<?php endwhile; else:
	get_template_part('lib/fragments/error');
	endif;
}
genesis();