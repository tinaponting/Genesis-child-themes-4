<?php

/**

 * @link         https://watdesignexpress.com/

 * @author       WAT Design Express

 */



/*

Template Name: About

*/



add_action( 'genesis_loop', 'wat_genesis_about_loop' );

function wat_genesis_about_loop() {

	if (have_posts()) : while (have_posts()) : the_post(); ?>

	<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<div><h1 class="page-title about-title"><?php the_title(); ?></h1></div>

		<div class="content-about page-content"><?php the_content(); ?></div>

		<div class="clear"></div>

	</div>

	<?php endwhile; else:

	get_template_part('lib/fragments/error');

	endif;

}

genesis();