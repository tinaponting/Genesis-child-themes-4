<div id="post-<?php the_ID(); ?>" <?php post_class( 'style-list' ); ?>>
	<div class="featured-thumbnail">
		<div class="featured-thumbnail-inner">
			<?php if ( has_post_thumbnail() ) { ?>
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('square', array( 'class' => 'img-list' )); ?></a>
					<?php } ?>
		</div>
	</div>
	<div class="post-content">
		<div class="wrap-title">
		<h2 class="post-title">
		<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<?php if ( !is_search() ) { ?>
		<div class="post-meta"><span class="meta-category">In <?php echo the_category( ', ' ) .'</span>&nbsp; &bull; &nbsp;by '. get_the_author() .', '. apply_filters( 'the_date', get_the_date(), get_option( 'date_format' ), '', '' ); 
		?>
		</div>
	</div>
		<?php } ?>
		<p><?php echo excerpt(44); ?></p>
		<?php if ( !is_single() )
		{
			get_template_part('lib/fragments/read-more');
			get_template_part('lib/fragments/social-share');
		}
				
		?>
	</div>
	<div class="clear"></div>
</div>
