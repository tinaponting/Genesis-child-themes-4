<div id="post-<?php the_ID(); ?>" <?php post_class( 'style-excerpt' ); ?>>
	<div class="wrap-title">
		<h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<div class="post-meta"><span class="meta-category">In <?php echo the_category( ', ' ) .'</span>&emsp; &bull; &emsp;<span class="style-author">by '. get_the_author() .', </span>'. apply_filters( 'the_date', get_the_date(), get_option( 'date_format' ), '', '' ) .'<span class="style-comment">&emsp; &bull; &emsp;'; 
		if ( comments_open() ) : ?><a href="<?php echo get_permalink(); ?>#respond">
		<?php comments_number(__('Leave a Comment'), __('1 Comment'), __('% Comments')); ?></a><?php endif; ?></span>
		</div>
	</div>
	<div class="post-content">
		<a href="<?php the_permalink(); ?>">
	<?php if ( is_home() || is_front_page() ) {
			if ( 'full-width' == get_theme_mod( 'homepage_layout_set' ) ) {
				the_post_thumbnail('featured-full', array('class' => 'aligncenter featured'));
			}
			else {
				the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
			}
		}
		elseif ( is_category() ) {
			if ( 'full-width' == get_theme_mod( 'category_layout_set' ) ) {
				the_post_thumbnail('featured-full', array('class' => 'aligncenter featured'));
			}
			else {
				the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
			}
		}
		elseif ( is_archive() ) {
			if ( 'full-width' == get_theme_mod( 'archives_layout_set' ) ) {
				the_post_thumbnail('featured-full', array('class' => 'aligncenter featured'));
			}
			else {
				the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
			}
		}
		else {
			the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
		}?>
		</a>
		<?php echo the_content();?>
		<div class="clear"></div>
	</div>
<?php 
	get_template_part('lib/fragments/social-share');
	 ?>
	<div class="clear"></div>
</div>