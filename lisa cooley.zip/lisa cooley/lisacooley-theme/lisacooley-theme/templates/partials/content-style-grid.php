<?php 
	$column_classes = array( '', '', 'one-half style-grid', 'one-third style-grid', 'one-fourth style-grid', 'one-fifth style-grid', 'one-sixth style-grid' );

	$columns = 3;// Num post
	$classes[] = $column_classes[$columns];// Class

	$postCount = ++$GLOBALS['wpdb']->wpse_post_counter; // Count post

?>

<div id="post-<?php the_ID(); echo ' order-'.$postCount ?>" <?php
		if( $postCount == 1 || $postCount % $columns == 1)
			$classes[] = 'first';
		post_class($classes);		
	?>>
	<div class="featured-thumbnail">
		<div class="featured-thumbnail-inner">
			<?php if ( has_post_thumbnail() ) { ?>
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('square', array( 'class' => 'img-grid' )); ?></a>
					<?php }
					if ( !has_post_thumbnail() ) {?>
					<a href="<?php the_permalink(); ?>"><img src="<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/images/default.jpg" alt="" /></a>
					<?php } ?>
		</div>
	</div>
	<div class="wrap-title">
	<h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
	<div class="wrap-date-cate">
	<?php if ( !is_search() ) { ?><span class="meta-category">In <?php the_category( ', ' ); ?>&nbsp;</span><?php } ?>
	<span class="the-date">
		<?php echo apply_filters( 'the_date', get_the_date(), get_option( 'date_format' ), '', '' ); ?>
	</span>
	</div>
	</div>
	<?php if ( is_home() || is_front_page() ) {
			 if ( !get_theme_mod( 'homepage_hide_text_grid_set', false ) ) { ?>
			 	<div class="post-content"><?php echo excerpt(18); ?></div>
			 <?php }
		}
		elseif ( is_category() ) {
			 if ( !get_theme_mod( 'category_hide_text_grid_set', false ) ) { ?>
			 	<div class="post-content"><?php echo excerpt(18); ?></div>
			 <?php }
		}
		elseif ( is_archive() ) {
			 if ( !get_theme_mod( 'archives_hide_text_grid_set', false ) ) { ?>
			 	<div class="post-content"><?php echo excerpt(18); ?></div>
			 <?php }
		}
		else { ?>
			 	<div class="post-content"><?php echo excerpt(18); ?></div>
			 <?php } ?>		
</div>

