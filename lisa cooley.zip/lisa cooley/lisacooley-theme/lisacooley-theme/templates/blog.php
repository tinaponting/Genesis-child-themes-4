<?php
/**
 * @link         https://watdesignexpress.com/
 * @author       WAT Design Express
 */

/*
Template Name: Blog
*/

add_action( 'genesis_loop', 'wat_genesis_blog_loop' );
function wat_genesis_blog_loop() {
	$num_post_blog = get_theme_mod( 'blog_numpost_set', 12 );
	$page_num = $paged; if ($pagenum='') $pagenum = 1;
	query_posts('&showposts='.$num_post_blog.'&paged='.$page_num);

	$style_firstpost = get_theme_mod( 'blog_content_style_firstpost_set','excerpt' );

	$style = get_theme_mod( 'blog_content_style_followingposts_set','excerpt' );

	$ignore_firstpost = $style_firstpost != "as-following-posts";

	if (have_posts()) :
		run_content_style_for_firstpost($style_firstpost);

		if ( 'full' == $style )
			run_content_style_full($ignore_firstpost);
		elseif ( 'excerpt' == $style )
			run_content_style_excerpt($ignore_firstpost);
		elseif ( 'list' == $style )
			run_content_style_list($ignore_firstpost);
		elseif ( 'grid' == $style )
			run_content_style_grid($ignore_firstpost);

		the_posts_pagination();
	else: get_template_part('lib/fragments/error');
	endif;
	wp_reset_query();
}
genesis();