<?php
if ( is_woocommerce_activated() && ( is_shop() || is_product_category() ) )
	return;

$style_firstpost = get_theme_mod( 'category_content_style_firstpost_set','excerpt' );

$style = get_theme_mod( 'category_content_style_followingposts_set','excerpt' );

$ignore_firstpost = $style_firstpost != "as-following-posts";

if (have_posts()) :
	run_content_style_for_firstpost($style_firstpost);

	if ( 'full' == $style )
		run_content_style_full($ignore_firstpost);
	elseif ( 'excerpt' == $style )
		run_content_style_excerpt($ignore_firstpost);
	elseif ( 'list' == $style )
		run_content_style_list($ignore_firstpost);
	elseif ( 'grid' == $style )
		run_content_style_grid($ignore_firstpost);

	the_posts_pagination();
else: get_template_part('lib/fragments/error');
endif;
wp_reset_query();
?>