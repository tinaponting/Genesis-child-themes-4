<?php
if (have_posts()) : while (have_posts()) : the_post();
	do_action( 'genesis_before_entry' ); ?>
	<div id="post-<?php the_ID(); ?>" <?php post_class('style-single'); ?>>
		<h1 class="post-title"><?php the_title(); ?></h1>
		<div class="post-meta"><span class="meta-category">In <?php echo the_category( ', ' ) .'</span>&emsp; &bull; &emsp;by '. get_the_author() .', '. apply_filters( 'the_date', get_the_date(), get_option( 'date_format' ), '', '' ); 
		?>
		</div>
		<div class="post-content">
		<?php if( get_theme_mod( 'featured_img_set' ) == 'enable') {
			the_post_thumbnail('full', array('class' => 'aligncenter featured'));
		}		
		do_action( 'genesis_entry_content' );
		the_tags();
		get_template_part('lib/fragments/social-share');
		?>
		<?php do_action( 'genesis_after_entry_content' ); ?>
		<?php //do_action( 'genesis_entry_footer' ); ?>
		<div class="clear"></div>
		</div>
	</div>
	<div class="divpost"></div>
	<div class="prev-post"><span>PREVIOUS</span><?php previous_post_link(); ?></div>
	<div class="next-post"><span>NEXT</span><?php next_post_link(); ?></div>
	<?php
	do_action( 'genesis_after_entry' );

endwhile; else: get_template_part('lib/fragments/error');
endif;
?>