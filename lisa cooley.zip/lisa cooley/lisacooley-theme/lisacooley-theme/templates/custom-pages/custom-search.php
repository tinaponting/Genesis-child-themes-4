<?php
if ( have_posts() ) {
	run_content_style_grid(false);
	the_posts_pagination();
}
else
	get_template_part('lib/fragments/error');
wp_reset_query();