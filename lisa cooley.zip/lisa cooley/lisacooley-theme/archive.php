<?php
/**
 * @link         https://watdesignexpress.com/
 * @author       WAT Design Express
 **/

if ( 'full-width' == get_theme_mod( 'archives_layout_set', 'full-width' ) ) :
	add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
elseif ( 'content-sidebar' == get_theme_mod( 'archives_layout_set' ) ) :
	add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );
elseif ( 'sidebar-content' == get_theme_mod( 'archives_layout_set' ) ) :
	add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_sidebar_content' );
endif;

add_filter( 'body_class', 'add_body_archive_class' );
function add_body_archive_class( $classes ) {
   $classes[] = 'wat-archive';
   return $classes;
}

remove_action(	'genesis_loop', 'genesis_do_loop' );
genesis();