<?php

/**
* @package Hello Beautiful
* @author  TinselPop
* @license GPL-2.0+
* @link    http://www.tinselpop.com/
*/


//* Remove the entry content
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );


//* Remove the entry image
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );

//* Add the featured image before post title
add_action( 'genesis_entry_header', 'display_featured_image', 8 );
function display_featured_image() {
	if ( $image = genesis_get_image( 'format=url&size=thumbnail-vertical' ) ) {
		printf( '<div class="category-image"><a href="%s" rel="bookmark"><img src="%s" alt="%s" /></a></div>', get_permalink(), $image, the_title_attribute( 'echo=0' ) );
	}
}

//* Remove the entry meta in the entry footer
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_after_post_content', 'genesis_post_meta' );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );

//* Run the Genesis loop
genesis();