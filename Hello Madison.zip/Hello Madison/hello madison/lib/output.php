<?php

add_action( 'wp_enqueue_scripts', 'genesis_sample_css' );

function genesis_sample_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$body_color = get_theme_mod( 'bcs_body_bg_color', bcs_body_bg() );
	$nav_color = get_theme_mod( 'bcs_nav_bg_color', bcs_nav_bg() );
	$text_color = get_theme_mod( 'bcs_body_text_color', bcs_body_text() );
	$logo_color = get_theme_mod( 'bcs_logo_text_color', bcs_logo_text() );
	$header_text_color = get_theme_mod( 'bcs_header_text_color', bcs_header_text() );
	$post_header_text_color = get_theme_mod( 'bcs_post_header_text_color', bcs_post_header_text() );
	$widget_header_text_color = get_theme_mod( 'bcs_widget_header_text_color', bcs_widget_header_text() );
	$widget_header_bg_color = get_theme_mod( 'bcs_widget_header_bg_color', bcs_widget_header_bg() );
	$link_color = get_theme_mod( 'bcs_link_text_color', bcs_link_text() );
	$button_text_color = get_theme_mod( 'bcs_button_text_color', bcs_button_text_color() );
	$button_color = get_theme_mod( 'bcs_button_bg_color', bcs_button_color() );
	$cta_text_color = get_theme_mod( 'bcs_cta_text_color', bcs_cta_text_color() );
	$cta_color = get_theme_mod( 'bcs_cta_bg_color', bcs_cta_color() );
	$footer_color = get_theme_mod( 'bcs_footer_bg_color', bcs_footer_color() );

	$css = '';

	$css .= ( bcs_body_bg() !== $body_color ) ? sprintf( '

		body {
			background: %s;
		}
		', $body_color ) : '';

	$css .= ( bcs_nav_bg() !== $nav_color ) ? sprintf( '

		.nav-primary,
		.nav-primary .search input {
			background: %s;
		}
		', $nav_color ) : '';

	$css .= ( bcs_body_text() !== $text_color ) ? sprintf( '

		.content p,
		.entry-categories a {
			color: %s;
		}
		', $text_color ) : '';

	$css .= ( bcs_logo_text() !== $logo_color ) ? sprintf( '

		.site-title,
		.site-title a,
		.site-title a:hover,
		.site-title a:focus,
		.site-description {
			color: %s;
		}
		', $logo_color ) : '';

	$css .= ( bcs_post_header_text() !== $post_header_text_color ) ? sprintf( '

		.content .entry-title,
		.content .entry-title a {
			color: %s;
		}
		', $post_header_text_color ) : '';

	$css .= ( bcs_widget_header_text() !== $widget_header_text_color ) ? sprintf( '

		.widget-title {
			color: %s;
		}
		', $widget_header_text_color ) : '';

	$css .= ( bcs_widget_header_bg() !== $widget_header_bg_color ) ? sprintf( '

		.widget-title {
			background: %s;
		}
		', $widget_header_bg_color ) : '';

	$css .= ( bcs_widget_header_bg() !== $widget_header_bg_color ) ? sprintf( '

		.widget-title::after {
			border-top-color: %s;
		}
		', $widget_header_bg_color ) : '';

	$css .= ( bcs_header_text() !== $header_text_color ) ? sprintf( '

		h1,
		h2,
		h3,
		h4,
		h5,
		h6 {
			color: %s;
		}
		', $header_text_color ) : '';

	$css .= ( bcs_link_text() !== $link_color ) ? sprintf( '

		.content a,
		.sidebar a {
			color: %s;
		}
		', $link_color ) : '';

	$css .= ( bcs_button_text_color() !== $button_text_color ) ? sprintf( '

		.content .more-link,
		.content .more-link:focus,
		.content .more-link:active,
		.content .more-from-category a,
		.content button,
		.more-link,
		.more-link:active,
		.more-from-category a,
		.sidebar .enews-widget input[type="submit"],
		.footer-widgets .enews-widget input[type="submit"] {
			color: %s;
		}
		', $button_text_color ) : '';

	$css .= ( bcs_button_color() !== $button_color ) ? sprintf( '

		.content .more-link,
		.content .more-link:focus,
		.content .more-link:active,
		.content .more-from-category a,
		.content button,
		.more-link,
		.more-link:active,
		.more-from-category a,
		.sidebar .enews-widget input[type="submit"],
		.footer-widgets .enews-widget input[type="submit"] {
			background: %s;
		}
		', $button_color ) : '';

	$css .= ( bcs_button_color() !== $button_color ) ? sprintf( '

		.content .more-link,
		.content .more-link:focus,
		.content .more-link:active,
		.content .more-from-category a,
		.content button,
		.more-link,
		.more-link:active,
		.more-from-category a,
		.sidebar .enews-widget input[type="submit"],
		.footer-widgets .enews-widget input[type="submit"] {
			outline-color: %s;
		}
		', $button_color ) : '';

	$css .= ( bcs_cta_text_color() !== $cta_text_color ) ? sprintf( '

		.home-ctas a,
		.home-ctas widget {
			color: %s;
		}
		', $cta_text_color ) : '';

	$css .= ( bcs_cta_color() !== $cta_color ) ? sprintf( '

		.home-ctas .widget {
			background: %s;
		}
		', $cta_color ) : '';

	$css .= ( bcs_cta_color() !== $cta_color ) ? sprintf( '

		.home-ctas .widget {
			outline-color: %s;
		}
		', $cta_color ) : '';

	$css .= ( bcs_footer_color() !== $footer_color ) ? sprintf( '

		.footer-widgets,
		.site-footer {
			background: %s;
		}
		', $footer_color ) : '';

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}