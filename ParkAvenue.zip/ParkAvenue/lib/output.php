<?php
/**
 * This file adds the required CSS for the Customizer to the Faithful theme
 */

add_action( 'wp_enqueue_scripts', 'vivienne_customizer_css' );
/**
* Checks the settings for the link color color, primary color, and header
* If any of these value are set the appropriate CSS is output
*
* @since 1.0.0
*/
function vivienne_customizer_css() {

	$handle = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color_blogtitle         = get_theme_mod( 'vivienne_blogtitle_color', vivienne_customizer_get_default_blogtitle_color() );
	$color_text              = get_theme_mod( 'vivienne_text_color', vivienne_customizer_get_default_text_color() );
	$color_link              = get_theme_mod( 'vivienne_link_color', vivienne_customizer_get_default_link_color() );
	$color_linkhover         = get_theme_mod( 'vivienne_linkhover_color', vivienne_customizer_get_default_linkhover_color() );
	$color_navbackground     = get_theme_mod( 'vivienne_navbackground_color', vivienne_customizer_get_default_navbackground_color() );
	$color_navlink           = get_theme_mod( 'vivienne_navlink_color', vivienne_customizer_get_default_navlink_color() );
    $color_socialbg            = get_theme_mod( 'vivienne_social_background', vivienne_customizer_get_default_social_background() );
	$color_social        = get_theme_mod( 'vivienne_social_color', vivienne_customizer_get_default_social_color() );
	$color_osbuttonbg       = get_theme_mod( 'vivienne_osbutton_background', vivienne_customizer_get_default_osbutton_background() );
	$color_osbuttonhover   = get_theme_mod( 'vivienne_osbutton_hover', vivienne_customizer_get_default_osbutton_hover() );
	$color_osicon        = get_theme_mod( 'vivienne_osicon_color', vivienne_customizer_get_default_osicon_color() );
	$color_osmenubg    = get_theme_mod( 'vivienne_osmenu_background', vivienne_customizer_get_default_osmenu_background() );
	$color_osmenucolor          = get_theme_mod( 'vivienne_osmenu_color', vivienne_customizer_get_default_osmenu_color() );
	$color_button            = get_theme_mod( 'vivienne_button_color', vivienne_customizer_get_default_button_color() );
	$color_buttontext        = get_theme_mod( 'vivienne_buttontext_color', vivienne_customizer_get_default_buttontext_color() );
	$color_buttonhover       = get_theme_mod( 'vivienne_buttonhover_color', vivienne_customizer_get_default_buttonhover_color() );
	$color_buttontexthover   = get_theme_mod( 'vivienne_buttontexthover_color', vivienne_customizer_get_default_buttontexthover_color() );
	$color_related        = get_theme_mod( 'vivienne_related_background', 
vivienne_customizer_get_default_related_background() );
    $color_featuredbackground    = get_theme_mod( 'vivienne_featured_background', vivienne_customizer_get_default_featured_background() );
    $color_featuredcolor          = get_theme_mod( 'vivienne_featured_color', vivienne_customizer_get_default_featured_color() );
	$color_frontpage2background        = get_theme_mod( 'vivienne_frontpage2_background', 
vivienne_customizer_get_default_frontpage2_background() );
	$color_homebackground    = get_theme_mod( 'vivienne_homebackground_color', vivienne_customizer_get_default_homebackground_color() );
	$color_frontpage2color        = get_theme_mod( 'vivienne_frontpage2_color', 
vivienne_customizer_get_default_frontpage2_color() );
	$color_widget    = get_theme_mod( 'vivienne_widget_color', vivienne_customizer_get_default_widget_color() );
	$color_leadcapture          = get_theme_mod( 'vivienne_leadcapture_background', vivienne_customizer_get_default_leadcapture_background() );
	$color_footer            = get_theme_mod( 'vivienne_footer_background', vivienne_customizer_get_default_footer_background() );
	$color_footercolor        = get_theme_mod( 'vivienne_footer_color', vivienne_customizer_get_default_footer_color() );
	$color_igbg        = get_theme_mod( 'vivienne_instagram_background', vivienne_customizer_get_default_instagram_background() );
	$color_igcolor    = get_theme_mod( 'vivienne_instagram_color', vivienne_customizer_get_default_instagram_color() );
	$color_igicon          = get_theme_mod( 'vivienne_instagram_icon', vivienne_customizer_get_default_instagram_icon() );
	$color_igmenu            = get_theme_mod( 'vivienne_instagram_menu', vivienne_customizer_get_default_instagram_menu_background() );
	$color_igmenucolor        = get_theme_mod( 'vivienne_instagram_menucolor', vivienne_customizer_get_default_instagram_menu_color() );


	$css = '';

	$css .= ( vivienne_customizer_get_default_blogtitle_color() !== $color_blogtitle ) ? sprintf( '

		.site-title a,
		.site-title a:hover {
			color: %1$s;
		}

		', $color_blogtitle ) : '';


	$css .= ( vivienne_customizer_get_default_text_color() !== $color_text ) ? sprintf( '

		body,
		body.vivienne-home,
		input,
		select,
		textarea {
			color: %1$s;
		}

		', $color_text ) : '';


	$css .= ( vivienne_customizer_get_default_link_color() !== $color_link ) ? sprintf( '

		.entry-content a:not(.button):not(.more-link),
		.sharrre .share,
		.sharrre:hover .share,
		.social i {
			color: %1$s;
		}

		.woocommerce ul.products li.product a {
			color: %1$s !important;
		}

		', $color_link ) : '';


	$css .= ( vivienne_customizer_get_default_linkhover_color() !== $color_linkhover ) ? sprintf( '

		.entry-content a:hover,
		a:hover,
		.vivienne-home .featuredpost .entry-title a:hover,
		.pagination-previous a:hover,
		.pagination-next a:hover,
		.archive-pagination li a:hover,
		.archive-pagination .active a,
		.prev-next-navigation a:hover,
		.social i:hover,
		.creds a:hover,
		.footer-widgets a:hover,
		.footer-widgets .social i:hover,
		.vivienne-featured h4 a:hover,
		.nav-primary a:hover,
		.nav-secondary a:hover,
        .nav-primary .social i:hover {
			color: %1$s !important;
		}
		
        .nav-primary .social i:hover { color: %1$s !important; }

		.woocommerce ul.products li.product h3:hover,
		.woocommerce ul.products li.product a:hover,
		.woocommerce .product h2:hover {
			color: %1$s !important;
		}

		', $color_linkhover ) : '';


	$css .= ( vivienne_customizer_get_default_navbackground_color() !== $color_navbackground ) ? sprintf( '

		.site-header {
			background-color: %1$s !important;
		}

		', $color_navbackground ) : '';

	$css .= ( vivienne_customizer_get_default_navlink_color() !== $color_navlink ) ? sprintf( '

		.nav-primary a {
			color: %1$s !important;
		}

		', $color_navlink ) : '';

	$css .= ( vivienne_customizer_get_default_social_background() !== $color_socialbg ) ? sprintf( '

		.nav-primary .widget-wrap {
			background-color: %1$s !important;
		}

		', $color_socialbg ) : '';


	$css .= ( vivienne_customizer_get_default_social_background() !== $color_social ) ? sprintf( '

		.nav-primary .social i {
			color: %1$s;
		}

		', $color_social ) : '';


	$css .= ( vivienne_customizer_get_default_osbutton_background() !== $color_osbuttonbg ) ? sprintf( '

		.offscreen-content button,
        .offscreen-content-icon button {
			background-color: %1$s;
		}

		', $color_osbuttonbg ) : '';


	$css .= ( vivienne_customizer_get_default_osbutton_hover() !== $color_osbuttonhover ) ? sprintf( '

		.offscreen-content button:hover,
        .offscreen-content-icon button:hover {
			background-color: %1$s !important;
		}

		', $color_osbuttonhover ) : '';


	$css .= ( vivienne_customizer_get_default_osicon_color() !== $color_osicon ) ? sprintf( '

		.offscreen-content button,
        .offscreen-content-icon button {
			color: %1$s !important;
		}

		', $color_osicon ) : '';


	$css .= ( vivienne_customizer_get_default_osmenu_background() !== $color_osmenubg ) ? sprintf( '

		.offscreen-content {
			background-color: %1$s !important;
		}

		', $color_osmenubg ) : '';


	$css .= ( vivienne_customizer_get_default_osmenu_color() !== $color_osmenucolor ) ? sprintf( '

		.offscreen-content .widget-title,
		.offscreen-content .enews-widget .widget-title,
		.offscreen-content .widget_nav_menu li a,
		.offscreen-content .social i,
		.offscreen-content p,
		.offscreen-content .widget {
		    color: %1$s !important;
		}

		', $color_osmenucolor ) : '';


	$css .= ( vivienne_customizer_get_default_button_color() !== $color_button ) ? sprintf( '

		button, input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
        .widget .button,
		a.more-link,
		.more-from-category a,
		.comment-reply a,
		.vivienne-home .enews-widget input[type="submit"],
        .vivienne-home .home-area .enews-widget input[type="submit"],
        .pricing-table a.button {
			background-color: %1$s;
		}

		.woocommerce #respond input#submit, 
		.woocommerce a.button, 
		.woocommerce button.button, 
		.woocommerce input.button,
		nav.woocommerce-MyAccount-navigation li a:hover {
			background-color: %1$s !important;
		}

		', $color_button ) : '';

	$css .= ( vivienne_customizer_get_default_buttontext_color() !== $color_buttontext ) ? sprintf( '

		button, input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		a.more-link,
		.more-from-category a,
        .widget .button,
		.comment-reply a,
		.vivienne-home .enews-widget input[type="submit"],
        .vivienne-home .home-area .enews-widget input[type="submit"],
        .pricing-table a.button {
			color: %1$s;
		}

		.entry-content a.button { color: %1$s !important; }

		.woocommerce #respond input#submit, 
		.woocommerce a.button, 
		.woocommerce button.button, 
		.woocommerce input.button,
		nav.woocommerce-MyAccount-navigation li a:hover {
			color: %1$s !important;
		}

		', $color_buttontext ) : '';

	$css .= ( vivienne_customizer_get_default_buttonhover_color() !== $color_buttonhover ) ? sprintf( '

		button, input[type="button"]:hover,
		.sidebar li.cat-item a:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		.button:hover,
        .widget .button:hover,
		a.more-link:hover,
		.more-from-category a:hover,
		.comment-reply a:hover,
		.vivienne-home .enews-widget input[type="submit"]:hover,
		.pricing-table a.button:hover,
        .vivienne-home .home-area .enews-widget input[type="submit"]:hover,
        .sidebar li.cat-item a:hover,
        .sidebar .widget_nav_menu a:hover {
			background-color: %1$s;
		}

		.woocommerce #respond input#submit:hover,
		.woocommerce a.button:hover,
		.woocommerce button.button:hover,
		.woocommerce input.button:hover {
			background-color: %1$s !important;
		}

		', $color_buttonhover ) : '';


	$css .= ( vivienne_customizer_get_default_buttontexthover_color() !== $color_buttontexthover ) ? sprintf( '

		button, input[type="button"]:hover,
		.sidebar li.cat-item a:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		.button:hover,
        .widget .button,
		a.more-link:hover,
		.more-from-category a:hover,
		.comment-reply a:hover,
		.vivienne-home .enews-widget input[type="submit"]:hover,
		.pricing-table a.button:hover,
        .vivienne-home .home-area .enews-widget input[type="submit"]:hover,
        .sidebar li.cat-item a:hover,
        .sidebar .widget_nav_menu a:hover {
			color: %1$s;
		}

		.entry-content a.button:hover { color: %1$s !important; }

		.woocommerce #respond input#submit:hover,
		.woocommerce a.button:hover,
		.woocommerce button.button:hover,
		.woocommerce input.button:hover {
			color: %1$s !important;
		}


		', $color_buttontexthover ) : '';

    $css .= ( vivienne_customizer_get_default_related_background() !== $color_related ) ? sprintf( '

        .yarpp-related,
		.yuzo_related_post {
            background-color: %1$s !important;
        }

        ', $color_related ) : '';

    $css .= ( vivienne_customizer_get_default_featured_background() !== $color_featuredbackground ) ? sprintf( '

        .vivienne-home .front-page-1 .featuredpost .post {
            background-color: %1$s !important;
        }

        ', $color_featuredbackground ) : '';

    $css .= ( vivienne_customizer_get_default_featured_color() !== $color_featuredcolor ) ? sprintf( '

        .vivienne-home .featuredpost .entry-title a {
            color: %1$s;
        }

        ', $color_featuredcolor ) : '';


	$css .= ( vivienne_customizer_get_default_frontpage2_background() !== $color_frontpage2background ) ? sprintf( '

		.front-page-2 {
			background-color: %1$s !important;
		}

		', $color_frontpage2background ) : '';

	$css .= ( vivienne_customizer_get_default_homebackground_color() !== $color_homebackground ) ? sprintf( '

		blockquote,
		div.easyrecipe,
		.sidebar .enews-widget,
		.nf-form-layout,
		.front-page-4,
		.front-page-6,
		.comment-respond,
		.error404 .entry-content .search-form,
        #genesis-responsive-slider,
        .flexslider,
        .vivienne-home .front-page-1 .featuredpost .post,
        .vivienne-home .featuredpage .widget-title {
			background-color: %1$s !important;
		}

		', $color_homebackground ) : '';


	$css .= ( vivienne_customizer_get_default_frontpage2_color() !== $color_frontpage2color ) ? sprintf( '

		.front-page-2 p,
		.fornt-page-2 .enews-widget p,
        .vivienne-home .home-area .enews .widget-title {
			color: %1$s !important;
		}

		', $color_frontpage2color ) : '';

	$css .= ( vivienne_customizer_get_default_widget_color() !== $color_widget ) ? sprintf( '

		.vivienne-home .home-area .widget-title {
			color: %1$s;
		}

		', $color_widget ) : '';

	$css .= ( vivienne_customizer_get_default_leadcapture_background() !== $color_leadcapture ) ? sprintf( '

		body.vivienne-lead-capture,
        .vivienne-lead-capture .site-inner {
			background-color: %1$s;
		}

		', $color_leadcapture ) : '';

	$css .= ( vivienne_customizer_get_default_footer_background() !== $color_footer ) ? sprintf( '

		.footer-menu {
			background-color: %1$s;
		}

		
		@media only screen and (max-width: 1000px) { .creds { background-color: %1$s; }}

		', $color_footer ) : '';

	$css .= ( vivienne_customizer_get_default_footer_color() !== $color_footercolor ) ? sprintf( '

		.footer-menu li a,
		.creds p,
		.creds a {
			color: %1$s;
		}

		', $color_footercolor ) : '';

	$css .= ( vivienne_customizer_get_default_instagram_background() !== $color_igbg ) ? sprintf( '

		.vivienne-insta .site-container,
		.vivienne-insta .site-inner,
		.vivienne-insta .site-header {
			background-color: %1$s !important;
		}

		', $color_igbg ) : '';

	$css .= ( vivienne_customizer_get_default_instagram_color() !== $color_igcolor ) ? sprintf( '

		.vivienne-insta .site-title,
		.vivienne-insta .site-title a,
		.vivienne-insta .site-description,
		.vivienne-insta .widget-title,
		.vivienne-insta p,
		.vivienne-insta div {
			color: %1$s !important;
		}

		', $color_igcolor ) : '';

	$css .= ( vivienne_customizer_get_default_instagram_icon() !== $color_igicon ) ? sprintf( '

		.vivienne-insta .social i {
			color: %1$s;
		}

		', $color_igicon ) : '';

	$css .= ( vivienne_customizer_get_default_instagram_menu_background() !== $color_igmenu ) ? sprintf( '

		.vivienne-insta .menu li a {
			background-color: %1$s;
		}

		', $color_igmenu ) : '';

	$css .= ( vivienne_customizer_get_default_instagram_menu_color() !== $color_igmenucolor ) ? sprintf( '

		.vivienne-insta .menu li a {
			color: %1$s !important;
		}

		', $color_igmenucolor ) : '';

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}
