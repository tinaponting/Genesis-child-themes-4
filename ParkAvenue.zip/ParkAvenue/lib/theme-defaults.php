<?php
/**
 * This file adds the default theme settings to the Faithful theme.
 */

add_filter( 'genesis_theme_settings_defaults', 'vivienne_theme_defaults' );
function vivienne_theme_defaults( $defaults ) {
    $defaults['update']                    = 1;
    $defaults['content_archive']           = 'excerpt';
    $defaults['content_archive_limit']     = 300;
    $defaults['content_archive_thumbnail'] = 1;
    $defaults['comments_posts']            = 1;
    $defaults['image_size']                = 'blog-large';
    $defaults['image_alignment']           = 'alignleft';
    $defaults['posts_nav']                 = 'numeric';
    $defaults['site_layout']               = 'content-sidebar';

    return $defaults;

}

add_action( 'after_switch_theme', 'vivienne_theme_setting_defaults' );
/**
 * Function to setup the theme settings.
 *
 * @since 1.0.0
 */
function vivienne_theme_setting_defaults() {

    if ( function_exists( 'genesis_update_settings' ) ) {

        genesis_update_settings( array(
            'update'                    => 1,
            'content_archive'           => 'excerpt',
            'content_archive_limit'     => 300,
            'content_archive_thumbnail' => 1,
            'comments_posts'            => 1,
            'image_size'                => 'blog-large',
            'image_alignment'           => 'alignleft',
            'posts_nav'                 => 'numeric',
            'site_layout'               => 'content-sidebar',
        ));

    }

    update_option( 'posts_per_page', 5 );

}

add_filter( 'genesis_responsive_slider_settings_defaults', 'vivienne_responsive_slider_defaults' );

function vivienne_responsive_slider_defaults( $defaults ) {
    $defaults = array(
        'post_type' => 'post',
        'posts_term' => '',
        'exclude_terms' => '',
        'include_exclude' => '',
        'post_id' => '',
        'posts_num' => 3,
        'posts_offset' => 0,
        'orderby' => 'date',
        'slideshow_timer' => 6000,
        'slideshow_delay' => 2000,
        'slideshow_arrows' => 0,
        'slideshow_pager' => 1,
        'slideshow_loop' => 1,
        'slideshow_height' => 700,
        'slideshow_width' => 1050,
        'slideshow_effect' => 'slide',
        'slideshow_title_show' => 1,
        'slideshow_excerpt_content' => 'full',
        'slideshow_excerpt_content_limit' => 200,
        'slideshow_more_text' => 'Read the Post',
        'slideshow_excerpt_show' => 1,
        'slideshow_excerpt_width' => 50,
        'location_vertical' => 'top',
        'location_horizontal' => 'right',
        'slideshow_hide_mobile' => 1
    );
    return $defaults;
}