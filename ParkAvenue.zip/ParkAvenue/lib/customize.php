<?php
/**
 * This file adds the Customizer settings to the Vivienne theme
 */
 

/**
 * Function to get default blog title color for Customizer.
 *
 * @since 1.0.0
 *ƒ
 * @return string Hex value of the default blog title color.
 */
function vivienne_customizer_get_default_blogtitle_color() {
	return '#222222';
}

/**
 * Function to get default text color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default text color.
 */
function vivienne_customizer_get_default_text_color() {
	return '#444444';
}

/**
 * Function to get default link color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default link color.
 */
function vivienne_customizer_get_default_link_color() {
	return '#ccc7c6';
}


/**
 * Function to get default link hover color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default link hover color.
 */
function vivienne_customizer_get_default_linkhover_color() {
	return '#222222';
}

/**
 * Function to get default navigation background color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default navigation background color.
 */
function vivienne_customizer_get_default_navbackground_color() {
	return '#ffffff';
}

/**
 * Function to get default navigation link color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default navigation link color.
 */
function vivienne_customizer_get_default_navlink_color() {
	return '#222222';
}

/**
 * Function to get default social background color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default social background color.
 */
function vivienne_customizer_get_default_social_background() {
	return '#f9f9f9';
}

/**
 * Function to get default social icon color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default social icon color.
 */
function vivienne_customizer_get_default_social_color() {
	return '#222222';
}

/**
 * Function to get default offscreen menu button background for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default offscreen menu button background color.
 */
function vivienne_customizer_get_default_osbutton_background() {
    return '#ece7e6';
}

/**
 * Function to get default offscren menu background on hover for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default offscreen menu background on hover.
 */
function vivienne_customizer_get_default_osbutton_hover() {
    return '#222222';
}

/**
 * Function to get default offscreen menu icon color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default offscreen menu icon color.
 */
function vivienne_customizer_get_default_osicon_color() {
    return '#222222';
}

/**
 * Function to get default offscreen menu background for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default button hover text color.
 */
function vivienne_customizer_get_default_osmenu_background() {
    return '#f9f9f9';
}

/**
 * Function to get default offscreen menu text color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default offscreen menu tezt color.
 */
function vivienne_customizer_get_default_osmenu_color() {
    return '#222222';
}

/**
 * Function to get default button background color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default button background color.
 */
function vivienne_customizer_get_default_button_color() {
	return '#222222';
}

/**
 * Function to get default button text color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default button text color.
 */
function vivienne_customizer_get_default_buttontext_color() {
	return '#ffffff';
}

/**
 * Function to get default button background hover color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default button background hover color.
 */
function vivienne_customizer_get_default_buttonhover_color() {
	return '#ece7e6';
}

/**
 * Function to get default button hover text color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default button hover text color.
 */
function vivienne_customizer_get_default_buttontexthover_color() {
	return '#222222';
}

/**
 * Function to get default related posts background color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default button background color.
 */
function vivienne_customizer_get_default_related_background() {
    return '#ece7e6';
}

/**
 * Function to get default featured posts background color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default featured posts background color.
 */
function vivienne_customizer_get_default_featured_background() {
    return '#f9f9f9';
}

/**
 * Function to get default featured posts link color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default featured posts link color color.
 */
function vivienne_customizer_get_default_featured_color() {
    return '#222';
}

/**
 * Function to get default front page 2 background for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default front page 2 background.
 */
function vivienne_customizer_get_default_frontpage2_background() {
    return '#ece7e6';
}


/**
 * Function to get default front page 4 and 6 background color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default front page 4 and 6 background color.
 */
function vivienne_customizer_get_default_homebackground_color() {
    return '#f9f9f9';
}

/**
 * Function to get default front page 2 widget title color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default front page 2 widget title color.
 */
function vivienne_customizer_get_default_frontpage2_color() {
    return '#222222';
}

/**
 * Function to get default front page widget titles color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default front page widget title color.
 */
function vivienne_customizer_get_default_widget_color() {
    return '#222222';
}

/**
 * Function to get default lead capture background for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default headings color.
 */
function vivienne_customizer_get_default_leadcapture_background() {
    return '#ece7e6';
}

/**
 * Function to get default footer background color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default script text color.
 */
function vivienne_customizer_get_default_footer_background() {
    return '#ece7e6';
}

/**
 * Function to get default footer text color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default footer text color.
 */
function vivienne_customizer_get_default_footer_color() {
    return '#222222';
}

/**
 * Function to get default Instagram page background for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default Instagram page background color.
 */
function vivienne_customizer_get_default_instagram_background() {
    return '#ece7e6';
}

/**
 * Function to get default Instagram font color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default Instagram font color.
 */
function vivienne_customizer_get_default_instagram_color() {
    return '#222222';
}

/**
 * Function to get default Instagram icon color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default Instagram icon color.
 */
function vivienne_customizer_get_default_instagram_icon() {
    return '#222222';
}

/**
 * Function to get default Instagram menu background for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default Instagram menu background.
 */
function vivienne_customizer_get_default_instagram_menu_background() {
    return '#FFFFFF';
}

/**
 * Function to get default Instagram menu font color for Customizer.
 *
 * @since 1.0.0
 *
 * @return string Hex value of the default Instagram menu font color.
 */
function vivienne_customizer_get_default_instagram_menu_color() {
    return '#222222';
}


add_action( 'customize_register', 'vivienne_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 *
 * @param stdClass $wp_customize Class object containing available methods.
 */
function vivienne_customizer_register( $wp_customize ) {

	$wp_customize->add_setting(
		'vivienne_blogtitle_color',
		array(
			'default'           => vivienne_customizer_get_default_blogtitle_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_text_color',
		array(
			'default'           => vivienne_customizer_get_default_text_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_link_color',
		array(
			'default'           => vivienne_customizer_get_default_link_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_linkhover_color',
		array(
			'default'           => vivienne_customizer_get_default_linkhover_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_navbackground_color',
		array(
			'default'           => vivienne_customizer_get_default_navbackground_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_navlink_color',
		array(
			'default'           => vivienne_customizer_get_default_navlink_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_social_background',
		array(
			'default'           => vivienne_customizer_get_default_social_background(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_social_color',
		array(
			'default'           => vivienne_customizer_get_default_social_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_osbutton_background',
		array(
			'default'           => vivienne_customizer_get_default_osbutton_background(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_osbutton_hover',
		array(
			'default'           => vivienne_customizer_get_default_osbutton_hover(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_osicon_color',
		array(
			'default'           => vivienne_customizer_get_default_osicon_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_osmenu_background',
		array(
			'default'           => vivienne_customizer_get_default_osmenu_background(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

    $wp_customize->add_setting(
		'vivienne_osmenu_color',
		array(
			'default'           => vivienne_customizer_get_default_osmenu_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_button_color',
		array(
			'default'           => vivienne_customizer_get_default_button_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_buttontext_color',
		array(
			'default'           => vivienne_customizer_get_default_buttontext_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_buttonhover_color',
		array(
			'default'           => vivienne_customizer_get_default_buttonhover_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_buttontexthover_color',
		array(
			'default'           => vivienne_customizer_get_default_buttontexthover_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

$wp_customize->add_setting(
        'vivienne_related_background',
        array(
            'default'           => vivienne_customizer_get_default_related_background(),
            'sanitize_callback' => 'sanitize_hex_color',
        )
    );

    $wp_customize->add_setting(
        'vivienne_featured_background',
        array(
            'default'           => vivienne_customizer_get_default_featured_background(),
            'sanitize_callback' => 'sanitize_hex_color',
        )
    );

        $wp_customize->add_setting(
        'vivienne_featured_color',
        array(
            'default'           => vivienne_customizer_get_default_featured_color(),
            'sanitize_callback' => 'sanitize_hex_color',
        )
    );

	$wp_customize->add_setting(
		'vivienne_frontpage2_background',
		array(
			'default'           => vivienne_customizer_get_default_frontpage2_background(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_homebackground_color',
		array(
			'default'           => vivienne_customizer_get_default_homebackground_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_frontpage2_color',
		array(
			'default'           => vivienne_customizer_get_default_frontpage2_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_widget_color',
		array(
			'default'           => vivienne_customizer_get_default_widget_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);


	$wp_customize->add_setting(
		'vivienne_leadcapture_background',
		array(
			'default'           => vivienne_customizer_get_default_leadcapture_background(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_footer_background',
		array(
			'default'           => vivienne_customizer_get_default_footer_background(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_footer_color',
		array(
			'default'           => vivienne_customizer_get_default_footer_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_instagram_background',
		array(
			'default'           => vivienne_customizer_get_default_instagram_background(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_instagram_color',
		array(
			'default'           => vivienne_customizer_get_default_instagram_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_instagram_icon',
		array(
			'default'           => vivienne_customizer_get_default_instagram_icon(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_instagram_menu',
		array(
			'default'           => vivienne_customizer_get_default_instagram_menu_background(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);

	$wp_customize->add_setting(
		'vivienne_instagram_menucolor',
		array(
			'default'           => vivienne_customizer_get_default_instagram_menu_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);


	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_blogtitle_color',
			array(
				'description' => __( 'Change the default color of the site title.', 'vivienne' ),
			    'label'       => __( 'Site Title Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_blogtitle_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_text_color',
			array(
				'description' => __( 'Change the default color for all the body text on your site.', 'vivienne' ),
			    'label'       => __( 'Body Text Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_text_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_link_color',
			array(
				'description' => __( 'Change the default color for all the links on your site.', 'vivienne' ),
			    'label'       => __( 'Link Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_link_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_linkhover_color',
			array(
				'description' => __( 'Change the default color for your links on hover.', 'vivienne' ),
			    'label'       => __( 'Link Hover Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_linkhover_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_navbackground_color',
			array(
				'description' => __( 'Change the default background color of the top navigation bar.', 'vivienne' ),
			    'label'       => __( 'Navigation Background Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_navbackground_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_navlink_color',
			array(
				'description' => __( 'Change the default link color in the top navigation bar.', 'vivienne' ),
			    'label'       => __( 'Navigation Link Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_navlink_color',
			)
		)
	);


    $wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_social_background',
			array(
				'description' => __( 'Change the default background color of the social icons in the top navigation.', 'vivienne' ),
			    'label'       => __( 'Social Background Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_social_background',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_social_color',
			array(
				'description' => __( 'Change the default social icon color in top navigation.', 'vivienne' ),
			    'label'       => __( 'Social Icon Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_social_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_osbutton_background',
			array(
				'description' => __( 'Change the default background color of offscreen menu button.', 'vivienne' ),
			    'label'       => __( 'Offscreen Button Background', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_osbutton_background',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_osbutton_hover',
			array(
				'description' => __( 'Change the default background color of offscreen menu on hover.', 'vivienne' ),
			    'label'       => __( 'Offscreen Button Background Hover', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_osbutton_hover',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_osicon_color',
			array(
				'description' => __( 'Change the default icon color for the offscreen menu button.', 'vivienne' ),
			    'label'       => __( 'Offscreen Button Icon Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_osicon_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_osmenu_background',
			array(
				'description' => __( 'Change the default background color the offscreen menu when opened.', 'vivienne' ),
			    'label'       => __( 'Offscreen Menu Background Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_osmenu_background',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_osmenu_color',
			array(
				'description' => __( 'Change the default color of text and links in the offscreen menu.', 'vivienne' ),
			    'label'       => __( 'Offscreen Menu Text Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_osmenu_color',
			)
		)
	);


	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_button_color',
			array(
				'description' => __( 'Change the default background color for all of your buttons.', 'vivienne' ),
			    'label'       => __( 'Button Background Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_button_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_buttontext_color',
			array(
				'description' => __( 'Change the default text color for all of your buttons.', 'vivienne' ),
			    'label'       => __( 'Button Text Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_buttontext_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_buttonhover_color',
			array(
				'description' => __( 'Change the default background color for all the buttons when hovered.', 'vivienne' ),
			    'label'       => __( 'Button Background on Hover', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_buttonhover_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_buttontexthover_color',
			array(
				'description' => __( 'Change the default color for the button text when hovered.', 'vivienne' ),
			    'label'       => __( 'Button Text Color on Hover', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_buttontexthover_color',
			)
		)
	);

$wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'vivienne_related_background',
            array(
                'description' => __( 'Change the default background color of the related posts section.', 'vivienne' ),
                'label'       => __( 'Related Posts Background', 'vivienne' ),
                'section'     => 'colors',
                'settings'    => 'vivienne_related_background',
            )
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'vivienne_featured_background',
            array(
                'description' => __( 'Change the default background color of the featured posts on the homepage.', 'vivienne' ),
                'label'       => __( 'Featured Posts Background', 'vivienne' ),
                'section'     => 'colors',
                'settings'    => 'vivienne_featured_background',
            )
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
            $wp_customize,
            'vivienne_featured_color',
            array(
                'description' => __( 'Change the default link color of the entry titles in the featured posts widget on the homepage.', 'vivienne' ),
                'label'       => __( 'Featured Posts Title Color', 'vivienne' ),
                'section'     => 'colors',
                'settings'    => 'vivienne_featured_color',
            )
        )
    );

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_frontpage2_background',
			array(
				'description' => __( 'Change the default background color of the Front Page 2 widget area.', 'vivienne' ),
			    'label'       => __( 'Front Page 2 Background', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_frontpage2_background',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_homebackground_color',
			array(
				'description' => __( 'Change the default background color of Front Page 4 and Front Page 6. Also changes background color of the contact form and sidebar newsletter.', 'vivienne' ),
			    'label'       => __( 'Front Page 4 & 6 Background', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_homebackground_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_frontpage2_color',
			array(
				'description' => __( 'Change the default font color of the Front Page 2 widget area.', 'vivienne' ),
			    'label'       => __( 'Front Page 2 Text Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_frontpage2_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_widget_color',
			array(
				'description' => __( 'Change the default font color of the widget titles in Front Page widget areas 3, 4, 5, and 6.', 'vivienne' ),
			    'label'       => __( 'Front Page Widget Title Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_widget_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_leadcapture_background',
			array(
				'description' => __( 'Change the default background color of the lead capture page.', 'vivienne' ),
			    'label'       => __( 'Lead Capture Background', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_leadcapture_background',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_footer_background',
			array(
				'description' => __( 'Change the default background color of the site footer.', 'vivienne' ),
			    'label'       => __( 'Footer Background Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_footer_background',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_footer_color',
			array(
				'description' => __( 'Change the default text color in the site footer.', 'vivienne' ),
			    'label'       => __( 'Footer Text Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_footer_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_instagram_background',
			array(
				'description' => __( 'Change the default background color of the Instagram page.', 'vivienne' ),
			    'label'       => __( 'Instagram Page Background', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_instagram_background',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_instagram_color',
			array(
				'description' => __( 'Change the default text color on the Instagram page', 'vivienne' ),
			    'label'       => __( 'Instagram Page Text Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_instagram_color',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_instagram_icon',
			array(
				'description' => __( 'Change the default color of the social icons on the Instagram page.', 'vivienne' ),
			    'label'       => __( 'Instagram Page Icons Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_instagram_icon',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_instagram_menu',
			array(
				'description' => __( 'Change the default background color of the menu buttons on the Instagram page.', 'vivienne' ),
			    'label'       => __( 'Instagram Menu Background Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_instagram_menu',
			)
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'vivienne_instagram_menucolor',
			array(
				'description' => __( 'Change the default link color in the menu buttons on the Instagram page.', 'vivienne' ),
			    'label'       => __( 'Instagram Menu Link Color', 'vivienne' ),
			    'section'     => 'colors',
			    'settings'    => 'vivienne_instagram_menucolor',
			)
		)
	);

}
