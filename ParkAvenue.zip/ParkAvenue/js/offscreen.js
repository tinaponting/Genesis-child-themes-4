
jQuery(function($) {

    // Set offscreen container height
    var windowHeight = $(window).height();

    $( '.offscreen-container' ).css({
        'height': windowHeight + 'px'
    });

    if ( ( 'relative' !== $( '.js .nav-primary' ).css( 'position' ) ) ) {
        var headerHeight = $( '.site-header' ).height();
        $( '.site-inner' ).not( '.front-page .site-inner' ).css( 'margin-top', headerHeight+'px' );
    } else {
        $( '.site-inner' ).removeAttr( 'style' );
    }

    $(window).resize(function() {

        var windowHeight = $(window).height();

        $( '.offscreen-container' ).css({
            'height': windowHeight + 'px'
        });

        if ( ( 'relative' !== $( '.js .nav-primary' ).css( 'position' ) ) ) {
            var headerHeight = $( '.site-header' ).height();
            $( '.site-inner' ).not( '.front-page .site-inner' ).css( 'margin-top', headerHeight+'px' );
        } else {
            $( '.site-inner' ).removeAttr( 'style' );
        }

    });



    // Set offscreen content variables
    var body = $( 'body' ),
        content = $( '.offscreen-content' ),
        sOpen = false;

    // Toggle the offscreen content widget area
    $(document).ready(function() {

        $( '.offscreen-content-toggle' ).click(function() {
            __toggleOffscreenContent();
        });

    });

    function __toggleOffscreenContent() {

        if (sOpen) {
            content.fadeOut();
            body.toggleClass( 'no-scroll' );
            sOpen = false;
        } else {
            content.fadeIn();
            body.toggleClass( 'no-scroll' );
            sOpen = true;
        }

    }

});