<?php
/**
 * This file adds the Instagram Page template to the Faithful theme
 */
/*
Template Name: Instagram
*/

//* Add custom body class to the head
add_filter( 'body_class', 'faithful_add_body_class' );
function faithful_add_body_class( $classes ) {

   $classes[] = 'faithful-insta';
   return $classes;

}

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

//* Remove site header elements
remove_action( 'genesis_before', 'faithful_offscreen_content_output' );

//* Remove navigation
remove_action( 'genesis_before', 'genesis_do_subnav', 0 );
remove_action( 'genesis_before', 'genesis_do_nav', 0 );
remove_action( 'genesis_before', 'genesis_do_nav', 0 );
remove_action( 'genesis_after', 'faithful_footer_menu', 0 ); 


// Remove header, navigation, breadcrumbs, footer widgets, footer 
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );
remove_action( 'genesis_after_header', 'genesis_do_nav' );
remove_action( 'genesis_before', 'genesis_do_subnav' );
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );
remove_action( 'genesis_after', 'genesis_footer_widget_areas' );
remove_action( 'genesis_after', 'genesis_footer_markup_open', 11 );
remove_action( 'genesis_after', 'genesis_do_footer', 12 );
remove_action( 'genesis_after', 'genesis_footer_markup_close', 13 );


//* Remove breadcrumbs
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

//* Remove site footer widgets
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );

//* Remove site footer elements
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
remove_action( 'genesis_after', 'genesis_footer_widget_areas', 5 );
remove_action( 'genesis_after', 'genesis_do_footer', 12 );
remove_action( 'genesis_after', 'faithful_footer_social', 8 );
remove_action( 'genesis_after', 'faithful_instagram', 5 );

//* Add Instagram page widget area
add_action( 'genesis_entry_content', 'faithful_insta' );
function faithful_insta() {
 
    genesis_widget_area( 'faithful-insta', array(
        'before' => '<div class="faithful-insta widget-area"><div class="wrap">',
        'after'  => '</div></div>', 
    ) );
    
}

//* Run the Genesis loop
genesis();
