<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Register navigation menus
add_theme_support ( 'genesis-menus' , array ( 
      'primary' => 'Primary Navigation Menu' 
) );

// Reposition primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before', 'genesis_do_nav', 5 );

//* Remove output of primary navigation right extras
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 5, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 5, 2 );

//* Add Home Slider Overlay below Header
add_action( 'genesis_after_header', 'refined_home_slider' );
function refined_home_slider() {
	if( ! ( is_home() || is_front_page() ) ) {
		return;
	}
	
	if ( get_query_var( 'paged' ) >= 2 )
		return;
		
	if( function_exists( 'soliloquy' ) ) {
		echo '<div class="home-slider-container"><div class="home-slider">';
			soliloquy( 'home-slider', 'slug' );
		echo '</div>';

		genesis_widget_area( 'home-slider-overlay', array(
			'before'	=> '<div class="home-slider-overlay widget-area"><div class="wrap">',
			'after'		=> '</div></div></div>',
		) );
	}
}

//* Set Localization (do not remove)
load_child_theme_textdomain( 'faithful', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'faithful' ) );

//* Add WordPress theme customizer color support
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Install plugins
require_once( get_stylesheet_directory() . '/lib/plugins/register-plugins.php' );

//*Set up theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

// Include Customizer CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'faithful' );
define( 'CHILD_THEME_URL', 'https://www.ollieandkay.com' );
define( 'CHILD_THEME_VERSION', '1.0.0' );

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'faithful_enqueue_scripts_styles' );
function faithful_enqueue_scripts_styles() {

    wp_enqueue_script( 'faithful-global', get_bloginfo( 'stylesheet_directory' ) . '/js/global.js', array( 'jquery' ), '1.0.0' );
    wp_enqueue_script( 'digital-fadeup-script', get_stylesheet_directory_uri() . '/js/fadeup.js', array( 'jquery' ), '1.0.0', true );
    wp_enqueue_style( 'dashicons' );
    wp_enqueue_style( 'ionicons', '//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css', array(), CHILD_THEME_VERSION );
    wp_enqueue_style( 'faithful-google-fonts', '//fonts.googleapis.com/css?family=Cardo:400,400i|Montserrat:300,400|Work+Sans:400,700', array(), CHILD_THEME_VERSION );
    
    if ( class_exists( 'woocommerce' ) ) {
        wp_enqueue_style( 'custom-stylesheet', CHILD_URL . '/woo/faithful-woocommerce.css', array() );
    }
}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

// Register responsive menu script
add_action( 'wp_enqueue_scripts', 'faithful_responsive_menu' );
function faithful_responsive_menu() {

    wp_enqueue_script( 'faithful-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
 
}

//* Add new image sizes
add_image_size( 'blog-large', 750, 9999, FALSE );
add_image_size( 'featured-long', 700, 1050, TRUE );
add_image_size( 'featured-wide', 550, 380, TRUE );
add_image_size( 'portfolio', 400, 400, TRUE );
add_image_size( 'category-index', 320, 320, TRUE );
add_image_size('yarpp-thumbnail', 300, 300, true);

function remove_admin_login_header() {
    remove_action('wp_head', '_admin_bar_bump_cb');
}
add_action('get_header', 'remove_admin_login_header');

//* Add support for a 3-column footer widget area
add_theme_support( 'genesis-footer-widgets', 3 );

//* Reposition the 3-column footer
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
add_action( 'genesis_after', 'genesis_footer_widget_areas', 5 );

//* Reposition the footer
remove_action( 'genesis_footer', 'genesis_do_footer' );
add_action( 'genesis_after', 'genesis_do_footer', 12 );

//* Customize the footer credits
add_filter( 'genesis_footer_creds_text', 'faithful_footer_creds_text' );
function faithful_footer_creds_text() {

    echo '<div class="credits"><p>';
    echo 'Copyright &copy; ';
    echo date('Y ');
    echo get_bloginfo( 'name' );
    echo ' &middot; MADE BY <a target="_blank" href="http://example.com">Ollie &amp; MY NAME</a>';
    echo '</p></div>';

}

//* Set number of posts on category archive pages
function faithful_category_post_count($query)
{
    if ($query->is_main_query() && $query->is_category() && !is_admin())
        $query->set('posts_per_page', 6);
}
 
add_action('pre_get_posts', 'faithful_category_post_count');

//* Modify Genesis Read More Link
add_filter( 'excerpt_more', 'faithful_read_more_link' );
add_filter( 'get_the_content_more_link', 'faithful_read_more_link' );
add_filter( 'the_content_more_link', 'faithful_read_more_link' );
/**
 * Modify the Genesis read more link.
 *
 * @since  1.0.0
 *
 * @param  string $more
 * @return string Modified read more text.
 */
function faithful_read_more_link() {
    return '...</p><p><a class="more-link" href="' . get_permalink() . '">' . __( 'VIEW <i>the</i> POST', 'faithful' ) . '</a></p>';
}

//* Unregister the header right widget area
unregister_sidebar( 'header-right' );

//* Reposition header outside main wrap */
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_do_header' );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 ) ;

add_action( 'genesis_before', 'genesis_header_markup_open', 5 );
add_action( 'genesis_before', 'genesis_do_header' );
add_action( 'genesis_before', 'genesis_header_markup_close', 15 );


//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
    'flex-height'     => true,
    'width'           => 450,
    'height'          => 130,
    'header-selector' => '.site-title a',
    'header-text'     => false,
) );

//* Add support for structural wraps
add_theme_support( 'genesis-structural-wraps', array(
    'nav',
    'subnav',    
	'header',
    'footer-widgets',
    'footer',
) );

//* Reposition entry image
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
add_action( 'genesis_entry_header', 'genesis_do_post_image', 5 );

//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'faithful_author_box_gravatar' );
function faithful_author_box_gravatar( $size ) {

    return 176;

}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'faithful_comments_gravatar' );
function faithful_comments_gravatar( $args ) {

    $args['avatar_size'] = 120;

    return $args;

}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'faithful_remove_comment_form_allowed_tags' );
function faithful_remove_comment_form_allowed_tags( $defaults ) {

    $defaults['comment_field'] = '<p class="comment-form-comment"><label for="comment">' . _x( 'Comment', 'noun', 'faithful' ) . '</label> <textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>';
    $defaults['comment_notes_after'] = '';

    return $defaults;

}

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'faithful_search_button_text' );
function faithful_search_button_text( $text ) {
    return esc_attr( 'GO' );
}

//* Genesis Previous/Next Post Post Navigation
add_action( 'genesis_before_comments', 'faithful_prev_next_post_nav', 1);

function faithful_prev_next_post_nav() {

    if ( is_single() ) {

        echo '<div class="prev-next-navigation">';
        previous_post_link( '<div class="previous">%link</div>', '%title' );
        next_post_link( '<div class="next">%link</div>', '%title' );
        echo '</div><!-- .prev-next-navigation -->';
    }
}

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Remove Add to Cart on Archives
add_action( 'woocommerce_after_shop_loop_item', 'faithful_remove_add_to_cart_buttons', 1 );
function faithful_remove_add_to_cart_buttons() {

    remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart' );
}

//* Remove Related Products
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

//* Add WooCommerce Gallery and Lightbox
add_action( 'after_setup_theme', 'faithful_woo_setup' );
function faithful_woo_setup() {
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}

//* Force full width layout on WooCommerce pages
function faithful_woo_full_layout() {
 if( is_page ( array( 'shop', 'cart', 'checkout' )) || 'product' == get_post_type() ) {
 return 'full-width-content';
 }
}
add_filter( 'genesis_site_layout', 'faithful_woo_full_layout' );


//* Display 12 products per page
add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 12;' ), 20 );

/**
 * Setup widget counts.
 *
 * @param string $id The widget area ID.
 * @return int Number of widgets in the widget area.
 */
function vivienne_count_widgets( $id ) {
    global $sidebars_widgets;

    if ( isset( $sidebars_widgets[ $id ] ) ) {
        return count( $sidebars_widgets[ $id ] );
    }
}

/**
 * Set the widget class for flexible widgets.
 *
 * @param string $id The widget area ID.
 * @return Name of column class.
 */
function vivienne_widget_area_class( $id ) {
    $count = vivienne_count_widgets( $id );

    $class = '';

    if ( 1 === $count ) {
        $class .= ' widget-full';
    } elseif ( 0 === $count % 3 ) {
        $class .= ' widget-thirds';
    } elseif ( 0 === $count % 4 ) {
        $class .= ' widget-fourths';
    } elseif ( 1 === $count % 2 ) {
        $class .= ' widget-halves uneven';
    } else {
        $class .= ' widget-halves';
    }

    return $class;
}

//* Add shop the post custom field
add_action( 'genesis_entry_footer', 'faithful_shop_post', 12 );
function faithful_shop_post() {
if(is_page() || is_front_page() || is_single() ) {
genesis_custom_field('shop_post');
}
}

//* Customize the entry meta in the entry header
add_filter( 'genesis_post_info', 'faithful_post_info_filter' );
function faithful_post_info_filter( $post_info ) {

    $post_info = '[post_categories before=""] &middot; [post_date]';

    return $post_info;

}

//* Change number of Portfolio posts per page
add_action( 'pre_get_posts', 'portfolio_posts_per_page' );
function portfolio_posts_per_page( $query ) {
	if( $query->is_main_query() && is_post_type_archive( $portfolio )  && ! is_admin() ) {
		$query->set( 'posts_per_page', '45' );
	}
}

//* Edit width of tiled portfolio
if ( ! isset( $content_width ) )
    $content_width = 1100;

//* Create Portfolio Taxonomy
add_action( 'init', 'faithful_portfolio_taxonomy' );
function faithful_portfolio_taxonomy() {

    register_taxonomy( 'portfolio-type', 'portfolio',
        array(
            'labels' => array(
                'name'          => _x( 'Types', 'taxonomy general name', 'faithful' ),
                'add_new_item'  => __( 'Add New Portfolio Type', 'faithful' ),
                'new_item_name' => __( 'New Portfolio Type', 'faithful' ),
            ),
            'exclude_from_search' => true,
            'has_archive'         => true,
            'hierarchical'        => true,
            'rewrite'             => array( 'slug' => 'portfolio-type', 'with_front' => false ),
            'show_ui'             => true,
            'show_tagcloud'       => false,
        )
    );

}

//* Create portfolio custom post type
add_action( 'init', 'faithful_portfolio_post_type' );
function faithful_portfolio_post_type() {

    register_post_type( 'portfolio',
        array(
            'labels' => array(
                'name'          => __( 'Portfolio', 'faithful' ),
                'singular_name' => __( 'Portfolio', 'faithful' ),
            ),
            'has_archive'  => true,
            'hierarchical' => true,
            'menu_icon'    => 'dashicons-screenoptions',
            'public'       => true,
            'rewrite'      => array( 'slug' => 'portfolio', 'with_front' => false ),
            'supports'     => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'revisions', 'page-attributes', 'genesis-seo', 'genesis-cpt-archives-settings' ),
            'taxonomies'   => array( 'portfolio-type' ),

        )
    );
    
}

//* Add Portfolio Type Taxonomy to columns
add_filter( 'manage_taxonomies_for_portfolio_columns', 'faithful_portfolio_columns' );
function faithful_portfolio_columns( $taxonomies ) {

    $taxonomies[] = 'portfolio-type';
    return $taxonomies;

}

//* Remove entry meta on blog page
add_action( 'loop_start', 'remove_entry_meta' );
function remove_entry_meta() {

if ( is_singular('post') )
return;

remove_action( 'genesis_entry_footer', 'genesis_post_meta' );  
}

//* Position post info above post title
remove_action( 'genesis_entry_header', 'genesis_post_info', 12);
add_action( 'genesis_entry_header', 'genesis_post_info', 9 );

//* Customize the entry meta in the entry footer
add_filter( 'genesis_post_meta', 'faithful_post_meta_filter' );
function faithful_post_meta_filter( $post_meta ) {

    $post_meta = '[post_author_posts_link before="Posted By: "] &middot; [post_categories before="In: "]';

    return $post_meta;

}

//* Add Full-Width Footer widget area (Instagram)
add_action( 'genesis_footer', 'faithful_instagram', 1 );
function faithful_instagram() {

    if (is_active_sidebar( 'faithful-instagram' ) && is_home() || is_front_page() || is_page('about') || is_single() || genesis_is_blog_template() ) {
        genesis_widget_area( 'faithful-instagram', array(
            'before' => '<div class="faithful-instagram widget-area"><div>',
            'after' => '</div></div>'
            ) );
    }
}

//* Position YARPP
add_action( 'genesis_before_comments', 'faithful_related', 5 );
function faithful_related() {
    if (function_exists('related_posts') ) {
    related_posts(); }
}

//* Position Yuzo Related
add_action( 'genesis_before_comments', 'faithful_yuzo', 5 );
function faithful_yuzo () { 
	if ( function_exists( 'get_yuzo_related_posts' ) ) {
	get_yuzo_related_posts(); }
}

//* Register widget areas

genesis_register_sidebar( array(
    'id'          => 'front-page-1',
    'name'        => __( 'Front Page 1', 'faithful' ),
    'description' => __( 'This is the first flexible homepage widget area.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'          => 'front-page-2',
    'name'        => __( 'Front Page 2', 'faithful' ),
    'description' => __( 'This is the second flexible homepage widget area.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'          => 'front-page-3',
    'name'        => __( 'Front Page 3', 'faithful' ),
    'description' => __( 'This is the third flexible homepage widget area.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'          => 'front-page-4',
    'name'        => __( 'Front Page 4', 'faithful' ),
    'description' => __( 'This is the fourth flexible homepage widget area.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'          => 'front-page-5',
    'name'        => __( 'Front Page 5', 'faithful' ),
    'description' => __( 'This is the fifth flexible homepage widget area.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'          => 'front-page-6',
    'name'        => __( 'Front Page 6', 'faithful' ),
    'description' => __( 'This is the sixth flexible homepage widget area.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'          => 'category-page',
    'name'        => __( 'Category Index Page', 'faithful' ),
    'description' => __( 'This is the area for the Category Index.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'            => 'faithful-instagram',
    'name'          => __( 'Instagram Footer Area', 'faithful' ),
    'description'   => __( 'This is the full-width footer area for the Instagram widget.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'          => 'faithful-contact-left',
    'name'        => __( 'Contact Page - Left Column', 'faithful' ),
    'description' => __( 'This is the area for the left half of the contact page.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'            => 'faithful-contact-right',
    'name'          => __( 'Contact Page - Right Column', 'faithful' ),
    'description'   => __( 'This is the area for the right half of the contact page.', 'faithful' ),
) );
genesis_register_sidebar( array(
    'id'          => 'faithful-insta',
    'name'        => __( 'Instagram Page', 'faithful' ),
    'description' => __( 'This is the area for the Instagram page template.', 'faithful' ),
) );