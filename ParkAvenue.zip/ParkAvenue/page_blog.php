<?php
/**
 * This file adds the front page to the Faithful theme
 */

add_action( 'genesis_meta', 'faithful_front_page_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function faithful_front_page_genesis_meta() {

    if ( !is_paged() && is_active_sidebar( 'front-page-1' ) ) {

        //* Enqueue scripts
        add_action( 'wp_enqueue_scripts', 'faithful_enqueue_faithful_script' );
        function faithful_enqueue_faithful_script() {

            wp_enqueue_script( 'faithful-script', get_bloginfo( 'stylesheet_directory' ) . '/js/home.js', array( 'jquery' ), '1.0.0' );
            wp_enqueue_script( 'localScroll', get_stylesheet_directory_uri() . '/js/jquery.localScroll.min.js', array( 'scrollTo' ), '1.2.8b', true );
            wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );

        }

        //* Add front-page body class
        add_filter( 'body_class', 'faithful_body_class' );
        function faithful_body_class( $classes ) {

            $classes[] = 'faithful-home';
            return $classes;

        }

        //* Remove breadcrumbs
        remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

    }

}

//* Add markup for front page widgets
function faithful_homepage_widgets() {

    genesis_widget_area( 'front-page-1', array(
        'before' => '<div id="front-page-1" class="front-page-1 home-area"><div class="wrap"><div class="flexible-widgets widget-area fadeup-effect' . vivienne_widget_area_class( 'front-page-1' ) . '">',
        'after'  => '</div></div></div>',
    ));

}

genesis();

