<?php
/**
 * Category
 */
//* Category Archive for the Faithful theme

//* Remove the post meta and date
remove_action( 'genesis_entry_header', 'genesis_post_info' );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

//* Remove breadcrumb navigation
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

//* Remove the post image
remove_action( 'genesis_entry_header', 'genesis_do_post_image', 5 );

//* Remove the entry content
remove_action( 'genesis_entry_content', 'genesis_do_post_content' );

//* Add category body class to the head
add_filter( 'body_class', 'faithful_body_class' );
function faithful_body_class( $classes ) {
   
   $classes[] = 'faithful-category-archive';
   return $classes;
   
}

//* Change number posts that display on category archive pages
add_action( 'pre_get_posts',  'change_number_posts_per_category'  );
function change_number_posts_per_category( $query ) {

    if ( is_archive() ) {
        $query->set( 'posts_per_page', 12 );

    return $query;
}}

//* Add featured image before post title
add_action( 'genesis_entry_header', 'faithful_cat_archive', 1 );
function faithful_cat_archive() {

    if ( $image = genesis_get_image( 'format=url&size=featured-long' ) ) {
        printf( '<div class="cat-archive-featured-image"><a href="%s" rel="bookmark"><img src="%s" alt="%s" /></a></div>', get_permalink(), $image, the_title_attribute( 'echo=0' ) );

    }
}

//* Run the Genesis loop
genesis();