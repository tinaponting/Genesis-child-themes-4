<?php

// Start the engine
require_once( get_template_directory() . '/lib/init.php' );

//* Add HTML5 markup structure
add_theme_support( 'html5' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add Image Upload and Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Enqueue Dashicons
 add_action( 'wp_enqueue_scripts', 'load_dashicons_front_end' );
function load_dashicons_front_end() {
wp_enqueue_style( 'dashicons' );
}

//* Enqueue scripts for Responsive menu
add_action( 'wp_enqueue_scripts', 'enqueue_responsive_menu_script' );
function enqueue_responsive_menu_script() {wp_enqueue_script( 'my-responsive-menu', get_bloginfo( 'stylesheet_directory' ) . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
}

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Reposition the primary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//Register sidebar before the content on the Home Page
genesis_register_sidebar( array(
	'id'          => 'before-home',
	'name'        => __( 'Featured Posts', 'wpsites' ),
	'description' => __( 'Displays Before Content On Home Page.', 'wpsites' ),
) );

add_action( 'genesis_before_content', 'wpsites_widget_before_home' );
function wpsites_widget_before_home() {
if ( is_home() && is_active_sidebar('before-home') ) {
	genesis_widget_area( 'before-home', array(
		'before' => '<div class="before-home" class="widget-area">',
		'after'  => '</div>',
	) );
}
}

// Add in custom header support.
// Need to add in flex-height and flex-width to be able to skip cropping in the Customizer.
add_theme_support( 'custom-header', array(
 'width' => 400,
 'height' => 150,
 'flex-height' => true,
 'flex-width' => true,
 'header-text' => false,
) );


//// Remove Genesis header style so we can use the customiser and header function genesischild_swap_header to add our header logo.
remove_action( 'wp_head', 'genesis_custom_header_style' );
function foxie_swap_header( $title, $inside, $wrap ) {

 // Set what goes inside the wrapping tags.
 if ( get_header_image() ) :
 $logo = '<img  src="' . get_header_image() . '" width="' . esc_attr( get_custom_header()->width ) . '" height="' . esc_attr( get_custom_header()->height ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
 else :
 $logo = get_bloginfo( 'name' );
 endif;
 $inside = sprintf( '<a href="%s" title="%s">%s</a>', trailingslashit( home_url() ), esc_attr( get_bloginfo( 'name' ) ), $logo );
 
 
 // Determine which wrapping tags to use - changed is_home to is_front_page to fix Genesis bug.
 $wrap = is_front_page() && 'title' === genesis_get_seo_option( 'home_h1_on' ) ? 'h1' : 'p';
 
 
 // A little fallback, in case an SEO plugin is active - changed is_home to is_front_page to fix Genesis bug.
 $wrap = is_front_page() && ! genesis_get_seo_option( 'home_h1_on' ) ? 'h1' : $wrap;
 
 
 // And finally, $wrap in h1 if HTML5 & semantic headings enabled.
 $wrap = genesis_html5() && genesis_get_seo_option( 'semantic_headings' ) ? 'h1' : $wrap;
 $title = sprintf( '<%1$s %2$s>%3$s</%1$s>', $wrap, genesis_attr( 'site-title' ), $inside );
 return $title;
}
add_filter( 'genesis_seo_title','foxie_swap_header', 10, 3 );



/**
 * Add class for screen readers to site description.
 * This will keep the site description mark up but will not have any visual presence on the page
 * This runs if their is a header image set in the Customiser.
 */

 function foxie_add_site_description_class( $attributes ) {
 if ( get_header_image() ) :
 $attributes['class'] .= ' screen-reader-text';
 return $attributes;
 endif;
 return $attributes;
 }
 add_filter( 'genesis_attr_site-description', 'foxie_add_site_description_class' );


//Register before header widget
genesis_register_sidebar( array(
'id' => 'opt-in-widget',
'name' => __( 'Opt-in Widget', 'genesis' ),
'description' => __( 'Opt-In Widget', 'foxie' ),
) );
add_action( 'genesis_before_header', 'add_genesis_widget_area' );
function add_genesis_widget_area() {
                genesis_widget_area( 'opt-in-widget', array(
		'before' => '<div class="opt-in-widget widget-area">',
		'after'  => '</div>',
    ) );

}



//Register sidebar on Home Page just below header for Featured Posts
genesis_register_sidebar( array(
    'id' => 'featured-slideshow',
    'name' => __( 'Featured Slideshow', 'genesis' ),
    'description' => __( 'Featured Slideshow', 'foxie' ),
) );

add_action( 'genesis_after_header', 'home_page_widget' );
function home_page_widget() {
    if ( is_front_page() || is_page_template ('front-page.php') ) {
    genesis_widget_area( 'featured-slideshow', array(
    'before' => '<div class="featured-slideshow widget-area">',
    'after'  => '</div>',
    ) );
    }
}



//Register a header widget for the footer

function genesischild_footerwidgetheader() {
	genesis_register_sidebar( array(
	'id' => 'footerwidgetheader',
	'name' => __( 'Footer Widget Header', 'genesis' ),
	'description' => __( 'This is for the Footer Widget Headline', 'genesis' ),
	) );

}

add_action ('widgets_init','genesischild_footerwidgetheader');


//Position the header widget for the footer
function genesischild_footerwidgetheader_position ()  {
	echo '<div class="footerwidgetheader-container"><div class="wrap">';
	genesis_widget_area ('footerwidgetheader');
	echo '</div></div>';

}

add_action ('genesis_before_footer','genesischild_footerwidgetheader_position');



// Add Read More Link to Post Excerpts
add_filter('excerpt_more', 'get_read_more_link');
add_filter( 'the_content_more_link', 'get_read_more_link' );
function get_read_more_link() {
   return '<br><a class="more-link" href="' . get_permalink() . '">Read&nbsp;the&nbsp;Post</a>';
}


/**
 * Create Rotator post type
 */
function be_register_portfolio_post_type() {
	$labels = array(
		'name' => 'Portfolio Items',
		'singular_name' => 'Portfolio Item',
		'add_new' => 'Add New Item',
		'add_new_item' => 'Add New Portfolio Item',
		'edit_item' => 'Edit Portfolio',
		'new_item' => 'New Portfolio',
		'view_item' => 'View Portfolio',
		'search_items' => 'Search Portfolio Items',
		'not_found' =>  'No items found',
		'not_found_in_trash' => 'No items found in trash',
		'parent_item_colon' => '',
		'menu_name' => 'Portfolio'
	);
	
	$args = array(
		'labels' => $labels,
		'public' => true,
		'publicly_queryable' => true,
		'show_ui' => true, 
		'show_in_menu' => true, 
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'has_archive' => true, 
		'hierarchical' => false,
		'menu_position' => null,
		'supports' => array('title','thumbnail','editor')
	); 
	register_post_type( 'portfolio', $args );
}
add_action( 'init', 'be_register_portfolio_post_type' );	


//customize that thumbnail size

add_image_size( ‘artist-gallery-thumb’, 350, 350, true );


// Widgets for front page template

//top
genesis_register_sidebar( array(
	'id'		=> 'top',
	'name'		=> __( 'Top Front Page Widget', 'foxie' ),
	'description'	=> __( 'This is the widget area for a specific page.', 'foxie' ),
) );

//middle
genesis_register_sidebar( array(
	'id'		=> 'middle',
	'name'		=> __( 'Middle Front Page Widget', 'foxie' ),
	'description'	=> __( 'This is the widget area for a specific page.', 'foxie' ),
) );

//bottom
genesis_register_sidebar( array(
	'id'		=> 'bottom',
	'name'		=> __( 'Bottom Front Page Widget', 'foxie' ),
	'description'	=> __( 'This is the widget area for a specific page.', 'foxie' ),
) );


// Location of top widget 
add_action( 'genesis_entry_header', 'foxie_front_page_top' );
function foxie_front_page_top() {
	if ( is_page_template( 'front-page.php' ) )
	genesis_widget_area ('top', array(
        'before' => '<div class="top"><div class="wrap">',
        'after' => '</div></div>',
	) );
}

// Location of middle widget

add_action( 'genesis_entry_content', 'foxie_front_page_middle' );
function foxie_front_page_middle() {
	if ( is_page_template( 'front-page.php' ) )
	genesis_widget_area ('middle', array(
        'before' => '<div class="middle"><div class="wrap">',
        'after' => '</div></div>',
	) );
}

// Location of top widget

add_action( 'genesis_entry_footer', 'foxie_front_page_bottom' );
function foxie_front_page_bottom() {
	if ( is_page_template( 'front-page.php' ) )
	genesis_widget_area ('bottom', array(
        'before' => '<div class="bottom"><div class="wrap">',
        'after' => '</div></div>',
	) );
}


//* Add support for post formats
add_theme_support( 'post-formats', array(
	'aside',
	'audio',
	'chat',
	'gallery',
	'image',
	'link',
	'quote',
	'status',
	'video'
) );