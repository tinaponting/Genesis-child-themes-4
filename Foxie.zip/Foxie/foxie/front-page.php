<?php
/**
* Template Name: Front Page Template
* Description: A Widgetized Home Page option
*
*/
function foxie_front_page_info() {
	if ( is_active_sidebar( 'top' ) || is_active_sidebar( 'middle' ) || is_active_sidebar( 'bottom' ) ) {
		// Remove the default Genesis loop.
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		// Add a custom loop for the home page.
		add_action( 'genesis_loop', 'foxie_front_page' );
	}
}


//Widgetized home page

function foxie_front_page() {
	// Add the home top section if it has content.
	genesis_widget_area( 'top', array(
		'before' => '<div class="widget-area top">',
		'after'  => '</div> <!-- end .top -->',
	) );

	// Add the home middle section if it has content.
	genesis_widget_area( 'middle', array(
		'before' => '<div class="widget-area middle">',
		'after'  => '</div> <!-- end .middle -->',
	) );

	// Add the home bottom section if it has content.
	genesis_widget_area( 'bottom', array(
		'before' => '<div class="widget-area bottom">',
		'after'  => '</div> <!-- end .bottom -->',
	) );
}

genesis();


?>