<?php

// Additional Custom options

add_action('customize_register','foxie_customizer_options');

// Customize the Colors

// Featured Posts BG Color
function foxie_customizer_options( $wp_customize ) {
	
	 
  //Background Patterns
$wp_customize->add_setting('BG_Pattern', array( 'default' => get_stylesheet_directory_uri() . '/images/backgrounds/tan.jpg',));


$wp_customize->add_control('BG_Pattern', array(
  'label'      => __('Background Pattern', 'foxie'),
  'section'    => 'backgrounds',
  'settings'   => 'BG_Pattern',
  'type'       => 'radio',
  'choices'    => array(
   get_stylesheet_directory_uri() . '/images/backgrounds/tan.jpg'   => 'tan pattern',
   get_stylesheet_directory_uri() . '/images/backgrounds/gray.jpg'   => 'gray pattern',
   get_stylesheet_directory_uri() . '/images/backgrounds/teal.jpg'     => 'teal pattern',
   get_stylesheet_directory_uri() . '/images/backgrounds/teal_solid.jpg'     => 'teal solid',
   get_stylesheet_directory_uri() . '/images/backgrounds/gray_solid.jpg'     => 'gray solid',
   get_stylesheet_directory_uri() . '/images/backgrounds/tan_solid.jpg'     => 'tan solid',
   get_stylesheet_directory_uri() . '/images/backgrounds/black.jpg'     => 'black',
   get_stylesheet_directory_uri() . '/images/backgrounds/white.jpg'     => 'white',




  ),
));
$wp_customize->add_section('backgrounds' , array(
    'title' => __('Backgrounds','foxie'),
	'priority' => 101

));

	
//Color Options

//Accent Color
$wp_customize->add_setting(
 'foxie_accent_color',
 array(
 'default' => '#ffffff',
 )
 );
 
 
 $wp_customize->add_control(
 new WP_Customize_Color_Control(
 $wp_customize,
 'foxie_accent_color',
 array(
 'label' => __( 'Featured Posts BG Color', 'foxie' ), 
 'section' => 'colors',  
 'settings' => 'foxie_accent_color' 
 )
 )
 );
 
 // Link and Navigation Hover Color
 $wp_customize->add_setting(
 'foxie_link_color',
 array(
 'default' => '#ffcaca',
 )
 );
 $wp_customize->add_control(
 new WP_Customize_Color_Control(
 $wp_customize,
 'foxie_custom_link_color',
 array(
 'label' => __( 'Link Color and Navigation Hover', 'foxie' ), 
 'section' => 'colors',
 'settings' => 'foxie_link_color'
 )
 )
 );
 
 // Button Text Color
 $wp_customize->add_setting(
 'foxie_buttontext_color',
 array(
 'default' => '#ffffff',
 )
 );
 $wp_customize->add_control(
 new WP_Customize_Color_Control(
 $wp_customize,
 'foxie_buttontext_color',
 array(
 'label' => __( 'Button Text Color', 'foxie' ),
 'section' => 'colors',
 'settings' => 'foxie_buttontext_color'
 )
 )
 );
 
 //foxie Title Text Color
$wp_customize->add_setting(
 'foxie_title_color',
 array(
 'default' => '#c7a885',
 )
 );
 
 
 $wp_customize->add_control(
 new WP_Customize_Color_Control(
 $wp_customize,
 'foxie_title_color',
 array(
 'label' => __( 'Title Text Color', 'foxie' ), 
 'section' => 'colors',  
 'settings' => 'foxie_title_color' 
 )
 )
 );
 
 
 // Button BG Color
 $wp_customize->add_setting(
 'foxie_button_color',
 array(
 'default' => '#fbf2eb',
 )
 );
 $wp_customize->add_control(
 new WP_Customize_Color_Control(
 $wp_customize,
 'foxie_custom_button_color',
 array(
 'label' => __( 'Buttons BG Color', 'foxie' ),
 'section' => 'colors',
 'settings' => 'foxie_button_color'
 )
 )
 );
 
 // Footer Text Color
 $wp_customize->add_setting(
 'foxie_footertext_color',
 array(
 'default' => '#000000',
 )
 );
 $wp_customize->add_control(
 new WP_Customize_Color_Control(
 $wp_customize,
 'foxie_footertext_color',
 array(
 'label' => __( 'Footer Text', 'foxie' ),
 'section' => 'colors',
 'settings' => 'foxie_footertext_color'
 )
 )
 );
}

/*
 * Output our custom Setting CSS Style 
 *
 */

add_action( 'wp_head', 'foxie_customize_css' );
 
function foxie_customize_css() {
 ?>
 
 <style type="text/css">
 .before-home { background-color:<?php echo get_theme_mod( 'foxie_accent_color', '#ffffff' ); ?>; }
 
 a, .nav-primary .genesis-nav-menu a:hover, .nav-primary .genesis-nav-menu .current-menu-item > a, .nav-primary .genesis-nav-menu .sub-menu .current-menu-item > a:hover {color:<?php echo get_theme_mod( 'foxie_link_color', '#ffcaca' ); ?>; }
 
 .site-title a {color:<?php echo get_theme_mod( 'foxie_title_color', '#c7a885' ); ?>; }

.read-more, button, input[type="button"], input[type="reset"], input[type="submit"], .button, .enews-widget input[type="submit"] {color:<?php echo get_theme_mod( 'foxie_buttontext_color', '#000000' ); ?>; }

.read-more, button, input[type="button"], input[type="reset"], input[type="submit"], .button, .enews-widget input[type="submit"] {background-color:<?php echo get_theme_mod( 'foxie_button_color', '#fbf2eb' ); ?>; }

.site-footer {color:<?php echo get_theme_mod( 'foxie_footertext_color', '#000000' ); ?>; }
 </style>
 <?php
}


/**
 * Adds the individual sections, settings, and controls to the theme customizer
 */
function textbox_customizer( $wp_customize ) {
    $wp_customize->add_section(
        'copyright_textbox',
        array(
            'title' => 'Footer Text',
            'description' => 'Insert copyright info, credentials or any footer text.',
            'priority' => 35,
        )
    );
	$wp_customize->add_setting(
    'copyright_textbox',
    array(
        'default' => 'Made by ♥ Foxie',
    )
);

$wp_customize->add_control(
    'copyright_textbox',
    array(
        'label' => 'Copyright text',
        'section' => 'copyright_textbox',
        'type' => 'text',
    )
);

}
add_action( 'customize_register', 'textbox_customizer' );



add_filter('genesis_footer_creds_text', 'footer_creds_filter');
function footer_creds_filter( $editthecredit ) {
  echo get_theme_mod( 'copyright_textbox', 'Made by ♥ Foxie' );
  
  
  
  
 


//the end
}




