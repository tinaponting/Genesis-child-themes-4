<?php
/**
 * Blush Theme
 * @package 	Blush Theme
 */

 
//* Adds a CSS class to the body element
// --------------------------------------------------------
add_filter( 'body_class', 'pl_archives_body_class' );
function pl_archives_body_class( $classes ) {

	$classes[] = 'pl-archives';
	return $classes;

}

//* Display as Columns
// --------------------------------------------------------
add_filter( 'post_class', 'pl_grid_post_class' );
function pl_grid_post_class( $classes ) {

	if ( is_main_query() ) { // conditional to ensure that column classes do not apply to Featured widgets
		$columns = 2; // Set the number of columns here

		$column_classes = array( '', '', 'one-half', 'one-third', 'one-fourth', 'one-fifth', 'one-sixth' );
		$classes[] = $column_classes[$columns];
		global $wp_query;
		if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % $columns )
			$classes[] = 'first';
	}

	return $classes;

}

//* Remove the breadcrumb navigation
// --------------------------------------------------------
remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

//* Show Excerpts regardless of Theme Settings
// --------------------------------------------------------
add_filter( 'genesis_pre_get_option_content_archive', 'pl_show_excerpts' );
function pl_show_excerpts() {
	return 'excerpts';
}

//* Modify the length of post excerpts
// --------------------------------------------------------
add_filter( 'excerpt_length', 'pl_excerpt_length' );
function pl_excerpt_length( $length ) {
	return 20; // pull first 50 words
}

//* Modify the Excerpt read more link
// --------------------------------------------------------
add_filter('excerpt_more', 'pl_new_excerpt_more');
function pl_new_excerpt_more($more) {
	return '... <br><a class="more-link" href="' . get_permalink() . '">Read More</a>';
}

//* Make sure content limit (if set in Theme Settings) doesn't apply
// --------------------------------------------------------
add_filter( 'genesis_pre_get_option_content_archive_limit', 'pl_no_content_limit' );
function pl_no_content_limit() {
	return '0';
}

//* Remove the entry header markup (requires HTML5 theme support)
// --------------------------------------------------------
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );

//* Remove entry footer
// --------------------------------------------------------
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );

genesis();