<?php
/**
 * Blush Theme
 * @package 	Blush Theme
 */

 
// Add widget support for home page. If no widgets active, display the default loop.
// --------------------------------------------------------
add_action( 'genesis_meta', 'pl_home_genesis_meta' );

function pl_home_genesis_meta() {

	if ( 
		is_active_sidebar( 'home-page-1' ) || 
		is_active_sidebar( 'home-page-2' ) || 
		is_active_sidebar( 'home-grid-1' ) || 
		is_active_sidebar( 'home-grid-2' ) || 
		is_active_sidebar( 'home-grid-3' ) || 
		is_active_sidebar( 'home-page-4' ) || 
		is_active_sidebar( 'home-page-5' ) || 
		is_active_sidebar( 'home-page-6' ) 
	) {
		
		//* Enqueue scripts
		add_action( 'wp_enqueue_scripts', 'pl_enqueue_pl_script' );
		function pl_enqueue_pl_script() {
			wp_enqueue_style( 'pl-home-styles', CHILD_URL . '/css/style-home.css');
		}
		
		//* Add body class
		add_filter( 'body_class', 'pl_home_page_body_class' );
		
		//* Force full width content layout
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
		
		//* Add widgets on front page
		add_action( 'genesis_before_content', 'pl_home_page_widgets' );
		
		$blog = get_option( 'pl_blog_setting', 'true' );

		if ( $blog === 'true' ) {

			//* Add opening markup for blog section
			add_action( 'genesis_before_content', 'pl_home_page_blog_open' );

			//* Add closing markup for blog section
			add_action( 'genesis_after_content', 'pl_home_page_blog_close' );
			
			//* Force full width content layout
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );
			
			//* Add archive body class to the head
			add_filter( 'body_class', 'pl_add_archive_body_class' );
			function pl_add_archive_body_class( $classes ) {
   				$classes[] = 'pl-blog';
   				return $classes;
			}
			
			//* Remove entry meta
			remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
			remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
			remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

		} else {

			//* Remove the default Genesis loop
			remove_action( 'genesis_loop', 'genesis_do_loop' );

		}

	}
}


// Define front-page body class
// --------------------------------------------------------
function pl_home_page_body_class( $classes ) {

	$classes[] = 'pl-home';
	return $classes;

}

// Add Markup for Home Page Widgets
// --------------------------------------------------------
function pl_home_page_widgets() {

	if ( get_query_var( 'paged' ) >= 2 )
		return;

	genesis_widget_area( 'home-page-1', array(
		'before' => '<div id="home-page-1" class="home-page-1 home-page-image-1 image-section home-section"><div class="flexible-widgets widget-area fadeup-effect' . pl_widget_area_class( 'home-page-1' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'home-page-2', array(
		'before' => '<div id="home-page-2" class="home-page-2 home-section"><div class="flexible-widgets widget-area fadeup-effect' . pl_widget_area_class( 'home-page-2' ) . ' "><div class="wrap">',
		'after'  => '</div></div></div>',
	) );
	
	if ( is_active_sidebar( 'home-grid-1' ) || is_active_sidebar( 'home-grid-2' ) || is_active_sidebar( 'home-grid-3' ) ) {

    	echo '<div id="home-page-3" class="home-page-3 home-section home-grid">';
		echo '<div class="widget-area fadeup-effect"><div class="wrap">';
		echo '<div class="wrap">';
		
			echo '<div class="home-grid-1">';
				dynamic_sidebar( 'home-grid-1' );
			echo '</div>';

			echo '<div class="home-grid-2">';
				dynamic_sidebar( 'home-grid-2' );
			echo '</div>';

			echo '<div class="home-grid-3">';
				dynamic_sidebar( 'home-grid-3' );
			echo '</div>';

		echo '</div></div></div></div>';

	}
	
	genesis_widget_area( 'home-page-4', array(
		'before' => '<div id="home-page-4" class="home-page-4 home-page-image-4 image-section home-section"><div class="flexible-widgets widget-area fadeup-effect' . pl_widget_area_class( 'home-page-4' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'home-page-5', array(
		'before' => '<div id="home-page-5" class="home-page-5 home-section"><div class="flexible-widgets widget-area fadeup-effect' . pl_widget_area_class( 'home-page-5' ) . ' "><div class="wrap">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'home-page-6', array(
		'before' => '<div id="home-page-6" class="home-page-6 home-page-image-4 image-section home-section"><div class="flexible-widgets widget-area fadeup-effect' . pl_widget_area_class( 'home-page-6' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

}

// Add opening markup for blog section
// --------------------------------------------------------
function pl_home_page_blog_open() {

	$blog_text = get_option( 'pl_blog_text', __( 'Latest from the Blog', 'pl-blush' ) );
	
	if ( 'posts' == get_option( 'show_on_front' ) ) {

		echo '<div class="blog widget-area"><div class="wrap">';

		if ( ! empty( $blog_text ) ) {

			echo '<h3 class="home-blog-title">' . $blog_text . '</h3>';

		}

	}

}

// Add closing markup for blog section
// --------------------------------------------------------
function pl_home_page_blog_close() {

	if ( 'posts' == get_option( 'show_on_front' ) ) {

		echo '</div></div>';

	}

}


//* Run the default Genesis loop
genesis();