<?php
/**
* Blush Theme
* @package 	Blush Theme
*/