<?php
/**
* Blush Theme
* @package 	Blush Theme
*/

// Register Home Widget Areas
// --------------------------------------------------------

genesis_register_widget_area(
    array(
        'id'          => 'home-page-1',
        'name'        => __( 'Home Page 1', 'pl-blush' ),
        'description' => __( 'This is the first image section on the home page. You can change the background image by opening the customizer and choosing the Home Page Background section.', 'pl-blush' ),
    )
);

genesis_register_widget_area(
    array(
        'id'          => 'home-page-2',
        'name'        => __( 'Home Page 2', 'pl-blush' ),
        'description' => __( 'The second dynamic content section on the home page.', 'pl-blush' ),
    )
);

genesis_register_widget_area(
    array(
        'id'          => 'home-grid-1',
        'name'        => __( 'Home Grid 1', 'pl-blush' ),
        'description' => __( 'Homepage Grid Area 1 - Slider Section', 'pl-blush' ),
    )
);

genesis_register_widget_area(
    array(
        'id'          => 'home-grid-2',
        'name'        => __( 'Home Grid 2', 'pl-blush' ),
        'description' => __( 'Homepage Grid Area 2 - Featured Page Section', 'pl-blush' ),
    )
);

genesis_register_widget_area(
    array(
        'id'          => 'home-grid-3',
        'name'        => __( 'Home Grid 3', 'pl-blush' ),
        'description' => __( 'Homepage Grid Area 3 - Text Area', 'pl-blush' ),
    )
);

genesis_register_widget_area(
    array(
        'id'          => 'home-page-4',
        'name'        => __( 'Home Page 4', 'pl-blush' ),
        'description' => __( 'This is the second image section on the home page. You can change the background image by opening the customizer and choosing the Home Page Background section.', 'pl-blush' ),
    )
);

genesis_register_widget_area(
    array(
        'id'          => 'home-page-5',
        'name'        => __( 'Home Page 5', 'pl-blush' ),
        'description' => __( 'The fifth dynamic content section on the home page.', 'pl-blush' ),
    )
);

genesis_register_widget_area(
    array(
        'id'          => 'home-page-6',
        'name'        => __( 'Home Page 6', 'pl-blush' ),
        'description' => __( 'This is the third image section on the home page. You can change the background image by opening the customizer and choosing the Home Page Background section.', 'pl-blush' ),
    )
);