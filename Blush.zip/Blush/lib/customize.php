<?php
/**
 * Blush Theme
 * @package 	Blush Theme
 */
 
// --------------------------------------------------------
// Set the default primary colors for Customizer
// --------------------------------------------------------
 
// Default Text Color
function pl_customizer_get_default_text_color() {
	return '#313131';
}

// Default Link Color
function pl_customizer_get_default_links_color() {
	return '#999';
}

// Default Link Hover Color
function pl_customizer_get_default_links_hover_color() {
	return '#333';
}

// Menu Link Color
function pl_customizer_get_default_menulinks_color() {
	return '#000';
}

// Menu Link Hover Color
function pl_customizer_get_default_menulinks_hover_color() {
	return '#999';
}

// Default Site Title Color
function pl_customizer_get_default_site_title_color() {
	return '#161616';
}

// Default Title Color
function pl_customizer_get_default_title_color() {
	return '#161616';
}

// Default Light Theme Color
function pl_customizer_get_default_light_theme_color() {
	return '#faf1f0';
}

// Default Dark Theme Color
function pl_customizer_get_default_dark_theme_color() {
	return '#eed4d1';
}

// Default Button Color
function pl_customizer_get_default_button_color() {
	return '#eed4d1';
}

// Default Button Text Color
function pl_customizer_get_default_buttontext_color() {
	return '#515151';
}

// Default Button Hover Color
function pl_customizer_get_default_buttonhover_color() {
	return '#000';
}

// Default Button Hover Text Color
function pl_customizer_get_default_buttonhovertext_color() {
	return '#fff';
}


// --------------------------------------------------------
// Register settings and controls with the Customizer
// --------------------------------------------------------
add_action( 'customize_register', 'pl_customizer_register' );
function pl_customizer_register( $wp_customize ) {
	
	// Register Image Settings
	// ---------------------------------
	$images = apply_filters( 'pl_images', array( '1', '4', '6' ) );

	$wp_customize->add_section( 'pl-settings', array(
		'description' => __( 'Customize the images displayed on the home page. <br /><br />The default images are <strong>1800 pixels wide and 1000 pixels tall</strong>.', 'pl-blush' ),
		'title'       => __( 'Home Background Images', 'pl-blush' ),
		'priority'    => 80.1,
	) );

	foreach( $images as $image ){

		$wp_customize->add_setting( $image .'pl-image', array(
			'default' => sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $image ),
			'type'    => 'option',
		) );

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				$image .'pl-image',
				array(
					'label'    => sprintf( __( 'Featured Section %s Image:', 'pl-blush' ), $image ),
					'section'  => 'pl-settings',
					'settings' => $image .'pl-image',
					'priority' => $image+1,
				)
			)
		);

	}
	
	// Add single image section to the Customizer.
    $wp_customize->add_section(
		'pl_single_image_section',
		array(
			'title'       => __( 'Post and Page Images', 'pl-blush' ),
			'description' => __( 'Choose if you would like to display the featured image above the content on single posts and pages.', 'pl-blush' ),
			'priority'    => 158.85,
		)
	);

    // Add single image setting to the Customizer.
    $wp_customize->add_setting(
		'pl_single_image_setting',
		array(
			'default'    => true,
			'capability' => 'edit_theme_options',
		)
	);

    $wp_customize->add_control(
		'pl_single_image_setting',
		array(
			'section'  => 'pl_single_image_section',
			'settings' => 'pl_single_image_setting',
			'label'    => __( 'Show Featured Image on Posts and Pages?', 'pl-blush' ),
			'type'     => 'checkbox',
		)
	);

	// Register Settings
	// ---------------------------------

	// Text Color Setting
	$wp_customize->add_setting(
		'pl_text_color',
		array(
			'default'           => pl_customizer_get_default_text_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Link Color Setting
	$wp_customize->add_setting(
		'pl_link_color',
		array(
			'default'           => pl_customizer_get_default_links_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Link Hover Color Setting
	$wp_customize->add_setting(
		'pl_link_hover_color',
		array(
			'default'           => pl_customizer_get_default_links_hover_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Menu Link Color Setting
	$wp_customize->add_setting(
		'pl_menulink_color',
		array(
			'default'           => pl_customizer_get_default_menulinks_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Menu Link Hover Color Setting
	$wp_customize->add_setting(
		'pl_menulink_hover_color',
		array(
			'default'           => pl_customizer_get_default_menulinks_hover_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Site Title Color Setting
	$wp_customize->add_setting(
		'pl_site_title_color',
		array(
			'default'           => pl_customizer_get_default_site_title_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Header Title Color Setting
	$wp_customize->add_setting(
		'pl_header_title_color',
		array(
			'default'           => pl_customizer_get_default_title_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Light Theme Color Setting
	$wp_customize->add_setting(
		'pl_light_theme_color',
		array(
			'default'           => pl_customizer_get_default_light_theme_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Dark Theme Color Setting
	$wp_customize->add_setting(
		'pl_dark_theme_color',
		array(
			'default'           => pl_customizer_get_default_dark_theme_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Button Color Setting
	$wp_customize->add_setting(
		'pl_button_color',
		array(
			'default'           => pl_customizer_get_default_button_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Button Text Color Setting
	$wp_customize->add_setting(
		'pl_buttontext_color',
		array(
			'default'           => pl_customizer_get_default_buttontext_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Button Hover Color Setting
	$wp_customize->add_setting(
		'pl_buttonhover_color',
		array(
			'default'           => pl_customizer_get_default_buttonhover_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Button Hover Text Color Setting
	$wp_customize->add_setting(
		'pl_buttonhovertext_color',
		array(
			'default'           => pl_customizer_get_default_buttonhovertext_color(),
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	
	// Add Home Page Settings
	// ---------------------------------
	
	//* Add home page section to the Customizer
    $wp_customize->add_section( 'pl_blog_section', array(
        'title'    => __( 'Home Page Content Settings', 'pl-blush' ),
        'description' => __( 'Choose if you would like to display the blog below the content on the home page.', 'pl-blush' ),
        'priority' => 75.01,
    ));

    //* Add home page setting to the Customizer
    $wp_customize->add_setting( 'pl_blog_setting', array(
        'default'           => 'true',
        'capability'        => 'edit_theme_options',
        'type'              => 'option',
    ));
	
	$wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'pl_blog_control', array(
			'label'       => __( 'Home Page Content Display', 'pl-blush' ),
			'description' => __( 'Show or Hide the Blog Section on the Home Page. The section will be hidden on the home page by default.', 'pl-blush' ),
			'section'     => 'pl_blog_section',
			'settings'    => 'pl_blog_setting',
			'type'        => 'select',
			'choices'     => array(                    
				'false'   => __( 'Hide Blog Section', 'pl-blush' ),
				'true'    => __( 'Show Blog Section', 'pl-blush' ),
			),
        ))
	);
	
    $wp_customize->add_setting( 'pl_blog_text', array(
		'default'           => __( 'The Blog', 'pl-blush' ),
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'wp_kses_post',
		'type'              => 'option',
    ));
	
	$wp_customize->add_control( new WP_Customize_Control( 
        $wp_customize, 'pl_blog_text_control', array(
			'label'      => __( 'Blog Section Title', 'pl-blush' ),
			'description' => __( 'Choose the title text you would like to display above the blog posts on the home page.<br /><br />This text will only be shown when displaying both the blog posts and widgets on the home page.', 'pl-blush' ),
			'section'    => 'pl_blog_section',
			'settings'   => 'pl_blog_text',
			'type'       => 'text',
		))
	);
	
	
	// Register Controls
	// ---------------------------------

	// Text Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_text_color',
			array(
				'description' => __( 'Change the default color for all of the main body text on the site.', 'pl-blush' ),
				'label'       => __( 'Text Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_text_color',
			)
		)
	);
	
	// Link Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_link_color',
			array(
				'description' => __( 'Change the default color of all of the links on the site.', 'pl-blush' ),
				'label'       => __( 'Link Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_link_color',
			)
		)
	);
	
	// Link Hover Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_link_hover_color',
			array(
				'description' => __( 'Change the default hover color of all of the links on the site.', 'pl-blush' ),
				'label'       => __( 'Link Hover Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_link_hover_color',
			)
		)
	);
	
	// Menu Link Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_menulink_color',
			array(
				'description' => __( 'Change the default color for all of the menus on the site. This includes the main menus at the side of the logo.', 'pl-blush' ),
				'label'       => __( 'Menu Link Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_menulink_color',
			)
		)
	);
	
	// Menu Link Hover Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_menulink_hover_color',
			array(
				'description' => __( 'Change the default hover color for all of the menus on the site.', 'pl-blush' ),
				'label'       => __( 'Menu Link Hover Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_menulink_hover_color',
			)
		)
	);
	
	// Site Title Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_site_title_color',
			array(
				'description' => __( 'Change the default text color of the main site tile at the top of the page.', 'pl-blush' ),
				'label'       => __( 'Site Title Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_site_title_color',
			)
		)
	);
	
	// Header Title Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_header_title_color',
			array(
				'description' => __( 'Change the default text color of the titles & headers on your site. This includes the sidebar titles and entry titles', 'pl-blush' ),
				'label'       => __( 'Header Title Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_header_title_color',
			)
		)
	);
	
	// Light Theme Accent Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_light_theme_color',
			array(
				'description' => __( 'Change the themes light accent color for the entire site. A lighter color works best here', 'pl-blush' ),
				'label'       => __( 'Theme Light Accent Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_light_theme_color',
			)
		)
	);
	
	// Dark Theme Accent Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_dark_theme_color',
			array(
				'description' => __( 'Change the themes darker accent color for the entire site. A darker color works best here', 'pl-blush' ),
				'label'       => __( 'Theme Darker Accent Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_dark_theme_color',
			)
		)
	);
	
	// Button Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_button_color',
			array(
				'description' => __( 'Change the default background color for all of the buttons on the site', 'pl-blush' ),
				'label'       => __( 'Button Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_button_color',
			)
		)
	);
	
	// Button Text Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_buttontext_color',
			array(
				'description' => __( 'Change the default text color for all the buttons on the site', 'pl-blush' ),
				'label'       => __( 'Button Text Color', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_buttontext_color',
			)
		)
	);
	
	// Button Hover Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_buttonhover_color',
			array(
				'description' => __( 'Change the default background hover color for all the buttons on the site', 'pl-blush' ),
				'label'       => __( 'Button Hover Colour', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_buttonhover_color',
			)
		)
	);
	
	// Button Hover Text Colour Control
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'pl_buttonhovertext_color',
			array(
				'description' => __( 'Change the default text hover color for all the buttons on the site', 'pl-blush' ),
				'label'       => __( 'Button Hover Text Colour', 'pl-blush' ),
				'section'     => 'colors',
				'settings'    => 'pl_buttonhovertext_color',
			)
		)
	);

}