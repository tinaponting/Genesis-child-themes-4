<?php
/**
 * Blush Theme
 * @package 	Blush Theme
 */

 
// Checks the settings for the link color, and accent color
// --------------------------------------------------------
add_action( 'wp_enqueue_scripts', 'pl_css' );
function pl_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'pl-blush';
	
	$opts = apply_filters( 'pl_images', array( '1', '4', '6' ) );

	$color_text = get_theme_mod( 'pl_text_color', pl_customizer_get_default_text_color() );
	$color_link = get_theme_mod( 'pl_link_color', pl_customizer_get_default_links_color() );
	$color_link_hover = get_theme_mod( 'pl_link_hover_color', pl_customizer_get_default_links_hover_color() );
	$color_menulink = get_theme_mod( 'pl_menulink_color', pl_customizer_get_default_menulinks_color() );
	$color_menulink_hover = get_theme_mod( 'pl_menulink_hover_color', pl_customizer_get_default_menulinks_hover_color() );
	$color_site_title = get_theme_mod( 'pl_site_title_color', pl_customizer_get_default_site_title_color() );
	$color_header_title = get_theme_mod( 'pl_header_title_color', pl_customizer_get_default_title_color() );
	$color_light_theme = get_theme_mod( 'pl_light_theme_color', pl_customizer_get_default_light_theme_color() );
	$color_dark_theme = get_theme_mod( 'pl_dark_theme_color', pl_customizer_get_default_dark_theme_color() );
	$color_button = get_theme_mod( 'pl_button_color', pl_customizer_get_default_button_color() );
	$color_buttontext = get_theme_mod( 'pl_buttontext_color', pl_customizer_get_default_buttontext_color() );
	$color_buttonhover = get_theme_mod( 'pl_buttonhover_color', pl_customizer_get_default_buttonhover_color() );
	$color_buttonhovertext = get_theme_mod( 'pl_buttonhovertext_color', pl_customizer_get_default_buttonhovertext_color() );
	
	$settings = array();

	foreach( $opts as $opt ){
		$settings[$opt]['image'] = preg_replace( '/^https?:/', '', get_option( $opt .'pl-image', sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $opt ) ) );
	}

	$css = '';
	
	foreach ( $settings as $section => $value ) {

		$background = $value['image'] ? sprintf( 'background-image: url(%s);', $value['image'] ) : '';

		if( is_front_page() ) {
			$css .= ( ! empty( $section ) && ! empty( $background ) ) ? sprintf( '.home-page-%s { %s }', $section, $background ) : '';
		}

	}

	$css .= ( pl_customizer_get_default_text_color() !== $color_text ) ? sprintf( '

		body {
			color: %1$s;
		}
		
		*::-moz-placeholder {
			color: %1$s;
		}
			
		', $color_text ) : '';
	
	
	$css .= ( pl_customizer_get_default_links_color() !== $color_link ) ? sprintf( '

		a,
		.woocommerce div.product .woocommerce-tabs ul.tabs li a {
			color: %1$s;
		}
			
		', $color_link ) : '';
	
	
	$css .= ( pl_customizer_get_default_links_hover_color() !== $color_link_hover ) ? sprintf( '

		a:focus,
		a:hover {
			color: %1$s;
		}
			
		', $color_link_hover ) : '';
		
		
	$css .= ( pl_customizer_get_default_menulinks_color() !== $color_menulink ) ? sprintf( '

		.genesis-nav-menu a {
			color: %1$s;
		}
			
		', $color_menulink ) : '';
		
		
	$css .= ( pl_customizer_get_default_menulinks_hover_color() !== $color_menulink_hover ) ? sprintf( '

		.genesis-nav-menu a:hover, 
		.genesis-nav-menu a:focus, 
		.genesis-nav-menu .current-menu-item > a, 
		.genesis-nav-menu .sub-menu .current-menu-item > a:hover, 
		.genesis-nav-menu .sub-menu .current-menu-item > a:focus {
			color: %1$s;
		}
			
		', $color_menulink_hover ) : '';
	
	
	$css .= ( pl_customizer_get_default_site_title_color() !== $color_site_title ) ? sprintf( '

		.site-title, 
		.site-title a {
			color: %1$s;
		}
			
		', $color_site_title ) : '';
	
	
	$css .= ( pl_customizer_get_default_title_color() !== $color_header_title ) ? sprintf( '

		h1, h2, h3, h4, h5, h6 {
			color: %1$s;
		}
			
		', $color_header_title ) : '';
	
	
	$css .= ( pl_customizer_get_default_light_theme_color() !== $color_light_theme ) ? sprintf( '
		
		.home-page-3,
		.footer-widgets-1,
		.to-top,
		.genesis-nav-menu .sub-menu,
		.content article.entry,
		.comment-list li.comment,
		.portfolio-overlay,
		.woocommerce #content div.product div.summary, 
		.woocommerce div.product div.summary, 
		.woocommerce-page #content div.product div.summary, 
		.woocommerce-page div.product div.summary,
		.woocommerce div.product .woocommerce-tabs .panel,
		.woocommerce table.shop_table th,
		.genesis-nav-menu .sub-menu a:focus,
		.genesis-nav-menu .sub-menu a:hover,
		.genesis-nav-menu .sub-menu .current-menu-item > a:focus,
		.genesis-nav-menu .sub-menu .current-menu-item > a:hover,
		.home-page-2::after, .home-page-3::before {
			background-color: %1$s !important;
		}
		
		body,
		.home-section .widget_text,
		.content h1.entry-title, 
		.content h2.entry-title a, 
		.content .entry-comments > h3, 
		.content .feat-list-post h2.entry-title a, 
		.list-page .content .entry h2.entry-title a, 
		.woocommerce-page .content .page-title, 
		.woocommerce div.product .product_title, 
		.single-product .related > h2,
		.page-template-default .content, 
		.woocommerce-page .content,
		form.wpcf7-form,
		.entry-comments,
		.single-product div.product .woocommerce-tabs ul.tabs li a,
		.single-product .related,
		.comment-list li.comment,
		.site-header.fix,
		.footer-widgets-2,
		.home-page-2 .featured-content.featuredpage .entry img {
			border-color: %1$s !important;
		}
		
		.genesis-nav-menu .sub-menu:after,
		.genesis-nav-menu .sub-menu:before {
			border-bottom-color: %1$s !important;
		}
			
		', $color_light_theme ) : '';
	
	
	$css .= ( pl_customizer_get_default_dark_theme_color() !== $color_dark_theme ) ? sprintf( '

		.home-section .home-grid-2 .featured-content.featuredpage h4.widget-title,
		.home-section .flex-direction-nav li a,
		.woocommerce-info::before {
			color: %1$s !important;
		}
		
		.image-section .flexible-widgets.widget-full .widget_text h4::after, 
		.home-section .home-grid-3 .widget_text h4::after, 
		.home-section .enews h4::after, 
		.home-section .featured-content h4.widget-title::after, 
		.home-section .featured-content.featuredpost .entry p.entry-meta::after, 
		.home-section .widget_products h4.widget-title::after, 
		.content .entry .entry-content .cta-button a::before, 
		.content .entry .entry-footer p.entry-meta::before, 
		.sidebar .widget-title::after,
		a.cta-button.color-default,
		.pl-home .featuredpost .entry img.entry-image,
		.home-section .cta-button a,
		.home-section .widget_products ul.product_list_widget li span.product-title,
		.content .entry .entry-content img,
		.sidebar .featuredpost .entry img,
		.comment-list li.comment li.comment,
		.list-page .content .entry .list-thumb img, 
		.blog-feature-page .feat-list-post .list-thumb img,
		.content .entry .entry-content img,
		.masonry-page .content article.entry .entry-image-link img,
		.portfolio-item,
		.woocommerce ul.products li.product a img
		.woocommerce div.product .summary p.price::after, 
		.woocommerce div.product .summary span.price::after,
		.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,
		.woocommerce div.product .woocommerce-tabs .panel h2,
		.woocommerce-error, .woocommerce-info, .woocommerce-message,
		.footer-widget-area .widget .widget-title::after,
		.woocommerce div.product .flex-viewport,
		.woocommerce div.product .summary p.price::after, 
		.woocommerce div.product .summary span.price::after,
		.woocommerce ul.products li.product a img,
		.enews input[type="text"], .enews input[type="email"],
		.home-section .enews input[type="text"], .home-section .enews input[type="email"],
		.footer-widgets-2 ul.menu li a {
			border-color: %1$s !important;
		}
		
		.home-section .widget_products ul.product_list_widget li img:hover {
			outline-color: %1$s !important;
		}
		
		.footer-widgets-5,
		.sidebar ul.instagram-pics li,
		.grid-page .content .entry .entry-header .entry-meta .entry-time,
		.woocommerce span.onsale,
		.enews input[type="submit"],
		.footer-widgets-2 ul.menu li a:hover {
			background-color: %1$s !important;
		}
			
		', $color_dark_theme ) : '';
		
		
	$css .= ( pl_customizer_get_default_button_color() !== $color_button ) ? sprintf( '

		button, 
		input[type="button"], 
		input[type="reset"], 
		input[type="submit"], 
		.button, a.button, 
		.woocommerce nav.woocommerce-pagination ul li a,
		.woocommerce nav.woocommerce-pagination ul li span,
		.woocommerce #respond input#submit,
		.woocommerce a.button,
		.woocommerce button.button,
		.woocommerce button.button.alt,
		.woocommerce a.button.alt,
		.woocommerce input.button,
		.woocommerce input.button.alt,
		.site-container button:disabled,
		.site-container button:disabled:hover,
		.site-container input:disabled,
		.site-container input:disabled:hover,
		.site-container input[type="button"]:disabled,
		.site-container input[type="button"]:disabled:hover,
		.site-container input[type="reset"]:disabled,
		.site-container input[type="reset"]:disabled:hover,
		.site-container input[type="submit"]:disabled,
		.site-container input[type="submit"]:disabled:hover,
		.enews input[type="submit"],
		.archive-pagination a {
			background-color: %1$s;
		}
		
		ul.filter a {
			border-color: %1$s !important;
		}
			
		', $color_button ) : '';
		
		
	$css .= ( pl_customizer_get_default_buttontext_color() !== $color_buttontext ) ? sprintf( '

		button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.button,
		a.button,
		.woocommerce nav.woocommerce-pagination ul li a,
		.woocommerce nav.woocommerce-pagination ul li span,
		.woocommerce #respond input#submit,
		.woocommerce a.button,
		.woocommerce button.button,
		.woocommerce button.button.alt,
		.woocommerce a.button.alt,
		.woocommerce input.button,
		.woocommerce input.button.alt,
		.enews input[type="submit"],
		.archive-pagination a {
			color: %1$s;
		}
			
		', $color_buttontext ) : '';
		
		
	$css .= ( pl_customizer_get_default_buttonhover_color() !== $color_buttonhover ) ? sprintf( '

		button:hover,
		input:hover[type="button"],
		input:hover[type="reset"],
		input:hover[type="submit"],
		.button:hover,
		.woocommerce nav.woocommerce-pagination ul li a:hover,
		.woocommerce nav.woocommerce-pagination ul li span:hover,
		.woocommerce #respond input#submit:hover,
		.woocommerce a.button:hover,
		.woocommerce button.button:hover,
		.woocommerce button.button.alt:hover,
		.woocommerce a.button.alt:hover,
		.woocommerce input.button:hover,
		.woocommerce input.button.alt:hover,
		.enews input:hover[type="submit"],
		a.cta-button.color-default:hover,
		.home-section .cta-button a:hover,
		.archive-pagination a:hover, 
		.archive-pagination .active a,
		ul.filter a:hover, ul.filter a.active {
			background-color: %1$s;
		}
		
		a.cta-button.color-default:hover,
		.home-section .cta-button a:hover,
		.archive-pagination a:hover, 
		.archive-pagination .active a,
		ul.filter a:hover, ul.filter a.active {
			border-color: %1$s !important;
		}
			
		', $color_buttonhover ) : '';
		
		
	$css .= ( pl_customizer_get_default_buttonhovertext_color() !== $color_buttonhovertext ) ? sprintf( '

		button:hover,
		input:hover[type="button"],
		input:hover[type="reset"],
		input:hover[type="submit"],
		.button:hover,
		.woocommerce nav.woocommerce-pagination ul li a:hover,
		.woocommerce nav.woocommerce-pagination ul li span:hover,
		.woocommerce #respond input#submit:hover,
		.woocommerce a.button:hover,
		.woocommerce button.button:hover,
		.woocommerce button.button.alt:hover,
		.woocommerce a.button.alt:hover,
		.woocommerce input.button:hover,
		.woocommerce input.button.alt:hover,
		.enews input:hover[type="submit"],
		code a.cta-button.color-default:hover,
		.home-section .cta-button a:hover,
		.archive-pagination a:hover, 
		.archive-pagination .active a {
			color: %1$s;
		}
			
		', $color_buttonhovertext ) : '';
		

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}