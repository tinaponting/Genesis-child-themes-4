<?php
/**
 * Blush Theme
 * @package 	Blush Theme
 */

 
// Start the engine
// --------------------------------------------------------
include_once( get_template_directory() . '/lib/init.php' );

// Child theme (do not remove)
// --------------------------------------------------------
define( 'CHILD_THEME_NAME', 'Blush Theme' );
define( 'CHILD_THEME_VERSION', '1.0.0' );


// ---------------------------------------------------------------------------------------------------------
// ACCESSIBILITY & SUPPORT >>
// ---------------------------------------------------------------------------------------------------------

// Set Localization (do not remove)
// --------------------------------------------------------
add_action( 'after_setup_theme', 'pl_localization_setup' );
function pl_localization_setup(){
	load_child_theme_textdomain( 'pl-blush', get_stylesheet_directory() . '/languages' );
}

// Add Image upload and Color select to WordPress Theme Customizer
// --------------------------------------------------------
require_once( get_stylesheet_directory() . '/lib/customize.php' );

// Install Reccomended Plugins
// --------------------------------------------------------
require_once( get_stylesheet_directory() . '/lib/plugins/tgm-plugin-activation/register-plugins.php' );

// Add Widget Spaces
// --------------------------------------------------------
require_once( get_stylesheet_directory() . '/lib/widgets.php' );

// Include Customizer CSS
// --------------------------------------------------------
include_once( get_stylesheet_directory() . '/lib/output.php' );

// Enqueue Scripts and Styles
// --------------------------------------------------------
add_action( 'wp_enqueue_scripts', 'pl_enqueue_scripts_styles' );
function pl_enqueue_scripts_styles() {

	wp_enqueue_style( 'pl-fonts', '//fonts.googleapis.com/css?family=Muli:400,400i|Lora:400,400i|Kristi', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'dashicons' );
	wp_enqueue_style( 'pl-font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
	wp_enqueue_style( 'pl-customwoo', CHILD_URL . '/css/custom-woo.css' );
	wp_enqueue_style( 'pl-normalize', CHILD_URL . '/css/normalize.css' );
	wp_enqueue_style( 'pl-sticky-nav', CHILD_URL . '/css/pl-stickynav.css' );
	
	wp_enqueue_script( 'pl-sticky-js', get_stylesheet_directory_uri() . '/js/sticky-menu.js', array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_enqueue_script( 'pl-global', get_stylesheet_directory_uri() . '/js/global.js', array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_enqueue_script( 'pl-fadeup-script', get_stylesheet_directory_uri() . '/js/fadeup.js', array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_enqueue_script( 'pl-to-top', get_stylesheet_directory_uri() . '/js/to-top.js', array( 'jquery' ), CHILD_THEME_VERSION, true );
	
	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'pl-responsive-menu', get_stylesheet_directory_uri() . "/js/responsive-menus{$suffix}.js", array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_localize_script(
		'pl-responsive-menu',
		'genesis_responsive_menu',
		pl_responsive_menu_settings()
	);
	
}

// Define our responsive menu settings
// --------------------------------------------------------
function pl_responsive_menu_settings() {

	$settings = array(
		'mainMenu'          => __( 'Menu', 'pl-blush' ),
		'menuIconClass'     => 'dashicons-before dashicons-menu',
		'subMenu'           => __( 'Submenu', 'pl-blush' ),
		'subMenuIconsClass' => 'dashicons-before dashicons-arrow-down-alt2',
		'menuClasses'       => array(
			'combine' => array(
				'.nav-primary',
				'.nav-secondary',
			),
			'others'  => array(),
		),
	);

	return $settings;

}

// Remove output of primary navigation right extras
// --------------------------------------------------------
remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );

// Add HTML5 markup structure
// --------------------------------------------------------
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

// Add Accessibility support
// --------------------------------------------------------
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

// Add viewport meta tag for mobile browsers
// --------------------------------------------------------
add_theme_support( 'genesis-responsive-viewport' );

// Setup widget counts for flexible widget
// --------------------------------------------------------
function pl_count_widgets( $id ) {

	$sidebars_widgets = wp_get_sidebars_widgets();

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

// Set the widget class for flexible widgets
// --------------------------------------------------------
function pl_widget_area_class( $id ) {

	$count = pl_count_widgets( $id );

	$class = '';

	if ( $count == 1 ) {
		$class .= ' widget-full';
	} elseif ( $count % 3 == 0 ) {
		$class .= ' widget-thirds';
	} elseif ( $count % 4 == 0 ) {
		$class .= ' widget-fourths';
	} elseif ( $count % 2 == 1 ) {
		$class .= ' widget-halves uneven';
	} else {
		$class .= ' widget-halves';
	}

	return $class;

}

// Unregister layout settings
// --------------------------------------------------------
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

// Unregister secondary sidebar
// --------------------------------------------------------
unregister_sidebar( 'sidebar-alt' );



// ---------------------------------------------------------------------------------------------------------
// IMAGES >>
// ---------------------------------------------------------------------------------------------------------


// Define New Image Sizes
// --------------------------------------------------------
add_image_size( 'post-feature', 1024, 512, TRUE );
add_image_size( 'featured', 560, 560, TRUE );
add_image_size( 'featured-small', 560, 360, TRUE );
add_image_size( 'home-grid-small', 270, 270, TRUE );
add_image_size( 'home-grid-large', 550, 550, TRUE );
add_image_size( 'sidebar', 335, 400, TRUE );
add_image_size( 'list-thumbnail', 300, 400, TRUE );
add_image_size( 'masonry-thumb', 400, 0, TRUE );
add_image_size( 'grid-image', 405, 200, TRUE );
add_image_size( 'side-post', 100, 100, TRUE );
add_image_size( 'portfolio', 450, 350, TRUE );



// ---------------------------------------------------------------------------------------------------------
// HEADER >>
// ---------------------------------------------------------------------------------------------------------

// Add support for custom header.
// --------------------------------------------------------
add_theme_support( 'custom-header', array(
	'width'           => 720,
	'height'          => 260,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

// Remove Header Right widget area.
// --------------------------------------------------------
unregister_sidebar( 'header-right' );



// ---------------------------------------------------------------------------------------------------------
// NAVIGATION >>
// ---------------------------------------------------------------------------------------------------------

// Add Primary Navigation's structural wrap
// --------------------------------------------------------
add_theme_support( 'genesis-structural-wraps', array(
    'header',
    'footer-widgets',
	'footer-widget-area',
    'footer'
	
) );

// Rename Menus
// --------------------------------------------------------
add_theme_support( 'genesis-menus', array(
	'primary'   => __( 'Header Left', 'pl-blush' ),
	'secondary' => __( 'Header Right', 'pl-blush' ),
) );

// Move Navigation to Site Header
// --------------------------------------------------------
remove_action( 'genesis_after_header', 'genesis_do_nav' );
remove_action( 'genesis_after_header', 'genesis_do_subnav' );

add_action( 'genesis_header', 'genesis_do_nav', 5 );
add_action( 'genesis_header', 'genesis_do_subnav', 5 );



// Add Cart To Menu Bar
// --------------------------------------------------------
add_filter('wp_nav_menu_items','pl_wcmenucart', 10, 2);
function pl_wcmenucart($menu, $args) {

	if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) || 'secondary' !== $args->theme_location )
		return $menu;

	ob_start();
		global $woocommerce;
		$viewing_cart = __('View your shopping cart', 'pl-blush');
		$start_shopping = __('Start shopping', 'pl-blush');
		$cart_url = $woocommerce->cart->get_cart_url();
		$shop_page_url = get_permalink( woocommerce_get_page_id( 'shop' ) );
		$cart_contents_count = $woocommerce->cart->cart_contents_count;
		$cart_contents = sprintf(_n('%d', '%d', $cart_contents_count, 'pl-blush'), $cart_contents_count);
		$cart_total = $woocommerce->cart->get_cart_total();
		// Uncomment the line below to hide nav menu cart item when there are no items in the cart
		// if ( $cart_contents_count > 0 ) {
			if ($cart_contents_count == 0) {
				$menu_item = '<li class="right nav-cart"><a class="wcmenucart-contents" href="'. $shop_page_url .'">';
			} else {
				$menu_item = '<li class="right nav-cart"><a class="wcmenucart-contents" href="'. $cart_url .'">';
			}

			$menu_item .= '<i class="fa fa-shopping-cart"></i> ';

			$menu_item .= $cart_contents.' - '. $cart_total;
			$menu_item .= '</a></li>';
		// Uncomment the line below to hide nav menu cart item when there are no items in the cart
		// }
		echo $menu_item;
	$social = ob_get_clean();
	return $menu . $social;

}


// ---------------------------------------------------------------------------------------------------------
// POSTS >>
// ---------------------------------------------------------------------------------------------------------


// Add support for after entry widget.
// --------------------------------------------------------
add_theme_support( 'genesis-after-entry-widget-area' );

// Add single post navigation
// --------------------------------------------------------
add_action( 'genesis_after_entry', 'genesis_prev_next_post_nav', 5 );
add_action( 'genesis_after_loop', 'genesis_adjacent_entry_nav', 5 );

// Display author box on single posts
// --------------------------------------------------------
add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );
remove_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );
add_action( 'genesis_before_comments', 'genesis_do_author_box_single', 8 );

// Show Featured Image in Single Posts
// --------------------------------------------------------
add_action( 'genesis_entry_content', 'pl_show_featured_image_single_posts', 5 );
function pl_show_featured_image_single_posts() {
	if ( ! is_singular( 'post' ) ) {
		return;
	}
	$image_args = array(
		'size' => 'full',
	);
	genesis_image( $image_args );
}

// Modify the size of the Gravatar in the entry comments
// --------------------------------------------------------
add_filter( 'genesis_comment_list_args', 'pl_comments_gravatar' );
function pl_comments_gravatar( $args ) {

	$args['avatar_size'] = 75;
	return $args;

}

// Modify the size of the Gravatar in the author box
// --------------------------------------------------------
add_filter( 'genesis_author_box_gravatar_size', 'pl_author_box_gravatar' );
function pl_author_box_gravatar( $size ) {

	return 100;

}

// Modify the size of the Gravatar in the Genesis User Profile Widget
// --------------------------------------------------------
add_filter( 'genesis_gravatar_sizes', 'pl_user_profile' );
function pl_user_profile( $sizes ) {
	$sizes['XXLarge'] = 300;
	return $sizes;
}

// Modify the Genesis content limit read more link
// --------------------------------------------------------
add_filter( 'get_the_content_more_link', 'pl_read_more_link' );
function pl_read_more_link() {
	return '...<span class="cta-button"><a href="' . get_permalink() . '">Read More</a></span>';
}

// Move Author to Bottom
// --------------------------------------------------------
add_action( 'genesis_entry_footer', 'pl_move_byline', 10);
function pl_move_byline() {
	if ( !is_page() ) {
		echo do_shortcode('[post_author before="by " after=""]');
	}
}

// Move Comments to Bottom
// --------------------------------------------------------
add_action( 'genesis_entry_footer', 'pl_move_comments', 7);
function pl_move_comments() {
	if ( !is_page() ) {
		echo do_shortcode('[post_comments zero="No Comments" one="1 Comment" more="% Comments" hide_if_off="disabled"]');
	}
}

// Customize entry meta in the entry header
// --------------------------------------------------------
add_filter( 'genesis_post_info', 'pl_date_filter' );
function pl_date_filter( $post_date ) {
	if ( !is_page() ) {
		$post_date = '[post_date]';
	}
	return $post_date;
}

// Customize entry meta in the entry footer
// --------------------------------------------------------
add_filter( 'genesis_post_meta', 'pl_meta_filter' );
function pl_meta_filter($post_meta) {
if ( !is_page() ) {
	$post_meta = '[post_categories before=""] [post_tags before=""]';
	return $post_meta;
}}



// ---------------------------------------------------------------------------------------------------------
// SHORTCODES >>
// ---------------------------------------------------------------------------------------------------------

// Add Shortcodes to Widgets
// --------------------------------------------------------
add_filter('widget_text', 'do_shortcode');


// Call To Action Button Shortcode
// --------------------------------------------------------
function ctabutton_shortcode( $atts, $content = 'Click Here' ) {
	extract(shortcode_atts(array(
		'color' => 'grey',
		'url' => '#'
	), $atts));
	
	$ctabutton = '<a class="button cta-button color-' . esc_attr( $color ) . '" href="' . esc_url( $url ) . '">' . esc_attr( $content ) . '</a>';
	return $ctabutton;
}
add_shortcode( 'cta-button', 'ctabutton_shortcode' );



// ---------------------------------------------------------------------------------------------------------
// WOOCOMMERCE >>
// ---------------------------------------------------------------------------------------------------------

// Add WooCommerce support
// --------------------------------------------------------
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-setup.php' );

// Add the Genesis Connect WooCommerce notice.
// --------------------------------------------------------
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-notice.php' );



// ---------------------------------------------------------------------------------------------------------
// SIDEBAR >>
// ---------------------------------------------------------------------------------------------------------

// Pre-Load Simple Social Icons Defaults
// --------------------------------------------------------
add_filter( 'simple_social_default_styles', 'minmimum_default_style' );
function minmimum_default_style( $defaults ) {

	$defaults['size']                      = '32';
	$defaults['border_radius']             = '0';
	$defaults['icon_color']	               = '#000';
	$defaults['icon_color_hover']          = '#e8e8e8';
	$defaults['background_color']          = 'transparent';
	$defaults['background_color_hover']    = 'transparent';
	$defaults['alignment']                 = 'aligncenter';

	return $defaults;

}


// ---------------------------------------------------------------------------------------------------------
// FOOTER >>
// ---------------------------------------------------------------------------------------------------------

// Add To Top button
// --------------------------------------------------------
add_action( 'genesis_before', 'genesis_to_top');
	function genesis_to_top() {
	 echo '<a href="#0" class="to-top" title="Back To Top">Top</a>';
}

// Add support for 4-column footer widgets.
// --------------------------------------------------------
add_theme_support( 'genesis-footer-widgets', 5 );

// Change Footer Text & Copyright
// --------------------------------------------------------
add_filter( 'genesis_footer_creds_text', 'pl_footer_creds_filter' );
function pl_footer_creds_filter( $creds ) {
	$creds = '[footer_copyright before="Copyright "] [footer_childtheme_link before ="&middot; "] by <a href="httpS://exemple.se">EXEMPLE</a>';

	return $creds;
}