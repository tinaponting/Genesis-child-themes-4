<?php
/**
 * This file adds the blog page template to the Paper Lotus Theme.
 * @package 	Blush Theme
 *
 */

/*
Template Name: Blog Page
*/

genesis();