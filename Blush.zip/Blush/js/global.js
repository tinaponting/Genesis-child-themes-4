jQuery(function( $ ){

	$('#main-nav-search-link').click(function(){
		$('.search-div').slideToggle('fast');
	});

});