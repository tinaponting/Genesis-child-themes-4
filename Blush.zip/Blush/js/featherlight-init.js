jQuery(function( $ ){
		$('.thumblight').featherlightGallery();
});