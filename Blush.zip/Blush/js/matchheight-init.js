jQuery(function( $ ){

	$('.sprinkle-archives .content .entry, .front-page .blog .entry, .category-index .featured-content .entry').matchHeight();

});