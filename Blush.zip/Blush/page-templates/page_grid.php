<?php
/**
 * Blush Theme
 * @package			Blush Theme
 * Template Name:   Grid Blog Layout
 */

 
// Grab the Posts and Run Loop
// -----------------------------------------------------------------------------------
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'pl_grid_loop' );
function pl_grid_loop() {

	$include = genesis_get_option( 'blog_cat' );
	$exclude = genesis_get_option( 'blog_cat_exclude' ) ? explode( ',', str_replace( ' ', '', genesis_get_option( 'blog_cat_exclude' ) ) ) : '';
	$paged   = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;

	$query_args = wp_parse_args(

		genesis_get_custom_field( 'query_args' ),

		array(
			'cat'              => $include,
			'category__not_in' => $exclude,
			'showposts'        => genesis_get_option( 'blog_cat_num' ),
			'paged'            => $paged,
		)
	);

	genesis_custom_loop( $query_args );

	wp_reset_postdata();

}


// Arrange Posts into Grid Layout
// -----------------------------------------------------------------------------------

add_action( 'get_header', 'pl_posts_in_columns' );
function pl_posts_in_columns() {

	add_filter( 'post_class', 'be_archive_post_class' );	

	remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
	remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
	remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
	remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
	remove_action( 'genesis_entry_footer', 'genesis_post_meta' );

	add_action( 'genesis_entry_content', 'pl_do_post_image', 8 );
	add_action( 'genesis_entry_header', 'genesis_post_meta', 13 );

}


// Column Class
// -----------------------------------------------------------------------------------

function be_archive_post_class( $classes ) {

	// Don't run on single posts or pages
	if( is_singular() )

		return $classes;

	$classes[] = 'one-half';

	global $wp_query;

	if( 0 == $wp_query->current_post || 0 == $wp_query->current_post % 2 )

		$classes[] = 'first';

	return $classes;

}


// Grab Post Image Thumb
// -----------------------------------------------------------------------------------

function pl_do_post_image() {

	$image_args = array(

	 	'size' => 'grid-image'

	);

	echo '<div class="grid-image"><a href="' . get_permalink() . '">' . genesis_get_image( $image_args ) . '</a></div>';

}


// Force Content Limit regardless of Content Archive theme settings
// -----------------------------------------------------------------------------------
add_filter( 'genesis_pre_get_option_content_archive', 'pl_show_full_content' );
add_filter( 'genesis_pre_get_option_content_archive_limit', 'pl_content_limit' );
function pl_show_full_content() {

	return 'full';

}

function pl_content_limit() {

	return '180'; // Limit content characters

}


// Add custom body class to the head
// -----------------------------------------------------------------------------------
add_filter( 'body_class', 'pl_body_class' );
function pl_body_class( $classes ) {

	$classes[] = 'grid-page page-template-page_blog';

	return $classes;

}


// Customize Entry Meta in Post Header
// -----------------------------------------------------------------------------------
add_filter( 'genesis_post_info', 'pl_post_info_filter' );
function pl_post_info_filter($post_info) {

	$post_info = '[post_date]';

	return $post_info;

}


// Customize Entry Meta in Post Footer
// -----------------------------------------------------------------------------------
add_filter( 'genesis_post_meta', 'pl_post_meta_filter' );
function pl_post_meta_filter($post_meta) {

	$post_meta = '[post_categories before=""]';

	return $post_meta;

}


// Run the Genesis loop
// -----------------------------------------------------------------------------------
genesis();