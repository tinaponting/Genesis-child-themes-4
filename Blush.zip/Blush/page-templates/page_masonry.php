<?php
/**
 * Blush Theme
 * @package			Blush Theme
 * Template Name:   Masonry Blog Layout
 */

 
// Enqueue Masonry
// -----------------------------------------------------------------------------------
wp_enqueue_script( 'masonry' );


// Initialize Masonry
// -----------------------------------------------------------------------------------
wp_enqueue_script( 'masonry-init', get_bloginfo( 'stylesheet_directory' ) . '/js/masonry-init.js', '', '', true );


// Add custom body class to the head
// -----------------------------------------------------------------------------------
add_filter( 'body_class', 'pl_body_class' );
function pl_body_class( $classes ) {

	$classes[] = 'masonry-page page-template-page_blog';
	return $classes;

}


// Grab All Posts and Run Loop
// -----------------------------------------------------------------------------------
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'pl_masonry_loop' );
function pl_masonry_loop() {

	$include = genesis_get_option( 'blog_cat' );
	$exclude = genesis_get_option( 'blog_cat_exclude' ) ? explode( ',', str_replace( ' ', '', genesis_get_option( 'blog_cat_exclude' ) ) ) : '';
	$paged   = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;

	$query_args = wp_parse_args(

		genesis_get_custom_field( 'query_args' ),

		array(
			'cat'              => $include,
			'category__not_in' => $exclude,
			'showposts'        => genesis_get_option( 'blog_cat_num' ),
			'paged'            => $paged,
		)
	);
	
	genesis_custom_loop( $query_args );

}


// Force Content Limit regardless of Content Archive theme settings
// -----------------------------------------------------------------------------------
add_filter( 'genesis_pre_get_option_content_archive', 'pl_show_full_content' );
add_filter( 'genesis_pre_get_option_content_archive_limit', 'pl_content_limit' );
function pl_show_full_content() {

	return 'full';

}

function pl_content_limit() {

	return '150'; // Limit content characters

}


// Remove author and comment link in entry header's entry meta
// -----------------------------------------------------------------------------------
add_filter( 'genesis_post_info', 'pl_post_info_filter' );
function pl_post_info_filter($post_info) {

	$post_info = '[post_date]';
	
	return $post_info;

}


// Display Featured image linking to entry
// -----------------------------------------------------------------------------------
function pl_image() {

	$image_args = array(

		'size' => 'masonry-thumb'

	);

	// Get the featured image HTML
	$image = genesis_get_image( $image_args );
	echo '<a rel="bookmark" href="'. get_permalink() .'">'. $image .'</a>';

}


// Run the Genesis loop
// -----------------------------------------------------------------------------------
genesis();