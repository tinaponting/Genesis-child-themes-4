<?php
/**
 * Blush Theme
 * @package			Blush Theme
 * Template Name:   List Blog Layout
 */
 
 
// Grab the Posts and run loop
// -----------------------------------------------------------------------------------
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'pl_grid_loop' );
function pl_grid_loop() {

	$include = genesis_get_option( 'blog_cat' );
	$exclude = genesis_get_option( 'blog_cat_exclude' ) ? explode( ',', str_replace( ' ', '', genesis_get_option( 'blog_cat_exclude' ) ) ) : '';

	$paged   = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;

	//* Easter Egg
	$query_args = wp_parse_args(

		genesis_get_custom_field( 'query_args' ),

		array(
			'cat'              => $include,
			'category__not_in' => $exclude,
			'showposts'        => genesis_get_option( 'blog_cat_num' ),
			'paged'            => $paged,
		)

	);

	genesis_custom_loop( $query_args );

	wp_reset_postdata();

}


// Add custom body class to the head
// -----------------------------------------------------------------------------------
add_filter( 'body_class', 'pl_body_class' );
function pl_body_class( $classes ) {

	$classes[] = 'list-page page-template-page_blog';

	return $classes;

}



// Remove post info, post title, content and post meta and add post title and content for entries
// -----------------------------------------------------------------------------------
add_action ('genesis_meta','pl_remove_post_stuff_list');
function pl_remove_post_stuff_list() {

	remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
	remove_action( 'genesis_entry_content', 'genesis_do_post_image' );

	add_action( 'genesis_entry_content', 'genesis_do_post_content' );

}


// Force Content Limit regardless of Content Archive theme settings
// -----------------------------------------------------------------------------------
add_filter( 'genesis_pre_get_option_content_archive', 'pl_show_full_content' );
add_filter( 'genesis_pre_get_option_content_archive_limit', 'pl_content_limit' );
function pl_show_full_content() {

	return 'full';

}

function pl_content_limit() {

	return '400'; // Limit content to 400 characters

}


// Add List Layout Featured Image
// -----------------------------------------------------------------------------------
add_action ( 'genesis_entry_header', 'pl_featured_image_title', 8 );
function pl_featured_image_title() {

	if ( !has_post_thumbnail() )

		return;

	echo '<div class="list-thumb">';

	genesis_image( array( 'size' => 'list-thumbnail' ) );

	echo '</div>';

}


// Now Remove the post image
// -----------------------------------------------------------------------------------
remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );


// Run the Genesis loop
// -----------------------------------------------------------------------------------
genesis();