<?php

/**
* @package      Ariaina
* @link         http://tinselpop.com
* @author       TinselPop
* @copyright    Copyright (c) 2015, TinselPop
* @license      GPL-2.0+
*/

//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'genesis-sample', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'genesis-sample' ) );

//* Add Image upload and Color select to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Include Customizer CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Hello Beautiful' );
define( 'CHILD_THEME_URL', 'http://www.tinselpop.com' );
define( 'CHILD_THEME_VERSION', '2.2.4' );

//* Enqueue Scripts and Styles
add_action( 'wp_enqueue_scripts', 'genesis_sample_enqueue_scripts_styles' );
function genesis_sample_enqueue_scripts_styles() {

	wp_enqueue_style( 'google-font-Poppins', '//fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap', array(), CHILD_THEME_VERSION );

	wp_enqueue_style( 'google-font-merriweather', '//fonts.googleapis.com/css?family=Nunito+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap', array(), CHILD_THEME_VERSION );

	wp_enqueue_style( 'google-font-Open+Sans', '//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i', array(), CHILD_THEME_VERSION );
	
	wp_enqueue_style( 'google-font-Playfair+Display', '//fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i,900,900i', array(), CHILD_THEME_VERSION );

	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );

	wp_enqueue_style( 'dashicons' );



}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

//* Add Accessibility support
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'width'           => 800,
	'height'          => 220,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Add support for 3-column footer widgets
add_theme_support( 'genesis-footer-widgets', 3 );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Remove content/sidebar/sidebar layout
genesis_unregister_layout( 'content-sidebar-sidebar' );

//* Remove sidebar/sidebar/content layout
genesis_unregister_layout( 'sidebar-sidebar-content' );
 
//* Remove sidebar/content/sidebar layout
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Add the recent post slider to the home page
genesis_register_sidebar( array(
	'id'			=> 'home-slider',
	'name'			=> __( 'Home Slider', 'beautiful' ),
	'description'	=> __( 'This is the home page slider area.', 'beautiful' ),
) );

add_action( 'genesis_before_content', 'beautiful_home_slider' );

function beautiful_home_slider() {
	if ( is_home() || is_front_page() ) {
		genesis_widget_area( 'home-slider', array(
			'before' => '<div class="home-slider"><div class="wrap">',
			'after' => '</div></div>',
		) );
	}
}


//* Customize the entry meta in the entry header (requires HTML5 theme support)
add_filter( 'genesis_post_info', 'sp_post_info_filter' );
function sp_post_info_filter($post_info) {
	$post_info = '[post_date]  [post_comments before="&nbsp; &nbsp; &nbsp;"]';
	return $post_info;
}

//* Remove the entry meta in the entry footer (requires HTML5 theme support)
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );


//* Modify the WordPress read more link
add_filter( 'the_content_more_link', 'sp_read_more_link' );
add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
add_filter('excerpt_more', 'sp_read_more_link');
function sp_read_more_link() {
	return '... <p class="more-paragraph"><a class="more-link" href="' . get_permalink() . '">Read More..</a></p>';
}

//* Customize search form input box text
add_filter( 'genesis_search_text', 'sp_search_text' );
function sp_search_text( $text ) {
	return esc_attr( 'Search...' );
}

//* Register category page widget
genesis_register_sidebar( array(
	'id'		=> 'category-index',
	'name'		=> __( 'Category Index', 'beautiful' ),
	'description'	=> __( 'This is the widget area for the category page.', 'beautiful' ),
) );

//* Add Excerpt Support to Pages
add_post_type_support('page', 'excerpt');

//* Adds custom excerpt field for the shop the post
add_post_type_support('post', 'excerpt');


//* Add Image Sizes
add_image_size( 'thumbnail-horizontal', 425, 275, true );
add_image_size( 'thumbnail-vertical', 425, 575, true );
add_image_size( 'thumbnail-square', 425, 425, true );
add_image_size( 'featured-horizontal', 1200, 800, true );


genesis_register_sidebar( array(
	'id'          => 'nav-social-menu',
	'name'        => __( 'Nav Social Menu', 'your-theme-slug' ),
	'description' => __( 'This is the nav social menu section.', 'your-theme-slug' ),
) );

add_filter( 'genesis_nav_items', 'sws_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'sws_social_icons', 10, 2 );

function sws_social_icons($menu, $args) {
	$args = (array)$args;
	if ( 'primary' !== $args['theme_location'] )
		return $menu;
	ob_start();
	genesis_widget_area('nav-social-menu');
	$social = ob_get_clean();
	return $menu . $social;
}

if ( ! isset( $content_width ) )
/**set width below **/
 $content_width = 1200;

/* ------------------------------------------------------------------
   Register Full Width Widget Area for Instagram Feed
------------------------------------------------------------------ */

genesis_register_sidebar( array(
	'id'            => 'instagram-feed',
	'name'          => __( 'Instagram Feed', 'oheartsan' ),
	'description'   => __( 'Full width widget area above footer for Instagram feed', 'oheartsan' ),
) );


/* ------------------------------------------------------------------
   Display Full Width Widget Area for Instagram Feed
------------------------------------------------------------------ */

function ab_instagram_feed() {

	genesis_widget_area( 'instagram-feed', array(
			'before' => '<div class="instagram-feed">',
			'after' => '</div>',
		) );

}
add_action( 'genesis_before_footer', 'ab_instagram_feed' );

genesis_register_sidebar( array(
	'id'			=> 'home-slider',
	'name'			=> __( 'Home Slider', 'prose' ),
	'description'	=> __( 'This is the slider widget area for your homepage.', 'prose' ),
) );



//* Declare WooCommerce Support
add_theme_support( 'woocommerce' );

// Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'custom_scripts_styles_mobile_responsive' );
function custom_scripts_styles_mobile_responsive() {

	wp_enqueue_script( 'beautiful-responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_style( 'dashicons' );

}


// hide coupon field on cart page
function hide_coupon_field_on_cart( $enabled ) {
	if ( is_cart() ) {
		$enabled = false;
	}
	return $enabled;
}
add_filter( 'woocommerce_coupons_enabled', 'hide_coupon_field_on_cart' );

add_filter( 'woocommerce_show_page_title' , 'woo_hide_page_title' );
/**
 * woo_hide_page_title
 *
 * Removes the "shop" title on the main shop page
 *
 * @access      public
 * @since       1.0 
 * @return      void
*/
function woo_hide_page_title() {
	
	return false;
	
}

// Removes showing results
 
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );


/**
 * Setup widget counts.
 *
 * @param string $id The widget area ID.
 * @return int Number of widgets in the widget area.
 */
function custom_count_widgets( $id ) {
    global $sidebars_widgets;

    if ( isset( $sidebars_widgets[ $id ] ) ) {
        return count( $sidebars_widgets[ $id ] );
    }
}

/**
 * Set the widget class for flexible widgets.
 *
 * @param string $id The widget area ID.
 * @return Name of column class.
 */
function custom_widget_area_class( $id ) {
    $count = custom_count_widgets( $id );

    $class = '';

    if ( 1 === $count ) {
        $class .= ' widget-full';
    } elseif ( 0 === $count % 3 ) {
        $class .= ' widget-thirds';
    } elseif ( 0 === $count % 4 ) {
        $class .= ' widget-fourths';
    } elseif ( 1 === $count % 2 ) {
        $class .= ' widget-halves uneven';
    } else {
        $class .= ' widget-halves';
    }

    return $class;
}




/** Add new featured image sizes */
add_image_size( 'featured-category', 300, 75, TRUE );

/** Register New Widget */
genesis_register_sidebar( array(
	'id'          => 'category-top',
	'name'        => __( 'Category - Top', '$text_domain' ),
	'description' => __( 'This is the top section of the home page.', '$text_domain' ),
) );
/**
* @author Brad Dalton - WP Sites
* @example http://wpsites.net/web-design/add-featured-widgets-inline-anywhere-in-genesis/
*/

/** Change The Conditional Tags & Hook To Display In Different Positions & Locations */
add_action( 'genesis_before_content_sidebar_wrap', 'category_featured_posts' );

function category_featured_posts() {

	if ( is_active_sidebar( 'category-top' ) ) {
	
		genesis_widget_area( 'category-top', array(
		'before' => '<div class="category-top widget-area">',
		'after'  => '</div>',
	) );
}}
