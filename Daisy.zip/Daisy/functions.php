<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'daisy' );
define( 'CHILD_THEME_VERSION', '1.0.1' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'genesis_sample_google_fonts' );
function genesis_sample_google_fonts() {

	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Lora|Open+Sans', array(), CHILD_THEME_VERSION );
	// If WooCommerce is installed, add Custom CSS for WooCommerce
	if ( class_exists( 'woocommerce' ) ) {
		wp_enqueue_style( 'custom-stylesheet', CHILD_URL . '/woocommerce/woocommerce.css', array() );
	}

}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Connect to WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

/* Do theme setup on the 'after_setup_theme' hook. */
add_action( 'after_setup_theme', 'daisy_theme_setup', 11 );
/**
 * Theme setup function.
 */
function daisy_theme_setup(){
    /* updater args */
    $updater_args = array(
        'repo_uri'  => 'https://exempel.com/',
        'repo_slug' => 'daisy',
        'key'       => '',
        'dashboard' => false,
        'username'  => false,
    );
    /* add support for updater */
    add_theme_support( 'auto-hosted-child-theme-updater', $updater_args );
}
/* Load Child Theme Updater */
require_once( trailingslashit( get_stylesheet_directory() ) . 'includes/child-theme-updater.php' );
new Daisy_Theme_Updater;

//* Unregister content/sidebar/sidebar layout setting
genesis_unregister_layout( 'content-sidebar-sidebar' );
 
//* Unregister sidebar/sidebar/content layout setting
genesis_unregister_layout( 'sidebar-sidebar-content' );
 
//* Unregister sidebar/content/sidebar layout setting
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Unregister sidebar
unregister_sidebar( 'header-right' );
unregister_sidebar( 'sidebar-alt' );

//* Add image sizes
add_image_size( 'horizontal', 450, 350, TRUE );
add_image_size( 'square', 450, 450, TRUE );
add_image_size( 'vertical', 350, 450, TRUE );
add_image_size( 'horizontal-long', 450, 250, TRUE );

//* Create style options
add_theme_support( 'genesis-style-selector', array(
	'theme-orange'		=> __( 'Orange', 'daisy' ),
	'theme-red'			=> __( 'Red', 'daisy' ),
	'theme-purple'		=> __( 'Purple', 'daisy' )
) );

//* Move the primary navigation before the header
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action ('genesis_before_header', 'genesis_do_nav' );

//* Register top left widget area 
genesis_register_sidebar( array(
	'id'            => 'home-top-left',
	'name'          => __( 'Home Top Left', 'daisy' ),
	'description'   => __( 'This is the widget area at the top left side of your home page.', 'daisy' ),
) );

//* Register top right widget area 
genesis_register_sidebar( array(
	'id'            => 'home-top-right',
	'name'          => __( 'Home Top Right', 'daisy' ),
	'description'   => __( 'This is the top right widget area.', 'daisy' ),
) );

//* Register middle widget area 
genesis_register_sidebar( array(
	'id'            => 'home-middle',
	'name'          => __( 'Home Middle', 'daisy' ),
	'description'   => __( 'This is the middle widget area on the home page.', 'daisy' ),
) );

//* Change the footer text
add_filter('genesis_footer_creds_text', 'daisy_footer_creds_filter');
function daisy_footer_creds_filter( $creds ) {
	$creds = 'Copyright [footer_copyright] | <a href="https://exempel.com/">EXEMPEL</a> by <a href="https://exempel.com/">EXEMPEL</a>';
	return $creds;
}

//* Modify the Genesis content limit read more link
add_filter( 'get_the_content_more_link', 'daisy_read_more_link' );
function daisy_read_more_link() {
	return '... <a class="more-link" href="' . get_permalink() . '">Read More</a>';
}

//* Remove related products on single page
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
