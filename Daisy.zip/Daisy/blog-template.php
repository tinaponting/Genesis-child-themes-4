<?php

//* Template Name: Blog

//* Show page content above posts
add_action( 'genesis_loop', 'genesis_standard_loop', 5 );

genesis();