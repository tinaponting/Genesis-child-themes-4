<?php 
/**
* Home page layout for the Mandolin Theme
* @package Mandolin
* 
*/

add_action( 'genesis_meta', 'daisy_home_meta' );
function daisy_home_meta() {
	
	if ( is_active_sidebar( 'home-top-left' ) || is_active_sidebar( 'home-top-right' ) || is_active_sidebar( 'home-middle' )) {
		
		//* Remove loop from homepage
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		
		//* Add widget function
		add_action( 'genesis_loop', 'daisy_home_widgets' );
		
		//* Force full width layout setting
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
		
		//* Add a body class to the home page
		add_filter( 'body_class', 'daisy_home_body_class' );
		
	}
}

//* Display the widgets
function daisy_home_widgets() {
	
	echo '<div class="home-top">';
	
		genesis_widget_area( 'home-top-left', array(
			'before' => '<div class="home-top-left widget-area">',
			'after'  => '<div class="clear"></div></div>',
		));		
		
		genesis_widget_area( 'home-top-right', array(
			'before' => '<div class="home-top-right widget-area">',
			'after'  => '<div class="clear"></div></div>'
		));
		
	echo '</div>';
	
	echo '<div class="home-middle-center">';
	
		genesis_widget_area( 'home-middle', array(
			'before' => '<div class="home-middle-widget widget-area">',
			'after'  => '<div class="clear"></div></div>'
		));
		
	echo '</div>';

}

//* Add a body class to the home page
function daisy_home_body_class( $classes ) {

		$classes[] = 'daisy-home';
		return $classes;

}

genesis();