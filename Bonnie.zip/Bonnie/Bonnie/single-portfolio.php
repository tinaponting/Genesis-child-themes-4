<?php
/**
 * Portfolio Single
 *
 */
 add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

// Remove items from loop
remove_action( 'genesis_entry_header', 'genesis_post_info', 12 );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );

/**
 * Add Portfolio Image
 *
 */
function be_portfolio_image() {
	echo wpautop( '<a href="' . get_permalink() . '">' . genesis_get_image( array( 'size' => 'portfolio' ) ). '</a>' );
}
add_action( 'genesis_before_entry', 'be_portfolio_image' );
add_filter( 'genesis_pre_get_option_content_archive_thumbnail', '__return_false' );


genesis();