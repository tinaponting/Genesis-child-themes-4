<?php
/* * @package Daisy Theme */
genesis_structural_wrap( 'site-inner', 'close' );
echo '</div>'; //* end .site-inner or #inner
do_action( 'genesis_before_footer' );
do_action( 'genesis_footer' );
do_action( 'genesis_after_footer' );echo '</div>'; //* end .site-container or #wrap
do_action( 'genesis_after' );
wp_footer(); //* we need this for plugins?><!-----------------------------   Add Responsive Menu   -------------------------------->
<script src='http://codepen.io/assets/editor/live/css_live_reload_init.js'></script>
	<script>
	( function( window, $, undefined ) {	'use strict';	$( 'nav' ).before( '<button class="menu-toggle" role="button" aria-pressed="false"></button>' ); // Add toggles to menus	$( 'nav .sub-menu' ).before( '<button class="sub-menu-toggle" role="button" aria-pressed="false"></button>' ); // Add toggles to sub menus	// Show/hide the navigation	$( '.menu-toggle, .sub-menu-toggle' ).on( 'click', function() {		var $this = $( this );		$this.attr( 'aria-pressed', function( index, value ) {			return 'false' === value ? 'true' : 'false';		});		$this.toggleClass( 'activated' );
		$this.next( 'nav, .sub-menu' ).slideToggle( 'fast' );		
	});})( this, jQuery );	</script>
<!-----------------------------   Next...   -------------------------------->	
</body>
</html>
