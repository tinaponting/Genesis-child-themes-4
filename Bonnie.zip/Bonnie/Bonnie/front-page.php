<?php/** * This file adds the Home Page to the Daisy Theme. * @package Daisy Theme * @subpackage Customizations */
add_action( 'genesis_meta', 'daisy_home_genesis_meta' );/* * Add widget support for homepage. If no widgets active, display the default loop. */function daisy_home_genesis_meta() {		if ( is_active_sidebar( 'home-page' ) ) {				//* Force sidebar-content-sidebar layout setting		add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );		
		//* Remove breadcrumbs		remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );		
		//* Remove the default Genesis loop		remove_action( 'genesis_loop', 'genesis_do_loop' );		
		//* Add home widgets		add_action( 'genesis_loop', 'beatrice_home_widgets' );	}}function beatrice_home_widgets() {	genesis_widget_area( 'home-page', array(		'before' => '<div class="home-page">',		'after'  => '</div>',	) );}
genesis();