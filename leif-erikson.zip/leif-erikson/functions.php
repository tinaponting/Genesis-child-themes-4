<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Leif Erikson' );
define( 'CHILD_THEME_VERSION', '2.2' );

//* Enqueue Google Fonts
add_action( 'wp_enqueue_scripts', 'genesis_custom_google_fonts' );
function genesis_custom_google_fonts() {

	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Quando|Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800', array(), CHILD_THEME_VERSION );

}

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'genesis_scripts_styles_mobile_responsive' );
function genesis_scripts_styles_mobile_responsive() {
	wp_enqueue_script( 'responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_style( 'dashicons' );
}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for custom background
add_theme_support( 'custom-background' );

//* Remove Genesis child theme style sheet
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
 
//* Enqueue Genesis child theme style sheet at higher priority
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

//* Add support for 1 footer widget
add_theme_support( 'genesis-footer-widgets', 1 );

//* Unregister sidebars
unregister_sidebar( 'sidebar' );
unregister_sidebar( 'sidebar-alt' );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content' );
genesis_unregister_layout( 'content-sidebar' );

//* Force full width layout selection
add_filter( 'genesis_pre_get_option_site_layout', 'genesis_do_layout' );
function genesis_do_layout( $opt ) {
    $opt = 'full-width-content';
    return $opt;
}

//* Unregister primary/secondary navigation menus
remove_theme_support( 'genesis-menus' );

//* Rename header right
unregister_sidebar( 'header-right' );
genesis_register_sidebar( array( 'id' => 'header-right', 'name' => 'Header' ) );

//* Display author box on archive pages & single posts
add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );
add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );