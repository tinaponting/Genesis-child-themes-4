<?php
/**
	Theme Name: Julia Theme
	Theme URI: http://lovelyconfetti.com/shop
	Description: A mobile responsive and HTML5 theme built for the Genesis Framework.
	Author: Cristina Sanz
	Author URI: http://lovelyconfetti.com/
	Version: 1.0.0
 */

add_action( 'wp_enqueue_scripts', 'julia_css' );
/**
* Checks the settings for the link color, and accent color.
* If any of these value are set the appropriate CSS is output.
*
* @since 1.0.0
*/
function julia_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$opts = apply_filters( 'julia_images', array( '1', '3', '5', '7' ) );

	$settings = array();

	foreach( $opts as $opt ){
		$settings[$opt]['image'] = preg_replace( '/^https?:/', '', get_option( $opt .'-julia-image', sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $opt ) ) );
	}

	$css = '';

	foreach ( $settings as $section => $value ) {

		$background = $value['image'] ? sprintf( 'background-image: url(%s);', $value['image'] ) : '';

		if( is_front_page() ) {
			$css .= ( ! empty( $section ) && ! empty( $background ) ) ? sprintf( '.front-page-image-%s { %s }', $section, $background ) : '';
		}

	}



	

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}
