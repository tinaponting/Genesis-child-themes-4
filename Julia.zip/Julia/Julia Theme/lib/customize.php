<?php
/**
	Theme Name: Hilary Theme
	Theme URI: http://lovelyconfetti.com/shop
	Description: A mobile responsive and HTML5 theme built for the Genesis Framework.
	Author: Cristina Sanz
	Author URI: http://lovelyconfetti.com/
	Version: 1.0.0
 */

/**
 * Get default link color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for link color.
 */
function hilary_customizer_get_default_link_color() {
	return '#e36344';
}

/**
 * Get default accent color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for accent color.
 */
 
function hilary_customizer_get_default_accent_color() {
	return '#5da44f';
}

add_action( 'customize_register', 'hilary_customizer_register' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function hilary_customizer_register() {

	global $wp_customize;

	$images = apply_filters( 'hilary_images', array( '1', '3', '5', '7' ) );

	$wp_customize->add_section( 'hilary-settings', array(
		'description' => __( 'Use the included default images or personalize your site by uploading your own images.<br /><br />The default images are <strong>1800 pixels wide and 1000 pixels tall</strong>.', 'hilary' ),
		'title'    => __( 'Front Page Background Images', 'hilary' ),
		'priority' => 80.1,
	) );

	foreach( $images as $image ){

		$wp_customize->add_setting( $image .'-hilary-image', array(
			'default'  => sprintf( '%s/images/bg-%s.jpg', get_stylesheet_directory_uri(), $image ),
			'type'     => 'option',
		) );

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				$image .'-hilary-image',
				array(
					'label'    => sprintf( __( 'Featured Section %s Image:', 'hilary' ), $image ),
					'section'  => 'hilary-settings',
					'settings' => $image .'-hilary-image',
					'priority' => $image+1,
				) 
			)
		);

	}

	
    //* Add single image section to the Customizer
    $wp_customize->add_section(
		'hilary_single_image_section',
		array(
			'title'       => __( 'Post and Page Images', 'hilary' ),
			'description' => __( 'Choose if you would like to display the featured image above the content on single posts and pages.', 'hilary' ),
			'priority' => 158.85,
		)
	);

    //* Add single image setting to the Customizer
    $wp_customize->add_setting(
		'hilary_single_image_setting',
		array(
			'default'           => true,
			'capability'        => 'edit_theme_options',
		)
	);

    $wp_customize->add_control(
		'hilary_single_image_setting',
		array(
			'section'   => 'hilary_single_image_section',
			'settings'  => 'hilary_single_image_setting',
			'label'     => __( 'Show featured image on posts and pages?', 'hilary' ),
			'type'      => 'checkbox'
		)
	);

}
