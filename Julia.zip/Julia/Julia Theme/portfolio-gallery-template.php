<?php 
/*
 * Template Name: Portfolio Gallery
 */

add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');

remove_action(	'genesis_loop', 'genesis_do_loop' );
add_action(	'genesis_loop', 'zp_portfolio_gallery_template' );
function zp_portfolio_gallery_template() { 

	global $post;		
	
	$column_number = get_post_meta( $post->ID, 'column_number_value', true );	
	zp_portfolio_template( $column_number, -1 , 'gallery', true , '' );
   
}

genesis();