<?php
/**
 * Custom amendments for the theme.
 *
 * @package     Julia Theme
 * @subpackage  Genesis
 * @copyright   Copyright (c) 2017, Cristina Sanz
 * @license     GPL-2.0+
 * @link        https://lovelyconfetti.com/feminine-wordpress-themes
 * @since       1.0.0
 */

//* Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', 'julia_load_textdomain' );

//** Loads the child theme textdomain.

function julia_load_textdomain() {
	load_child_theme_textdomain(
		'julia',
		trailingslashit( get_stylesheet_directory() ) . 'languages'
	);
}


//* Translate theme
load_theme_textdomain('julia', get_template_directory() . '/languages');


function my_theme_setup(){
    load_theme_textdomain('julia', get_template_directory() . '/languages');
}


//** disable redirect front page
function disable_front_page_redirect_madness($redirect_url) {
	if( is_front_page() ) {
		$redirect_url = false;
	}

	return $redirect_url;
}

add_filter( 'redirect_canonical', 'disable_front_page_redirect_madness' );


//* Remove wordpress galery styles
add_filter( 'use_default_gallery_style', '__return_false' );

//* Add Theme Support for WooCommerce
add_theme_support( 'genesis-connect-woocommerce' );

//* Compatible WooCommerce 3.0
add_action( 'after_setup_theme', 'yourtheme_setup' );

function yourtheme_setup() {
add_theme_support( 'wc-product-gallery-zoom' ); 
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );

}

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );


//* Load Font Awesome
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );
/**
 * Make Font Awesome available.
 */
function enqueue_font_awesome() {
    wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
}

add_filter( 'nav_menu_css_class', 'custom_add_item_label_as_class', 10, 3 );
/**
 * Automatically add `<nav-menu-item-label>` class to nav menu items.
 *
 * @param array  $classes Nav menu item classes.
 * @param object $item Nav menu item data object.
 * @param array  $args Nav menu arguments.
 */
function custom_add_item_label_as_class( $classes, $item, $args ) {
    $classes[] = sanitize_title_with_dashes( $item->title );

    return $classes;
}

//* Include Shortcodes

require_once( get_stylesheet_directory() . '/includes/shortcodes/shortcode.php'  );

//* Include Custom Post Types

require_once( get_stylesheet_directory() . '/includes/cpt/super-cpt.php'  );
require_once( get_stylesheet_directory() . '/includes/cpt/julia_cpt.php'  );

//* Theme Options/Functions

require_once ( get_stylesheet_directory() . '/includes/theme_functions.php'  );

// Add Image upload and Color select to WordPress Theme Customizer.
require( get_stylesheet_directory() . '/lib/customize.php' );

// Include Customizer CSS.
require( get_stylesheet_directory() . '/lib/output.php' );


// Install plugins.
require_once( get_stylesheet_directory() . '/lib/plugins/tgm-plugin-activation/register-plugins.php' );

//* Additional Stylesheets

add_action( 'wp_enqueue_scripts', 'julia_print_styles' );

function julia_print_styles() {

	wp_register_style( 'shortcode-css', get_stylesheet_directory_uri().'/includes/shortcodes/shortcode.css' );
	wp_enqueue_style( 'shortcode-css' );
	wp_register_style( 'pretty_photo_css', get_stylesheet_directory_uri().'/css/prettyPhoto.css' );
	wp_enqueue_style( 'pretty_photo_css' );	
	wp_register_style( 'flexslider-css', get_stylesheet_directory_uri().'/css/flexslider.css' );
	wp_enqueue_style( 'flexslider-css' );

}

//* Shortcode CSS
add_action('admin_enqueue_scripts', 'julia_enqueue_scripts');  
function julia_enqueue_scripts(){
	global $current_screen;
	if($current_screen->base=='post'){

		//enqueue the script and CSS files for the TinyMCE editor formatting buttons
   		
		wp_enqueue_script('jquery');
		wp_enqueue_script('jquery-ui-dialog');
		wp_enqueue_script('jquery-ui-core');
		wp_enqueue_script('jquery-ui-sortable');
		//set the style files
		wp_enqueue_style( 'shortcode_editor_style',get_stylesheet_directory_uri( ).'/includes/shortcodes/shortcode_editor_style.css' );

	}

}

//* Enable Shortcode in the Widget Area
add_filter('widget_text', 'do_shortcode');

//* Remove default WooCommerce Styles
add_filter( 'woocommerce_enqueue_styles', 'dequeue_woocommerce_general_stylesheet' );
function dequeue_woocommerce_general_stylesheet( $enqueue_styles ) {
	unset( $enqueue_styles['woocommerce-general'] );	
	return $enqueue_styles;
} 

/*//** Add WooCommerce Styles
function woocommerce_style_sheet() {
wp_register_style( 'woocommerce', get_stylesheet_directory_uri() . '/woocommerce/woocommerce.css' );
if ( class_exists( 'woocommerce' ) ) {
wp_enqueue_style( 'woocommerce' );
	}
}
add_action('wp_enqueue_scripts', 'woocommerce_style_sheet'); */



//* Display 12 products per page

add_filter( 'loop_shop_per_page', create_function( '$cols', 'return 12;' ), 21 );

//* Change number or products per row to 3

add_filter('loop_shop_columns', 'loop_columns');
if (!function_exists('loop_columns')) {
function loop_columns() {
return 3; // 3 products per row
}
}

//* Number of related products on product page
 
function woo_related_products_limit() {
  global $product;
	
	$args['posts_per_page'] = 9;
	return $args;
}

//* Number of related products on product page
add_filter( 'woocommerce_output_related_products_args', 'julia_related_products_args' );
  function julia_related_products_args( $args ) {
	$args['posts_per_page'] = 3; // 3 related products
	$args['columns'] = 3; // arranged in 3 columns
	return $args;
}


//* Remove default sidebar, add shop sidebar
add_action( 'genesis_before', 'wpstudio_add_woo_sidebar', 20 );
function wpstudio_add_woo_sidebar() {
    if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
        if( is_woocommerce() ) {
            remove_action( 'genesis_sidebar', 'genesis_do_sidebar' );
            remove_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
            add_action( 'genesis_sidebar', 'wpstudio_woo_sidebar' );
        }
    }
    
}

//* Display the WooCommerce sidebar
function wpstudio_woo_sidebar() {
    if ( ! dynamic_sidebar( 'woo_primary_sidebar' ) && current_user_can( 'edit_theme_options' )  ) {
        genesis_default_widget_area_content( __( 'WooCommerce Primary Sidebar', 'genesis' ) );
    }
}

//* Add Menu descriptions
add_filter( 'walker_nav_menu_start_el', 'skin_add_menu_description', 10, 4 );
function skin_add_menu_description( $item_output, $item, $depth, $args ) {
    if ( 'secondary' == $args->theme_location && $item->description );
    if ( 'primary' == $args->theme_location && $item->description );
     {
        $item_output = str_replace( $args->link_after . '</a>', '<span class="menu-description">' . $item->description . '</span>' . $args->link_after . '</a>', $item_output );
    }

    return $item_output;
}  

//* Add theme support for new menu
// Add Footer Menu; Keep Primary and Secondary Menus

add_theme_support ( 'genesis-menus' , array ( 
	'primary'   => __( 'Left Navigation Menu', 'julia' ),
	'secondary' => __( 'Right Navigation Menu', 'julia' ),
    'footer'    => __( 'Footer Navigation Menu', 'julia' )
	) );


//* Add Attributes for Footer Navigation
add_filter( 'genesis_attr_nav-footer', 'genesis_attributes_nav' ); 

// Add attributes to markup
// Add footer menu just above footer widget area
add_action( 'genesis_footer', 'julia_footer_menu', 9 );
function julia_footer_menu() {

	genesis_nav_menu( array(
		'theme_location' => 'footer',
		'container'       => 'div',
		'container_class' => 'wrap',
		'menu_class'     => 'menu genesis-nav-menu menu-footer',
		'depth'           => 1
	) );

}

//* Add custom attributes to footer navigation
add_filter( 'genesis_attr_nav-footer', 'custom_add_nav_footer_attr' );
function custom_add_nav_footer_attr( $attributes ){

    $attributes['role'] = 'navigation';
    $attributes['itemscope'] = 'itemscope';
    $attributes['itemtype'] = 'http://schema.org/SiteNavigationElement';
    
    return $attributes;
        
}

add_action( 'genesis_setup', 'julia_theme_setup', 15 );


//* Theme Setup
function julia_theme_setup() {

	//* Child theme (do not remove)
	define( 'CHILD_THEME_NAME', __( 'Julia Theme', 'julia' ) );
	define( 'CHILD_THEME_VERSION', '1.0.0' );
	define( 'CHILD_THEME_URL', 'https://lovelyconfetti.com/feminine-wordpress-themes' );
	define( 'CHILD_THEME_DEVELOPER', __( 'Cristina Sanz', 'julia' ) );

	//* Add viewport meta tag for mobile browsers.
	add_theme_support( 'genesis-responsive-viewport' );

	//* Add HTML5 markup structure.
	add_theme_support( 'html5' );

	//**	Set content width.
	$content_width = apply_filters( 'content_width', 610, 610, 980 );

	//* Add new featured image sizes.
	add_image_size( 'horizontal-thumbnail', 400, 300, true );
	add_image_size( 'vertical-thumbnail', 400, 600, true );
	add_image_size( 'Home 2 columns', 375, 330, true );
	add_image_size( 'Home 3 columns', 365, 300, true );
	add_image_size( 'Home 4 columns', 265, 200, true );
	add_image_size( 'Home 6 columns', 150, 150, true );
	add_image_size( 'Home-flexible', 564, 263, true );
	add_image_size( 'large', 1024, 678, TRUE );
	add_image_size( 'portfolio', 365, 250, TRUE );
	add_image_size( 'related', 235, 305, true );

	
//* Unregister header right sidebar.
	unregister_sidebar( 'header-right' );

//* Replace 'Home' text with a home icon in Genesis Framework breadcrumb
	add_filter ( 'genesis_home_crumb', 'afn_breadcrumb_home_icon' ); 
	function afn_breadcrumb_home_icon( $crumb ) {
     $crumb = '<a href="' . home_url() . '" title="' . get_bloginfo('name') . '"><i class="dashicons dashicons-admin-home"></i></a>';
     return $crumb;
	}

//* Hooks before header widget areas
	add_action( 'genesis_before_header', 'before_header_widgets'  ); 
	function before_header_widgets() {

	echo '<div class="before-header">';

    genesis_widget_area( 'before-header-left', array(
		'before' => '<div class="before-header-left widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
    
    genesis_widget_area( 'before-header-right', array(
		'before' => '<div class="before-header-right widget-area"><div class="wrap">',
		'after'  => '</div></div>',
    ) );
    
    echo '</div>';

	}

//* Activate After Entry widget area and display it on single Posts
add_theme_support( 'genesis-after-entry-widget-area' );

//* Remove 'You are here' texts in Genesis Framework breadcrumb
	add_filter( 'genesis_breadcrumb_args', 'julia_breadcrumb_args' );
	function julia_breadcrumb_args( $args ) {
	$args['labels']['prefix'] = '';
	return $args;
	}

//* Hook menus
	add_action( 'genesis_after_header', 'julia_menus_container' );
	function julia_menus_container() {

	echo '<div class="navigation-container">';
	do_action( 'julia_menus' );
	echo '</div>';

}

//* Relocate Primary (Left) Navigation
	remove_action( 'genesis_after_header', 'genesis_do_nav' );
	add_action( 'julia_menus', 'genesis_do_nav' );

//* Relocate Secondary (Right) Navigation
	remove_action( 'genesis_after_header', 'genesis_do_subnav' );
	add_action( 'julia_menus', 'genesis_do_subnav' );

//* Remove output of primary navigation right extras
	remove_filter( 'genesis_nav_items', 'genesis_nav_right', 10, 2 );
	remove_filter( 'wp_nav_menu_items', 'genesis_nav_right', 10, 2 );


//* Add support for custom header
	add_theme_support( 'custom-header', array(
	'width'           => 700,
	'height'          => 300,
	'header-selector' => '.site-title a',
	'header-text'     => false
	) );


//* Add page title wrapper 
add_filter( 'genesis_after_header','julia_add_div' );
function julia_add_div(  ){
	
global $post;
$img = '';
if(  ( !is_home(  ) || !is_front_page() )  && !is_page_template( 'shop' )  )  {
	if(isset( $post ))
		$img = get_post_meta(  $post->ID, 'zp_page_image_value', true  );
	
	if( $img  ){
		$url = wp_get_attachment_image_src( $img , 'full' );
		$img_url = $url[0];	
	}else{
		$img_url = get_stylesheet_directory_uri(  ).'/images/header_page_image.jpg';
	}
	
	$style = 'style="background-image:url('.$img_url.')"';
	
	echo '<div class="page_title_wrap" '.$style.'>';
	}
}

//* Close Page Title 
add_filter( 'genesis_after_header','julia_close_div' );
function julia_close_div(  ){
	if(  ( !is_home(  ) || !is_front_page() )  && !is_page_template( 'shop-index.php' )   ) 
		echo '</div>';
}

//* Add support for 4-column footer widgets.
 add_theme_support( 'genesis-footer-widgets', 4 );
}

	add_action( 'genesis_setup', 'julia_includes', 20 );

//* Load additional functions and helpers.
	function julia_includes() {
	$includes_dir = trailingslashit( get_stylesheet_directory() ) . 'includes/';

	// Load the customizer library.
	require_once $includes_dir . 'vendor/customizer-library/customizer-library.php';

	// Load all customizer files.
	require_once $includes_dir . 'customizer/customizer-display.php';
	require_once $includes_dir . 'customizer/customizer-settings.php';


	// Load everything in the includes root directory.
	require_once $includes_dir . 'helper-functions.php';
	require_once $includes_dir . 'compatability.php';
	require_once $includes_dir . 'simple-grid.php';
	require_once $includes_dir . 'widgeted-areas.php';
	require_once $includes_dir . 'widgets.php';
	
}

/**
 * Load Genesis
 *
 * This is technically not needed.
 * However, to make functions.php snippets work, it is necessary.
 */
require_once( get_template_directory() . '/lib/init.php' );

add_action( 'wp_enqueue_scripts', 'julia_enqueue_js' );


//* Load all required JavaScript for the julia theme.

function julia_enqueue_js() {
	$js_uri = get_stylesheet_directory_uri() . '/assets/js/';
	// Add general purpose scripts.

	wp_enqueue_style( 'dashicons' );
	wp_register_script( 'jquery_cycle', get_stylesheet_directory_uri(  ) . '/js/jquery.cycle.lite.js', array( 'jquery' ), '1.7', true );	
	wp_register_script('custom_js', get_stylesheet_directory_uri().'/js/jquery.custom.js',array( 'jquery' ), '1.5', true );
	wp_register_script('jquery_pretty_photo_js', get_stylesheet_directory_uri() . '/js/jquery.prettyPhoto.js', array('jquery', 'custom_js') ,'3.1.6', true);			
    wp_enqueue_script('jquery');
	wp_enqueue_script('jquery_easing_js', get_stylesheet_directory_uri() . '/js/jquery-easing.js', array(), '1.3', true);
	wp_enqueue_script('script_js', get_stylesheet_directory_uri() . '/js/script.js', array(), '1.2.4', true );	
	wp_enqueue_script('jquery_isotope_min_js', get_stylesheet_directory_uri().'/js/jquery.isotope.min.js', array(), '1.5.25', true );	
	wp_enqueue_script('jQuery_ScrollTo_min_js', get_stylesheet_directory_uri() .'/js/jquery.scrollTo.min.js', array(), '1.4.2', true );
	wp_enqueue_script('jquery_tipTip', get_stylesheet_directory_uri().'/js/jquery.tipTip.minified.js', array(), '1.3', true );
	wp_enqueue_script('custom_js');	
	wp_enqueue_script('jquery_pretty_photo_js');
	wp_register_script( 'jquery_carouFredSel', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.carouFredSel.min.js', array( 'jquery' ), '6.2.1', true );
	wp_register_script( 'jquery_mousewheel', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.mousewheel.min.js',array( 'jquery' ), '3.0.6', true );
	wp_register_script( 'jquery_touchswipe', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.touchSwipe.min.js',array( 'jquery' ), '1.3.3', true );
	wp_register_script( 'jquery_transit', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.transit.min.js',array( 'jquery' ), '0.9.9', true );
	wp_register_script( 'jquery_throttle', get_stylesheet_directory_uri(  ) . '/js/carousel/jquery.ba-throttle-debounce.min.js', array( 'jquery' ), '1.1', true );		
	wp_enqueue_script( 'navigation', get_bloginfo( 'stylesheet_directory' ) . '/js/navigation.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_script( 'localScroll', get_stylesheet_directory_uri() . '/js/jquery.localScroll.min.js', array( 'scrollTo' ), '1.2.8b', true );
	wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );
	wp_enqueue_script( 'fadeup-script', get_stylesheet_directory_uri() . '/js/fadeup.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'match-height', get_stylesheet_directory_uri() . '/js/jquery.matchHeight-min.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'match-height-init', get_stylesheet_directory_uri() . '/js/matchheight-init.js', array( 'match-height' ), '1.0.0', true );


}

add_filter( 'body_class', 'julia_add_body_class' );

//* Add the theme name class to the body element.
function julia_add_body_class( $classes ) {
	$classes[] = 'julia';
	return $classes;
}


add_action( 'wp_enqueue_scripts', 'enqueue_scroll_animations' );
function enqueue_scroll_animations() {
	wp_enqueue_style( 'animate', get_stylesheet_directory_uri() . '/css/animate.css' );
	wp_enqueue_script( 'waypoints', get_stylesheet_directory_uri() . '/js/waypoints.min.js', array( 'jquery' ), '1.0.0' );
	wp_enqueue_script( 'waypoints-init', get_stylesheet_directory_uri() .'/js/waypoints-init.js' , array( 'jquery', 'waypoints' ), '1.0.0' );
}


//* Add navigation to single post
add_action( 'genesis_after_entry', 'julia_single_post_nav' );
function julia_single_post_nav(){
	if( is_single() ){
		$output = '';
		$output .= '<div class="single_post_nav">';		
		$prev_post = get_previous_post();
		if ( !empty( $prev_post )){
			$output .= '<a href="'.get_permalink( $prev_post->ID ).'" class="single_post_prev"><span class="single_nav_arrow"><i class="fa fa-angle-left"></i></span><span class="single_nav_title"><span>'.__( 'Previous Post:', 'julia' ).'</span>'.$prev_post->post_title.'</span><span class="single_nav_thumb" style="display: none">'.get_the_post_thumbnail( $prev_post->ID, 'thumbnail' ).'</span></a>';
		}
		
		$next_post = get_next_post();
		if ( !empty( $next_post )){
			$output .= '<a href="'.get_permalink( $next_post->ID ).'" class="single_post_next"><span class="single_nav_arrow"><i class="fa fa-angle-right"></i></span><span class="single_nav_title"><span>'.__( 'Next Post:', 'julia' ).'</span>'.$next_post->post_title.'</span><span class="single_nav_thumb" style="display: none;">'.get_the_post_thumbnail( $next_post->ID , 'thumbnail' ).'</span></a>';
		}
		$output .= '</div>';
		echo $output;
	}
}

//* Add post navigation.
//add_action( 'genesis_after_entry_content', 'genesis_prev_next_post_nav', 5 );

add_filter( 'excerpt_more', 'julia_read_more_link' );
add_filter( 'get_the_content_more_link', 'julia_read_more_link' );
add_filter( 'the_content_more_link', 'julia_read_more_link' );

//* To Top Link
add_action( 'genesis_before_footer','julia_add_top_link' );
function julia_add_top_link(  ){
	echo '<a href="#top" id="top-link"><i class="fa fa-angle-up"></i></a>';
}

//* Modify the Genesis read more link.

function julia_read_more_link() {
	return '...</p><p><a class="more-link" href="' . get_permalink() . '">' . __( 'Read More', 'julia' ) . ' </a></p>';
}

add_filter( 'genesis_comment_form_args', 'julia_comment_form_args' );


//* Setup widget counts
function julia_count_widgets( $id ) {

	global $sidebars_widgets;

	if ( isset( $sidebars_widgets[ $id ] ) ) {
		return count( $sidebars_widgets[ $id ] );
	}

}

function julia_widget_area_class( $id ) {

	$count = julia_count_widgets( $id );

	$class = '';

	if ( $count == 1 ) {
		$class .= ' widget-full';
	} elseif ( $count % 3 == 0 ) {
		$class .= ' widget-thirds';
	} elseif ( $count % 4 == 0 ) {
		$class .= ' widget-fourths';
	} elseif ( $count % 2 == 1 ) {
		$class .= ' widget-halves uneven';
	} else {	
		$class .= ' widget-halves';
	}

	return $class;

}

//* Modify the speak your mind text.

function julia_comment_form_args( $args ) {
	$args['title_reply'] = __( 'Comments', 'julia' );
	return $args;
}

//* Customize the credits 
	add_filter('genesis_footer_creds_text', 'custom_footer_creds_text');
	function custom_footer_creds_text() {
    echo '<div class="creds"><p>';
    echo 'Copyright &copy; ';
    echo date('Y');
    echo ' &middot; <a target="_blank" href="http://lovelyconfetti.com/feminine-wordpress-themes">Julia theme</a> by <a target="_blank" href="http://www.lovelyconfetti.com">Lovely Confetti</a><a href="http://www.dmca.com/Protection/Status.aspx?ID=0960d3f3-2441-4900-bc5d-877ef3e6272c" title="DMCA.com Protection Status" class="dmca-badge"> <img src="//images.dmca.com/Badges/dmca-badge-w100-5x1-11.png?ID=0960d3f3-2441-4900-bc5d-877ef3e6272c" alt="DMCA.com Protection Status"></a> <script src="//images.dmca.com/Badges/DMCABadgeHelper.min.js"> </script>';
    echo '</p></div>';

}

//* Add Accessibility support
add_theme_support( 'genesis-accessibility', array( 'headings', 'drop-down-menu',  'search-form', 'skip-links' ) );

//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'julia_search_button_text' );
function julia_search_button_text( $text ) {

	return esc_attr( '&#xf002;' );

}

//* Replace h3 with h4 for all widget titles
add_filter( 'genesis_register_widget_title_defaults', 'custom_register_widget_title_defaults' );
function custom_register_widget_title_defaults( $defaults ) {
	$defaults['before_title'] = '<h1 class="widget-title widgettitle">';
	$defaults['after_title'] = '</h1>';
	return $defaults;
}

//* Hide Woocommerce page title 
add_filter( 'woocommerce_show_page_title' , 'woo_hide_page_title' );
function woo_hide_page_title() {
	
	return false;
	
}

//* Customize the post info function 
add_filter( 'genesis_post_info', 'post_info_filter' );
function post_info_filter($post_info) {
if ( !is_page() ) {
    $post_info = '[post_date]';
    return $post_info;
}}

//* Customize the post meta function
add_filter( 'genesis_post_meta', 'tnt_post_meta_filter' );
function tnt_post_meta_filter( $post_meta ) {
    $post_meta = '[post_categories before=""] [post_tags before="Tagged: "] [post_comments]';
    return $post_meta;
}



//* Add the after footer widget area
add_action( 'genesis_before_footer', 'julia_after_footer_widget' );
function julia_after_footer_widget() {

	genesis_widget_area( 'after-footer', array(
		'after' => '<div id="after-footer" class="after-footer"><h2 class="genesis-sidebar-title screen-reader-text">' . __( 'After Footer', 'julia' ) . '</h2><div class="flexible-widgets widget-area ' . julia_widget_area_class( 'before-footer' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

}

//* Register side-sticky widget area.
genesis_register_widget_area(
    array(
        'id'          => 'side-sticky',
        'name'        => __( 'Side Sticky', 'julia' ),
        'description' => __( 'This appears in the sticky side section.', 'julia' ),
    )
);

add_action( 'wp_footer', 'sk_side_sticky' );
/**
 * Display sticky side section.
 */
function sk_side_sticky() {
    // if there is no widget in the Side Sticky widget area, abort.
    if ( ! is_active_sidebar( 'side-sticky' ) ) {
        return;
    } ?>

    <div id="side-container">
        <div id="side-section">
            <?php
            genesis_widget_area( 'side-sticky', array(
                'before'    => '<div class="side-sticky widget-area">',
                'after'     => '</div>',
            ) ); ?>
        </div>
        <div id="side-sticky-button"><a class="sticky-switch" href="#"><?php echo __( 'Subscribe', 'julia' ); ?></a></div>
    </div>
<?php }

add_action( 'wp_enqueue_scripts', 'enqueue_side_sticky' );
/**
 * Load side-sticky.js.
 */
function enqueue_side_sticky() {
    // if there is no widget in the Side Sticky widget area, abort.
    if ( ! is_active_sidebar( 'side-sticky' ) ) {
        return;
    }

    wp_enqueue_script( 'side-sticky',  get_stylesheet_directory_uri() . '/js/side-sticky.js', array( 'jquery' ), '1.0.0', true );
}




//* Related posts

//for XHTML themes
add_action( 'genesis_after_post_content', 'child_related_posts' );
//for HTML5 themes
add_action( 'genesis_after_entry_content', 'child_related_posts' );
/**
 * Outputs related posts with thumbnail
 * 
 * @author Nick the Geek
 * @url http://designsbynickthegeek.com/tutorials/related-posts-genesis
 * @global object $post 
 */
function child_related_posts() {
     
    if ( is_single ( ) ) {
         
        global $post;
 
        $count = 0;
        $postIDs = array( $post->ID );
        $related = '';
        $cats = wp_get_post_categories( $post->ID );
         
               
           
        if ( $count <= 3 ) {
             
            $catIDs = array( );
 
            foreach ( $cats as $cat ) {
                 
                if ( 3 == $cat )
                    continue;
                $catIDs[] = $cat;
                 
            }
             
            $showposts = 4 - $count;
 
            $args = array(
                'category__in'          => $catIDs,
                'post__not_in'          => $postIDs,
                'showposts'             => $showposts,
                'ignore_sticky_posts'   => 1,
                'orderby'               => 'rand',
                'tax_query'             => array(
                                    array(
                                        'taxonomy'  => 'post_format',
                                        'field'     => 'slug',
                                        'terms'     => array( 
                                            'post-format-link', 
                                            'post-format-status', 
                                            'post-format-aside', 
                                            'post-format-quote' ),
                                        'operator' => 'NOT IN'
                                    )
                )
            );
 
            $cat_query = new WP_Query( $args );
             
            if ( $cat_query->have_posts() ) {
                 
                while ( $cat_query->have_posts() ) {
                     
                    $cat_query->the_post();
 
                    $img = genesis_get_image() ? genesis_get_image( array( 'size' => 'related' ) ) : '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/related.png" alt="' . get_the_title() . '" />';
 
                    $related .= '<li><a href="' . get_permalink() . '" rel="bookmark" title="Permanent Link to' . get_the_title() . '">' . $img . get_the_title() . '</a></li>';
                }
            }
        }
 
        if ( $related ) {
             
            printf( '<div class="related-posts"><h3 class="related-title">Related Posts</h3><ul class="related-list">%s</ul></div>', $related );
         
        }
         
        wp_reset_query();
         
    }
}

