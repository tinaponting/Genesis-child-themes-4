<?php
/**
	Theme Name: Julia Theme
	Theme URI: https://lovelyconfetti.com/feminine-wordpress-themes
	Description: A mobile responsive and HTML5 theme built for the Genesis Framework.
	Author: Cristina Sanz
	Author URI: http://lovelyconfetti.com/
	Version: 1.0.0
 */


add_action( 'genesis_meta', 'julia_front_page_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function julia_front_page_genesis_meta() {

	if ( is_active_sidebar ( 'front-page-image-1' ) || is_active_sidebar( 'front-page-2' ) || is_active_sidebar( 'front-page-image-3' ) || is_active_sidebar( 'front-page-4' ) || is_active_sidebar( 'front-page-image-5' )  || is_active_sidebar( 'front-page-6' ) ) {

		//* Enqueue scripts
		add_action( 'wp_enqueue_scripts', 'julia_enqueue_front_script_styles' );
		function julia_enqueue_front_script_styles() {

			
			wp_enqueue_script( 'scrollTo', get_stylesheet_directory_uri() . '/js/jquery.scrollTo.min.js', array( 'jquery' ), '1.4.5-beta', true );
			wp_enqueue_script( 'julia-script', get_bloginfo( 'stylesheet_directory' ) . '/js/home.js', array( 'jquery' ), '1.0.0' );
			wp_enqueue_style( 'julia-front-styles', get_stylesheet_directory_uri() . '/style-front.css' );

		}

		//* Add front-page body class
		add_filter( 'body_class', 'julia_body_class' );
		function julia_body_class( $classes ) {

   			$classes[] = 'front-page';

  			return $classes;

		}

		//* Remove breadcrumbs
		remove_action( 'genesis_before_loop', 'genesis_do_breadcrumbs' );

		//* Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );

		//* Add homepage widgets
		add_action( 'genesis_loop', 'julia_front_page_widgets' );

		//* Force full width content layout
		add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );

	}

}


//* Add markup for front page widgets
function julia_front_page_widgets() {

	echo '<h2 class="screen-reader-text">' . __( 'Main Content', 'julia' ) . '</h2>';

	genesis_widget_area( 'front-page-image-1', array(
		'before' => '<div id="front-page-image-1" class="front-page-image-1 image-section"><div class="flexible-widgets widget-area' . julia_widget_area_class( 'front-page-image-1' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-2', array(
		'before' => '<div id="front-page-2" class="front-page-2"><div class="flexible-widgets widget-area fadeup-effect' . julia_widget_area_class( 'front-page-2' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-image-3', array(
		'before' => '<div id="front-page-3" class="front-page-image-3 image-section"><div class="flexible-widgets widget-area fadeup-effect' . julia_widget_area_class( 'front-page-image-3' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-4', array(
		'before' => '<div id="front-page-4" class="front-page-4"><div class="flexible-widgets widget-area fadeup-effect' . julia_widget_area_class( 'front-page-4' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-image-5', array(
		'before' => '<div id="front-page-image-5" class="front-page-image-5 image-section"><div class="flexible-widgets widget-area fadeup-effect' . julia_widget_area_class( 'front-page-image-5' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-6', array(
		'before' => '<div id="front-page-6" class="front-page-6"><div class="flexible-widgets widget-area fadeup-effect' . julia_widget_area_class( 'front-page-6' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-image-7', array(
		'before' => '<div id="front-page-image-7" class="front-page-image-7 image-section"><div class="flexible-widgets widget-area fadeup-effect' . julia_widget_area_class( 'front-page-image-7' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-8', array(
		'before' => '<div id="front-page-8" class="front-page-8"><div class="flexible-widgets widget-area fadeup-effect' . julia_widget_area_class( 'front-page-8' ) . '"><div class="wrap">',
		'after'  => '</div></div></div>',
	) );

}

//* Run the Genesis loop
genesis();
