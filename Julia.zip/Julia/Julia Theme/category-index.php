<?php
/**
 * Template Name: Category Index
 *
 * @package     Hilary Theme
 * @subpackage  Genesis
 * @copyright   Copyright (c) 2016, Cristina Sanz
 * @license     GPL-2.0+
 * @link        http://lovelyconfetti.com/shop
 * @since       1.0.0
 */

add_action( 'genesis_meta', 'hilary_category_genesis_meta' );
/**
 * Add widget support for categories page.
 * If no widgets active, display the default page content.
 *
 * @since 1.0.1
 */
function hilary_category_genesis_meta() {
	if ( is_active_sidebar( 'categories-top' ) || is_active_sidebar( 'categories-bottom' ) ) {
		// Remove the default Genesis loop.
		remove_action( 'genesis_loop', 'genesis_do_loop' );
		// Add a custom loop for the home page.
		add_action( 'genesis_loop', 'hilary_category_loop_helper' );
	}
}

/**
 * Display the category page widgeted sections.
 *
 * @since 1.0.0
 */
function hilary_category_loop_helper() {
	genesis_widget_area( 'categories-top',  array(
		'before' => '<div class="widget-area categories-top">',
		'after'  => '</div> <!-- end .categories-top -->',
	) );

	genesis_widget_area( 'categories-bottom', array(
		'before' => '<div class="widget-area categories-bottom">',
		'after'  => '</div> <!-- end .categories-bottom -->',
	) );
}

genesis();
