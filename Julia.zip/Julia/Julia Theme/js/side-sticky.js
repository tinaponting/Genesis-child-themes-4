jQuery(document).ready(function($) {

    // click event for .sticky-switch.
    $('.sticky-switch').click(function(event) {
        // stop the click on the link adding a # to the end of URL
        event.preventDefault();

        $(this).parents('#side-container').toggleClass('open');

    });

    // Close if user clicks outside of panel.
    $(document).click(function(event) {
        if(!$(event.target).closest('#side-container').length) {
        // ... clicked on the 'body', but not inside of #side-container
            if($('#side-container').hasClass('open')) {
                $('#side-container').removeClass('open');
            }
        }
    });

    // Close the side panel after Submit button inside #side-section has been clicked.
    $('#side-section input[type="submit"]').click(function(event) {
        $('#side-container').removeClass('open');
    });

});