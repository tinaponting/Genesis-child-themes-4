jQuery(function($) {


	


	$('.after-entry').waypoint(function() {
		$(this).toggleClass( 'animated pulse' );
	},
	{
		offset: '100%',
		// triggerOnce: true
	});

	

});