jQuery(function($){
	$(window).load(function() {

			/*main function*/
			function wpexportfolioIsotope() {
				var $container = $('.portfolio-content');
				$container.imagesLoaded(function(){
					$container.isotope({
						itemSelector: '.portfolio-item'
					});
				});
			} wpexportfolioIsotope();

			/*filter*/
			$('.filter a').click(function(){
			  var selector = $(this).attr('data-filter');
				$('.portfolio-content').isotope({ filter: selector });
				$(this).parents('ul').find('a').removeClass('active');
				$(this).addClass('active');
			  return false;
			});

			/*resize*/
			var isIE8 = $.browser.msie && +$.browser.version === 8;
			if (isIE8) {
				document.body.onresize = function () {
					wpexportfolioIsotope();
				};
			} else {
				$(window).resize(function () {
					wpexportfolioIsotope();
				});
			}

			// Orientation change
			window.addEventListener("orientationchange", function() {
				wpexportfolioIsotope();
			});

	});
}); 
