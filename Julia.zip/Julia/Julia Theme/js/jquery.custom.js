/*-------------------------------------------------*/
// Custom JS
/*-------------------------------------------------*/
jQuery.noConflict();


// portfolio dimension on window resize

function zp_portfolio_item_dimension(){
	var window_width = jQuery(window).width();
	var container_width = jQuery('#container').width();
	
	if( window_width < 480 ){
		jQuery('.element').each( function(){		
			//3 columns
			if( jQuery(this).hasClass( 'element-3col' ) || jQuery(this).hasClass( 'gallery-3col' ) ){
				item_height = jQuery(this).children('.portfolio_image').children('img').height();
				item_width  = Math.floor(( container_width - 20 ) / 1);
				jQuery(this).css({"width": item_width+"px"});
				jQuery(this).css({"height": item_height+"px"});
			}
			
			//4 columns
			if( jQuery(this).hasClass( 'element-4col' ) || jQuery(this).hasClass( 'gallery-4col' ) ){
				item_height = jQuery(this).children('.portfolio_image').children('img').height();
				item_width  = Math.floor(( container_width - 20 ) / 1);
				jQuery(this).css({"width": item_width+"px"});
				jQuery(this).css({"height": item_height+"px"});
			}
		});
		
	}else if( window_width < 700 ){
		jQuery('.element').each( function(){					
			//3 columns
			if( jQuery(this).hasClass( 'element-3col' ) || jQuery(this).hasClass( 'gallery-3col' ) ){
				item_height = jQuery(this).children('.portfolio_image').children('img').height();
				item_width  = Math.floor(( container_width - 40 ) / 2);
				jQuery(this).css({"width": item_width+"px"});
				jQuery(this).css({"height": item_height+"px"});
			}
			
			//4 columns
			if( jQuery(this).hasClass( 'element-4col' ) || jQuery(this).hasClass( 'gallery-4col' ) ){
				item_height = jQuery(this).children('.portfolio_image').children('img').height();
				item_width  = Math.floor(( container_width - 40 ) / 2);
				jQuery(this).css({"width": item_width+"px"});
				jQuery(this).css({"height": item_height+"px"});
			}
		});		
	}else{
		jQuery('.element').each( function(){
			//3 columns
			if( jQuery(this).hasClass( 'element-3col' ) || jQuery(this).hasClass( 'gallery-3col' ) ){
				item_height = jQuery(this).children('.portfolio_image').children('img').height();
				item_width  = Math.floor(( container_width - 60 ) / 3);
				jQuery(this).css({"width": item_width+"px"});
				jQuery(this).css({"height": item_height+"px"});
			}
			
			//4 columns
			if( jQuery(this).hasClass( 'element-4col' ) || jQuery(this).hasClass( 'gallery-4col' ) ){
				item_height = jQuery(this).children('.portfolio_image').children('img').height();
				item_width  = Math.floor(( container_width - 80 ) / 4);
				jQuery(this).css({"width": item_width+"px"});
				jQuery(this).css({"height": item_height+"px"});
			}
		});
	}
	
}

jQuery(document).ready(function() {
/*-------------------------------------------------*/
// Isotope Filter Effect
/*-------------------------------------------------*/

	zp_portfolio_item_dimension();

	//var filter_val = jQuery('#portfolio-categories li a.selected').attr('data-option-value');
	
	var jQuerycontainer = jQuery('#container');
	jQuerycontainer.isotope({
		 itemSelector : '.element',
		 filter: jQuery('#portfolio-categories li a.selected').attr('data-option-value')
	});	
	

	var jQueryoptionSets = jQuery('#options .option-set'),
	  jQueryoptionLinks = jQueryoptionSets.find('a');
							
		  jQueryoptionLinks.click(function(){
			var jQuerythis = jQuery(this);
	
			// don't proceed if already selected
			if ( jQuerythis.hasClass('selected') ) {
			  return false;
			}
		
			var jQueryoptionSet = jQuerythis.parents('.option-set');
			jQueryoptionSet.find('.selected').removeClass('selected');
			jQuerythis.addClass('selected');
								  
			// make option object dynamically, i.e. { filter: '.my-filter-class' }
			var options = {},
				key = jQueryoptionSet.attr('data-option-key'),
				value = jQuerythis.attr('data-option-value');
				// parse 'false' as false boolean
				value = value === 'false' ? false : value;
				options[ key ] = value;
			
			if ( key === 'layoutMode' && typeof changeLayoutMode === 'function' ) {
			  // changes in layout modes need extra logic
			  changeLayoutMode( jQuerythis, options )
			} else {
			 // otherwise, apply new options
				jQuerycontainer.isotope( options );
			}
										
			return false;
	});
	jQuery('.element').hover(function(){	
		jQuery(this).children('.portfolio_image').children('a').animate({"opacity": "1"}, "fast");
		jQuery(this).children('.portfolio_image').children('a').children('h4').animate({"opacity": "1"}, "fast");
	}, function(){
		jQuery(this).children('.portfolio_image').children('a').animate({"opacity": "0"}, "fast");
		jQuery(this).children('.portfolio_image').children('a').children('h4').animate({"opacity": "0"}, "fast");
	});		
/*-------------------------------------------------*/
//	To Top Link
/*-------------------------------------------------*/
		jQuery.fn.topLink = function(settings) {
			settings = jQuery.extend({
				min: 1,
				fadeSpeed: 200
				},
				settings );
				return this.each(function() {
					// listen for scroll
					var el =jQuery(this);
					el.hide(); // in case the user forgot
					jQuery(window).scroll(function() {
					if(jQuery(window).scrollTop() >= settings.min) {
					el.fadeIn(settings.fadeSpeed);
					} else {
					el.fadeOut(settings.fadeSpeed);
					}
				});
			});
			};

/*-------------------------------------------------------------*/
//					usage w/ smoothscroll
/*------------------------------------------------------------*/
			jQuery(document).ready(function() {
			// set the link
				jQuery('#top-link').topLink({
				min: 400,
				fadeSpeed: 500
				});
				
				// smoothscroll
				jQuery('#top-link').click(function(e) {
				e.preventDefault();
				jQuery.scrollTo(0,300);
				});
			});
	
/*-------------------------------------------------*/
// 	Homepage Top Button
/*-------------------------------------------------*/	
		jQuery('.top_trigger').toggle(function() {
			jQuery(this).removeClass('close');
			jQuery(this).addClass('open');	
			jQuery('.top .top_widget').slideToggle("slow");
		}, function(){
			jQuery(this).removeClass('open');
			jQuery(this).addClass('close');	
			jQuery('.top .top_widget').slideToggle("slow");
		});

/*-------------------------------------------------*/
// Lightbox (Prettyphoto)
/*-------------------------------------------------*/	
			jQuery("a[rel^='prettyPhoto']").prettyPhoto({
				theme: 'light_rounded',
				counter_separator_label: ' of '
			});
/*-------------------------------------------------*/
// Image Hover
/*-------------------------------------------------*/				

			jQuery( ".ad img, .portfolio-large img" ).hover( 
				function( ) {
					jQuery( this ).animate( {"opacity": ".8"}, "fast" );
					},
				function( ) {
					jQuery( this ).animate( {"opacity": "1"}, "fast" );
			} );			
								
/*-------------------------------------------------*/
// Toggle 
/*-------------------------------------------------*/	

			jQuery( ".toggle-container" ).hide( );	 
			jQuery( ".trigger" ).toggle( function( ){
				jQuery( this ).addClass( "active" );
				}, function ( ) {
				jQuery( this ).removeClass( "active" );
			} );
			jQuery( ".trigger" ).click( function( ){
				jQuery( this ).next( ".toggle-container" ).slideToggle( );
			} );			jQuery( '.trigger a' ).hover( function( ) {
			jQuery( this ).stop( true,false ).animate( {color: '#666'},50 );
				}, function ( ) {
				jQuery( this ).stop( true,false ).animate( {color: '#888'},150 );
			} );
/*-------------------------------------------------*/
// 	Homepage Top Button
/*-------------------------------------------------*/	
	jQuery('.top_trigger').click(function() {		
		var trigger_class = jQuery(this).attr("class");
		var new_class = new Array();
		new_class = trigger_class.split(" ");
		
		if(new_class[1] == "open"){
			jQuery(this).removeClass('open');
			jQuery(this).addClass('close');
		}else{
			jQuery(this).removeClass('close');
			jQuery(this).addClass('open');
		}
		
		//jQuery('.top .top_widget').slideToggle("slow");
	});
/*-------------------------------------------------*/
// Mobile Menu
/*-------------------------------------------------*/				
		jQuery('.mobile_menu').toggle(function(){
			jQuery('.nav-primary').slideDown(500);
		},function(){
			jQuery('.nav-primary').slideUp(500);
		});	
/*-------------------------------------------------*/
// Accordion
/*-------------------------------------------------*/	
			jQuery( '.accordion' ).hide( );
			jQuery( '.trigger-button' ).click( function( ) {
				jQuery( ".trigger-button" ).removeClass( "active" )
				jQuery( '.accordion' ).slideUp( 'normal' );
				if( jQuery( this ).next( ).is( ':hidden' ) == true ) {
					jQuery( this ).next( ).slideDown( 'normal' );
					jQuery( this ).addClass( "active" );
				 } 
			 } );
			 jQuery( '.trigger-button' ).hover( function( ) {
				jQuery( this ).stop( true,false ).animate( {color: '#666'},50 );
					}, function ( ) {
					jQuery( this ).stop( true,false ).animate( {color: '#888'},150 );
			} );

/*-------------------------------------------------*/
// Tab
/*-------------------------------------------------*/						

			jQuery( function( ) {
				jQuery( ".tabs-container" ).tabs();
			} );
});

/* ========== ISOTOPE FILTERING ========== */

jQuery(window).load(function(){	
		zp_portfolio_item_dimension();
		
		var jQuerycontainer = jQuery('#container');
		jQuerycontainer.isotope({
			 itemSelector : '.element',
			 filter: jQuery('#portfolio-categories li a.selected').attr('data-option-value')
		});
			
});

/* ========== REFRESJ ISOTOPE WHEN RESIZE ========== */

jQuery(window).resize(function(){	
	zp_portfolio_item_dimension();
	var jQuerycontainer = jQuery('#container');
	jQuerycontainer.isotope({
		 itemSelector : '.element',
		filter: jQuery('#portfolio-categories li a.selected').attr('data-option-value')
	});
});