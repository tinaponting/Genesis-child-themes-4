<?php 

// ZP Custom Post Types Initialization
function zp_custom_post_type() {
    if ( ! class_exists( 'Super_CPT' ) )
        return;
/*----------------------------------------------------*/

// Add Portfolio Custom Post Type

/*---------------------------------------------------*/
	$portfolio_custom_default = array(

		'supports' => array( 'title', 'editor', 'thumbnail', 'revisions', 'excerpt'),	
		'menu_icon' =>  get_stylesheet_directory_uri().'/includes/cpt/images/portfolio.png',

	);



	// register portfolio post type
	$portfolio = new Super_Custom_Post_Type( 'portfolio', 'Portfolio', 'Portfolio',  $portfolio_custom_default );
	$portfolio_category = new Super_Custom_Taxonomy( 'portfolio_category' ,'Portfolio Category', 'Portfolio Categories', 'cat' );
	connect_types_and_taxes( $portfolio, array( $portfolio_category ) );



	$portfolio->add_meta_box( array(

		'id' => 'portfolio-metaItem',
		'context' => 'normal',
		'priority' => 'high',
		'fields' => array(

			'zp_portfolio_meta_item_value' => array( 'label' =>__( 'Include Portfolio MetaItem','julia'), 'type' => 'select', 'options' => array('true' => 'True','false' => 'False'), 'data-zp_desc' => __('Select True to include meta on portfolio single page.','julia') ),
			'client_item_label_value' => array( 'label' => __('Client Label','julia'), 'type' => 'text', 'data-zp_desc' => __('Define client label','julia') ),
			'client_item_value' => array( 'label' => __('Client Value','julia'), 'type' => 'text', 'data-zp_desc' => __('Define client Value','julia')  ),		
			'date_item_label_value' => array( 'label' => __('Date Label','julia'), 'type' => 'text' , 'data-zp_desc' => __('Define date label','julia') ),	
			'date_item_value' => array( 'label' => __('Date Label','julia'), 'type' => 'text', 'data-zp_desc' =>  __('Define date label','julia')  ),				
			'category_item_label_value' => array( 'label' =>__( 'Category Label','julia'), 'type' => 'text', 'data-zp_desc' => __('Define category label' ,'julia') ),	
			'category_item_value' => array( 'label' => __('Category Value','julia'), 'type' => 'text', 'data-zp_desc' => __('Define category value','julia')  ),			
			'visit_project_label_value' => array( 'label' => __('Visit Project Label','julia'), 'type' => 'text', 'data-zp_desc' => __('Define visit project label','julia')  ),	
			'visit_project_value' => array( 'label' => __('Visit Project Link','julia'), 'type' => 'text', 'data-zp_desc' => __('Define visit project link','julia')  ),	
					
		)

	) );


	$portfolio->add_meta_box( array(
			'id' => 'portfolio-images',
			'context' => 'normal',
			'priority' => 'high',
			'fields' => array(
				'portfolio_images' => array( 'label' => __( 'Upload/Attach an image to this portfolio item. Images attached in here will be shown in the single portfolio page as a slider','prestige'), 'type' => 'multiple_media' , 'data-zp_desc' => __( 'Attach images to this portfolio item','prestige' )),
			)
		) );

	$portfolio->add_meta_box( array(
		'id' => 'portfolio-videos',
		'context' => 'normal',
		'priority' => 'high',
		'fields' => array(
			'zp_video_url_value' => array( 'label' => __('Youtube or Vimeo URL','julia'), 'type' => 'text', 'data-zp_desc' => __('Place here the video url. Example video url: YOUTUBE: https://www.youtube.com/watch?v=GsPq9mzFNGY and VIMEO: https://vimeo.com/139024795','julia') ),		

			'zp_video_embed_value' => array( 'label' => __('Embed Code','julia'), 'type' => 'textarea' , 'data-zp_desc' => __('If you are using anything else other than YouTube or Vimeo, paste the embed code here. This field will override anything from the above.','julia') ),	

			'zp_height_value' => array( 'label' => __('Video Height','julia'), 'type' => 'text', 'data-zp_desc' => __('Please input your video height. Example: 400','julia') )										

		)

	) );		

	// manage portfolio columns 
	function zp_add_portfolio_columns($columns) {

		return array(

			'cb' => '<input type="checkbox" />',
			'title' => __('Title', 'julia'),
			'portfolio_category' => __('Portfolio Category', 'julia'),
			'author' =>__( 'Author', 'julliette'),
			'date' => __('Date', 'julia'),			

		);

	}

	add_filter('manage_portfolio_posts_columns' , 'zp_add_portfolio_columns');


	function zp_custom_portfolio_columns( $column, $post_id ) {

		switch ( $column ) {
		case 'portfolio_category' :
			$terms = get_the_term_list( $post_id , 'portfolio_category' , '' , ',' , '' );
			if ( is_string( $terms ) )
				echo $terms;
			else
				_e( 'Unable to get author(s)', 'julia' );

			break;

		}

	}

	add_action( 'manage_posts_custom_column' , 'zp_custom_portfolio_columns', 10, 2 );

	

/*----------------------------------------------------*/

// Add Page Custom Meta

/*---------------------------------------------------*/

	$page_meta = new Super_Custom_Post_Meta( 'page' );

	$page_meta->add_meta_box( array(

		'id' => 'Page Image Wrap',
		'context' => 'side',
		'priority' => 'high',
		'fields' => array(

			'zp_page_image_value' => array( 'label' => __( 'Upload page Image Wrap','prestige'),'type' => 'media', 'data-zp_desc' => __('Add page image wrap.','julia') ),
		)

	) );

	$page_meta->add_meta_box( array(

		'id' => 'portfolio-page-settings',
		'context' => 'side',
		'priority' => 'high',
		'fields' => array(

			'column_number_value' => array( 'label' => __('Number of Columns','julia'), 'type' => 'select' , 'options' => array('2' => 'Two Columns','3' => 'Three Columns', '4' => 'Four Columns'), 'data-zp_desc' => __('Choose the portfolio page columns.','julia'))

		)



	) );	


	$page_meta = new Super_Custom_Post_Meta( 'post' );

	$page_meta->add_meta_box( array(

		'id' => 'Page Image Wrap',
		'context' => 'side',
		'priority' => 'high',
		'fields' => array(

			'zp_page_image_value' => array( 'label' => __( 'Upload page Image Wrap','prestige'),'type' => 'media', 'data-zp_desc' => __('Add page image wrap.','julia') ),
		)

	) );
				

}

add_action( 'after_setup_theme', 'zp_custom_post_type' );