<?php 
/*------------------------------------------------------------------------------------
	Theme Functions
------------------------------------------------------------------------------------*/

// Add new image sizes
add_image_size(  'Frontpage', 233, 150, TRUE  ); 
add_image_size(  'Mini', 125, 90, TRUE  ); 
add_image_size(  'Square', 86, 86, TRUE  );
add_image_size(  'Blog', 700, 310, TRUE  );
add_image_size(  'portfolio_2col', 560, 423, TRUE  );
add_image_size(  'portfolio_3col', 344, 305, TRUE  );
add_image_size(  'portfolio_4col', 280, 225, TRUE  );

/**
 * Get portfolio items values ( width, height, columns and number of items )
 * @param integer $columns - Number of Columns Set
 * @returns an array of values (width, height, column class) to be used in the template 
*/
function zp_portfolio_items_values( $columns ){
	$values = array();

	if(  $columns == 2  ){
		$values['image_size'] = 'portfolio_2col';
		$values['class'] = '-2col';
	}
	
	if(  $columns == 3  ){
		$values['image_size'] = 'portfolio_3col';
		$values['class'] = '-3col';
	}
	
	if(  $columns == 4  )
	{
		$values['image_size'] = 'portfolio_4col';
		$values['class'] = '-4col';
	}
	return $values;	
}

/**
 * Get the terms where the portfolio items belong and use as a class
 * Terms was used as a selector on the isotope fitler
 * @param integer $id - ID of the post
 * @returns string - list of terms separated by space
*/

function zp_portfolio_items_term( $id ){
	$output = '';
	
	$terms = wp_get_post_terms( $id, 'portfolio_category' );
	$term_string = '';
	foreach( $terms as $term ){
		$term_string.=( $term->slug ).',';
	}
	
	$term_string = substr( $term_string, 0, strlen( $term_string )-1 );
	
	/** separate terms with space*/
	$string = str_replace( ","," ",$term_string );
	$output = $string." ";
	
	return $output;
}

/**
 * Display portfolio items
 * @param integer $columns - number of columns to display
 * @param integer $num_items - number of items 
 * @param string $type - type of portfolio to display ( portfolio or gallery )
 * @param boolean $filter - enable/disable portfolio filter
 * @param string $category - portfolio category to display
*/
function zp_portfolio_template(  $columns, $num_items, $type, $filter, $category ){
	global $post, $paged, $wp_query;
	printf( '<article %s>', genesis_attr( 'entry' ) );
	
if( is_post_type_archive( 'portfolio' ) ){

echo '<header class="entry-header"><h1 class="entry-title" itemprop="headline">'.post_type_archive_title( '',false ).'</h1></header>';

}else if( is_tax( 'portfolio_category' ) ){

echo '<header class="entry-header"><h1 class="entry-title" itemprop="headline">'.single_tag_title( '',FALSE ).'</h1></header>';

}else if( is_page( ) ){

echo '<header class="entry-header"><h1 class="entry-title" itemprop="headline">'.the_title('','', false ).'</h1></header>';

}
		
if( have_posts( ) ) {

while ( have_posts( ) ) {

the_post( );

printf( '<div %s>', genesis_attr( 'entry-content' ) );

echo apply_filters( 'the_content', get_the_content() );

echo '</div>';

}

}


	
	//get column size and class		
		$values = zp_portfolio_items_values( $columns );
		
		$class = ( $type == 'portfolio' )? 'element' : 'gallery';

	
		$html='';
	
		$filter  = ( $filter ) ? '' : 'style="display: none"';
		echo '<div id="options" class="clearfix" '.$filter.'>';
		
		if( $category == '' ){
			$default = 'class="selected"';
		}else{
			$default = '';			
		}			
			
		echo '<ul id="portfolio-categories" class="option-set" data-option-key="filter"><li><a href="#" data-option-value="*" '.$default.'>'.__('Show all', 'julia').'</a></li>';						

		$term_args = array( 
			'orderby' => 'name',
			'order' => 'ASC',
			'taxonomy' => 'portfolio_category'
		 );
		
		$portfolio_categories = get_categories( $term_args );
			foreach( $portfolio_categories as $portfolio_cat ) :
				if( $category == $portfolio_cat->slug ){
					$selected = 'class="selected"';
				}else{
					$selected = '';	
				}
				
				echo '<li><a '.$selected.' href="#" data-option-value=".'.$portfolio_cat->slug.'">'.$portfolio_cat->name.'</a></li>';
			endforeach;
		
		echo '</ul></div>';	

		
		// check if it is the taxonomy page
		if(  !is_tax(  'portfolio_category'  )  ){ 
			$paged = get_query_var( 'paged' );
			$args= array(
				'posts_per_page' =>$num_items,
				'post_type' => 'portfolio',
				'paged' => $paged,
				'orderby' => 'date',
				'order' => 'DESC'
			);				
			$new_query = new WP_Query( $args );
		}else{
			$term =	$wp_query->queried_object;
			$args= array( 
				'posts_per_page' =>$num_items,
				'post_type' => 'portfolio',
				'paged' => $paged,
				'portfolio_category' => $term->slug
			);
		}
		$new_query = new WP_Query( $args );
		?>

<div id="container" style="height: auto; width: 100%;">
  <?php
		while($new_query->have_posts()) : $new_query->the_post();
			
			$t = get_the_title(  );
			$permalink=get_permalink(  );	
			$icon='';		
																		
			$thumbnail = wp_get_attachment_image( get_post_thumbnail_id(  $post->ID  ) , $values['image_size'] );
			$thumbnail_url = wp_get_attachment_image_src( get_post_thumbnail_id(  $post->ID  ) , 'full' );
			$video_url = get_post_meta( $post->ID, 'zp_video_url_value', true);
			$portfolio_images = get_post_meta( $post->ID, 'portfolio_images', true );

			//get the image title	
								
			$openLink='<div class="portfolio_image">';
			$closeLink='</div>';
					
			if(  $type == 'portfolio'  ){
					$icon='gallery-image';
					$span_icon='<a href="'.$permalink.'" id="icon"  style="top:0; display:block; position: absolute; opacity:0;"><h4>'.$t.'</h4></a>';	
			}else{
				
				if( $video_url != '' ){
					$icon='gallery-video';
					$span_icon='<a href="'.get_post_meta($post->ID, 'zp_video_url_value', true).'" rel="prettyPhoto[pp_gal]" id="icon"  style="top:0; display:block; position: absolute; opacity:0;"><h4>'.$t.'</h4></a>';
				}else{
					$icon='gallery-image';
					$span_icon='<a href="'.$thumbnail_url[0].'" rel="prettyPhoto[pp_gal]" title="'.$t.'" id="icon"  style="top:0; display:block; position: absolute; opacity:0;"><h4>'.$t.'</h4></a>';
					}
				}	
					
			$terms = wp_get_post_terms( $post->ID, 'portfolio_category' );
			$term_string='';
				foreach( $terms as $term ){
					$term_string.=( $term->slug ).',';
				}
			$term_string=substr( $term_string, 0, strlen( $term_string )-1 );
			$samp=str_replace( " ","-",$term_string );	
			$string = str_replace( ","," ",$samp );
			$finale= $string." ";	

								//generate the final item HTML
			$html.= '<div class="element '.$class.''.$values['class'].' '.$finale.'" data-filter="'.$finale.'">'.$openLink.''.$span_icon.''.$thumbnail.''.$closeLink.'</div>';
		endwhile;
		wp_reset_query(  );		
			echo $html;	
		?>
</div>
</div>
</article>
<?php



}





/*
* Portfolio Shortcode Function
*
* function for portfolio shortcode
*
* @param integer $columns - Number of Columns
* @param integer $num_items - Number of items to display
* @param string $type -  portfolio or gallery
* @param boolean $filter -  to either have a filter or not
*/
function  zp_portfolio_shortcode(  $columns, $num_items, $type, $filter  ){
	global $post, $paged;

	if(  $columns == 2  ){
		$column='2col';
		$num_post = $num_items;
	}else if(  $columns == 3  ){
		$column='3col';
		$num_post = $num_items;
	}else if(  $columns == 4  ){
		$column='4col';
		$num_post = $num_items;
	}else{
		$column='3col';
		$num_post = $num_items;
	}

	$html='';
	$output = '';
	$output .= '<div class="portfolio_shortcode">';
	if(  $filter  ){
		$output .= '<div id="options" class="clearfix">';
		$output .= '<ul id="portfolio-categories" class="option-set" data-option-key="filter"><li><a href="#" data-option-value="*" class="selected">show all</a></li>';

		$term_args = array(
			'orderby' => 'name',
			'order' => 'ASC',
			'taxonomy' => 'portfolio_category'
		);

		$categories = get_categories( $term_args );
		foreach( $categories as $category ) :
			$tms=str_replace( " ","-",$category->name );
			$output .= '<li><a class="active" href="#" data-option-value=".'.$category->slug.'">'.$category->name.'</a></li>';
		endforeach;

		$output .= '</ul></div>';
	}

	// check if it is the taxonomy page
	if(  !is_tax(  'portfolio_category'  )  ){
		$paged = get_query_var( 'paged' );

		$args= array(
			'posts_per_page' =>$num_post,
			'post_type' => 'portfolio',
			'paged' => $paged,
			'orderby' => 'date',
			'order' => 'DESC'
		);

		query_posts( $args );
	}

	$output .= '<div id="container" style="height: auto; width: 100%;">';
	if(  have_posts(  )  ) {
		while (  have_posts(  )  ) {
			the_post(  );
			$t=get_the_title(  );
			$permalink=get_permalink(  );

			$icon='';

			$thumbnail= wp_get_attachment_url(  get_post_thumbnail_id(  $post->ID  )  );
			$portfolio_thumb = wp_get_attachment_image_src( get_post_thumbnail_id(  $post->ID  ), $column );

			//get the image title

			$openLink='<div class="portfolio_image">';
			$closeLink='</div>';
					
			$icon='gallery-image';
			$span_icon='<a href="'.$permalink.'" id="icon"  style="top:0; display:block; position: absolute; opacity:0;"><h4>'.$t.'</h4></a>';	
					
			$terms = wp_get_post_terms( $post->ID, 'portfolio_category' );
			$term_string='';
				foreach( $terms as $term ){
					$term_string.=( $term->slug ).',';
				}
			$term_string=substr( $term_string, 0, strlen( $term_string )-1 );
			$samp=str_replace( " ","-",$term_string );	
			$string = str_replace( ","," ",$samp );
			$finale= $string." ";	


			//generate the final item HTML
			$html.= '<div class="element element-'.$column.' '.$finale.'" data-filter="'.$finale.'">'.$openLink.''.$span_icon.'<img src="'.$portfolio_thumb[0].'" title="'.get_the_title(  ).'" alt="'.$t.'" />'.$closeLink.'</div>';
		}
	}
	$output .= $html;
	$output .= '</div>';
	$output .= '</div>';
	wp_reset_query(  );

	return $output;
}


/**
 * Displays the related portfolio in the single portfolio page.
 */
function zp_related_portfolio(){
global $post;
		
	$terms = get_the_terms( $post->ID , 'portfolio_category' );	
	$term_ids = array_values( wp_list_pluck( $terms,'term_id' ) );
	$columns = genesis_get_option( 'zp_related_portfolio_columns' , ZP_SETTINGS_FIELD );
	$values = zp_portfolio_items_values( $columns );
	$html = '';

	$args=array(
     'post_type' => 'portfolio',
     'tax_query' => array(
                    array(
                        'taxonomy' => 'portfolio_category',
                        'field' => 'id',
                        'terms' => $term_ids,
                        'operator'=> 'IN' 
                     )),
      'posts_per_page' => 4,
      'orderby' => 'rand',
      'post__not_in'=>array($post->ID)
	);

	$new_query = new WP_Query( $args );
?>
<div class = "related_portfolio">
 <h4><?php echo genesis_get_option( 'zp_related_portfolio_title' , ZP_SETTINGS_FIELD ); ?>Related Portfolio</h4>
  <!-- Separator -->
    <div class="section_separator">
        <span class="separator_color"></span>
        <span class="separator_line"></span>
    </div>
    <!-- End Separator -->
</div>
<div class="related_container">
<div id="container" style="height: auto; width: 100%;">
  <?php
	while($new_query->have_posts()) : $new_query->the_post();
			$t = get_the_title(  );
			$permalink=get_permalink(  );	
			$icon='';		
																		
			$thumbnail = wp_get_attachment_image( get_post_thumbnail_id(  $post->ID  ) , $values['image_size'] );
			$thumbnail_url = wp_get_attachment_image_src( get_post_thumbnail_id(  $post->ID  ) , 'full' );
			$video_url = get_post_meta( $post->ID, 'zp_video_url_value', true);

			//get the image title	
								
			$openLink='<div class="portfolio_image">';
			$closeLink='</div>';
					
			$icon='gallery-image';
			$span_icon='<a href="'.$permalink.'" id="icon"  style="top:0; display:block; position: absolute; opacity:0;"><h4>'.$t.'</h4></a>';	
					
			$terms = wp_get_post_terms( $post->ID, 'portfolio_category' );
			$term_string='';
				foreach( $terms as $term ){
					$term_string.=( $term->slug ).',';
				}
			$term_string=substr( $term_string, 0, strlen( $term_string )-1 );
			$samp=str_replace( " ","-",$term_string );	
			$string = str_replace( ","," ",$samp );
			$finale= $string." ";	

			//generate the final item HTML
			$html.= '<div class="element element-4col'.$values['class'].' '.$finale.'" data-filter="'.$finale.'">'.$openLink.''.$span_icon.''.$thumbnail.''.$closeLink.'</div>';
	endwhile;
			echo $html;	
		?>
</div>
</div>
<?php }
