<?php
/**
 * Widgeted areas and related functions.
 *
 * @package     Julia Theme
 * @subpackage  Genesis
 * @copyright   Copyright (c) 2017, Cristina Sanz
 * @license     GPL-2.0+
 * @link        http://lovelyconfetti.com/feminine-wordpress-themes
 * @since       1.0.0
 */

//* Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'genesis_before', 'julia_before_header' );
/**
 * Load an ad section before .site-inner.
 *
 * @since   1.0.0
 *
 * @return  null if the before-header sidebar isn't active.
 */
function julia_before_header() {
	
	//* Return early if we have no ad.
	if ( ! is_active_sidebar( 'before-header' ) ) {
		return;
	}

	echo '<div class="before-header">';
		dynamic_sidebar( 'before-header' );
	echo '</div>';
}

add_action( 'genesis_before_comments', 'julia_after_entry' );

//* Load an after entry section before .entry-comments on single entries.

function julia_after_entry() {
	//* Return early if we have no ad.
	if ( ! is_active_sidebar( 'after-entry' ) ) {
		return;
	}

	echo '<div class="after-entry">';
		dynamic_sidebar( 'after-entry' );
	echo '</div>';
}

//* Register widget areas.

//* Register widget areas

genesis_register_sidebar( array(
	'id'          => 'front-page-image-1',
	'name'        => __( 'Front Page Image 1', 'julia' ),
	'description' => __( 'This is the front page 1 section with background image.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-2',
	'name'        => __( 'Front Page 2', 'julia' ),
	'description' => __( 'This is the front page 2 section.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-image-3',
	'name'        => __( 'Front Page Image 3', 'julia' ),
	'description' => __( 'This is the front page 3 section with background image.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-4',
	'name'        => __( 'Front Page 4', 'julia' ),
	'description' => __( 'This is the front page 4 section.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-image-5',
	'name'        => __( 'Front Page Image 5', 'julia' ),
	'description' => __( 'This is the front page 5 section with background image.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-6',
	'name'        => __( 'Front Page 6', 'julia' ),
	'description' => __( 'This is the front page 6 section.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-image-7',
	'name'        => __( 'Front Page Image 7', 'julia' ),
	'description' => __( 'This is the front page 5 section with background image.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'          => 'front-page-8',
	'name'        => __( 'Front Page 8', 'julia' ),
	'description' => __( 'This is the front page 8 section.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'          => 'after-footer',
	'name'        => __( 'After Footer', 'julia' ),
	'description' => __( 'This is the after footer section.', 'julia' ),
) );

genesis_register_sidebar( array(
	'id'          => 'before-header-left',
	'name'        => __( 'Before Header Left', 'julia' ),
	'description' => __( 'This is the section after the header to the left.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'          => 'before-header-right',
	'name'        => __( 'Before Header Right', 'julia' ),
	'description' => __( 'This is the section above the header to the right.', 'julia' ),
) );

genesis_register_sidebar( array(
	'id'			=> 'categories-top',
	'name'			=> __( 'Categories Top', 'julia' ),
	'description'	=> __( 'This is the categories top section.', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'categories-bottom',
	'name'			=> __( 'Categories Bottom', 'julia' ),
	'description'	=> __( 'This is the categories bottom section.', 'julia' ),
) );
genesis_register_sidebar( array(
    'id'            => 'woo_primary_sidebar',
    'name'          => __( 'Shop Sidebar', 'julia' ),
    'description' => __( 'This is the WooCommerce webshop sidebar', 'julia' ),
) );
genesis_register_sidebar( array(
	'id'			=> 'after-entry',
	'name'			=> __( 'Post Bottom', 'julia' ),
	'description'	=> __( 'This is the after entry section.', 'julia' ),
) );

 
add_filter( 'genesis_nav_items', 'julia_social_icons', 10, 2 );
add_filter( 'wp_nav_menu_items', 'julia_social_icons', 10, 2 );
 
function julia_social_icons($menu, $args) {
    $args = (array)$args;
    if ( 'primary' !== $args['theme_location'] )
        return $menu;
    ob_start();
    genesis_widget_area('nav-social-menu');
    $social = ob_get_clean();
    return $menu . $social;
}



