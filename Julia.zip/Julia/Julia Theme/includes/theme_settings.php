<?php
/**---------------------------------------------------------
 * ZP Theme Settings
------------------------------------------------------------*/
/* Define constants
------------------------------------------------------------ */
define( 'ZP_SETTINGS_FIELD', 'zp-settings' );
/* Setup default options
------------------------------------------------------------ */
/**
 * zpsettings_default_theme_options function.
 *
*/
function zpsettings_default_theme_options() {
	$options = array(
		'zp_welcome_enable' => 1,
		'zp_welcome_message' => __( 'This is the welcome message section','absolute' ),
		'zp_front_enable' => 1,
		'zp_home_portfolio_title' => 'Latest Portfolio',
		'zp_home_portfolio_desc' => '',
		'zp_home_portfolio_items' => 8,
		'zp_home_portfolio_columns' => 4,
		'zp_home_portfolio_title' => __( 'Latest Portfolio','absolute' ),
		'zp_home_portfolio_filter' => 1,
		'zp_latest_blog_enable' => 1,
		'zp_latest_blog_title' => __( 'Latest Blog','absolute' ),
		'zp_latest_blog_desc' => __( 'This is a blog description.','absolute' ),
		'zp_latest_blog_link_title' => __( 'Read More','absolute' ),
		'zp_latest_blog_link' => '#',
		'zp_latest_blog_items' => 6,
		'zp_latest_blog_category' => '',
		'zp_color_scheme' => 'default',
		'zp_css_code' => '',
		'zp_slider_enable' 	=> 1,
		'zp_slider_height' 	=> 380,
		'zp_animation' 	=> 'slide',
		'zp_slider_speed' 	=> 6000,
		'zp_animation_duration' 	=> 7000,
		'zp_control_nav' 	=> 'true',
		'zp_direction_nav' 	=> 'true',
		'zp_pauseonaction' 	=> 'true',
		'zp_pauseonhover' 	=> 'true',
		'zp_related_portfolio' => 1,
		'zp_related_portfolio_title' => __( 'Related Portfolio','absolute' ),
		'zp_num_portfolio_items' => 8,
		'zp_portfolio_categories_label' => 'Archives for: ',
		'zp_logo' => '',
		'zp_logo_height' => 64,
		'zp_logo_width' => 180,'zp_footer_text' 	=> ''
	);
	return apply_filters( 'zpsettings_default_theme_options', $options );
}
/* Sanitize any inputs
------------------------------------------------------------ */
add_action( 'genesis_settings_sanitizer_init', 'zpsettings_sanitize_inputs' );
/**
* zpsettings_sanitize_inputs function.
*
*/ 
function zpsettings_sanitize_inputs() {
    genesis_add_option_filter( 'one_zero', 
				ZP_SETTINGS_FIELD, 
				array( 					
					'zp_home_portfolio_filter',
					'zp_latest_blog_enable',	
					'zp_front_enable',
					'zp_welcome_enable'
				) 
	);
	
    genesis_add_option_filter( 'no_html', 
				ZP_SETTINGS_FIELD, 
				array( 
					'zp_home_portfolio_title',
					'zp_latest_blog_title',
					'zp_home_portfolio_items',
					'zp_latest_blog_link',
					'zp_latest_blog_items',
					'zp_slider_height',
					'zp_slider_speed',
					'zp_animation_duration',
					'zp_num_portfolio_items',
					'zp_logo_height',
					'zp_logo_height',
					'zp_logo',
					'zp_home_portfolio_title',
					'zp_portfolio_categories_label'
					
				) 
	);	
	 genesis_add_option_filter( 'requires_unfiltered_html', 
					ZP_SETTINGS_FIELD, 
					array( 
						'zp_welcome_message',
						'zp_latest_blog_desc',
						'zp_latest_blog_link_title',
						'zp_footer_text',
						'zp_logo_upload',
						'zp_home_portfolio_desc'				
					) 
		);		
}
/* Register our settings and add the options to the database
------------------------------------------------------------ */
add_action( 'admin_init', 'zpsettings_register_settings' );
/**
* zpsettings_register_settings function.
*
*/
function zpsettings_register_settings() {
	register_setting( ZP_SETTINGS_FIELD, ZP_SETTINGS_FIELD );
	add_option( ZP_SETTINGS_FIELD, zpsettings_default_theme_options() );
	
	if ( genesis_get_option( 'reset', ZP_SETTINGS_FIELD ) ) {
		update_option( ZP_SETTINGS_FIELD, zpsettings_default_theme_options() );
		genesis_admin_redirect( ZP_SETTINGS_FIELD, array( 'reset' => 'true' ) );
		exit;
	}
}
/* Admin notices for when options are saved/reset
------------------------------------------------------------ */
add_action( 'admin_notices', 'zpsettings_theme_settings_notice' );
/**
* zpsettings_theme_settings_notice function.
*/
function zpsettings_theme_settings_notice() {
	if ( ! isset( $_REQUEST['page'] ) || $_REQUEST['page'] != ZP_SETTINGS_FIELD )
		return;
	if ( isset( $_REQUEST['reset'] ) && 'true' == $_REQUEST['reset'] )
		echo '<div id="message" class="updated"><p><strong>' . __( 'Settings reset.', 'absolute' ) . '</strong></p></div>';
	elseif ( isset( $_REQUEST['settings-updated'] ) && 'true' == $_REQUEST['settings-updated'] )
		echo '<div id="message" class="updated"><p><strong>' . __( 'Settings saved.', 'absolute' ) . '</strong></p></div>';
}
/* Register our theme options page
------------------------------------------------------------ */
add_action( 'admin_menu', 'zpsettings_theme_options' );
/**
* zpsettings_theme_options function.
*
*/
function zpsettings_theme_options() {
	global $_zpsettings_settings_pagehook;
	$_zpsettings_settings_pagehook = add_submenu_page( 'genesis', 'Absolute Settings', 'Absolute Settings', 'edit_theme_options', ZP_SETTINGS_FIELD, 'zpsettings_theme_options_page' );
	//add_action( 'load-'.$_zpsettings_settings_pagehook, 'zpsettings_settings_styles' );
	add_action( 'load-'.$_zpsettings_settings_pagehook, 'zpsettings_settings_scripts' );
	add_action( 'load-'.$_zpsettings_settings_pagehook, 'zpsettings_settings_boxes' );
}
/* Setup our scripts
------------------------------------------------------------ */
/**
* zpsettings_settings_scripts function.
* This function enqueues the scripts needed for the ZP Settings settings page.
*/
function zpsettings_settings_scripts() {	
	global $_zpsettings_settings_pagehook;
	
	if( is_admin() ){
	
	wp_register_script( 'zp_image_upload', get_stylesheet_directory_uri() .'/include/upload/image-upload.js', array('jquery','media-upload','thickbox') );	
	wp_enqueue_script('media-upload');
	wp_enqueue_script('jquery');
	wp_enqueue_script('thickbox');
	wp_enqueue_style('thickbox');
	wp_enqueue_script( 'common' );
	wp_enqueue_script( 'wp-lists' );
	wp_enqueue_script( 'postbox' );
	
	wp_enqueue_media( );
	wp_enqueue_script('zp_image_upload');
}
}
/* Setup our metaboxes
------------------------------------------------------------ */
/**
* zpsettings_settings_boxes function.
*
* This function sets up the metaboxes to be populated by their respective callback functions.
*
*/
function zpsettings_settings_boxes() {
	global $_zpsettings_settings_pagehook;
	add_meta_box( 'zpsettings_home_welcome', __( 'Home Welcome Message', 'absolute' ), 'zpsettings_home_welcome', $_zpsettings_settings_pagehook, 'main', 'high' );
	add_meta_box( 'zpsettings_home_portfolio', __( 'Home Portfolio Settings', 'absolute' ), 'zpsettings_home_portfolio', $_zpsettings_settings_pagehook, 'main', 'high' );
	add_meta_box( 'zpsettings_home_blog', __( 'Home Blog Settings', 'absolute' ), 'zpsettings_home_blog', $_zpsettings_settings_pagehook, 'main','high' );
	add_meta_box( 'zpsettings_slideshow_settings', __( 'Slideshow Settings', 'absolute' ), 'zpsettings_slideshow_settings', $_zpsettings_settings_pagehook, 'main','high' );
	add_meta_box( 'zpsettings_appearance_settings', __( 'Appearance Settings', 'absolute' ), 'zpsettings_appearance_settings', $_zpsettings_settings_pagehook, 'main' ,'high');	
	add_meta_box( 'zpsettings_portfolio', __( 'Portfolio Settings ', 'absolute' ), 'zpsettings_portfolio', $_zpsettings_settings_pagehook, 'main','high' );	
	add_meta_box( 'zpsettings_footer_settings', __( 'Footer Settings', 'absolute' ), 'zpsettings_footer_settings', $_zpsettings_settings_pagehook, 'main','high' );	
}
/* Add our custom post metabox for social sharing
------------------------------------------------------------ */
/**
* zpsettings_home_settings function.
*
* Callback function for the ZP Settings Social Sharing metabox.
*
*/
 
function zpsettings_home_welcome(){?>
<p><input type="checkbox" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_welcome_enable]" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_welcome_enable]" value="1" <?php checked( 1, genesis_get_option( 'zp_welcome_enable', ZP_SETTINGS_FIELD ) ); ?> /> <label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_welcome_enable]"><?php _e( 'Check to enable welcome message.', 'absolute' ); ?></label>    </p>
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_welcome_message]"><?php _e( 'Welcome Message', 'absolute' ); ?><br>
	<textarea class="widefat" rows="3" cols="78" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_welcome_message]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_welcome_message]"><?php echo genesis_get_option( 'zp_welcome_message', ZP_SETTINGS_FIELD ); ?></textarea>
	</label>
	</p>
<?php
}
 
function zpsettings_home_portfolio() { ?>
<p>	<input type="checkbox" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_front_enable]" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_front_enable]" value="1" <?php checked( 1, genesis_get_option( 'zp_front_enable', ZP_SETTINGS_FIELD ) ); ?> /> <label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_front_enable]"><?php _e( 'Check to enable Portfolio on the home page.', 'absolute' ); ?></label>
</p>
 <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_title]"><?php _e( 'Home Portfolio Title', 'absolute' ) ?></label>
	<input type="text" size="30" value="<?php echo genesis_get_option( 'zp_home_portfolio_title', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_title]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_title]"></p> 
    
 <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_desc]"><?php _e( 'Home Portfolio Description', 'absolute' ) ?></label>
	<textarea class="widefat" rows="3" cols="78" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_desc]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_desc]"><?php echo genesis_get_option( 'zp_home_portfolio_desc', ZP_SETTINGS_FIELD ); ?></textarea></p> 
        
 <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_items]"><?php _e( 'Number of Portfolio Items', 'absolute' ) ?></label>
	<input type="text" size="30" value="<?php echo genesis_get_option( 'zp_home_portfolio_items', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_items]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_items]"></p> 
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_columns]"><?php _e( 'Home Portfolio Columns:','absolute' );?></label>
	<select id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_columns]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_columns]">         
	<option value="2" <?php selected( genesis_get_option( 'zp_home_portfolio_columns', ZP_SETTINGS_FIELD ), '2' ); ?>>Two Columns</option>
	<option  value="3" <?php selected( genesis_get_option( 'zp_home_portfolio_columns', ZP_SETTINGS_FIELD ), '3' ); ?>>Three Columns</option>
    <option  value="4" <?php selected( genesis_get_option( 'zp_home_portfolio_columns', ZP_SETTINGS_FIELD ), '4' ); ?>>Four Columns</option>
    </select></p>    
    
	<p><input type="checkbox" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_filter]" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_filter]" value="1" <?php checked( 1, genesis_get_option( 'zp_home_portfolio_filter', ZP_SETTINGS_FIELD ) ); ?> /> <label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_portfolio_filter]"><?php _e( 'Check to enable Portfolio Filter on the home page.', 'absolute' ); ?></label></p>
    <p><span class="description"><?php _e( 'This settings applies to the home page portfolio section.','absolute' ) ?></span></p>  
    
<?php }
 
function zpsettings_home_blog() { ?>
	<p><input type="checkbox" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_enable]" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_enable]" value="1" <?php checked( 1, genesis_get_option( 'zp_latest_blog_enable', ZP_SETTINGS_FIELD ) ); ?> /> <label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_enable]"><?php _e( 'Check to enable homepage latest blog section..', 'absolute' ); ?></label>  </p>
      
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_title]"><?php _e( 'Latest Blog Title', 'absolute' ); ?></label>
	<input type="text" size="30" value="<?php echo genesis_get_option( 'zp_latest_blog_title', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_title]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_title]">
	</p>    
    
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_desc]"><?php _e( 'Latest Blog Description', 'absolute' ); ?><br>
	<textarea class="widefat" rows="3" cols="78" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_desc]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_desc]"><?php echo genesis_get_option( 'zp_latest_blog_desc', ZP_SETTINGS_FIELD ); ?></textarea>
	</label>
	</p>
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_items]"><?php _e( 'Number of Latest Blog', 'absolute' ); ?></label>
	<input type="text" size="30" value="<?php echo genesis_get_option( 'zp_latest_blog_items', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_items]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_items]">
	</p>    
     
    <p>
        <label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_category]"><?php _e( 'Select Blog Category', 'absolute' ); ?></label>
        <select name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_category]" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_latest_blog_category]">
            <option value=""><?php _e( 'Default', 'genesis' ); ?></option>
            <?php
				$of_categories_obj = get_categories('hide_empty=0');
				foreach ($of_categories_obj as $of_cat) {
                    ?><option value="<?php echo $of_cat->slug; ?>" <?php selected( genesis_get_option( 'zp_latest_blog_category', ZP_SETTINGS_FIELD ), $of_cat->slug ); ?> > <?php echo $of_cat->name; ?></option><?php
                }
            ?>
        </select>
    </p>
    
              
    <p><span class="description"><?php _e( 'This settings applies to the home page blog section.','absolute' ); ?> </span></p>  
	
<?php }
function zpsettings_slideshow_settings() { ?>
	<p><input type="checkbox" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_slider_enable]" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_slider_enable]" value="1" <?php checked( 1, genesis_get_option( 'zp_slider_enable', ZP_SETTINGS_FIELD ) ); ?> /> <label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_slider_enable]"><?php _e( 'Check to enable slider.', 'absolute' ); ?></label></p>
    <p>
        <label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_slideshow]"><?php _e( 'Select HomePage Slideshow', 'absolute' ); ?></label>
        <select name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_slideshow]" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_home_slideshow]">
            <?php
                $of_categories_obj = get_terms('slideshow');
                foreach ($of_categories_obj as $of_cat) {
                    ?><option value="<?php echo $of_cat->slug; ?>" <?php selected( genesis_get_option( 'zp_home_slideshow', ZP_SETTINGS_FIELD ), $of_cat->slug ); ?> > <?php echo $of_cat->name; ?></option><?php
                }
            ?>
        </select>
    </p>    
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_slider_height]"><?php _e( 'Slider Height (in pixel)', 'absolute' ); ?></label>
	<input type="text" size="30" value="<?php echo genesis_get_option( 'zp_slider_height', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_slider_height]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_slider_height]">
	</p>      
    <p>
	<label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_animation]"><?php _e( 'Select slider animation:','absolute' );?></label>
	<select id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_animation]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_animation]">         
	<option value="fade" <?php selected( genesis_get_option( 'zp_animation', ZP_SETTINGS_FIELD ), 'fade' ); ?>>Fade</option>
<option  value="slide" <?php selected( genesis_get_option( 'zp_animation', ZP_SETTINGS_FIELD ), 'slide' ); ?>>Slide</option>
    </select>
	</p>
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_slider_speed]"><?php _e( 'Set the speed of slideshow cycling in milliseconds.', 'absolute' ); ?></label>
	<input type="text" size="20" value="<?php echo genesis_get_option( 'zp_slider_speed', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_slider_speed]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_slider_speed]">
	</p> 
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_animation_duration]"><?php _e( 'Set the speed of animation in milliseconds.', 'absolute' ); ?></label>
	<input type="text" size="20" value="<?php echo genesis_get_option( 'zp_animation_duration', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_animation_duration]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_animation_duration]">
	</p>    
    
	<p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_control_nav]"><?php _e( 'Control Navigation.','absolute'); ?></label>
    <select id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_control_nav]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_control_nav]">         
	<option value="true" <?php selected( genesis_get_option( 'zp_control_nav', ZP_SETTINGS_FIELD ), 'true' ); ?>>True</option>
	<option  value="false" <?php selected( genesis_get_option( 'zp_control_nav', ZP_SETTINGS_FIELD ), 'false' ); ?>>False</option>
    </select>
	</p>    
    
	<p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_direction_nav]"><?php _e( 'Direction Navigation.','absolute'); ?></label>
    <select id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_direction_nav]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_direction_nav]">         
	<option value="true" <?php selected( genesis_get_option( 'zp_direction_nav', ZP_SETTINGS_FIELD ), 'true' ); ?>>True</option>
	<option  value="false" <?php selected( genesis_get_option( 'zp_direction_nav', ZP_SETTINGS_FIELD ), 'false' ); ?>>False</option>
    </select>
	</p>        
   	<p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_pauseonaction]"><?php _e( 'Pause on Action.','absolute'); ?></label>
    <select id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_pauseonaction]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_pauseonaction]">         
	<option value="true" <?php selected( genesis_get_option( 'zp_pauseonaction', ZP_SETTINGS_FIELD ), 'true' ); ?>>True</option>
	<option  value="false" <?php selected( genesis_get_option( 'zp_pauseonaction', ZP_SETTINGS_FIELD ), 'false' ); ?>>False</option>
    </select>
	</p> 
 
   	<p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_pauseonhover]"><?php _e( 'Pause on Hover.','absolute'); ?></label>
    <select id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_pauseonhover]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_pauseonhover]">         
	<option value="true" <?php selected( genesis_get_option( 'zp_pauseonhover', ZP_SETTINGS_FIELD ), 'true' ); ?>>True</option>
	<option  value="false" <?php selected( genesis_get_option( 'zp_pauseonhover', ZP_SETTINGS_FIELD ), 'false' ); ?>>False</option>
    </select>
	</p>        
   
<?php }
function zpsettings_appearance_settings() { ?>
     <p>
	<label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_color_scheme]"><?php _e( 'Select color scheme.','absolute'); ?></label>
	<select id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_color_scheme]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_color_scheme]">         
	<option value="default" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'default' ); ?>>Default</option>
	<option  value="dark" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'dark' ); ?>>dark</option>
   	<option  value="blue" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'blue' ); ?>>blue</option>
	<option  value="brown" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'brown' ); ?>>brown</option>
	<option  value="green" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'green' ); ?>>green</option>
	<option  value="light_blue" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'light_blue' ); ?>>light_blue</option>            
	<option  value="magenta" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'magenta' ); ?>>magenta</option>
	<option  value="orange" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'orange' ); ?>>orange</option>
	<option  value="pink" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'pink' ); ?>>pink</option>
    <option  value="red" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'red' ); ?>>red</option>
    <option  value="yellow" <?php selected( genesis_get_option( 'zp_color_scheme', ZP_SETTINGS_FIELD ), 'yellow' ); ?>>yellow</option>
    </select>
	</p>
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_css_code]"><?php _e( 'Custom CSS Code.', 'absolute' ); ?><br>
	<textarea class="widefat" rows="3" cols="78" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_css_code]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_css_code]"><?php echo genesis_get_option( 'zp_css_code', ZP_SETTINGS_FIELD ); ?></textarea>
	</label>
	</p>  
     
   <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo]"><?php _e( 'Upload Custom Logo.', 'brutal' ); ?></label>
    <input type="text" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo]" value="<?php echo  genesis_get_option( 'zp_logo', ZP_SETTINGS_FIELD ); ?>" />    
    <input id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo_upload_button]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo_upload_button]" type="button" class="button upload_button" value="<?php _e( 'Upload Logo', 'brutal' ); ?>" /> 
	<input name="zp_remove_button" type="button"  class="button remove_button" value="<?php _e( 'Remove Logo', 'brutal' ); ?>" /> 
    <span class="upload_preview" style="display: block;">
		<img style="max-width:100%;" src="<?php echo genesis_get_option( 'zp_logo', ZP_SETTINGS_FIELD ); ?>" />
	</span>
    </p>

    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo_width]"><?php _e( 'Custom Logo Width in pixel. e.g. 200', 'brutal' ); ?></label>

	<input type="text" size="30" value="<?php echo genesis_get_option( 'zp_logo_width', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo_width]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo_width]">

	</p> 
    
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo_height]"><?php _e( 'Custom Logo Height in pixel. e.g. 200', 'brutal' ); ?></label>

	<input type="text" size="30" value="<?php echo genesis_get_option( 'zp_logo_height', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo_height]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_logo_height]">

	</p>       

    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_favicon]"><?php _e( 'Upload Custom Favicon.', 'brutal' ); ?></label>  

    <input type="text" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_favicon]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_favicon]" value="<?php echo  genesis_get_option( 'zp_favicon', ZP_SETTINGS_FIELD ); ?>" />

    <input id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_favicon_upload_button]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_favicon_upload_button]" type="button" class="button upload_button" value="<?php _e( 'Upload Favicon', 'brutal' ); ?>" />
    <input name="zp_remove_button" type="button"  class="button remove_button" value="<?php _e( 'Remove Favicon', 'brutal' ); ?>" /> 
    <span class="upload_preview" style="display: block;">
		<img style="max-width:100%;" src="<?php echo genesis_get_option( 'zp_favicon', ZP_SETTINGS_FIELD ); ?>" />
	</span>
    </p>
   
	<p><span class="description"><?php _e( 'This is the appearance settings.','absolute' ); ?></span></p>    
	
<?php } 
function zpsettings_footer_settings() { ?>
    <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_footer_text]"><?php _e( 'Footer Text', 'absolute' ); ?><br>
	<textarea class="widefat" rows="3" cols="78" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_footer_text]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_footer_text]"><?php echo genesis_get_option( 'zp_footer_text', ZP_SETTINGS_FIELD ); ?></textarea>
	<br><small><strong><?php _e( 'Enter your site copyright here.', 'absolute' ); ?></strong></small>
	</label>
	</p>    
	
<?php }
function zpsettings_portfolio() { ?>
    <p>	<input type="checkbox" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio]" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio]" value="1" <?php checked( 1, genesis_get_option( 'zp_related_portfolio', ZP_SETTINGS_FIELD ) ); ?> /> <label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio]"><?php _e( 'Check to enable related portfolio in single portfolio page.', 'absolute' ); ?></label>
    </p>
     <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio_title]"><?php _e( 'Related Portfolio Title', 'absolute' ) ?></label>
        <input type="text" size="30" value="<?php echo genesis_get_option( 'zp_related_portfolio_title', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio_title]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_related_portfolio_title]"></p> 
        
     <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_num_portfolio_items]"><?php _e( 'Number of items in the portfolio page', 'absolute' ) ?></label>
        <input type="text" size="30" value="<?php echo genesis_get_option( 'zp_num_portfolio_items', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_num_portfolio_items]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_num_portfolio_items]"></p>      
      <p><label for="<?php echo ZP_SETTINGS_FIELD; ?>[zp_portfolio_categories_label]"><?php _e( 'Portfolio Categories Label', 'absolute' ) ?></label>
        <input type="text" size="30" value="<?php echo genesis_get_option( 'zp_portfolio_categories_label', ZP_SETTINGS_FIELD ); ?>" id="<?php echo ZP_SETTINGS_FIELD; ?>[zp_portfolio_categories_label]" name="<?php echo ZP_SETTINGS_FIELD; ?>[zp_portfolio_categories_label]"></p>        
 
     <p><span class="description"><?php _e( 'This settings applies to portfolio.','absolute' ) ?></span></p>  
    
<?php }
/* Replace the 'Insert into Post Button inside Thickbox'
------------------------------------------------------------ */
function zp_replace_thickbox_text($translated_text, $text ) {	
	if ( 'Insert into Post' == $text ) {
		$referer = strpos( wp_get_referer(), ZP_SETTINGS_FIELD );
		if ( $referer != '' ) {
			return __('Insert Image!', 'absolute' );
		}
	}
	return $translated_text;
}
/* Hook to filter Insert into Post Button in thickbox
------------------------------------------------------------ */
function zp_change_insert_button_text() {
		add_filter( 'gettext', 'zp_replace_thickbox_text' , 1, 2 );
}
add_action( 'admin_init', 'zp_change_insert_button_text' );
/* Set the screen layout to one column
------------------------------------------------------------ */
add_filter( 'screen_layout_columns', 'zpsettings_settings_layout_columns', 10, 2 );
/**
* zpsettings_settings_layout_columns function.
*
* This function sets the column layout to one for the ZP Settings settings page.
*
*/
function zpsettings_settings_layout_columns( $columns, $screen ) {
	global $_zpsettings_settings_pagehook;
	if ( $screen == $_zpsettings_settings_pagehook ) {
		$columns[$_zpsettings_settings_pagehook] = 2;
	}
	return $columns;
}
/* Build our theme options page
------------------------------------------------------------ */
/**
* zpsettings_theme_options_page function.
*
* This function displays the content for the ZP Settings settings page, builds the forms and outputs the metaboxes.
*
*/
function zpsettings_theme_options_page() { 
	global $_zpsettings_settings_pagehook, $screen_layout_columns;
	$screen = get_current_screen();
	$width = "width: 100%;";
	$hide2 = $hide3 = " display: none;";
	?>	
	
	<div id="zpsettings" class="wrap genesis-metaboxes">
		<form method="post" action="options.php">
		
			<?php wp_nonce_field( 'closedpostboxes', 'closedpostboxesnonce', false ); ?>
			<?php wp_nonce_field( 'meta-box-order', 'meta-box-order-nonce', false ); ?>
			<?php settings_fields( ZP_SETTINGS_FIELD ); ?>
		
			<h2>
				<?php _e( 'Absolute Child Theme Settings', 'absolute' ); ?>
				<input type="submit" class="button-primary genesis-h2-button" value="<?php _e( 'Save Settings', 'absolute' ) ?>" />
				<input type="submit" class="button genesis-h2-button" name="<?php echo ZP_SETTINGS_FIELD; ?>[reset]" value="<?php _e( 'Reset Settings', 'absolute' ); ?>" onclick="return genesis_confirm('<?php echo esc_js( __( 'Are you sure you want to reset?', 'absolute' ) ); ?>');" />
			</h2>
			<div class="metabox-holder">
				<div class="postbox-container" style="<?php echo $width; ?>">
					<?php do_meta_boxes( $_zpsettings_settings_pagehook, 'main', null ); ?>
				</div>
			</div>
		
		</form>
	</div>
	<script type="text/javascript">
		//<![CDATA[
		jQuery(document).ready( function($) {
			// close postboxes that should be closed
			$('.if-js-closed').removeClass('if-js-closed').addClass('closed');
			// postboxes setup
			postboxes.add_postbox_toggles('<?php echo $_zpsettings_settings_pagehook; ?>');
		});
		//]]>
	</script>
<?php }