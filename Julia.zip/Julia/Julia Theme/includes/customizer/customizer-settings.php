<?php

/**

 * Register Customizer settings.
 *
 * @package     Julia Theme
 * @subpackage  Genesis
 * @copyright   Copyright (c) 2017, Cristina Sanz
 * @license     GPL-2.0+
 * @link        https://lovelyconfetti.com/feminine-wordpress-themes
 * @since       1.0.0

 */

//* Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

//* Continue if the Customizer_Library exists.
if ( class_exists( 'Customizer_Library' ) ) :
add_action( 'customize_register', 'julia_remove_customizer_defaults' );

//* Remove unwanted default customizer sections for the julia theme.
function julia_remove_customizer_defaults( $wp_customize ) {

	$wp_customize->remove_section( 'colors' );

}

add_action( 'customize_register', 'julia_register_customizer_settings' );

//* Register custom sections for the julia theme.

function julia_register_customizer_settings() {

	// Stores all the controls that will be added
	$options = array();

	// Stores all the sections to be added
	$sections = array();

	// Adds the sections to the $options array
	$options['sections'] = $sections;

	// Colors
	$section = 'julia_colors';
	$sections[] = array(

		'id'          => $section,
		'title'       => __( 'Colors', 'julia' ),
		'description' => __( 'You can customize your theme colors by changing any of the options below.', 'julia' ),
		'priority'    => '70',

	);

	$colors = julia_get_colors();

	$counter = 20;

	foreach ( $colors as $color => $setting ) {

		$options[ $color ] = array(
			'id'       => $color,
			'label'    => $setting['label'],
			'section'  => $section,
			'type'     => 'color',
			'default'  => $setting['default'],
			'priority' => $counter++,

		);

	}


//* Allow users to disable Google Fonts Output.

	if ( ! apply_filters( 'julia_disable_google_fonts', false ) ) {

		// Typography

		$section = 'julia_typography';
		$sections[] = array(

			'id'          => $section,
			'title'       => __( 'Typography', 'julia' ),
			'description' => __( 'You can customize your website with more than 60 beautiful Google Fonts. For best results, I recommend using no more than two unique font families.', 'julia' ),

			'priority'    => '75',

		);


		$fonts = julia_get_fonts();
		$counter = 20;

		foreach ( $fonts as $font => $setting ) {

			$options[ $font . '_family' ] = array(

				'id'      => $font . '_family',
				'label'   => $setting['label'] . __( ' Family', 'julia' ),
				'section' => $section,
				'type'    => 'select',
				'choices' => customizer_library_get_font_choices(),
				'default' => $setting['default_family'],

			);

			$choices = array(
				'200' => 'Extra Light',
				'300' => 'Light',
				'400' => 'Normal',
				'700' => 'Bold',
				'900' => 'Extra Bold',

			);

			$options[ $font . '_weight' ] = array(
				'id'      => $font . '_weight',
				'label'   => $setting['label'] . __( ' Weight', 'julia' ),
				'section' => $section,
				'type'    => 'select',
				'choices' => $choices,
				'default' => $setting['default_weight'],

			);

			if ( 'disabled' !== $setting['default_size'] ) {

				$choices = array(
					'10px' => '10px',
					'11px' => '11px',
					'12px' => '12px',
					'13px' => '13px',
					'14px' => '14px',
					'15px' => '15px',
					'16px' => '16px',
					'17px' => '17px',
					'18px' => '18px',
					'19px' => '19px',
					'20px' => '20px',
					'21px' => '22px',
					'22px' => '22px',
					'23px' => '23px',
					'24px' => '24px',
					'25px' => '25px',
					'26px' => '26px',
					'27px' => '27px',
					'28px' => '28px',
					'29px' => '29px',
					'30px' => '30px',
					'31px' => '31px',
					'32px' => '32px',
					'33px' => '33px',
					'34px' => '34px',
					'35px' => '35px',
					'36px' => '36px',
					'37px' => '37px',
					'38px' => '38px',
					'39px' => '39px',
					'40px' => '40px',
					'41px' => '41px',
					'42px' => '42px',
					'43px' => '43px',
					'44px' => '44px',
					'45px' => '45px',
					'46px' => '46px',
					'47px' => '47px',
					'48px' => '48px',
					'49px' => '49px',
					'50px' => '50px',
					'51px' => '51px',
					'52px' => '52px',
					'53px' => '53px',
					'54px' => '54px',

				);

				$options[ $font . '_size' ] = array(
					'id'      => $font . '_size',
					'label'   => $setting['label'] . __( ' Size', 'julia' ),
					'section' => $section,
					'type'    => 'select',
					'choices' => $choices,
					'default' => $setting['default_size'],

				);

			}

			if ( 'disabled' !== $setting['default_style'] ) {

				$choices = array(
					'normal' => 'Normal',
					'italic' => 'Italic',

				);

				$options[ $font . '_style' ] = array(
					'id'      => $font . '_style',
					'label'   => $setting['label'] . __( ' Style', 'julia' ),
					'section' => $section,
					'type'    => 'select',
					'choices' => $choices,
					'default' => $setting['default_style'],

				);

			}

		}

	}

	$choices = array(
		'full'       => __( 'Full Width', 'julia' ),
		'one_half'   => __( 'One Half', 'julia' ),
		'one_third'  => __( 'One Third', 'julia' ),
		'one_fourth' => __( 'One Fourth', 'julia' ),
		'one_sixth'  => __( 'One Sixth', 'julia' ),

	);

	$options['julia_archive_grid'] = array(
		'id'      => 'julia_archive_grid',
		'label'   => __( 'Archive Grid Display:', 'julia' ),
		'section' => 'genesis_archives',
		'type'    => 'select',
		'choices' => $choices,
		'default' => 'full',
		'priority' => 0,

	);

	$options['julia_archive_show_title'] = array(
		'id'       => 'julia_archive_show_title',
		'label'    => __( 'Display The Title?', 'julia' ),
		'section'  => 'genesis_archives',
		'type'     => 'checkbox',
		'default'  => 1,
		'priority' => 5,

	);

	$options['julia_archive_show_info'] = array(
		'id'       => 'julia_archive_show_info',
		'label'    => __( 'Display The Entry Info?', 'julia' ),
		'section'  => 'genesis_archives',
		'type'     => 'checkbox',
		'default'  => 1,
		'priority' => 6,

	);

	$options['julia_archive_show_content'] = array(
		'id'       => 'julia_archive_show_content',
		'label'    => __( 'Display The Content?', 'julia' ),
		'section'  => 'genesis_archives',
		'type'     => 'checkbox',
		'default'  => 1,
		'priority' => 7,

	);

	$options['julia_archive_show_meta'] = array(
		'id'       => 'julia_archive_show_meta',
		'label'    => __( 'Display The Entry Meta?', 'julia' ),
		'section'  => 'genesis_archives',
		'type'     => 'checkbox',
		'default'  => 1,
		'priority' => 8,

	);

	$choices = array(
		'after_title'   => __( 'After Title', 'julia' ),
		'before_title'  => __( 'Before Title', 'julia' ),
		'after_content' => __( 'After Content', 'julia' ),

	);

	$options['julia_archive_image_placement'] = array(
		'id'      => 'julia_archive_image_placement',
		'label'   => __( 'Featured Image Placement:', 'julia' ),
		'section' => 'genesis_archives',
		'type'    => 'select',
		'choices' => $choices,
		'default' => 'after_title',

	);

	// Adds the sections to the $options array

	$options['sections'] = $sections;
	$customizer_library = Customizer_Library::Instance();
	$customizer_library->add_options( $options );

}

//* An array of the color settings used in julia Theme.



function julia_get_colors() {

	$colors = array(

		'julia_element_border_color' => array(
			'default'  => '#eee',
			'label'    => __( 'Element border color Color', 'julia' ),
			'selector' => '.title-area, .nav-primary, .nav-secondary, .genesis-nav-menu .sub-menu, .front-page-6 .woocommerce ul.cart_list li img, .front-page-4 .woocommerce ul.product_list_widget li img, .navigation-container.fixed, .sidebar .widget, .sidebar h3.widget-title, .entry-footer .entry-meta, .julia .easyrecipe, .related-list img, .entry-footer .entry-meta .entry-tags, .front-page-6 .woocommerce ul.product_list_widget li img, .front-page-4 .featured-content img, .front-page-6 .featured-content img, .gallery img, li.comment, .pricing-table .one-third:nth-child(3n+2), .pricing-table .one-third:nth-child(3n+1), .pricing-table .one-third:nth-child(3n), .front-page-3 .enews input, .front-page-5 .enews input, .entry-time, .entry-author, #top-link, .pricing-table h4, .content .share-after, .entry-categories, .entry-tags, .woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page div.product .woocommerce-tabs ul.tabs li, .sidebar-primary, .footer-widgets-3, .woocommerce #content div.product .woocommerce-tabs .panel, .woocommerce div.product .woocommerce-tabs .panel, .woocommerce-page #content div.product .woocommerce-tabs .panel, .woocommerce-page div.product .woocommerce-tabs .panel, .authorStuff, .dateStuff, .categoryStuff, #top-link i, .front-page-2 div.one-half.pricing, .front-page-2 div.one-third.pricing, .front-page-2 div.two-third.pricing, .front-page-2 div.three-fourth.pricing, .front-page-2 div.one-fourth.pricing, .front-page-image-3 div.one-half.pricing, .front-page-image-3 div.one-third.pricing, .front-page-image-3 div.two-third.pricing,.front-page-image-3 div.three-fourth.pricing, .front-page-image-3 div.one-fourth.pricing, .front-page-4 div.one-half.pricing, .front-page-4 div.one-third.pricing, .front-page-4 div.two-third.pricing, .front-page-4 div.three-fourth.pricing, .front-page-4 div.one-fourth.pricing, .front-page-image-5 div.one-half.pricing, .front-page-image-5 div.one-third.pricing, .front-page-image-5 div.two-third.pricing, .front-page-image-5 div.three-fourth.pricing, .front-page-image-5 div.one-fourth.pricing, .front-page-6 div.one-half.pricing, .front-page-6 div.one-third.pricing, .front-page-6 div.two-third.pricing, .front-page-6 div.three-fourth.pricing, .front-page-6 div.one-fourth.pricing, .front-page-image-7 div.one-half.pricing, .front-page-image-7 div.one-third.pricing, .front-page-image-7 div.two-third.pricing, .front-page-image-7 div.three-fourth.pricing, .front-page-image-7 div.one-fourth.pricing, .front-page-8 div.one-half.pricing, .front-page-8 div.one-third.pricing, .front-page-8 div.two-third.pricing, .front-page-8 div.three-fourth.pricing, .front-page-8 div.one-fourth.pricing, .page div.one-half.pricing, .page div.one-third.pricing, .page div.two-third.pricing, .page div.three-fourth.pricing, .page div.one-fourth.pricing, .single_post_prev, .single_nav_arrow i',
			'rule'     => 'border-color',

		),

		'julia_primary_element_color' => array(
			'default'  => '#e6f1ef',
			'label'    => __( 'Primary Element Color: Service Boxes,..', 'julia' ),
			'selector' => '.front-page-2 .widget_text .special-services-box, .front-page-4 .widget_text .special-services-box, .front-page-6 .widget_text .special-services-box, .front-page-8 .widget_text .special-services-box, .footer-widgets-1 .enews-widget, .front-page-2 .pricing .box-wrapper h3, .front-page-2 .pricing .box-wrapper h2, .front-page-2 .pricing .box-wrapper .price_terms, .front-page-image-3 .pricing .box-wrapper h3, .front-page-image-3 .pricing .box-wrapper h2, .front-page-image-3 .pricing .box-wrapper .price_terms, .front-page-4 .pricing .box-wrapper h3, .front-page-4 .pricing .box-wrapper h2, .front-page-4 .pricing .box-wrapper .price_terms, .front-page-image-5 .pricing .box-wrapper h3, .front-page-image-5 .pricing .box-wrapper h2, .front-page-image-5 .pricing .box-wrapper .price_terms, .front-page-6 .pricing .box-wrapper h3, .front-page-6 .pricing .box-wrapper h2, .front-page-6 .pricing .box-wrapper .price_terms, .front-page-image-7 .pricing .box-wrapper h3, .front-page-image-7 .pricing .box-wrapper h2, .front-page-image-7 .pricing .box-wrapper .price_terms, .front-page-8 .pricing .box-wrapper h3, .front-page-8 .pricing .box-wrapper h2, .front-page-8 .pricing .box-wrapper .price_terms, ::selection, .page .pricing .box-wrapper h3, .page .pricing .box-wrapper h2, .page .pricing .box-wrapper .price_terms, .page .pricing .box-wrapper h3',   
			'rule'     => 'background-color',

		),

		'julia_primary_element_text_color' => array(
			'default'  => '#444',
			'label'    => __( 'Primary Element Text Color', 'julia' ),
			'selector' => '.woocommerce span.onsale, .woocommerce-page span.onsale, .sidebar ul li, .archive-pagination li, .categories-top, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active,.pricing-table .one-third:nth-child(3n+2), .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce #payment, .woocommerce-page #payment, .metaItem, .categories-top h4, .pricing-table ul li, .comment-reply a, .metaItem span, .categories-top h4.widget-title, .archive-pagination a:hover, .archive-pagination li.active a, .share-small:before, .flex-footer h4.widget-title, .front-page-2 .box-wrapper h4, .front-page-2 .box-wrapper h3, .front-page-image-3 .box-wrapper h4, .front-page-image-3 .box-wrapper h3, .front-page-4 .box-wrapper h4, .front-page-4 .box-wrapper h3, .front-page-image-5 .box-wrapper h4, .front-page-image-5 .box-wrapper h3, .front-page-6 .box-wrapper h4, .front-page-6 .box-wrapper h3, .front-page-image-7 .box-wrapper h4, .front-page-image-7 .box-wrapper h3, .front-page-8 .box-wrapper h4, .front-page-8 .box-wrapper h3, .front-page-2 .box-wrapper p, .front-page-image-3 .box-wrapper p, .front-page-4 .box-wrapper p, .front-page-image-5 .box-wrapper p, .front-page-6 .box-wrapper p, .front-page-image-7 .box-wrapper p, .front-page-8 .box-wrapper p, .footer-widgets-1 .widget-title, .footer-widgets-1 .enews-widget p, .front-page-2 .widget_text .special-services-box, .front-page-4 .widget_text .special-services-box, .front-page-6 .widget_text .special-services-box, .front-page-8 .widget_text .special-services-box, .footer-widgets-1 .enews-widget, .front-page-2 .pricing .box-wrapper h3, .front-page-2 .pricing .box-wrapper h2, .front-page-2 .pricing .box-wrapper .price_terms, .front-page-image-3 .pricing .box-wrapper h3, .front-page-image-3 .pricing .box-wrapper h2, .front-page-image-3 .pricing .box-wrapper .price_terms, .front-page-4 .pricing .box-wrapper h3, .front-page-4 .pricing .box-wrapper h2, .front-page-4 .pricing .box-wrapper .price_terms, .front-page-image-5 .pricing .box-wrapper h3, .front-page-image-5 .pricing .box-wrapper h2, .front-page-image-5 .pricing .box-wrapper .price_terms, .front-page-6 .pricing .box-wrapper h3, .front-page-6 .pricing .box-wrapper h2, .front-page-6 .pricing .box-wrapper .price_terms, .front-page-image-7 .pricing .box-wrapper h3, .front-page-image-7 .pricing .box-wrapper h2, .front-page-image-7 .pricing .box-wrapper .price_terms, .front-page-8 .pricing .box-wrapper h3, .front-page-8 .pricing .box-wrapper h2, .front-page-8 .pricing .box-wrapper .price_terms, .page .pricing .box-wrapper h3, .page .pricing .box-wrapper h2, .page .pricing .box-wrapper .price_terms, .page .pricing .box-wrapper h3',
			'rule'     => 'color',

		),

		'julia_secondary_element_color' => array(
			'default'  => '#f6f3f3',
			'label'    => __( 'Secondary Element Color: Footer widgets,..', 'julia' ),
			'selector' => '.footer-widgets, .wpcf7-text, .wpcf7-textarea, .wpcf7-captchar, .sidebar ul li, .woocommerce span.onsale, .woocommerce-page span.onsale, .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce #payment ul.payment_methods, .woocommerce-page #payment ul.payment_methods, .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce #payment, .woocommerce-page #payment, .page .pricing .box-wrapper ul, .woocommerce #content .quantity input.qty, .woocommerce .quantity input.qty, .woocommerce-page #content .quantity input.qty, .woocommerce-page .quantity input.qty, .portfolio_image a',   
			'rule'     => 'background-color',

		),

		'julia_secondary_element_text_color' => array(
			'default'  => '#444',
			'label'    => __( 'Secondary Element Text Color', 'julia' ),
			'selector' => '.footer-widgets, .wpcf7-text, .wpcf7-textarea, .wpcf7-captchar, .sidebar ul li, .woocommerce span.onsale, .woocommerce-page span.onsale, .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce #payment ul.payment_methods, .woocommerce-page #payment ul.payment_methods, .front-page-2 .pricing .box-wrapper ul, .front-page-image-3 .pricing .box-wrapper ul, .front-page-4 .pricing .box-wrapper ul, .front-page-image-5 .pricing .box-wrapper ul, .front-page-6 .pricing .box-wrapper ul, .front-page-image-7 .pricing .box-wrapper ul, .front-page-8 .pricing .box-wrapper ul, .sidebar a, .footer-widgets a, .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce #payment, .woocommerce-page #payment, .page .pricing .box-wrapper ul, .footer-widgets, .wpcf7-text, .wpcf7-textarea, .wpcf7-captchar, .sidebar ul li, .woocommerce span.onsale, .woocommerce-page span.onsale, .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce #payment ul.payment_methods, .woocommerce-page #payment ul.payment_methods, .woocommerce .woocommerce-error, .woocommerce .woocommerce-info, .woocommerce .woocommerce-message, .woocommerce-page .woocommerce-error, .woocommerce-page .woocommerce-info, .woocommerce-page .woocommerce-message, .woocommerce #payment, .woocommerce-page #payment, .page .pricing .box-wrapper ul, .portfolio_image a',
			'rule'     => 'color',

		),

		'julia_footer_menu_color' => array(
			'default'  => '#444',
			'label'    => __( 'Footer Menu Color', 'julia' ),
			'selector' => '.site-footer',
			'rule'     => 'background-color',

		),

		'julia_footer_menu_text_color' => array(
			'default'  => '#fff',
			'label'    => __(  'Footer Menu Text Color', 'julia' ),
			'selector' => '.site-footer, .site-footer .genesis-nav-menu a, .site-footer a',
			'rule'     => 'color',

		),

		'julia_site_title_color' => array(
			'default'  => '#444',
			'label'    => __( 'Site Title Color', 'julia' ),
			'selector' => '.site-title a, .site-title a:hover',
			'rule'     => 'color',

		),

		'julia_text_color' => array(
			'default'  => '#444',
			'label'    => __( 'Body Text Color', 'julia' ),
			'selector' => 'body, p, .genesis-nav-menu a',
			'rule'     => 'color',

		),

		'julia_headings_text_color' => array(
			'default'  => '#444',
			'label'    => __( 'Headings Text Color', 'julia' ),
			'selector' => 'h1, h2, h3, h4, h5, h6, h4.widget-title, .sidebar h3.widget-title, h1.entry-title, h2.entry-title, .front-page-2 h4.widget-title, .front-page-4 h4.widget-title, .front-page-6 h4.widget-title, .front-page-8 h4.widget-title',
			'rule'     => 'color',

		),

		'julia_link_color' => array(
			'default'  => '#d0bb44',
			'label'    => __( 'Link Color', 'julia' ),
			'selector' => 'a', 
			'rule'     => 'color',

		),

		'julia_link_hover_color' => array(
			'default'  => '#a3c7c1',
			'label'    => __( 'Link Hover Color', 'julia' ),
			'selector' => 'a:hover, .genesis-nav-menu a:hover, .site-footer .genesis-nav-menu a:hover',
			'rule'     => 'color',

		),

		'julia_button_color' => array(
			'default'  => '#444',
			'label'    => __( 'Button Color', 'julia' ),
			'selector' => '.enews-widget input[type="submit"], .front-page-image-image-1 .enews-widget input[type="submit"], .front-page-image-3 .enews-widget input[type="submit"], .front-page-image-5 .enews-widget input[type="submit"], .front-page-image-7 .enews-widget input[type="submit"], .footer-widgets-1 .enews-widget input[type="submit"], .button, .button-secondary, button, input[type="button"], input[type="reset"], input[type="submit"], .sidebar .enews-widget input[type="submit"], .woocommerce #content input.button, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce-page #content input.button, .woocommerce-page #respond input#submit, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page input.button, .fancybutton, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle, .pricing-table a.button, .after-entry .enews-widget input, a.more-link, .more-from-category a, #options li a.selected, #side-section input[type="submit"], .front-page-2 .pricing.bestprice.pricing .box-wrapper h3, .front-page-2 .pricing.bestprice.pricing .box-wrapper h2, .front-page-2 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-image-3 .pricing.bestprice.pricing .box-wrapper h3, .front-page-image-3 .pricing.bestprice.pricing .box-wrapper h2, .front-page-image-3 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-4 .pricing.bestprice.pricing .box-wrapper h3, .front-page-4 .pricing.bestprice.pricing .box-wrapper h2, .front-page-4 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-image-5 .pricing.bestprice.pricing .box-wrapper h3, .front-page-image-5 .pricing.bestprice.pricing .box-wrapper h2, .front-page-image-5 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-6 .pricing.bestprice.pricing .box-wrapper h3, .front-page-6 .pricing.bestprice.pricing .box-wrapper h2, .front-page-6 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-image-7 .pricing.bestprice.pricing .box-wrapper h3, .front-page-image-7 .pricing.bestprice.pricing .box-wrapper h2, .front-page-image-7 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-8 .pricing.bestprice.pricing .box-wrapper h3, .front-page-8 .pricing.bestprice.pricing .box-wrapper h2, .front-page-8 .pricing.bestprice.pricing .box-wrapper .price_terms, #options li:first-child a, .enews-widget input[type="submit"], .sidebar .enews-widget input[type="submit"]',
			'rule'     => 'background-color',

		),

		'julia_button_text_color' => array(
			'default'  => '#fff',
			'label'    => __( 'Button Text Color', 'julia' ),
			'selector' => '.enews-widget input[type="submit"], .front-page-image-1 .enews-widget input[type="submit"], .front-page-image-3 .enews-widget input[type="submit"], .front-page-image-5 .enews-widget input[type="submit"], .front-page-image-7 .enews-widget input[type="submit"], .footer-widgets-1 .enews-widget input[type="submit"], .button, .button-secondary, button, input[type="button"], input[type="reset"], input[type="submit"], .sidebar .enews-widget input[type="submit"], .woocommerce #content input.button, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce-page #content input.button, .woocommerce-page #respond input#submit, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page input.button, .fancybutton, .woocommerce .widget_price_filter .price_slider_amount .button, .woocommerce-page .widget_price_filter .price_slider_amount .button, .pricing-table a.button, .after-entry .enews-widget input, a.more-link, .more-from-category a, #options li a.selected, #side-section input[type="submit"], .front-page-2 .pricing.bestprice.pricing .box-wrapper h3, .front-page-2 .pricing.bestprice.pricing .box-wrapper h2, .front-page-2 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-image-3 .pricing.bestprice.pricing .box-wrapper h3, .front-page-image-3 .pricing.bestprice.pricing .box-wrapper h2, .front-page-image-3 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-4 .pricing.bestprice.pricing .box-wrapper h3, .front-page-4 .pricing.bestprice.pricing .box-wrapper h2, .front-page-4 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-image-5 .pricing.bestprice.pricing .box-wrapper h3, .front-page-image-5 .pricing.bestprice.pricing .box-wrapper h2, .front-page-image-5 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-6 .pricing.bestprice.pricing .box-wrapper h3, .front-page-6 .pricing.bestprice.pricing .box-wrapper h2, .front-page-6 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-image-7 .pricing.bestprice.pricing .box-wrapper h3, .front-page-image-7 .pricing.bestprice.pricing .box-wrapper h2, .front-page-image-7 .pricing.bestprice.pricing .box-wrapper .price_terms, .front-page-8 .pricing.bestprice.pricing .box-wrapper h3, .front-page-8 .pricing.bestprice.pricing .box-wrapper h2, .front-page-8 .pricing.bestprice.pricing .box-wrapper .price_terms, #options li:first-child a',
			'rule'     => 'color',

		),

		'julia_button_border_color' => array(
			'default'  => '#444',
			'label'    => __( 'Button border Color', 'julia' ),
			'selector' => '.enews-widget input[type="submit"], .front-page-image-1 .enews-widget input[type="submit"], .front-page-image-3 .enews-widget input[type="submit"], .front-page-image-5 .enews-widget input[type="submit"], .front-page-image-7 .enews-widget input[type="submit"], .footer-widgets-1 .enews-widget input[type="submit"], .front-page-image-7 .enews-widget input[type="submit"], .footer-widgets-1 .enews-widget input[type="submit"], .button, .button-secondary, button, input[type="button"], input[type="reset"], input[type="submit"], .sidebar .enews-widget input[type="submit"], .woocommerce #content input.button, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce-page #content input.button, .woocommerce-page #respond input#submit, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page input.button, .fancybutton, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle, .pricing-table a.button:hover,  a.more-link, .more-from-category a, #options li a, #side-section input[type="submit"], #options li:first-child a',
			'rule'     => 'outline-color',

		),

		'julia_button_hover_color' => array(
			'default'  => '#ecdbdd',
			'label'    => __( 'Button Hover Color', 'julia' ),
			'selector' => '.front-page-1 .enews-widget input[type="submit"]:hover, .front-page-image-3 .enews-widget input[type="submit"]:hover, .front-page-image-5 .enews-widget input[type="submit"]:hover, .front-page-image-7 .enews-widget input[type="submit"], .front-page-image-7 .enews-widget input[type="submit"]:hover, .footer-widgets-1 .enews-widget input[type="submit"]:hover, .button:hover, button:hover, input:hover[type="button"], .sidebar .enews-widget input:hover[type="submit"], .enews-widget input:hover[type="submit"], input:hover[type="reset"], input:hover[type="submit"], .fancybutton:hover, .woocommerce #content input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce-page #content input.button:hover, .woocommerce-page #respond input#submit:hover,  .woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page input.button:hover, .pricing-table a.button:hover, .pricing-table h4, .woocommerce .widget_price_filter .price_slider_wrapper .ui-widget-content, .woocommerce-page .widget_price_filter .price_slider_wrapper .ui-widget-content, a.more-link:hover, .more-from-category a:hover, .wpcf7 input.wpcf7-form-control.wpcf7-submit:hover, #side-section, a.sticky-switch, #options li a, #side-section input:hover[type="submit"]',
			'rule'     => 'background-color',

		),

		'julia_button_text_hover_color' => array(
			'default'  => '#444',
			'label'    => __( 'Button Hover Text Color', 'julia' ),
			'selector' => '.front-page-1 .enews-widget input[type="submit"]:hover, .sidebar .enews-widget input:hover[type="submit"], .front-page-image-3 .enews-widget input[type="submit"]:hover, .front-page-image-5 .enews-widget input[type="submit"]:hover, .front-page-image-7 .enews-widget input[type="submit"]:hover, .footer-widgets-1 .enews-widget input[type="submit"]:hover, .button:hover, button:hover, input:hover[type="button"], .sidebar .enews-widget input:hover[type="submit"], .enews-widget input:hover[type="submit"], input:hover[type="reset"], input:hover[type="submit"], .fancybutton:hover, .woocommerce #content input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce-page #content input.button:hover, .woocommerce-page #respond input#submit:hover,  .woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page input.button:hover, .pricing-table a.button:hover, .pricing-table h4, a.more-link:hover, .more-from-category a:hover, .wpcf7 input.wpcf7-form-control.wpcf7-submit:hover, #side-section, a.sticky-switch, #options li a, #side-section .enews p, #side-section .widget-title, #side-section input:hover[type="submit"]',
			'rule'     => 'color',

		),

		'julia_button_border_hover_color' => array(
			'default'  => '#444',
			'label'    => __( 'Button border hover Color', 'julia' ),
			'selector' => '.front-page-1 .enews-widget input[type="submit"]:hover, .front-page-image-3 .enews-widget input[type="submit"]:hover, .front-page-image-5 .enews-widget input[type="submit"]:hover, .button:hover, button:hover, input:hover[type="button"], .sidebar .enews-widget input:hover[type="submit"], .enews-widget input:hover[type="submit"], input:hover[type="reset"], input:hover[type="submit"], .fancybutton:hover, .woocommerce #content input.button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce-page #content input.button:hover, .woocommerce-page #respond input#submit:hover, .woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page input.button:hover, .pricing-table a.button, a.more-link:hover, .more-from-category a:hover, .wpcf7 input.wpcf7-form-control.wpcf7-submit:hover, #side-section input:hover[type="submit"]',
			'rule'     => 'outline-color',

		),

		'julia_icon_color' => array(
			'default'  => '#ecdbdd',
			'label'    => __( 'Icon Color: Share icons and entry meta', 'julia' ),
			'selector' => '.entry-categories:before, .entry-comments-link::before, .entry-tags:before, a.more-link:before, .more-from-category a:before, .previous:before, .next:after, .woocommerce div.product form.cart .button::before, .adjacent-entry-pagination .pagination-next a::after, .adjacent-entry-pagination .pagination-previous a::before, .content .share-filled .facebook .count, .content .share-filled .facebook .count:hover, .content .share-filled .googlePlus .count, .content .share-filled .googlePlus .count:hover, .content .share-filled .linkedin .count, .content .share-filled .linkedin .count:hover, .content .share-filled .pinterest .count, .content .share-filled .pinterest .count:hover, .content .share-filled .stumbleupon .count, .content .share-filled .stumbleupon .count:hover, .content .share-filled .twitter .count, .content .share-filled .twitter .count:hover, .sharrre .share, .sharrre:hover .share',
			'rule'     => 'color',

		),

	);

	return apply_filters( 'julia_get_colors', $colors );

}

//* An array of the font settings used in julia theme.



function julia_get_fonts() {

	$fonts = array(
		'julia_title_font' => array(
			'default_family' => 'Playfair Display',
			'default_size'   => '45px',
			'default_style'  => 'disabled',
			'default_weight' => '400',
			'label'          => __( 'Site title (45px)', 'julia' ),
			'selector'       => '.site-title, .box .title',

		),

		'julia_h1_font' => array(
			'default_family' => 'Cormorant Upright',
			'default_size'   => '26px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'H1 (26px) Title Font', 'julia' ),
			'selector'       => 'h1, h1.entry-title, .entry-title',

		),

		'julia_h2_font' => array(
			'default_family' => 'Cormorant Upright',
			'default_size'   => '24px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'H2 (24px) Title Font', 'julia' ),
			'selector'       => 'h2,  h2.entry-title, .home-bottom h2.entry-title, .categories-bottom .featuredpost h2, .home .one-third h2.entry-title, .home .one-fourth h2.entry-title, .home .one-sixth h2.entry-title, .categories-bottom .featuredpost h2, .boxes .h2tagline, .woocommerce #reviews #comments h2, .woocommerce-page #reviews #comments h2',

		),

		'julia_h3_font' => array(
			'default_family' => 'Cormorant Upright',
			'default_size'   => '22px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'H3 (22px) Title Font', 'julia' ),
			'selector'       => 'h3, .widgettitle ,.sidebar h3.widget-title, .comment-respond h3, .entry-comments h3, .woocommerce ul.products li.product h3, .woocommerce-page ul.products li.product h3, .woocommerce #reviews h3, .woocommerce-page #reviews h3, .after-entry .enews-widget .widget-title, .author-box h1, .footer-widgets-1 .widget-title, .footer-widgets-2 .widget-title, .footer-widgets-3 .widget-title, .footer-widgets-4 .widget-title, .above-blog .enews-widget .widget-title, .footer-widgets-2 .user-profile .widgettitle, .footer-widgets-3 .user-profile .widgettitle, .footer-widgets-4 .user-profile .widgettitle',

		),

		'julia_h4_font' => array(
			'default_family' => 'Cormorant Upright',
			'default_size'   => '20px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'H4 (20px) Title Font', 'julia' ),
			'selector'       => 'h4, .categories-top h4, h4.widget-title, .before-footer h4.widgettitle, .categories-bottom .widgettitle',

		),

		'julia_menu_font' => array(
			'default_family' => 'Cormorant Upright',
			'default_size'   => '14px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'Menu Font (14px)', 'julia' ),
			'selector'       => '.genesis-nav-menu a, .genesis-nav-menu .menu-item',

		),

		'julia_body_font' => array(
			'default_family' => 'Khula',
			'default_size'   => '14px',
			'default_style'  => 'normal',
			'default_weight' => '300',
			'label'          => __( 'Body Font (14px)', 'julia' ),
			'selector'       => 'body, .sidebar .featuredpost article, p, .boxes .pdescription, .related-list li a',

		),

		'julia_accent_font' => array(
			'default_family' => 'Playfair Display',
			'default_size'   => '11px',
			'default_style'  => 'italic',
			'default_weight' => '300',
			'label'          => __( 'Accent Font (11px)', 'julia' ),
			'selector'       => 'input, select, textarea, .wp-caption-text, .site-description, .entry-meta, .post-info, .post-meta, .entry-header .entry-meta, .entry-footer .entry-meta, a.more-link, .more-from-category a, .comment-reply a, .menu-description',

		),


	);

	return apply_filters( 'julia_get_fonts', $fonts );

}

add_filter( 'customizer_library_font_variants', 'julia_font_variants', 10, 3 );

//* Filters the allowed Google Font varoamts for the julia Theme.


function julia_font_variants( $chosen_variants, $font, $variants ) {

	// Only add "200" if it exists

	if ( in_array( '200', $variants ) ) {
		$chosen_variants[] = '200';

	}

	// Only add "300" if it exists

	if ( in_array( '300', $variants ) ) {
		$chosen_variants[] = '300';

	}

	// Only add "300italic" if it exists

	if ( in_array( '300italic', $variants ) ) {
		$chosen_variants[] = '300italic';

	}


	// Only add "900" if it exists

	if ( in_array( '900', $variants ) ) {
		$chosen_variants[] = '900';

	}

	return array_unique( $chosen_variants );



}


//* Disable standard fonts.

add_filter( 'customizer_library_all_fonts', 'customizer_library_get_google_fonts' );
add_filter( 'customizer_library_get_google_fonts', 'julia_get_google_fonts' );


//* Filters the allowed Google Fonts for the julia theme.

function julia_get_google_fonts( $fonts ) {

	$fonts = array(

		'Abel' => array(
			'label'    => 'Abel',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Abhaya Libre' => array(
			'label'    => 'Abhaya Libre',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Abril Fatface' => array(
			'label'    => 'Abril Fatface',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Adamina' => array(
			'label'    => 'Adamina',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(

				'latin',

			),

		),

		'Advent Pro' => array(
			'label'    => 'Advent Pro',
			'variants' => array(
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(

				'latin',

			),

		),

		'Alegreya' => array(
			'label'    => 'Alegreya',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(

				'latin',

			),

		),

		'Alex Brush' => array(
			'label'    => 'Alex Brush',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',


			),

		),

		'Alice' => array(
			'label'    => 'Alice',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',


			),

		),

		'Allura' => array(
			'label'    => 'Allura',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',


			),

		),

		'Amatic SC' => array(
			'label'    => 'Amatic SC',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Amiri' => array(
			'label'    => 'Amiri',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),


		'Antic Slab' => array(
			'label'    => 'Antic Slab',
			'variants' => array(
				'400',
				'italic',
				'700',

			),

			'subsets' => array(

				'latin',

			),

		),

		'Arapey' => array(
			'label'    => 'Arapey',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Archivo Narrow' => array(
			'label'    => 'Archivo Narrow',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Arima Madurai' => array(
			'label'    => 'Arima Madurai',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Arimo' => array(
			'label'    => 'Arimo',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Artifika' => array(
			'label'    => 'Artifika',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),


		'Arvo' => array(
			'label'    => 'Arvo',
			'variants' => array(
				'regular',

			),

			'subsets' => array(
				'latin',

			),

		),


		'Asap' => array(
			'label'    => 'Asap',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Asap Condensed' => array(
			'label'    => 'Asap Condensed',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Bad Script' => array(
			'label'    => 'Bad Script',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Bellefair' => array(
			'label'    => 'Bellefair',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'BenchNine' => array(
			'label'    => 'BenchNine',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Bentham' => array(
			'label'    => 'Bentham',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Berkshire Swash' => array(
			'label'    => 'Berkshire Swash',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Bree Serif' => array(
			'label'    => 'Bree Serif',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Bungee Inline' => array(
			'label'    => 'Bungee Inline',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Cabin Sketch' => array(
			'label'    => 'Cabin Sketch',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Cardo' => array(
			'label'    => 'Cardo',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Carme' => array(
			'label'    => 'Carme',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Cairo' => array(
			'label'    => 'Cairo',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Caveat Brush' => array(
			'label'    => 'Caveat Brush',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Catamaran' => array(
			'label'    => 'Catamaran',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Cookie' => array(
			'label'    => 'Cookie',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Comfortaa' => array(
			'label'    => 'Comfortaa',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Cormorant' => array(
			'label'    => 'Cormorant',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Cormorant Garamond' => array(
			'label'    => 'Cormorant Garamond',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Cormorant Infant' => array(
			'label'    => 'Cormorant Infant',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Cormorant Upright' => array(
			'label'    => 'Cormorant Upright',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Courgette' => array(
			'label'    => 'Courgette',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Covered By Your Grace' => array(
			'label'    => 'Covered By Your Grace',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Crimson Text' => array(
			'label'    => 'Crimson Text',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Damion' => array(
			'label'    => 'Damion',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Dancing Script' => array(
			'label'    => 'Dancing Script',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'David Libre' => array(
			'label'    => 'David Libre',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Domine' => array(

			'label'    => 'Domine',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Dosis' => array(
			'label'    => 'Dosis',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Droid Serif' => array(
			'label'    => 'Droid Serif',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'EB Garamond' => array(
			'label'    => 'EB Garamond',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Encode Sans Condensed' => array(
			'label'    => 'Encode Sans Condensed',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Exo' => array(
			'label'    => 'Exo',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Exo 2' => array(
			'label'    => 'Exo 2',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Fira Sans' => array(
			'label'    => 'Fira Sans',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Forum' => array(
			'label'    => 'Forum',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Gentium Basic' => array(
			'label'    => 'Gentium Basic',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Gilda Display' => array(
			'label'    => 'Gilda Display',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Goudy Bookletter 1911' => array(
			'label'    => 'Goudy Bookletter 1911',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Grand Hotel' => array(
			'label'    => 'Grand Hotel',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Great Vibes' => array(
			'label'    => 'Great Vibes',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Gudea' => array(
			'label'    => 'Gudea',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'IM Fell Great Primer' => array(
			'label'    => 'IM Fell Great Primer',
			'variants' => array(
				'300',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Inconsolata' => array(
			'label'    => 'Inconsolata',
			'variants' => array(
				'300',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Istok Web' => array(
			'label'    => 'Istok Web',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Italiana' => array(
			'label'    => 'Italiana',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Italianno' => array(
			'label'    => 'Italianno',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Josefin Sans' => array(
			'label'    => 'Josefin Sans',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Just Another Hand' => array(
			'label'    => 'Just Another Hand',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Karla' => array(
			'label'    => 'Karla',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Kaushan Script' => array(
			'label'    => 'Kaushan Script',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Khula' => array(
			'label'    => 'Khula',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'400italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Lateef' => array(
			'label'    => 'Lateef',
			'variants' => array(
				'100',
				'100italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Lato' => array(
			'label'    => 'Lato',
			'variants' => array(
				'100',
				'100italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Libre Baskerville' => array(
			'label'    => 'Libre Baskerville',
			'variants' => array(
				'regular',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Lobster Two' => array(
			'label'    => 'Lobster Two',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',

			),

		),

		'Lora' => array(
			'label'    => 'Lora',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',

			),

		),

		'Manuale' => array(
			'label'    => 'Manuale',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Marck Script' => array(
			'label'    => 'Marck Script',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Maven Pro' => array(
			'label'    => 'Maven Pro',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Meddon' => array(
			'label'    => 'Meddon',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Merriweather' => array(
			'label'    => 'Merriweather',
			'variants' => array(
				'300',
				'300italic',
				'400italic',
				'italic',
				'400',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',

			),

		),

		'Montserrat' => array(
			'label'    => 'Montserrat',
			'variants' => array(
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Mr De Haviland' => array(
			'label'    => 'Mr De Haviland',
			'variants' => array(
				'300',
				'400',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Mukta' => array(
			'label'    => 'Mukta',
			'variants' => array(
				'300',
				'regular',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Mukta Vaani' => array(
			'label'    => 'Mukta Vaani',
			'variants' => array(
				'300',
				'regular',
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Muli' => array(
			'label'    => 'Muli',
			'variants' => array(
				'300',
				'regular',
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Neuton' => array(
			'label'    => 'Neuton',
			'variants' => array(
				'200',
				'300',
				'regular',
				'italic',
				'400',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'News Cycle' => array(
			'label'    => 'News Cycle',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Niconne' => array(
			'label'    => 'Niconne',
			'variants' => array(
				'regular',
				'400',
				'400italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'Greek',
				'Greek-ext',

			),

		),

		'Noticia Text' => array(
			'label'    => 'Noticia Text',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'vietnamese',

			),

		),

		'Noto Sans' => array(
			'label'    => 'Noto Sans',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',
				'Greek',
				'Greek-ext',
				'vietnamese',

			),

		),

		'Nunito' => array(
			'label'    => 'Nunito',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',
				'Greek',
				'Greek-ext',
				'vietnamese',

			),

		),

		'Nunito Sans' => array(
			'label'    => 'Nunito Sans',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'cyrillic',
				'cyrillic-ext',
				'Greek',
				'Greek-ext',
				'vietnamese',

			),

		),

		'Old Standard TT' => array(
			'label'    => 'Old Standard TT',
			'variants' => array(
				'400',
				'regular',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Oleo Script' => array(
			'label'    => 'Oleo Script',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Open Sans' => array(
			'label'    => 'Open Sans',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Oswald' => array(
			'label'    => 'Oswald',
			'variants' => array(
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Pathway Gothic One' => array(
			'label'    => 'Pathway Gothic One',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Pacifico' => array(
			'label'    => 'Pacifico',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Parisienne' => array(
			'label'    => 'Parisienne',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Pavanam' => array(
			'label'    => 'Pavanam',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Philosopher' => array(
			'label'    => 'Philosopher',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Pinyon Script' => array(
			'label'    => 'Pinyon Script',
			'variants' => array(
				'300',
				'400',
				'400italic',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Poiret One' => array(
			'label'    => 'Poiret One',
			'variants' => array(
				'300',
				'400',
				'regular',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'PT Sans' => array(
			'label'    => 'PT Sans',
			'variants' => array(
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'PT Sans Narrow' => array(
			'label'    => 'PT Sans Narrow',
			'variants' => array(
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'PT Serif' => array(
			'label'    => 'PT Serif',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Playfair Display' => array(
			'label'    => 'Playfair Display',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',

			),

		),

		'Playfair Display SC' => array(
			'label'    => 'Playfair Display SC',
			'variants' => array(
				'regular',
				'italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'cyrillic',
				'latin-ext',

			),

		),

		'Pontano Sans' => array(
			'label'    => 'Pontano Sans',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Poppins' => array(
			'label'    => 'Poppins',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Quattrocento Sans' => array(
			'label'    => 'Quattrocento Sans',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Questrial' => array(
			'label'    => 'Questrial',
			'variants' => array(
				'400',
				'regular',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Quicksand' => array(
			'label'    => 'Quicksand',
			'variants' => array(
				'300',
				'400',
				'700',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Raleway' => array(
			'label'    => 'Raleway',
			'variants' => array(
				'100',
				'200',
				'300',
				'regular',
				'500',
				'600',
				'700',
				'800',
				'900',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Roboto Mono' => array(
			'label'    => 'Roboto Mono',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Roboto Slab' => array(
			'label'    => 'Roboto Slab',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Rock Salt' => array(
			'label'    => 'Rock Salt',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Rokkitt' => array(
			'label'    => 'Rokkitt',
			'variants' => array(
				'100',
				'300',
				'regular',
				'700',

			),

			'subsets' => array(
				'latin',
				'greek-ext',
				'cyrillic',
				'greek',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Sacramento' => array(
			'label'    => 'Sacramento',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Saira Condensed' => array(
			'label'    => 'Saira Condensed',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Sanchez' => array(
			'label'    => 'Sanchez',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Satisfy' => array(
			'label'    => 'Satisfy',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Shadows Into Light' => array(
			'label'    => 'Shadows Into Light',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Slavo 27px' => array(
			'label'    => 'Slavo 27px',
			'variants' => array(
				'400',
				'400italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Source Code Pro' => array(
			'label'    => 'Source Code Pro',
			'variants' => array(
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'vietnamese',
				'latin-ext',

			),

		),

		'Source Sans Pro' => array(
			'label'    => 'Source Sans Pro',
			'variants' => array(
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'vietnamese',
				'latin-ext',

			),

		),

		'Source Serif Pro' => array(
			'label'    => 'Source Serif Pro',
			'variants' => array(
				'200',
				'200italic',
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'vietnamese',
				'latin-ext',

			),

		),

		'Special Elite' => array(
			'label'    => 'Special Elite',
			'variants' => array(
				'300',
				'regular',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),


		),

		'Sorts Mill Goudy' => array(
			'label'    => 'Sorts Mill Goudy',
			'variants' => array(
				'regular',
				'300',
				'300italic',
				'700',
				'700italic',

			),

			'subsets' => array(
				'latin',

			),

		),

		'Sue Ellen Francisco' => array(
			'label'    => 'Sue Ellen Francisco',
			'variants' => array(
				'regular',
				'400',
				'700',

			),

			'subsets' => array(

				'latin',

			),

		),

		'Ubuntu' => array(
			'label'    => 'Ubuntu',
			'variants' => array(
				'300',
				'300italic',
				'regular',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Tangerine' => array(
			'label'    => 'Tangerine',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Tenor Sans' => array(
			'label'    => 'Tenor Sans',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Titillium Web' => array(
			'label'    => 'Titillium Web',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'italic',
				'600',
				'600italic',
				'700',
				'700italic',
				'900',
				'900italic',

			),

			'subsets' => array(
				'latin',
				'latin-ext',
				'greek',
				'greek-ext',
				'cyrillic',
				'vietnamese',
				'latin-ext',
				'cyrillic-ext',

			),

		),

		'Varela' => array(
			'label'    => 'Varela',
			'variants' => array(
				'400',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Varela Round' => array(
			'label'    => 'Varela Round',
			'variants' => array(
				'300',
				'300italic',
				'400',
				'400italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Vidaloka' => array(
			'label'    => 'Vidaloka',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',

			),

			'subsets' => array(

				'latin',
				'latin-ext',

			),

		),

		'Vollkorn' => array(
			'label'    => 'Vollkorn',
			'variants' => array(
				'400',
				'400italic',
				'300',
				'300italic',
				'italic',
				'700',
				'700italic',

			),

			'subsets' => array(

				'latin',
				'latin-ext',

			),

		),

		'Yanone Kaffeesatz' => array(
			'label'    => 'Yanone Kaffeesatz',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',

			),

			'subsets' => array(

				'latin',
				'latin-ext',

			),

		),

		'Yellowtail' => array(
			'label'    => 'Yellowtail',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',

			),

			'subsets' => array(

				'latin',
				'latin-ext',

			),

		),

		'Yeseva One' => array(
			'label'    => 'Yeseva One',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Yesteryear' => array(
			'label'    => 'Yesteryear',
			'variants' => array(
				'400',
				'300',
				'300italic',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),

		'Zilla Slab' => array(
			'label'    => 'Zilla Slab',
			'variants' => array(
				'400',
				'400italic',
				'300',
				'300italic',
				'italic',
				'700',

			),

			'subsets' => array(
				'latin',
				'latin-ext',

			),

		),



		

	);

	return $fonts;

}



endif;





