<?php
/**
 * Load theme widgets.
 *
 * @package     Julia Theme
 * @subpackage  Genesis
 * @copyright   Copyright (c) 2017, Cristina Sanz
 * @license     GPL-2.0+
 * @link        http://lovelyconfetti.com/feminine-wordpress-themes
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'widgets_init', 'julia_include_widgets', 10 );

//* Load all the required widget class files.

function julia_include_widgets() {
	if ( class_exists( 'julia_Featured_Posts' ) ) {
		return;
	}
	$widgets_dir = trailingslashit( get_stylesheet_directory() ) . 'includes/widgets/';
	require_once $widgets_dir . 'julia-featured-posts.php';
}

add_action( 'widgets_init', 'julia_register_widgets', 11 );

//* Unregister the default Genesis Featured Posts widget and register all of

function julia_register_widgets() {
	if ( ! class_exists( 'julia_Featured_Posts' ) ) {
		return;
	}
	unregister_widget( 'Genesis_Featured_Post' );
	register_widget( 'julia_Featured_Posts' );
}
