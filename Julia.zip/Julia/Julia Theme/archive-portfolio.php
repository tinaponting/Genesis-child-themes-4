<?php 
/*
 * Portfolio Archive Template
 */
 
add_filter('genesis_pre_get_option_site_layout', '__genesis_return_full_width_content');

remove_action(	'genesis_loop', 'genesis_do_loop' );
add_action(	'genesis_loop', 'julia_portfolio_archive_template' );
function julia_portfolio_archive_template() {
	
	$columns = genesis_get_option( 'zp_portfolio_archive_columns' , ZP_SETTINGS_FIELD );

	zp_portfolio_template( $columns, -1, 'portfolio', true, '' );
}

genesis();