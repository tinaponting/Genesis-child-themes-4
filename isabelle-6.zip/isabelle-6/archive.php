<?php
/**
 * This file adds the custom author archive template.
 *
 */
 

/**
 * Add custom headline and description to blog template pages.
 *
 * If we're not on a blog template page, then nothing extra is displayed.
 *
 * @since 2.2.0
 *
 * @uses genesis_a11y() Check if a post type should potentially support an archive setting page.
 * @uses genesis_do_custom_post_title() Get list of custom post types which need an archive settings page.
 *
 * @return null Return early if not on relevant blog template archive.
 */
function genesis_do_custom_blog_template_heading() {

	if ( ! is_page_template( 'page_blog.php' ) || ! genesis_a11y( 'headings' ) ) {
		return;
	}

	printf( '<div %s>', genesis_attr( 'blog-template-description' ) );
		genesis_do_post_title();
	echo '</div>';

}

add_filter( 'genesis_pre_get_option_content_archive', 'rgc_do_full_content' );
function rgc_do_full_content() {
	return 'full';
}

add_filter( 'genesis_pre_get_option_content_archive_limit', 'rgc_no_content_limit' );
function rgc_no_content_limit() {
	return '200';
}

add_filter( 'post_class', 'rgc_grid_post_class' );
function rgc_grid_post_class( $classes ) {
	global $wp_query;

	if ( ! $wp_query->is_main_query() ) {
		return $classes;
	}

	$term         = $wp_query->get_queried_object();
	$layout       = genesis_site_layout( $term );
	$number		= 2;
	$column_class = 'one-half';

	if ( in_array( $layout, array( __genesis_return_sidebar_content(), __genesis_return_content_sidebar() ) ) ) {
		$number       = 2;
		$column_class = 'one-half';
	}

	elseif ( __genesis_return_full_width_content() === $layout ) {
		$number       = 3;
		$column_class = 'one-third';
	}


	$classes[] = 'grid ' . $column_class;

	if ( 0 == $wp_query->current_post % $number ) {
		$classes[] = 'first';
	}

	return $classes;
}

add_action( 'genesis_entry_header', 'rgc_posts_grid', 5 );
function rgc_posts_grid() {
	global $post;

	if ( $image = genesis_get_image( 'format=url&size=product' ) ) {
		printf( '<div class="grid-image"><a href="%s" target="_blank" rel="bookmark"><img src="%s" alt="%s" class="aligncenter" /></a></div>', get_permalink(), $image, the_title_attribute( 'echo=0' ) );
	}
	else {
		printf( '<div class="grid-image"><a href="%s" target="_blank" rel="bookmark"><img src="%s" alt="%s" class="aligncenter" /></a></div>', get_permalink(), get_bloginfo( 'stylesheet_directory' ) . '/images/blank.jpg', the_title_attribute( 'echo=0' ) );
	}

}



genesis();