<?php
/**
 * This file adds the Home Page to the Isabelle Child Theme.
 * @package Isabelle
 * @subpackage Customizations
 */

//* Enqueue scripts
	add_action( 'wp_enqueue_scripts', 'isabelle_enqueue_isabelle_script' );
	function isabelle_enqueue_isabelle_script() {

	wp_enqueue_style( 'isabelle-front-styles', get_stylesheet_directory_uri() . '/front-wide-slider.css', array(), CHILD_THEME_VERSION );

}

add_action( 'genesis_meta', 'isabelle_home_genesis_meta' );
/**
 * Add widget support for homepage. If no widgets active, display the default loop.
 *
 */
function isabelle_home_genesis_meta() {

	if ( is_active_sidebar( 'home-top-left' ) || is_active_sidebar( 'home-top-right' ) || is_active_sidebar( 'home-middle' ) || is_active_sidebar( 'home-bottom-left' ) || is_active_sidebar( 'home-bottom-right' ) ) {

		//* Force full-width-content layout
		add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

		// Add isabelle-home body class
		add_filter( 'body_class', 'isabelle_body_class' );

		// Remove the default Genesis loop
		remove_action( 'genesis_loop', 'genesis_do_loop' );

		// Add homepage widgets
		add_action( 'genesis_loop', 'isabelle_homepage_widgets' );

	}
}

function isabelle_body_class( $classes ) {

	$classes[] = 'isabelle-home';
	return $classes;
	
}

function isabelle_homepage_widgets() {

	if ( is_active_sidebar( 'home-top-left' ) || is_active_sidebar( 'home-top-right' ) ) {

		echo '<div class="home-top"><div class="wrap">';

		genesis_widget_area( 'home-top-left', array(
			'before' => '<div class="home-top-left widget-area">',
			'after'  => '</div>',
		) );

		genesis_widget_area( 'home-top-right', array(
			'before' => '<div class="home-top-right widget-area">',
			'after'  => '</div>',
		) );

		echo '</div></div>';

		}	

	if ( is_active_sidebar( 'home-middle' ) ) {

		echo '<div class="home-middle"><div class="wrap">';

		genesis_widget_area( 'home-middle', array(
			'before' => '<div class="home-middle widget-area">',
			'after'  => '</div>',
		) );

		echo '</div></div>';

		}
}

genesis();