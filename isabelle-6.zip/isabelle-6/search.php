<?php
/**
 * Genesis Framework.
 * @package Genesis\Templates
 */

add_action( 'genesis_after_header', 'genesis_do_search_title' );
/**
 * Echo the title with the search term.
 *
 * @since 1.9.0
 */
function genesis_do_search_title() {

	$title = sprintf( '<div class="archive-description"><h1 class="archive-title">%s %s</h1></div>', apply_filters( 'genesis_search_title_text', __( 'Search Results for:', 'genesis' ) ), get_search_query() );

	echo apply_filters( 'genesis_search_title_output', $title ) . "\n";

}

add_filter( 'genesis_pre_get_option_content_archive', 'isabelle_do_full_content' );
function isabelle_do_full_content() {
	return 'full';
}

add_filter( 'genesis_pre_get_option_content_archive_limit', 'isabelle_no_content_limit' );
function isabelle_no_content_limit() {
	return '200';
}

add_filter( 'post_class', 'isabelle_grid_post_class' );
function isabelle_grid_post_class( $classes ) {
	global $wp_query;

	if ( ! $wp_query->is_main_query() ) {
		return $classes;
	}

	$term         = $wp_query->get_queried_object();
	$layout       = genesis_site_layout( $term );
	$number		= 2;
	$column_class = 'one-half';

	if ( in_array( $layout, array( __genesis_return_sidebar_content(), __genesis_return_content_sidebar() ) ) ) {
		$number       = 2;
		$column_class = 'one-half';
	}

	elseif ( __genesis_return_full_width_content() === $layout ) {
		$number       = 3;
		$column_class = 'one-third';
	}


	$classes[] = 'grid ' . $column_class;

	if ( 0 == $wp_query->current_post % $number ) {
		$classes[] = 'first';
	}

	return $classes;
}

add_action( 'genesis_entry_header', 'isabelle_posts_grid', 5 );
function isabelle_posts_grid() {
	global $post;

	if ( $image = genesis_get_image( 'format=url&size=product' ) ) {
		printf( '<div class="grid-image"><a href="%s" target="_blank" rel="bookmark"><img src="%s" alt="%s" class="aligncenter" /></a></div>', get_permalink(), $image, the_title_attribute( 'echo=0' ) );
	}
	else {
		printf( '<div class="grid-image"><a href="%s" target="_blank" rel="bookmark"><img src="%s" alt="%s" class="aligncenter" /></a></div>', get_permalink(), get_bloginfo( 'stylesheet_directory' ) . '/images/blank.jpg', the_title_attribute( 'echo=0' ) );
	}

}

genesis();
