<?php
/* 
 * Adds the required CSS to the front end.
 */

add_action( 'wp_enqueue_scripts', 'isabelle_css' );
/**
* Checks the settings for the images and background colors for each image
* If any of these value are set the appropriate CSS is output
*
* @since 1.0
*/
function isabelle_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'isabelle';
	
	$color = get_theme_mod( 'isabelle_accent_color', isabelle_customizer_get_default_accent_color() );
	
	$css = '';

	$css .= ( isabelle_customizer_get_default_accent_color() !== $color ) ? sprintf( '
		a,
		#genesis-responsive-slider a, 
		#genesis-responsive-slider h2 a:hover
		.front-page-3 .featured-content .entry-title a:hover,
		.entry-title a:hover,
		.footer-widgets a:hover,
		.genesis-nav-menu a:hover,
		.nav-primary .genesis-nav-menu .sub-menu a:hover,
		.site-footer .wrap a:hover,
		.genesis-nav-menu .current-menu-item > a, 
		.genesis-nav-menu .sub-menu .current-menu-item > a:hover,
		#slidebox .enews-widget .widget-title {
			color: %1$s;
		}

		#slidebox .enews-widget input[type="submit"]:hover,
		.pagination li a:hover, 
		.pagination li.active a,
		body .overlay {
			background-color: %1$s;
		}

		#slidebox {
			border-top: 3px solid %1$s;
		}

		', $color ) : '';

	if( $css ){
		wp_add_inline_style( $handle, $css );
	}

}
