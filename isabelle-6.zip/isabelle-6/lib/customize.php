<?php
/**
 * Customizer additions.
 * @package Isabelle Genesis Child Theme
 */
 
/**
 * Get default accent color for Customizer.
 *
 * Abstracted here since at least two functions use it.
 *
 * @since 1.0.0
 *
 * @return string Hex color code for accent color.
 */
function isabelle_customizer_get_default_accent_color() {
	return '#9b7d3d';
}

add_action( 'customize_register', 'isabelle_customizer' );
/**
 * Register settings and controls with the Customizer.
 *
 * @since 1.0.0
 * 
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function isabelle_customizer(){


	global $wp_customize;
	
		$wp_customize->add_setting(
		'isabelle_accent_color',
		array(
			'default' => isabelle_customizer_get_default_accent_color(),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'isabelle_accent_color',
			array(
				'description' => __( 'Change the default accent color for links, buttons, and more.', 'isabelle' ),
			    'label'       => __( 'Accent Color', 'isabelle' ),
			    'section'     => 'colors',
			    'settings'    => 'isabelle_accent_color',
			)
		)
	);

}
