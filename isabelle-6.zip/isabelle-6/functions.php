<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Install Plugins
require_once( get_stylesheet_directory() . '/lib/plugins/tgm-plugin-activation/register-plugins.php' );

//* Setup Theme
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );

//* Set Localization (do not remove)
load_child_theme_textdomain( 'isabelle', apply_filters( 'child_theme_textdomain', get_stylesheet_directory() . '/languages', 'isabelle' ) );

//* Add Image Upload and Color Selection to WordPress Theme Customizer
require_once( get_stylesheet_directory() . '/lib/customize.php' );

//* Include Section Image and Color CSS
include_once( get_stylesheet_directory() . '/lib/output.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', __( 'Isabelle Child Theme', 'isabelle' ) );
define( 'CHILD_THEME_VERSION', '1.1' );

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

//* Add Accessibility support
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Enqueue scripts and styles
add_action( 'wp_enqueue_scripts', 'isabelle_enqueue_scripts_styles' );
function isabelle_enqueue_scripts_styles() {

	wp_enqueue_script( 'responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_style( 'dashicons' );
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic|Roboto+Condensed:400,400i,700|Lora:400,400i,700,700i', array(), CHILD_THEME_VERSION );
}

//* Add support for custom header
add_theme_support( 'custom-header', array(
	'default-text-color'     => '000000',
	'header-selector'        => '.site-title a',
	'header-text'            => false,
	'height'                 => 72,
	'width'                  => 360,
) );

//* Customize read more text
add_filter( 'excerpt_more', 'genesis_read_more_link' );
add_filter( 'get_the_content_more_link', 'genesis_read_more_link' );
add_filter( 'the_content_more_link', 'genesis_read_more_link' );
function genesis_read_more_link() {

	return '<a class="more-link" href="' . get_permalink() . '">Read More </a>';

}

//* Add new featured image sizes
add_image_size( 'featured-image-main', 780, 385, TRUE );
add_image_size( 'featured-small', 100, 100, TRUE );

//* Add support for 5-column footer widgets
add_theme_support( 'genesis-footer-widgets', 5 );

//* Add support for after entry widget
add_theme_support( 'genesis-after-entry-widget-area' );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Unregister secondary sidebar
unregister_sidebar( 'sidebar-alt' );

//* Unregister secondary sidebar 
add_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );

//* Add custom body class to the head
add_filter( 'body_class', 'isabelle_custom_body_class' );
function isabelle_custom_body_class( $classes ) {

	$classes[] = 'isabelle';
	return $classes;

}

//* Hook before header widget area above header
add_action( 'genesis_before_header', 'isabelle_before_header' );
function isabelle_before_header() {

	genesis_widget_area( 'before-header', array(
		'before' => '<div class="before-header" class="widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

}

//* Hook first call to action widget area
add_action( 'genesis_before_footer', 'cta_one', 5 );
function cta_one() {

	if ( ! is_home() ) {
		return;
	}

	genesis_widget_area( 'cta-one', array(
		'before' => '<div class="cta-one" class="widget-area">',
		'after'  => '</div>',
	) );
}

//* Hook second call to action widget area
add_action( 'genesis_before_footer', 'cta_two', 5 );
function cta_two() {

	if ( ! is_home() ) {
		return;
	}

	genesis_widget_area( 'cta-two', array(
		'before' => '<div class="cta-two" class="widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

}

//* Hook home bottom widget area for featured posts widget
add_action( 'genesis_before_footer', 'isabelle_home_bottom', 5 );
function isabelle_home_bottom() {

	if ( ! is_home() ) {
		return;
	}

	genesis_widget_area( 'home-bottom', array(
		'before' => '<div class="home-bottom" class="widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );
}

//* Hook before footer widget area for tags
add_action( 'genesis_before_footer', 'isabelle_before_footer', 5 );
function isabelle_before_footer() {

	genesis_widget_area( 'before-footer', array(
		'before' => '<div class="before-footer" class="widget-area"><div class="wrap">',
		'after'  => '</div></div>',
	) );

}

//* Hook after footer widget area below footer for advertisement or other message
add_action( 'genesis_after_footer', 'isabelle_after_footer' );
function isabelle_after_footer() {

	genesis_widget_area( 'after-footer', array(
		'before' => '<div class="after-footer" class="widget-area">',
		'after'  => '</div>',
	) );

}

//* Hook extra widget area below the primary nav
add_action( 'genesis_before_content_sidebar_wrap', 'isabelle_after_primary_nav' );
function isabelle_after_primary_nav() {

	genesis_widget_area( 'after-primary-nav', array(
		'before' => '<div class="after-primary-nav" class="widget-area">',
		'after'  => '</div>',
	) );

}

//* Reposition the secondary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_after_header', 'genesis_do_subnav', 15 );

//* Hook slider widget area before content
add_action( 'genesis_before_content_sidebar_wrap', 'home_box_slider' );
function home_box_slider() {

	if ( ! is_front_page() || get_query_var( 'paged' ) >= 2 )
		return;

	genesis_widget_area( 'home-box-slider', array(
		'before' => '<div class="home-box-slider" class="widget-area">',
		'after'  => '</div>',
	) );

}

//* Customize the post meta function
add_filter( 'genesis_post_meta', 'sp_post_meta_filter' );
function sp_post_meta_filter($post_meta) {

	if ( !is_page() ) {
		$post_meta = '[post_tags before="In this story: "] [post_categories before="Category: "]';
		return $post_meta;
	}
}

//* Remove entry meta in entry footer
add_action( 'genesis_before_entry', 'isabelle_remove_entry_meta' );
function isabelle_remove_entry_meta() {
	
	//* Remove if not single post
	if ( ! is_single() ) {
		remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
		remove_action( 'genesis_entry_footer', 'genesis_post_meta' );
		remove_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
	}
}


//* Modify the size of the Gravatar in the author box
add_filter( 'genesis_author_box_gravatar_size', 'isabelle_author_box_gravatar' );
function isabelle_author_box_gravatar( $size ) {

	return 100;

}

//* Modify the size of the Gravatar in the entry comments
add_filter( 'genesis_comment_list_args', 'isabelle_comments_gravatar' );
function isabelle_comments_gravatar( $args ) {

	$args['avatar_size'] = 100;
	return $args;

}

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'isabelle_remove_comment_form_allowed_tags' );
function isabelle_remove_comment_form_allowed_tags( $defaults ) {

	$defaults['comment_notes_after'] = '';
	return $defaults;

}

//* Add Post Title above the content sidebar on single posts
add_action( 'get_header', 'reposition_single_entry_header' );
function reposition_single_entry_header() {
    if ( ! is_singular( 'post' ) ) {
        return;
    }
    remove_action( 'genesis_entry_header', 'genesis_do_post_title' );
    remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
    remove_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );
    add_action( 'genesis_before_content', 'genesis_entry_header_markup_open', 5 );
    add_action( 'genesis_before_content', 'genesis_do_post_title' );
    add_action( 'genesis_before_content', 'genesis_entry_header_markup_close', 15 );
}

//* Display excerpt after titles on single posts
add_action( 'genesis_before_content', 'add_excerpt_after_post_title', 13 );
function add_excerpt_after_post_title() {
    if ( ! is_singular( 'post' ) || ! has_excerpt() ) {
        return;
    }
    the_excerpt();
}

//* Apply Full Width Content layout to Posts page, Single Posts and Archives.
add_action( 'get_header', 'isabelle_set_full_layout' );
function isabelle_set_full_layout() {
	if ( ! ( is_author() || is_archive() || is_search() ) ) {
		return;
	}
	// Force full width content
	add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );
}


add_filter( 'wp_nav_menu_items', 'isabelle_menu_extras', 10, 2 );
/**
 * Filter menu items, appending a a search icon at the end.
 *
 * @param string   $menu HTML string of list items.
 * @param stdClass $args Menu arguments.
 *
 * @return string Amended HTML string of list items.
 */
function isabelle_menu_extras( $menu, $args ) {
 
    //* Add HTML to the menu in primary location
    if ( 'primary' == $args->theme_location ) {
        $menu .= '<li class="menu-item alignright"><a id="trigger-overlay" class="search-icon" href="#"><i class="fa fa-search"></i></a></li>';
    }
 
    return $menu;
 
}
 
// Load Font Awesome, Sticky Kit and files needed for full screen overlay
add_action( 'wp_enqueue_scripts', 'isabelle_enqueue_stuff' );
function isabelle_enqueue_stuff() {
 
    wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
 
    wp_enqueue_style( 'style3', get_stylesheet_directory_uri() . '/css/style3.css' );
 
    wp_enqueue_script( 'modernizr', get_stylesheet_directory_uri() . '/js/modernizr.custom.js' );
 
    wp_enqueue_script( 'classie', get_stylesheet_directory_uri() . '/js/classie.js', '', '', true );
    wp_enqueue_script( 'demo1', get_stylesheet_directory_uri() . '/js/demo1.js', '', '', true );
 
    // if being viewed on a tablet or mobile, abort.
    if ( wp_is_mobile() ) {
        return;
    }
 
    wp_enqueue_script( 'sticky-kit', get_stylesheet_directory_uri() . '/js/jquery.sticky-kit.min.js', array( 'jquery' ), CHILD_THEME_VERSION, true );
 
    wp_enqueue_script( 'non-handhelds', get_stylesheet_directory_uri() . '/js/non-handhelds.js', array( 'sticky-kit' ), CHILD_THEME_VERSION, true );
 
}
 
//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'isabelle_search_button_text' );
function isabelle_search_button_text( $text ) {
 
    return esc_attr( '&#xf002;' );
 
}
 
//* Overlay content
add_action( 'genesis_after', 'isabelle_search' );
function isabelle_search() {
 
    echo '<div class="overlay overlay-slidedown">';
        echo '<button type="button" class="overlay-close">Close</button>';
        get_search_form();
    echo '</div>';
 
}

//* Enqueue End of Page Slide Out Box jQuery
add_action( 'wp_enqueue_scripts', 'isabelle_enqueue_slideoutbox' );
function isabelle_enqueue_slideoutbox() {
	// if ( is_singular() ) {
	// 	return;
	// }

	wp_enqueue_script( 'modernizr', get_stylesheet_directory_uri() . '/js/modernizr.custom.90461.js', array( 'jquery' ), '1.0.0', true );

	wp_enqueue_script( 'end-of-page-slide-out-box', get_stylesheet_directory_uri() . '/js/end-of-page-slide-out-box.js', array( 'jquery' ), '1.0.0', true );
}


//* Display Slide Out Box
add_action( 'wp_footer', 'isabelle_show_slide_out_box' );
function isabelle_show_slide_out_box() {
	// if ( is_singular() ) {
	// 	return;
	// }

	genesis_widget_area( 'slide-out-box', array(
		'before'	=> '<section id="slidebox"><a class="close"></a>',
		'after'		=> '</section>',
	) );
}

//* Register a custom image size for Singular Featured images
add_image_size( 'singular-featured-thumb', 780, 480, true );

//* Display featured image automatically on posts
add_action( 'genesis_before_entry', 'isabelle_display_featured_image' );
function isabelle_display_featured_image() {
	if ( ! is_singular( array( 'post', 'page' ) ) ) {
		return;
	}
	if ( ! has_post_thumbnail() ) {
		return;
	}
	// Display featured image above content
	echo '<div class="singular-featured-image">';
		genesis_image( array( 'size' => 'singular-featured-thumb' ) );
	echo '<span class="caption">' . get_post( get_post_thumbnail_id() )->post_excerpt . '</span>';
	echo '</div>';
}

//* Adjust number of posts per author page
function author_posts_per_page( $query ) {
if (!is_admin() && is_author() )
        
        $query->set( 'posts_per_page', 6 );
}
add_filter('parse_query', 'author_posts_per_page');

//* Reposition author box
remove_action( 'genesis_before_loop', 'genesis_do_author_box_archive', 15 );
add_action( 'genesis_after_header', 'genesis_do_author_box_archive', 15 );

//* Reposition author title and description
remove_filter( 'genesis_author_intro_text_output', 'wpautop' );
remove_action( 'genesis_before_loop', 'genesis_do_author_title_description', 15 );

//* Add Ad Banner After Navigation
add_action( 'genesis_after_header', 'ad_banner_1' );
function ad_banner_1() {

	genesis_widget_area( 'ad-banner-1', array(
        	'before' => '<div class="ad-banner-1 widget-area">',
	'after'  => '</div>',
	) );
}

//* Add Ad Banner Before Footer
add_action( 'genesis_before_footer', 'custom_ad_banner_2', 8 );
function custom_ad_banner_2() {

	genesis_widget_area( 'ad-banner-2', array(
	        'before' => '<div class="ad-banner-2 widget-area">',
		'after'  => '</div>',
	) );
}

//* Add custom headline and / or description to category / tag / taxonomy archive pages
remove_action( 'genesis_before_loop', 'genesis_do_taxonomy_title_description', 15 );
add_action( 'genesis_after_header', 'isabelle_do_taxonomy_title_description', 15 );
function isabelle_do_taxonomy_title_description() {

	global $wp_query;

	if ( ! is_category() && ! is_tag() && ! is_tax() && ! is_author() )
		return;

	$term = is_tax() ? get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ) : $wp_query->get_queried_object();

	if ( ! $term )
		return;

	$headline = $intro_text = '';

	if ( $headline = get_term_meta( $term->term_id, 'headline', true ) ) {
		$headline = sprintf( '<h1 %s>%s</h1>', genesis_attr( 'archive-title' ), strip_tags( $headline ) );
	} else {
		if ( genesis_a11y( 'headings' ) ) {
			$headline = sprintf( '<h1 %s>%s</h1>', genesis_attr( 'archive-title' ), strip_tags( $term->name ) );
		}
	}

	if ( $intro_text = get_term_meta( $term->term_id, 'intro_text', true ) )
		$intro_text = apply_filters( 'genesis_term_intro_text_output', $intro_text );

	if ( is_category() )
		$category_rss = sprintf( '<a href="%s" class="category-rss button"></a>', esc_url( home_url() ) . '/category/' . $term->slug . '/feed/' );

	if ( $headline || $intro_text ) {
		if ( is_category() ) {
			printf( '<div %s>%s</div>', genesis_attr( 'taxonomy-archive-description' ), $headline . $category_rss . $intro_text );

		} else {
			printf( '<div %s>%s</div>', genesis_attr( 'taxonomy-archive-description' ), $headline . $intro_text );
		}
	}

}

//* Add Twitter field in User Profile page in WP admin
function author_box_contactmethods( $contactmethods ) {
	$contactmethods['twitter'] = 'Twitter (w/o the @)';
	
	return $contactmethods;
}
add_filter( 'user_contactmethods', 'author_box_contactmethods', 10, 1 );

//* Create [twitter_link] shortcode
add_shortcode( 'twitter_link', 'isabelle_twitter_link_shortcode' );
function isabelle_twitter_link_shortcode() {
    $twitter_handle = ltrim( get_the_author_meta( 'twitter' ), '@' );

    if ( empty( $twitter_handle ) ) {
        return '';
    }

    return sprintf(
        '<span class="twitter"><a href="%s" target="_blank">@%s</a></span>',
        esc_url( 'https://twitter.com/' . $twitter_handle ),
        $twitter_handle
    );
}

/**
 * Add author avatar to post info output
 */
add_filter( 'genesis_post_info', 'isabelle_post_info_filter' );
function isabelle_post_info_filter( $post_info ) {

	if ( ! is_singular( array( 'post', 'page' ) ) ) {
		return;
	}

	// get author details
	$entry_author = get_avatar( get_the_author_meta( 'email' ), 40 );
	$author_link = get_author_posts_url( get_the_author_meta( 'ID' ) );

	// build updated post_info
	$post_info = sprintf( '<span class="author-avatar"><a href="%s">%s</a></span>', $author_link, $entry_author );
	$post_info .= 'By [post_author_posts_link]   [post_date] [twitter_link] [post_edit]';
	return $post_info;

}

//* Add custom social fields in User Profile page in WP admin
function my_new_contactmethods( $contactmethods ) {
	$contactmethods['twitter'] = 'Twitter (w/o the @)';
	$contactmethods['facebook'] = 'Facebook URL';
	$contactmethods['pinterest'] = 'Pinterest URL';
	$contactmethods['instagram'] = 'Instagram URL';
	$contactmethods['bloglovin'] = 'Bloglovin URL';
	$contactmethods['rss'] = 'RSS Feed URL';

	return $contactmethods;
}
add_filter( 'user_contactmethods', 'my_new_contactmethods', 10, 1 );

//* Display user profile fields after title in author box
add_filter( 'genesis_author_box_title', 'isabelle_add_twitter_author_box_title', 10, 1 );
function isabelle_add_twitter_author_box_title( $title ) {

	$website_url = get_the_author_meta( 'url' );
	$twitter_handle = ltrim( get_the_author_meta( 'twitter' ), '@' );
	$facebook_url = get_the_author_meta( 'facebook' );
	$pinterest_url = get_the_author_meta( 'pinterest' );
	$instagram_url = get_the_author_meta( 'instagram' );
	$bloglovin_url = get_the_author_meta( 'bloglovin' );
	$rss_url = get_the_author_meta( 'rss' );

	$author_display_name = get_the_author_meta( 'display_name', (int) get_query_var( 'author' ) );

	if ( !empty( $website_url ) ) {
	$website_link = sprintf(
			'<span class="website author-box-social"><a href="%s" target="_blank" title="Visit %s\'s site"><i class="fa fa-globe" aria-hidden="true"></i></a></span></div>',
			esc_url( $website_url ),
			$author_display_name
		);
	}

	if ( !empty( $twitter_handle ) ) {
		$twitter_link = sprintf(
			'<span class="twitter author-box-social"><a href="%s" target="_blank" title="Visit %s on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></span>',
			esc_url( 'https://twitter.com/' . $twitter_handle ),
			$author_display_name
		);
	}

	if ( !empty( $facebook_url ) ) {
		$facebook_link = sprintf(
			'<span class="facebook author-box-social"><a href="%s" target="_blank" title="Visit %s on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></span>',
			esc_url( $facebook_url ),
			$author_display_name
		);
	}

	if ( !empty( $pinterest_url ) ) {
		$pinterest_link = sprintf(
			'<span class="pinterest author-box-social"><a href="%s" target="_blank" title="Visit %s on Pinterest"><i class="fa fa-pinterest" aria-hidden="true"></i></a></span>',
			esc_url( $pinterest_url ),
			$author_display_name
		);
	}

	if ( !empty( $instagram_url ) ) {
		$instagram_link = sprintf(
			'<span class="instagram author-box-social"><a href="%s" target="_blank" title="Visit %s on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a></span>',
			esc_url( $instagram_url ),
			$author_display_name
		);
	}

	if ( !empty( $bloglovin_url ) ) {
		$bloglovin_link = sprintf(
			'<span class="bloglovin author-box-social"><a href="%s" target="_blank" title="Visit %s on Bloglovin"><i class="fa fa-heart" aria-hidden="true"></i></a></span>',
			esc_url( $bloglovin_url ),
			$author_display_name
		);
	}

	if ( !empty( $rss_url ) ) {
		$rss_link = sprintf(
			'<span class="rss author-box-social"><a href="%s" target="_blank" title="Visit %s\'s RSS Feed"><i class="fa fa-rss" aria-hidden="true"></i></a></span>',
			esc_url( $rss_url ),
			$author_display_name
		);
	}

	return $title . $website_link . $twitter_link . $facebook_link . $pinterest_link . $instagram_link . $bloglovin_link . $rss_link;
}

//* Change the number of Related Posts displayed under your posts
function jetpackme_more_related_posts( $options ) {
    $options['size'] = 3;
    return $options;
}
add_filter( 'jetpack_relatedposts_filter_options', 'jetpackme_more_related_posts' );


//* Add Scriptless Social Sharing Buttons to Post Info if Plugin Active
remove_filter( 'the_content', 'scriptlesssocialsharing_print_buttons', 99 );
add_action( 'genesis_post_info', 'scriptlesssocialsharing_buttons_post_info', 8, 2 );
	function scriptlesssocialsharing_buttons_post_info() {
		if ( function_exists( 'scriptlesssocialsharing_do_buttons' ) ) {
			echo wp_kses_post( scriptlesssocialsharing_do_buttons() );
	}
}


/**
 * Template Redirect
 * Use archive.php in place of Blog Template
 */
add_filter( 'template_include', 'custom_content_archive_template', 99 );
function custom_content_archive_template( $template ) {

	if ( is_page_template( 'page_blog.php' ) ) {
		$new_template = locate_template( array( 'archive.php' ) );
		if ( '' != $new_template ) {
			return $new_template ;
		}
	}

	return $template;
}

//* Register widget areas
genesis_register_sidebar( array(
	'id'          => 'before-header',
	'name'        => __( 'Before Header', 'isabelle' ),
	'description' => __( 'This is the before header widget area.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'after-primary-nav',
	'name'        => __( 'After Primary Nav', 'isabelle' ),
	'description' => __( 'This is the after the primary nav widget area.', 'isabelle' ),
) );
genesis_register_sidebar( array(
    'id' => 'ad-banner-1',
    'name' => __( 'Ad Banner 1', 'genesis' ),
    'description' => __( 'This is the ad banner 1 widget below the navigation.', 'isabelle' ),
) );
genesis_register_sidebar( array(
    'id' => 'ad-banner-2',
    'name' => __( 'Ad Banner 2', 'isabelle' ),
    'description' => __( 'This is the ad banner 2 widget above the footer area.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-box-slider',
	'name'        => __( 'Home Box Slider', 'isabelle' ),
	'description' => __( 'This is the home box slider widget area below the navigation.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-top-left',
	'name'        => __( 'Home - Top Left', 'isabelle' ),
	'description' => __( 'This is the top left section of the homepage.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-top-right',
	'name'        => __( 'Home - Top Right', 'isabelle' ),
	'description' => __( 'This is the top right section of the homepage.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-middle',
	'name'        => __( 'Home - Middle', 'isabelle' ),
	'description' => __( 'This is the middle section of the homepage.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'home-bottom',
	'name'        => __( 'Home - Bottom', 'isabelle' ),
	'description' => __( 'This is the bottom section of the homepage.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'cta-one',
	'name'        => __( 'Call to Action One', 'isabelle' ),
	'description' => __( 'This is the call to action for the eNews widget area.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'cta-two',
	'name'        => __( 'Call to Action Two', 'isabelle' ),
	'description' => __( 'This is the call to action for the latest news widget area.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'before-footer',
	'name'        => __( 'Before Footer', 'isabelle' ),
	'description' => __( 'This is the before footer widget area.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'          => 'after-footer',
	'name'        => __( 'After Footer', 'isabelle' ),
	'description' => __( 'This is the after footer widget area.', 'isabelle' ),
) );
genesis_register_sidebar( array(
	'id'            => 'slide-out-box',
	'name'          => __( 'Slide Out Box', 'isabelle' ),
	'description'   => __( 'This is the end of page slide out box widget area', 'isabelle' ),
) );

