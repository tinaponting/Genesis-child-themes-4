<?php

remove_action(	'genesis_loop', 'genesis_do_loop' );

function cb_genesis_search_loop() {
	get_template_part('template-parts/content');
}

genesis();