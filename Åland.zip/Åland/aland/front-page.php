<?php
/**
 * This file adds all the settings for the home page.
 *
 * @link         http://watdesignexpress.com/
 * @author       WAT Design Express
 * @copyright    Copyright (c) 2018, WAT Design Express, Released 01/2018
 */

//* Add widget support for homepage.
add_action( 'genesis_meta', 'wat_front_page_genesis_meta' );
function wat_front_page_genesis_meta() {
	//* Add body class
	add_filter( 'body_class', 'wat_front_page_body_class' );
	
	//* Force content layout
	if ( 'full-width' == get_theme_mod( 'homepage_layout_set' ) ) :

	add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

	elseif ( 'content-sidebar' == get_theme_mod( 'homepage_layout_set' ) ) :

	add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );

	elseif ( 'sidebar-content' == get_theme_mod( 'homepage_layout_set' ) ) :

	add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_sidebar_content' );

	endif;	

	//* Add widgets on front page
	add_action( 'genesis_before_content_sidebar_wrap', 'wat_front_page_widgets' );
}


//* Add body class to the head
function wat_front_page_body_class( $classes ) {

	$classes[] = 'front-page';
	return $classes;

}
//* Check parallax effect
function check_parallax( $style, $number_front ) {
	if ( get_theme_mod( ''.$style.'','none') == 'none' )
		return;
	else
		return 'para-front-page-'. $number_front;
}

//* Add widgets on front page
function wat_front_page_widgets() {

	if ( get_query_var( 'paged' ) >= 2 )
		return;

	genesis_widget_area( 'front-page-1', array(
		'before' => '<div id="front-page-1" class="front-page-1 margin-front flexible-widgets widget-area' . custom_widget_area_class( 'front-page-1' ) . '"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_cb_1', '1') .'">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-2', array(
		'before' => '<div id="front-page-2" class="front-page-2 margin-front flexible-widgets widget-area' . custom_widget_area_class( 'front-page-2' ) . '"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_cb_2', '2') .'">',
		'after'  => '</div></div></div>',
	) );

	genesis_widget_area( 'front-page-3', array(
		'before' => '<div id="front-page-3" class="front-page-3 margin-front flexible-widgets widget-area' . custom_widget_area_class( 'front-page-3' ) . '"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_cb_3', '3') .'">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-4', array(
		'before' => '<div id="front-page-4" class="front-page-4 margin-front flexible-widgets widget-area' . custom_widget_area_class( 'front-page-4' ) . '"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_cb_4', '4') .'">',
		'after'  => '</div></div></div>',
	) );
	
	genesis_widget_area( 'front-page-5', array(
		'before' => '<div id="front-page-5" class="front-page-5 margin-front flexible-widgets widget-area' . custom_widget_area_class( 'front-page-5' ) . '"><div class="wrap"><div class="widget-area '. check_parallax('parallax_style_cb_5', '5') .'">',
		'after'  => '</div></div></div>',
	) );
}

//* Run the default Genesis loop
genesis();
