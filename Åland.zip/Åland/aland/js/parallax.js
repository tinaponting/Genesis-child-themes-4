(function($) {

	//* Make sure JS is enabled
	document.documentElement.className = "parallax";

	$(document).ready( function() {

		//* Run 0.25 seconds after document ready for any instances viewable on load
		setTimeout( function() {
			if (parallaxEffectName1 != 'none') {
				playObject('.para-front-page-1','para-effect-1-'+ parallaxEffectName1);
			}
			if (parallaxEffectName2 != 'none') {
				playObject('.para-front-page-2','para-effect-2-'+ parallaxEffectName2);
			}
			if (parallaxEffectName3 != 'none') {
				playObject('.para-front-page-3','para-effect-3-'+ parallaxEffectName3);
			}
			if (parallaxEffectName4 != 'none') {
				playObject('.para-front-page-4','para-effect-4-'+ parallaxEffectName4);
			}
			if (parallaxEffectName5 != 'none') {
				playObject('.para-front-page-5','para-effect-5-'+ parallaxEffectName5);
			}
		}, 250);

	});
	
	$(window).scroll( function() {
		//* Run on scroll
		if (parallaxEffectName1 != 'none') {
			playObject('.para-front-page-1','para-effect-1-'+ parallaxEffectName1);
		}
		if (parallaxEffectName2 != 'none') {
			playObject('.para-front-page-2','para-effect-2-'+ parallaxEffectName2);
		}
		if (parallaxEffectName3 != 'none') {
			playObject('.para-front-page-3','para-effect-3-'+ parallaxEffectName3);
		}
		if (parallaxEffectName4 != 'none') {
			playObject('.para-front-page-4','para-effect-4-'+ parallaxEffectName4);
		}
		if (parallaxEffectName5 != 'none') {
			playObject('.para-front-page-5','para-effect-5-'+ parallaxEffectName5);
		}				
	});

	function playObject(paraArea, paraEffect) {

		//* Define your object via class
		var object = $( paraArea );

		//* Loop through each object in the array
		$.each( object, function() {
			var windowHeight = $(window).height(),
				offset 		 = $(this).offset().top,
				top			 = offset - $(document).scrollTop(),
				percent 	 = Math.floor( top / windowHeight * 100 );

			if ( percent < 80 ) {
				$(this).addClass( paraEffect );

			}
		});
	}

})(jQuery);