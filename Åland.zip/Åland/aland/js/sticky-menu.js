// Add the sticky class to the navbar when you reach its scroll position. Remove "sticky" when you leave the scroll position
function sticky_primary_menu() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  }
  else {
    navbar.classList.remove("sticky");
  }
}

// Add the sticky class to the navbar when you reach its scroll position. Remove "sticky" when you leave the scroll position
function sticky_secondary_menu() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  }
  else {
    navbar.classList.remove("sticky");
  }
}

if (stickyMenu == 'primary') {
	// When the user scrolls the page
	window.onscroll = function() {sticky_primary_menu()};
	// Get the navbar
	var navbar = document.getElementById("main-menu");

// Get the offset position of the navbar
	var sticky = navbar.offsetTop + 50;
}
else if (stickyMenu == 'secondary') {
	// When the user scrolls the page, execute sticky_menu 
	window.onscroll = function() {sticky_secondary_menu()};

	// Get the navbar
	var navbar = document.getElementById("sub-menu");

	// Get the offset position of the navbar
	var sticky = navbar.offsetTop + 50;
}




