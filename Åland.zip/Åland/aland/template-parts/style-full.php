<div id="post-<?php the_ID(); ?>" <?php post_class( 'style-full' ); ?>>
	<a href="<?php the_permalink(); ?>">
	<?php if ( is_home() || is_front_page() ) {
			if ( 'full-width' == get_theme_mod( 'homepage_layout_set' ) ) {
				the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
			}
			else {
				the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
			}
		}
		elseif ( is_category() ) {
			if ( 'full-width' == get_theme_mod( 'category_layout_set' ) ) {
				the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
			}
			else {
				the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
			}
		}
		elseif ( is_archive() ) {
			if ( 'full-width' == get_theme_mod( 'archives_layout_set' ) ) {
				the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
			}
			else {
				the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
			}
		}
		else {
			the_post_thumbnail('featured', array('class' => 'aligncenter featured'));
		} ?></a>
	<div class="wrap-title">
		<h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<div class="post-meta">
				<?php echo the_category( ', ' ) .', '.apply_filters( 'the_date', get_the_date(), get_option( 'date_format' ), '', '' ); ?>
		</div>
	</div>
	<div class="post-content">
		<?php echo the_content();?>
		<div class="clear"></div>
	</div>
<?php 
	if ( !is_single() ) {
		get_template_part('lib/extras/readmore');
	}
	get_template_part('lib/extras/social-share'); ?>
	<div class="clear"></div>
</div>
