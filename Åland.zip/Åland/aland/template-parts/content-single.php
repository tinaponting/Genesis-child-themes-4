<?php
if (have_posts()) : while (have_posts()) : the_post();
	do_action( 'genesis_before_entry' ); ?>
	<div id="post-<?php the_ID(); ?>" <?php post_class('style-single'); ?>>
		<div class="wrap-title">
		<h2 class="post-title"><?php the_title(); ?></h2>
			<div class="post-meta">
					<?php echo the_category( ', ' ) .', '.apply_filters( 'the_date', get_the_date(), get_option( 'date_format' ), '', '' ); ?>
			</div>
		</div>
		<div class="post-content">
		<?php do_action( 'genesis_entry_content' ); ?>
		<div> <?php the_tags(); ?> </div>
		<?php get_template_part('lib/extras/social-share');
		get_template_part('lib/extras/leavecomments');
		?>
		<div class="clear"></div>
		<?php do_action( 'genesis_after_entry_content' ); ?>
		</div>
	</div>
	<div class="divpost"></div>
	<div class="shop-post"><?php
	// Get custom field post
		$custom = get_post_custom();
		if( isset( $custom['shop_post'] ) ) {
		    foreach($custom['shop_post'] as $key => $value) {
			     echo $value;
			}
		}?>
		</div>
<?php 
	// Related post
	do_action( 'genesis_after_entry' );
endwhile; else: get_template_part('lib/extras/error');
endif;
?>

