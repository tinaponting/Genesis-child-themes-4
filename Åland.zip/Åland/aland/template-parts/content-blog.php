<?php
$num_post_blog = get_theme_mod( 'blog_numpost_set', 12 );
$page_num = $paged; if ($pagenum='') $pagenum = 1;
query_posts('&showposts='.$num_post_blog.'&paged='.$page_num);

$counter = 1;
if (have_posts()) : $postCount = 0; while (have_posts()) : the_post(); $postCount++;
	if ( 'full' == get_theme_mod( 'blog_style_set','excerpt' ) ) {
		get_template_part('template-parts/style-full');
		if($postCount == 1) {get_template_part('lib/extras/after-first-post');}
	}
	elseif ( 'excerpt' == get_theme_mod( 'blog_style_set','excerpt' ) ) {
		get_template_part('template-parts/style-excerpt');
		if($postCount == 1) {get_template_part('lib/extras/after-first-post');}
	}
	elseif ( 'list' == get_theme_mod( 'blog_style_set','excerpt' ) ) {
		get_template_part('template-parts/style-list');
		if($postCount == 1) {get_template_part('lib/extras/after-first-post');}
	}
	elseif ( 'grid' == get_theme_mod( 'blog_style_set','excerpt' ) ) {
		get_template_part('template-parts/style-grid');
		if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
		if($postCount == 3) {get_template_part('lib/extras/after-first-post');}
		$counter++;
	}
	elseif ( 'full-excerpt' == get_theme_mod( 'blog_style_set','excerpt' ) ) {
		if($postCount == 1) {
			get_template_part('template-parts/style-full');
			get_template_part('lib/extras/after-first-post');
		}
		else {
			get_template_part('template-parts/style-excerpt');
		}
	}
	elseif ( 'full-grid' == get_theme_mod( 'blog_style_set','excerpt' ) ) {
		if($postCount == 1) {
			get_template_part('template-parts/style-full');
			get_template_part('lib/extras/after-first-post');
		}
		else {
			get_template_part('template-parts/style-grid');
			if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
			$counter++;			
		}	
	}
	elseif ( 'full-list' == get_theme_mod( 'blog_style_set','excerpt' ) ) {
		if($postCount == 1) {
			get_template_part('template-parts/style-full');
			get_template_part('lib/extras/after-first-post');
		}
		else {
			get_template_part('template-parts/style-list');
		}
	}
	elseif ( 'excerpt-grid' == get_theme_mod( 'blog_style_set','excerpt' ) ) {
		if($postCount == 1) {
			get_template_part('template-parts/style-excerpt');
			get_template_part('lib/extras/after-first-post');
		}
		else {
			get_template_part('template-parts/style-grid');
			if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
			$counter++;				
		}
	}
	elseif ( 'excerpt-list' == get_theme_mod( 'blog_style_set','excerpt' ) ) {
		if($postCount == 1) {
			get_template_part('template-parts/style-excerpt');
			get_template_part('lib/extras/after-first-post');
		}
		else {
			get_template_part('template-parts/style-list');
		}
	}
	endwhile;
	wat_numeric_posts_nav('query_posts');
else: get_template_part('lib/extras/error');
endif;
wp_reset_query();
?>