<?php 
$counter = 1;
if (have_posts()) : $postCount = 0; while (have_posts()) : the_post(); $postCount++;
	if ( is_category() ) {
		if ( 'excerpt' == get_theme_mod( 'category_style_set','excerpt' ) ) {
			get_template_part('template-parts/style-excerpt');
			if($postCount == 1) {get_template_part('lib/extras/after-first-post');}
		}
		elseif ( 'list' == get_theme_mod( 'category_style_set','excerpt' ) ) {
			get_template_part('template-parts/style-list');
			if($postCount == 1) {get_template_part('lib/extras/after-first-post');}
		}
		elseif ( 'grid' == get_theme_mod( 'category_style_set','excerpt' ) ) {
			get_template_part('template-parts/style-grid');
			if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
			if($postCount == 3) {get_template_part('lib/extras/after-first-post');}
			$counter++;
		}
		elseif ( 'excerpt-grid' == get_theme_mod( 'category_style_set','excerpt' ) ) {
			if($postCount == 1) {
				get_template_part('template-parts/style-excerpt');
				get_template_part('lib/extras/after-first-post');
			}
			else {
				get_template_part('template-parts/style-grid');
				if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
				$counter++;			
			}
		}
		elseif ( 'excerpt-list' == get_theme_mod( 'category_style_set','excerpt' ) ) {
			if($postCount == 1) {
				get_template_part('template-parts/style-excerpt');
				get_template_part('lib/extras/after-first-post');
			}
			else {
				get_template_part('template-parts/style-list');
			}
		}
		elseif ( 'list-grid' == get_theme_mod( 'category_style_set','excerpt' ) ) {
			if($postCount == 1) {
				get_template_part('template-parts/style-list');
				get_template_part('lib/extras/after-first-post');
			}
			else {
				get_template_part('template-parts/style-grid');
				if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
				$counter++;	
			}
		}
	}
	elseif ( is_archive() ) {
		if ( 'excerpt' == get_theme_mod( 'archives_style_set','excerpt' ) ) {
			get_template_part('template-parts/style-excerpt');
			if($postCount == 1) {get_template_part('lib/extras/after-first-post');}
		}
		elseif ( 'list' == get_theme_mod( 'archives_style_set','excerpt' ) ) {
			get_template_part('template-parts/style-list');
			if($postCount == 1) {get_template_part('lib/extras/after-first-post');}
		}
		elseif ( 'grid' == get_theme_mod( 'archives_style_set','excerpt' ) ) {
			get_template_part('template-parts/style-grid');
			if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
			if($postCount == 3) {get_template_part('lib/extras/after-first-post');}
			$counter++;
		}
		elseif ( 'excerpt-grid' == get_theme_mod( 'archives_style_set','excerpt' ) ) {
			if($postCount == 1) {
				get_template_part('template-parts/style-excerpt');
				get_template_part('lib/extras/after-first-post');
			}
			else {
				get_template_part('template-parts/style-grid');
				if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
				$counter++;			
			}
		}
		elseif ( 'excerpt-list' == get_theme_mod( 'archives_style_set','excerpt' ) ) {
			if($postCount == 1) {
				get_template_part('template-parts/style-excerpt');
				get_template_part('lib/extras/after-first-post');
			}
			else {
				get_template_part('template-parts/style-list');
			}
		}
		elseif ( 'list-grid' == get_theme_mod( 'archives_style_set','excerpt' ) ) {
			if($postCount == 1) {
				get_template_part('template-parts/style-list');
				get_template_part('lib/extras/after-first-post');
			}
			else {
				get_template_part('template-parts/style-grid');
				if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
				$counter++;	
			}
		}		
	}
	elseif ( is_search() ) {
		get_template_part('template-parts/style-grid');
		if ($counter % 3 == 0) : ?><div class="clear"></div><?php endif;
		$counter++;
	}
	else {
		get_template_part('template-parts/style-excerpt');
	}
endwhile;
wat_numeric_posts_nav('query_posts');
else: get_template_part('lib/extras/error');
endif;
wp_reset_query();	
?>