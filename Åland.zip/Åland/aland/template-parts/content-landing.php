<?php 
//* Force full width content layout
add_filter( 'genesis_site_layout', '__genesis_return_full_width_content' );
//* Remove widget above footer
remove_action( 'genesis_before_footer', 'wat_widget_below_footer', 10 ); 
//* Remove site footer widgets
remove_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
//* Remove widget above content
remove_action( 'genesis_after_header', 'wat_widget_above_content' );
//* Remove site footer elements
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="pagetitle landing-title"><?php wp_title('') ?></div>
		<div class="content-landing">
		<?php the_content(); ?>
		</div>
</div>
<?php endwhile; else: ?>
<?php get_template_part('lib/extras/error'); ?>
<?php endif; ?>

