<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="pagetitle about-title"><?php the_title(); ?></div>
	<div class="content-about">
		<?php the_content(); ?>
	</div>
	<div class="clear"></div>
</div>
<?php endwhile; else: ?>
<?php get_template_part('lib/extras/error'); ?>
<?php endif; ?>