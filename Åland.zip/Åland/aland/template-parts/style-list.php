<div id="post-<?php the_ID(); ?>" <?php post_class( 'style-list' ); ?>>
	<div class="featured-thumbnail">
		<div class="featured-thumbnail-inner">
			<?php if ( has_post_thumbnail() ) { ?>
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('rectangle-1', array( 'class' => 'img-list featured' )); ?></a>
					<?php } ?>
		</div>
	</div>
	<div class="post-content">
		<div class="wrap-title">
		<h2 class="post-title">
		<a href="<?php the_permalink(); ?>"><?php $title  = the_title('','',false); if(strlen($title) > 30): echo trim(substr($title, 0, 30)).'&period;&period;&period;';
		else: echo $title; endif; ?></a></h2>
		<?php if ( !is_search() ) { ?>
		<div class="post-meta">
				<?php echo the_category( ', ' ) .', '.apply_filters( 'the_date', get_the_date(), get_option( 'date_format' ), '', '' ); ?>
		</div>
		<?php } ?>
	</div>	
		<p><?php echo excerpt(48); ?></p>
		<?php if ( !is_single() )
		{
			get_template_part('lib/extras/readmore');
			get_template_part('lib/extras/social-share');
		}
				
		?>
	</div>
	<div class="clear"></div>
</div>
