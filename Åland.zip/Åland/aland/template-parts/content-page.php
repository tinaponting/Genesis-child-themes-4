<?php if (have_posts()) : while (have_posts()) : the_post() ?>
	<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if ( has_post_thumbnail() ) { ?>
	<div class="featured-thumbnail-full-page">
		<?php the_post_thumbnail('full', array('class' => 'aligncenter featured')); ?>
	</div>
	<?php } ?>
	<?php if ( is_home() || is_front_page() || is_page_template('templates/blog.php') ) ; else { ?>
		<h2 class="page-title"><?php the_title(); ?></h2>
	<?php } ?>
		<div class="page-content">
		<?php the_content(); ?>
		</div>
		<div class="clear"></div>
	</div>
	<?php endwhile; else: ?>
	<?php get_template_part('lib/extras/error'); ?>
	<?php endif; ?>