<?php
/**
 * Genesis Sample.
 *
 * This file adds the required CSS to the front end to the Genesis Sample Theme.
 *
 * @package Genesis Sample
 * @author  StudioPress
 * @license GPL-2.0+
 * @link    http://www.studiopress.com/
 */

add_action( 'wp_enqueue_scripts', 'genesis_sample_css' );
/**
* Checks the settings for the link color, and accent color.
* If any of these value are set the appropriate CSS is output.
*
* @since 2.2.3
*/
function genesis_sample_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
	$bg_header = get_theme_mod( 'banner_set' );
	$parallax_time = get_theme_mod( 'parallax_time','1' );

	$margin_top = get_theme_mod( 'margin_top_set', 3 );
	$margin_bottom = get_theme_mod( 'margin_bottom_set', 3 );

	$body_color = get_theme_mod( 'background_color','fff' );

	$text_color = get_theme_mod( 'text_color','#3D4A54' );
	$sub_text_color = get_theme_mod( 'sub_text_color','#3D4A54' );

	$top_menu_background_color = get_theme_mod( 'top_menu_background_color','#fff' );
	$top_menu_text_color = get_theme_mod( 'top_menu_text_color','#3D4A54' );

	$top_menu_hover_background_color = get_theme_mod( 'top_menu_hover_background_color','#3D4A54' );
	$top_menu_hover_text_color = get_theme_mod( 'top_menu_hover_text_color','#fff' );	

	$text_link_color = get_theme_mod( 'text_link_color','#3D4A54' );
	$text_link_hover_color = get_theme_mod( 'text_link_hover_color','#D4E5D8' );

	$button_background_color = get_theme_mod( 'button_background_color','#fff' );
	$button_text_color = get_theme_mod( 'button_text_color','#3D4A54' );
	$button_hover_background_color = get_theme_mod( 'button_hover_background_color','#3D4A54' );
	$button_hover_text_color = get_theme_mod( 'button_hover_text_color','#fff' );

	$footer_background_color = get_theme_mod( 'footer_background_color','#e9f2eb' );
	$footer_text_color = get_theme_mod( 'footer_text_color','#3D4A54' );
	$footer_link_color_hover =get_theme_mod('footer_link_color_hover','#3D4A54');

	$css = '';

	$css .= sprintf( '
		.site-header {
			background: url(%s) no-repeat center center;
		}
		', $bg_header );
	$css .= sprintf( '
		.site-header > .wrap {
			margin-top: %s;
			margin-bottom: %s;
		}
		', $margin_top.'%' , $margin_bottom.'%' );
	$css .= sprintf( '
		.parallax .para-front-page-1, .parallax .para-front-page-2, .parallax .para-front-page-3
		, .parallax .para-front-page-4, .parallax .para-front-page-5 {
			-webkit-animation-duration: %ss !important;
    		animation-duration: %ss !important;
	}
	', $parallax_time, $parallax_time );

	//Body
	$css .= sprintf( '
		body, .nav-primary, .entry, .sidebar .widget,
		.after-entry, .archive-description, .author-box, 
		.comment-respond, .entry-comments, .entry-pings,
		.nav-secondary, .enews-title, .input, .social-share [class*="fa fa-"],
		.sidebar .featuredpost-full .has-post-thumbnail .entry-meta .entry-categories, .footer-widgets-1 {
			background-color: #%s;
		}
		', $body_color );

	$css .= sprintf ('
		.slide-excerpt, .flexslider,
		#genesis-responsive-slider .slides li .slide-excerpt .slide-excerpt-border {
			background: #%s !important;
		}
		',$body_color );

	$css .= sprintf ('
		.overlay-ins, .to-top {
			color: #%s !important;
		}
		',$body_color );
	//Text color
	$css .= sprintf( '
		body, input, select, textarea {
			color: %s;
		}
		', $text_color );
	$css .= sprintf( '
	.woocommerce-error, .woocommerce-info, .woocommerce-message {
			color: %s !important;
		}
		', $text_color );
	//Sub text color
	$css .= sprintf( '
		.post-meta, .post-meta a {
			color: %s;
		}
		', $sub_text_color );
	//Text link color hover
	$css .= sprintf( '
		a, input[type="button"], input[type="submit"]  {
			color: %s;
		}
		', $text_link_color );
	$css .= sprintf( '
		input[type="button"]:hover, 
		input[type="button"]:focus, input[type="submit"]:hover, input[type="submit"]:focus, 
		.style-excerpt .post-meta a:hover, .style-full .post-meta a:hover, 
		.style-list .post-meta a:hover, .style-single .post-meta a:hover, .style-grid .meta-category a:hover, .style-grid .post-meta a:hover, .genesis-nav-menu a:hover, .sidebar .featuredpost-full .entry-meta .entry-categories a:hover {
			color: %s !important;
		}
		', $text_link_hover_color );
	$css .= sprintf( '
		a:hover, .sidebar .widget_categories li:hover a {
			color: %s;
		}
		', $text_link_hover_color );	
	//Top bar menu background
	$css .= sprintf( '
		.genesis-nav-menu .sub-menu a, .genesis-responsive-menu .genesis-nav-menu .sub-menu
		{
			background: %s !important;
		}
		', $top_menu_background_color );

	$css .= sprintf( '
		.menu-toggle, .menu-toggle:focus, .menu-toggle:hover {
			background: #%s !important;
			color: %s !important;
		}
		', $body_color, $text_color );
	//Top bar menu text
	$css .= sprintf( '
		.genesis-nav-menu a {
			color: %s !important;
		}
		', $top_menu_text_color );

	//Top bar hover menu background
	$css .= sprintf( '
		 .genesis-nav-menu .sub-menu a:hover {
			background: %s !important;
			color: %s !important;
		}
		', $top_menu_hover_background_color, $top_menu_hover_text_color );
	$css .= sprintf( '
		.sub-menu-toggle:hover, .sub-menu-toggle:focus {
			color: %s !important;
		}
		', $text_link_hover_color );
	$css .= sprintf( '
		.site-footer .genesis-nav-menu a:hover {
			color: %s !important;
		}
		', $top_menu_hover_background_color );
	//Button background color % text button color
	$css .= sprintf( '
		input[type="button"]:focus,
		input[type="reset"]:focus,
		input[type="submit"]:focus,
		.archive-pagination li a:focus,
		.archive-pagination .active a,
		.button:focus,
		.front-page .featuredpage .read-more,
		.category-index .more-from-category a,
		.sidebar .featuredpage .read-more,
		button, input[type="button"], input[type="reset"], input[type="submit"], .button,
		.comment-reply a,
		.slide-excerpt-border a.read-more,
		.style-excerpt .read-more a, .style-list .read-more a, .style-grid .read-more a,
		.front-page .featuredpage .more-link, .sidebar .enews-widget input[type="submit"],
		.sidebar .widget_search input[type="submit"], .more-link {
			background: %s !important;
			color: %s !important;		}
		', $button_background_color, $button_text_color );


	$css .= sprintf( '
		.sidebar .widget_search input {
			border-color: %s !important;
		}
		', $button_text_color );

	//Button hover background color % text hover button color
	$css .= sprintf( '
		button:hover,
		input[type="button"]:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		input[type="reset"]:hover,
		input[type="submit"]:hover,
		.archive-pagination li a:hover,
		.archive-pagination .active a:hover,
		.button:hover,
		.sidebar .enews-widget input[type="submit"]:hover,
		.front-page .featuredpage .read-more:hover,
		.category-index .more-from-category a:hover,
		.sidebar .featuredpage .read-more:hover,
		button:hover, input[type="button"]:hover, input[type="reset"]:hover, input[type="submit"]:hover,
		.front-page .enews-widget input[type="submit"]:hover,
		.comment-reply a:hover,
		.footer-widget-area .enews input[type="submit"]:hover,
		.slide-excerpt-border a.read-more:hover,
		.style-excerpt .read-more a:hover, .style-list .read-more a:hover,
		.style-grid .read-more a:hover, .front-page .featuredpage .more-link:hover,
		.sidebar .enews-widget input[type="submit"]:hover,
		.sidebar .widget_search input[type="submit"]:hover,
		.more-link:hover, .sidebar .widget_categories li:hover {
			background: %s !important;
			color: %s !important;
			border-color: %s !important;
		}
		', $button_hover_background_color, $button_hover_text_color, $button_hover_background_color );

	//Footer background color
	$css .= sprintf( '
		.overlay-ins, .to-top {
			background: %s !important;
		}
		', $top_menu_hover_background_color );	

	$css .= sprintf( '
		.site-footer, .footer-widgets, .footer-widgets .enews input[type="submit"], .top-page {
			background: %s !important;
		}
		', $footer_background_color );	
	//Footer text color
	$css .= sprintf( '
		.site-footer p, .footer-widgets-2, .footer-widgets a, .footer-widgets h3, footer-widgets p, .footer-widgets .footer-widgets-3, .footer-widgets .enews input, .site-footer a {
			color: %s;
		}
		', $footer_text_color );
	$css .= sprintf( '
		.site-footer .genesis-nav-menu a {
			color: %s !important;
		}
		', $footer_text_color );
	//Footer link color hover
	$css .=sprintf('
		.site-footer .genesis-nav-menu a:hover, .footer-widgets a:hover, .site-footer a:hover {
			color: %s !important;
		}
		', $footer_link_color_hover);
	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}
