<?php if ( is_active_sidebar( 'after-first-post' ) ) : ?>
<?php dynamic_sidebar( 'after-first-post' ); ?>
<?php endif; ?>