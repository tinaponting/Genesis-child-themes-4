<div class="read-more">
<a href="<?php the_permalink(); ?>">
	<?php echo get_theme_mod('readmore_set','Read More') ; ?>
</a></div>