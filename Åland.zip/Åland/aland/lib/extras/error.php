<?php if (is_search()) { ?>
	<h2 class="404 page-title">Not Found</h2>
	<p class="aligncenter">Sorry, no posts were found. Try searching for something else.</p>
<?php } else { ?>
	<h2 class="404 page-title">Not Found</h2>
	<p class="aligncenter">Sorry, the page you were looking for could not be found.</p>
<?php } ?>