<?php

if ( 'full-width' == get_theme_mod( 'category_layout_set' ) ) :

add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

elseif ( 'content-sidebar' == get_theme_mod( 'category_layout_set' ) ) :

add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_content_sidebar' );

elseif ( 'sidebar-content' == get_theme_mod( 'category_layout_set' ) ) :

add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_sidebar_content' );

endif;

remove_action(	'genesis_loop', 'genesis_do_loop' );

function wat_genesis_category_loop() {
	get_template_part('template-parts/content');
}

genesis();