<?php
/**
 * This file adds the about page template.
 *
 * @link         http://watdesignexpress.com/
 * @author       WAT Design Express
 * @copyright    Copyright (c) 2018, WAT Design Express, Released 01/2018
 */

/*
Template Name: About
*/

add_action( 'genesis_loop', 'wat_genesis_about_loop' );
function wat_genesis_about_loop() {
	get_template_part('template-parts/content-about');
}
genesis();