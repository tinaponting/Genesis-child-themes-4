<?php
/**
 * Aland
 *
 * This file adds functions to the Aland Theme.
 *
 * @package Aland
 * @author  WAT Design Express
 * @link    http://www.watdesignexpress.com/
 */

// Start the engine.
include_once( get_template_directory() . '/lib/init.php' );

// Add Image upload and Color select to WordPress Theme Customizer.
require_once( get_stylesheet_directory() . '/lib/customize.php' );

// Include Customizer CSS.
include_once( get_stylesheet_directory() . '/lib/output.php' );

// Add the Genesis Connect WooCommerce notice.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-notice.php' );

// Child theme (do not remove).
define( 'CHILD_THEME_NAME', 'Aland' );
define( 'CHILD_THEME_URL', 'http://www.demo.watdesignexpress.com/aland' );
define( 'CHILD_THEME_VERSION', '1.0' );

// Enqueue Scripts and Styles.
add_action( 'wp_enqueue_scripts', 'genesis_sample_enqueue_scripts_styles' );
function genesis_sample_enqueue_scripts_styles() {

	wp_enqueue_style( 'genesis-sample-fonts', '//fonts.googleapis.com/css?family=Cormorant:300,300i,400,400i,500,500i,600,600i,700,700i|Old+Standard+TT:400,400i,700', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'dashicons' );

	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'genesis-sample-responsive-menu', get_stylesheet_directory_uri() . "/js/responsive-menus{$suffix}.js", array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_localize_script(
		'genesis-sample-responsive-menu',
		'genesis_responsive_menu',
		genesis_sample_responsive_menu_settings()
	);
	wp_enqueue_script( 'wat-parallax-script', get_stylesheet_directory_uri() . '/js/parallax.js', array( 'jquery' ), '1.0.0', true );
	wp_register_style('style-common', get_stylesheet_directory_uri(   ). '/lib/css/style-common.css', '', '1.0');
	wp_enqueue_style('style-common');
    wp_enqueue_script( 'to-top', get_stylesheet_directory_uri() . '/js/to-top.js', array( 'jquery' ), '1.0', true );
   	wp_enqueue_script( 'wat-collapse', get_stylesheet_directory_uri() . '/js/collapse.js', array( 'jquery' ), '1.0.0', true );
	// Check sticky menu
	wp_enqueue_script( 'wat-sticky', get_stylesheet_directory_uri() . '/js/sticky-menu.js', array( 'jquery' ), '1.0.0', true );
	echo "<script type='text/javascript'>var stickyMenu ='". get_theme_mod('sticky_menu_set','primary')."';</script>";
}

// Define our responsive menu settings.
function genesis_sample_responsive_menu_settings() {

	$settings = array(
		'mainMenu'          => __( '', 'genesis-sample' ),
		'menuIconClass'     => 'dashicons-before dashicons-menu',
		'subMenu'           => __( '', 'genesis-sample' ),
		'subMenuIconsClass' => 'dashicons-before dashicons-arrow-down-alt2',
		'menuClasses'       => array(
			'combine' => array(
				'.nav-primary',
				'.nav-secondary',
			),
			'others'  => array(),
		),
	);

	return $settings;

}

// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );

// Add Accessibility support.
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );

// Add viewport meta tag for mobile browsers.
add_theme_support( 'genesis-responsive-viewport' );

// Add support for custom header.
add_theme_support( 'custom-header', array(
	'width'           => 800,
	'height'          => 180,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );


// Add support for after entry widget.
add_theme_support( 'genesis-after-entry-widget-area' );

// Add support for 4-column footer widgets.
add_theme_support( 'genesis-footer-widgets', 4 );

// Add Footer Menu; Keep Primary and Secondary Menus
add_theme_support ( 'genesis-menus' , array ( 
	'primary'   => __( 'Primary Navigation Menu', 'genesis' ),
	'secondary' => __( 'Secondary Navigation Menu', 'genesis' ),
    'footer'    => __( 'Footer Navigation Menu', 'genesis' )
	) );

// Reposition the primary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before', 'genesis_do_nav', 5 );

// Reposition the footer navigation menu.
add_action( 'genesis_footer', 'add_footer_menu', 5 ); 
function add_footer_menu() {
	wp_nav_menu( array( 'theme_location' => 'footer',
						'container_class' => 'nav-footer genesis-nav-menu',
						'depth' => 1 ) );
}

// Modify size of the Gravatar in the author box.
add_filter( 'genesis_author_box_gravatar_size', 'genesis_sample_author_box_gravatar' );
function genesis_sample_author_box_gravatar( $size ) {
	return 90;
}

// Modify size of the Gravatar in the entry comments.
add_filter( 'genesis_comment_list_args', 'genesis_sample_comments_gravatar' );
function genesis_sample_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;

	return $args;

}

//Variable effect parallax
add_action( 'genesis_meta','parallax_variable' );
function parallax_variable(){
	$parallax1 = get_theme_mod('parallax_style_cb_1','none');
	echo "<script type='text/javascript'>var parallaxEffectName1 ='". $parallax1 ."';</script>";

	$parallax2 = get_theme_mod('parallax_style_cb_2','none');
	echo "<script type='text/javascript'>var parallaxEffectName2 ='". $parallax2 ."';</script>";

	$parallax3 = get_theme_mod('parallax_style_cb_3','none');
	echo "<script type='text/javascript'>var parallaxEffectName3 ='". $parallax3 ."';</script>";

	$parallax4 = get_theme_mod('parallax_style_cb_4','none');
	echo "<script type='text/javascript'>var parallaxEffectName4 ='". $parallax4 ."';</script>";

	$parallax5 = get_theme_mod('parallax_style_cb_5','none');
	echo "<script type='text/javascript'>var parallaxEffectName5 ='". $parallax5 ."';</script>";
}

//* Add Widget Spaces
require_once( get_stylesheet_directory() . '/lib/widgets.php' );

//* Install Plugins
require_once( get_stylesheet_directory() . '/lib/plugins/tgm-plugin-activation/register-plugins.php' );

//* Coding WAT Custom Loop
function wat_custom_loop() {
	if (function_exists('woocommerce')) {
		if ( is_product() )
			return;
	}
	elseif ( is_page() ) {
		if ( !is_page_template() )
			get_template_part('template-parts/content-page');
	} 
	elseif ( is_home() || is_front_page() ) {
		if ( get_theme_mod( 'homepage_blog_set','enable' ) == 'enable')
			get_template_part('template-parts/content-home');
		else
			return;
	}
	elseif ( is_single() )
		get_template_part('template-parts/content-single'); 
	else
		get_template_part('template-parts/content'); 
} 

//* Replace the standard loop Coding WAT Custom Loop
remove_action( 'genesis_loop', 'genesis_do_loop' );
add_action( 'genesis_loop', 'wat_custom_loop' );

// Post per page
add_action( 'pre_get_posts', 'wpa_tag_posts_per_page' );
function wpa_tag_posts_per_page( $query ) {
	if ( is_admin() )
		return;
	elseif( is_home() || is_front_page() )
		$query->set( 'posts_per_page', get_theme_mod('homepage_numpost_set') );
	elseif( is_category() )
		$query->set( 'posts_per_page', get_theme_mod('category_numpost_set') );
	elseif( is_archive() )
		$query->set( 'posts_per_page', get_theme_mod('archives_numpost_set') );
	else 
		$query->set( 'posts_per_page', 30 );
}

//* Remove Genesis Page Templates
function be_remove_genesis_page_templates( $page_templates ) {
	unset( $page_templates['page_archive.php'] );
	unset( $page_templates['page_blog.php'] );
	return $page_templates;
}
add_filter( 'theme_page_templates', 'be_remove_genesis_page_templates' );

//* Add Font Awesome Support
add_action( 'wp_enqueue_scripts', 'enqueue_font_awesome' );
function enqueue_font_awesome() {
	wp_enqueue_style( 'font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css' );
}

//* Remove various metaboxes of Genesis Theme Settings
add_action( 'genesis_admin_before_metaboxes', 'wpb_remove_unwanted_genesis_metaboxes' );
function wpb_remove_unwanted_genesis_metaboxes() {
	remove_meta_box( 'genesis-theme-settings-nav', 'toplevel_page_genesis', 'main' );
	remove_meta_box( 'genesis-theme-settings-posts', 'toplevel_page_genesis', 'main' );
	remove_meta_box( 'genesis-theme-settings-blogpage', 'toplevel_page_genesis', 'main' );
	remove_meta_box( 'genesis-theme-settings-header', 'toplevel_page_genesis', 'main' );
}

//* Unregister sidebars
unregister_sidebar( 'sidebar-alt' );
unregister_sidebar( 'header-right' );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );
genesis_unregister_layout( 'sidebar-content-sidebar' );

add_image_size( 'featured', 1400, 700, true );
add_image_size( 'square', 500, 500, true );
add_image_size( 'rectangle-1', 570, 380, true );
add_image_size( 'rectangle-2', 480, 710, true );

add_action( 'after_setup_theme', 'wat_setup' );
function wat_setup() {
	include("lib/functions/excerpt.php");
	include("lib/functions/pagination.php");
	include("lib/widgets/featured-post-widget.php");
}

//* Customize footer credit
add_filter( 'genesis_footer_creds_text', 'cb_footer_creds_text' );
function cb_footer_creds_text() {
	return get_theme_mod( 'copyright_set','COPYRIGHT © 2018 THEMENAME' ).' · THEME BY <a href="https://watdesignexpress.com/">WATDESIGNEXPRESS</a>';
}
// Reposition archives title
//remove_action( 'genesis_before_loop', 'genesis_do_taxonomy_title_description', 15 );
//add_action( 'genesis_before_content_sidebar_wrap', 'genesis_do_taxonomy_title_description' );

// Add ID to primary menu
add_filter( 'genesis_attr_nav-primary', 'themeprefix_primary_nav_id' );
function themeprefix_primary_nav_id( $attributes ) {
	 $attributes['id'] = 'main-menu';
	 return $attributes;
}
// Add ID to secondary menu
add_filter( 'genesis_attr_nav-secondary', 'themeprefix_secondary_nav_id' );
function themeprefix_secondary_nav_id( $attributes ) {
	 $attributes['id'] = 'sub-menu';
	 return $attributes;
}
// Add thumbnail, related to single post
add_action( 'genesis_before_content_sidebar_wrap','featured_img');
function featured_img() {
	if ( get_theme_mod('featured_img_set') == 'enable' ) {
		if( is_single() || is_page_template('templates/about.php') )
			the_post_thumbnail('featured', array('class' => 'aligncenter featured'));		
	}
}
add_action( 'genesis_after_content_sidebar_wrap','related_post');
function related_post() {
	if( is_single() )
		if ( function_exists( "get_yuzo_related_posts" ) ) { get_yuzo_related_posts(); }
}
//* Customize search form input button text
add_filter( 'genesis_search_button_text', 'sp_search_button_text' );
function sp_search_button_text( $text ) {
	return esc_attr( '&#xf105;' );
}
// Setup widget counts.
function custom_count_widgets( $id ) {
    global $sidebars_widgets;

    if ( isset( $sidebars_widgets[ $id ] ) ) {
        return count( $sidebars_widgets[ $id ] );
    }
}
// Set the widget class for flexible widgets.
function custom_widget_area_class( $id ) {
    $count = custom_count_widgets( $id );

    $class = '';

	if( $count == 1 ) {
		$class .= ' widget-full';
	} elseif( $count % 3 == 1 ) {
		$class .= ' widget-thirds';
	} elseif( $count % 4 == 1 ) {
		$class .= ' widget-fourths';
	} elseif( $count % 2 == 0 ) {
		$class .= ' widget-halves uneven';
	} else {	
		$class .= ' widget-halves even';
	}
	return $class;
}

 //Back to Top
add_action( 'genesis_header', 'cswp_genesis_to_top');
function cswp_genesis_to_top() {
	echo '<a href="#0" class="to-top" title="Back To Top"><span class="dashicons dashicons-arrow-up-alt2"></span></a>';
}
//* Hooks widget area category page
add_action( 'genesis_before_content', 'slider_category', 1  );
function slider_category() {
	if ( is_category() ) {
		genesis_widget_area( 'slider-category', array(
		'before' => '<div id="top-category" class="top-category">',
		'after'  => '</div>',
		) );
	}
}
//* Hooks widget area top left, right on page
add_action( 'genesis_before', 'wat_widget_top_page', 1  );
function wat_widget_top_page() {
	genesis_widget_area( 'top-page', array(
	'before' => '<div id="top-page" class="top-page"><div class="wrap">',
	'after'  => '</div></div>',
	) );
}

//Change search form text
function themeprefix_search_button_text( $text ) {
	return ( 'Search...');
}
add_filter( 'genesis_search_text', 'themeprefix_search_button_text' );