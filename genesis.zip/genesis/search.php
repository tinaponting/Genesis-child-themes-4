<?php
/**
* Genesis Framework.
*/
add_action( 'genesis_before_loop', 'genesis_do_search_title' );
/**
* Echo the title with the search term.
*/
function genesis_do_search_title() {
$title = sprintf( '<div class="archive-description"><h1 class="archive-title">%s %s</h1></div>', apply_filters( 'genesis_search_title_text', __( 'Search Results for:', 'genesis' ) ), get_search_query() );
echo apply_filters( 'genesis_search_title_output', $title ) . "\n";}genesis();