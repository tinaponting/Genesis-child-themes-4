<?php
/**
* Genesis Framework.
* @package Genesis\Assets
*/
/**
* Retrieve a handle to the script loader.
*/
function genesis_scripts() {static $_genesis_scripts = null;if ( null === $_genesis_scripts ) {
$_genesis_scripts = new Genesis_Script_Loader();$_genesis_scripts->add_hooks();}return $_genesis_scripts;}genesis_scripts();