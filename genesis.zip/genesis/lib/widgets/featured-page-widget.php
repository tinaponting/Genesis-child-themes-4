<?php
/**
* Genesis Framework.
*/
class Genesis_Featured_Page extends WP_Widget {
	/**
	* Holds widget settings defaults, populated in constructor.
	*/
	protected $defaults;
	/**
	* Constructor. Set the default widget options and create widget.
	*/
	public function __construct() {$this->defaults = ['title'=> '','page_id'=> '','show_image'=> 0,
	'image_alignment'=> '','image_size'=> '','show_title'=> 0,'show_content'=> 0,'content_limit'=> '','more_text'=> '',
	];
	$widget_ops = ['classname'=> 'featured-content featuredpage','description'=> __( 'Displays featured page with thumbnails', 'genesis' ),
	];
	$control_ops = ['id_base'=> 'featured-page','width'=> 200,'height'=> 250,
	];
	parent::__construct( 'featured-page', __( 'Genesis - Featured Page', 'genesis' ), $widget_ops, $control_ops );
	}
	/**
	* Echo the widget content.
	*/
	public function widget( $args, $instance ) {global $wp_query;$instance = wp_parse_args( (array) $instance, $this->defaults );
	echo $args['before_widget'];if ( ! empty( $instance['title'] ) ) {
	echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base ) . $args['after_title'];
	}
	$wp_query = new WP_Query(
	[
	'page_id'=> $instance['page_id'],
	]);
	if ( have_posts() ) {while ( have_posts() ) {the_post();genesis_markup(
	[
	'open'=> '<article %s>','context'=> 'entry','params'=> ['is_widget'=> true,
	],]);
	$image = genesis_get_image(
	[
	'format'=> 'html','size'=> $instance['image_size'],'context'=> 'featured-page-widget','attr'=> genesis_parse_attr( 'entry-image-widget', [] ),
	]);
	if ( $image && $instance['show_image'] ) {
	$role = empty( $instance['show_title'] ) ? '' : ' aria-hidden="true" tabindex="-1"';
	printf('<a href="%s" class="%s"%s>%s</a>',
	esc_url( get_permalink() ),
	esc_attr( $instance['image_alignment'] ),
	$role,
	$image
	);}
	if ( ! empty( $instance['show_title'] ) ) {$title = get_the_title() ?: __( '(no title)', 'genesis' );
	$title = apply_filters( 'genesis_featured_page_title', $title, $instance, $args );
	$heading = genesis_a11y( 'headings' ) ? 'h4' : 'h2';
	$entry_title = genesis_markup(
	[
	'open'=> "<{$heading} %s>",'close'=> "</{$heading}>",'context'=> 'entry-title','content'=> sprintf( '<a href="%s">%s</a>', get_permalink(), $title ),'params' => ['is_widget'=> true,'wrap'=> $heading,
	],
	'echo'=> false,
	]);
	genesis_markup(
	[
	'open'=> '<header %s>','close'=> '</header>','context'=> 'entry-header','content'=> $entry_title,'params'=> ['is_widget'=> true,
	],]);}
	if ( ! empty( $instance['show_content'] ) ) {
	genesis_markup(
	[
	'open'=> '<div %s>','context'=> 'entry-content','params'=> ['is_widget'=> true,
	],]);
	if ( empty( $instance['content_limit'] ) ) {
	global $more;
	$orig_more = $more;
	$more = 0;
	the_content( genesis_a11y_more_link( $instance['more_text'] ) );
	$more = $orig_more; 
	} else {the_content_limit( (int) $instance['content_limit'], genesis_a11y_more_link( esc_html( $instance['more_text'] ) ) );
	}
	genesis_markup(
	[
	'close'=> '</div>','context'=> 'entry-content','params'=> ['is_widget'=> true,
	],]);}
	genesis_markup(
	[
	'close'=> '</article>','context'=> 'entry','params'=> ['is_widget'=> true,
	],]);}}
	wp_reset_query(); echo $args['after_widget'];
	}
	/**
	* Update a particular instance.
	*/
	public function update( $new_instance, $old_instance ) {
	$new_instance['title'] = wp_strip_all_tags( $new_instance['title'] );
	$new_instance['more_text'] = wp_strip_all_tags( $new_instance['more_text'] );return $new_instance;
	}
	/**
	* Echo the settings update form.
	*/
	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, $this->defaults );
		?>
		<p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" class="widefat" />
		</p><p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'page_id' ) ); ?>"><?php esc_html_e( 'Page', 'genesis' ); ?>:</label>
		<?php
		wp_dropdown_pages(
		[
		'name'=> $this->get_field_name( 'page_id' ),'id'=> $this->get_field_id( 'page_id' ),'exclude'=> get_option( 'page_for_posts' ),'selected'=> $instance['page_id'],
		]);
		?>
		</p>
		<hr class="div" />
		<p>
		<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1"<?php checked( $instance['show_image'] ); ?> />
		<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php esc_html_e( 'Show Featured Image', 'genesis' ); ?></label>
		</p><p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'image_size' ) ); ?>"><?php esc_html_e( 'Image Size', 'genesis' ); ?>:</label>
		<select id="<?php echo esc_attr( $this->get_field_id( 'image_size' ) ); ?>" class="genesis-image-size-selector" name="<?php echo esc_attr( $this->get_field_name( 'image_size' ) ); ?>">
		<?php
		$sizes = genesis_get_image_sizes();
		foreach ( $sizes as $name => $size ) {echo '<option value="' . esc_attr( $name ) . '" ' . selected( $name, $instance['image_size'], false ) . '>' . esc_html( $name ) . ' (' . absint( $size['width'] ) . 'x' . absint( $size['height'] ) . ')</option>';
		}
		?>
		</select>
		</p><p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'image_alignment' ) ); ?>"><?php esc_html_e( 'Image Alignment', 'genesis' ); ?>:</label>
		<select id="<?php echo esc_attr( $this->get_field_id( 'image_alignment' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'image_alignment' ) ); ?>">
		<option value="alignnone">- <?php esc_html_e( 'None', 'genesis' ); ?> -</option>
		<option value="alignleft" <?php selected( 'alignleft', $instance['image_alignment'] ); ?>><?php esc_html_e( 'Left', 'genesis' ); ?></option>
		<option value="alignright" <?php selected( 'alignright', $instance['image_alignment'] ); ?>><?php esc_html_e( 'Right', 'genesis' ); ?></option>
		<option value="aligncenter" <?php selected( 'aligncenter', $instance['image_alignment'] ); ?>><?php esc_html_e( 'Center', 'genesis' ); ?></option>
		</select>
		</p>
		<hr class="div" />
		<p>
		<input id="<?php echo esc_attr( $this->get_field_id( 'show_title' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_title' ) ); ?>" value="1"<?php checked( $instance['show_title'] ); ?> />
		<label for="<?php echo esc_attr( $this->get_field_id( 'show_title' ) ); ?>"><?php esc_html_e( 'Show Page Title', 'genesis' ); ?></label>
		</p><p>
		<input id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>" value="1"<?php checked( $instance['show_content'] ); ?> />
		<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php esc_html_e( 'Show Page Content', 'genesis' ); ?></label>
		</p><p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php esc_html_e( 'Content Character Limit', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( $instance['content_limit'] ); ?>" size="3" />
		</p><p>
		<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php esc_html_e( 'More Text', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
		</p>
		<?php
	}}