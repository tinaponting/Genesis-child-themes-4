<?php
/**
* Genesis Framework.
*/
add_action( 'widgets_init', 'genesis_handle_block_widget_editor' );
/**
* Default the block-based widget editor to be disabled, which is defaulted to be enabled in WP 5.8.
*/
function genesis_handle_block_widget_editor() {add_filter( 'use_widgets_block_editor', '__return_false', 0 );
}
add_action( 'admin_init', 'genesis_handle_dismissing_block_widget_editor_notice' );
/**
* Handle dismissing the admin notice for the block widget editor optin.
*/
function genesis_handle_dismissing_block_widget_editor_notice() {
if ( filter_input( INPUT_GET, 'genesis_widget_block_editor_dismiss', FILTER_SANITIZE_STRING ) !== '1' ) {return;
}
if ( ! isset( $_GET['_wpnonce'] ) ) {return;
}
if ( ! wp_verify_nonce( filter_input( INPUT_GET, '_wpnonce', FILTER_SANITIZE_STRING ), 'genesis-widget-block-editor-dismiss' ) ) {return;
}
if ( ! current_user_can( 'administrator' ) ) {return;
}
update_option( 'genesis_notice_dismissed_use_widgets_block_editor', true );
}
add_action( 'admin_notices', 'genesis_block_widgets_optin_notification' );
/**
* Show an admin notice on the widgets screen informing the user how to opt-in to block widgets.
*/
function genesis_block_widgets_optin_notification() {$current_screen = get_current_screen();if ( 'widgets' !== $current_screen->id ) {return;
	}
	if ( ! current_user_can( 'administrator' ) ) {return;
	}
	if ( get_option( 'genesis_notice_dismissed_use_widgets_block_editor' ) ) {return;
	}
	require ABSPATH . WPINC . '/version.php'; if ( version_compare( $wp_version, '5.8-RC1-51325', '<' ) ) {return false;
	}
	?>
	<div class="notice notice-success">
	<p>
	<?php
	echo wp_kses_post(
	sprintf(
	__( 'Note from Genesis: To maintain the best site editing experience for you, we\'ve disabled the widget screen introduced in WordPress 5.8. To learn more about the 5.8 widget experience and how to activate it, click the following link: %1$sLearn more%2$s %3$sDismiss%4$s', 'genesis' ),
	'<p><a href="https://my.studiopress.com/documentation/snippets/block-editor/enable-block-based-widget-editor" target="_blank" rel="noopener noreferrer" class="button">',
	'</a>',
	'<a href="' . wp_nonce_url( add_query_arg( [ 'genesis_widget_block_editor_dismiss' => 1 ], admin_url( 'widgets.php' ) ), 'genesis-widget-block-editor-dismiss' ) . '" rel="noopener noreferrer" class="button">',
	'</a></p>'
	));
	?>
	</p>
	</div>
	<?php
}
add_action( 'widgets_init', 'genesis_load_widgets' );
/**
* Register widgets for use in the Genesis theme.
*/
function genesis_load_widgets() {register_widget( 'Genesis_Featured_Page' );register_widget( 'Genesis_Featured_Post' );register_widget( 'Genesis_User_Profile_Widget' );
}
add_action( 'load-themes.php', 'genesis_remove_default_widgets_from_header_right' );
/**
  Temporary function to work around the default widgets that get added to
* Header Right when switching themes.
*/
function genesis_remove_default_widgets_from_header_right() {if ( ! isset( $_REQUEST['activated'] ) || 'true' !== $_REQUEST['activated'] ) { return;
	}
	$widgets = get_option( 'sidebars_widgets' );
	$defaults = [0 => 'search-2',1 => 'recent-posts-2',2 => 'recent-comments-2',3 => 'archives-2',4 => 'categories-2',5 => 'meta-2',
	];
	if ( isset( $widgets['header-right'] ) && $defaults === $widgets['header-right'] ) {$widgets['header-right'] = [];update_option( 'sidebars_widgets', $widgets );
	}}