<?php
/**
* Genesis Framework.
*/
/**
* Handle for Genesis_Admin_Meta_Boxes class.
*/
function genesis_meta_boxes() {static $meta_boxes = null;if ( null === $meta_boxes ) {$meta_boxes = new Genesis_Admin_Meta_Boxes();}return $meta_boxes;
}