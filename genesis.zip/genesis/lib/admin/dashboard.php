<?php
/**
* Genesis Framework.
*/
add_filter( 'update_right_now_text', 'genesis_update_right_now_text' );
/**
* Callback to amend the Right Now text, found in the At A Glance dashboard widget.
*/
function genesis_update_right_now_text( $content ){$string = sprintf(
esc_html__(' Using Genesis %s.','genesis'),
PARENT_THEME_VERSION);return $content . $string;
}