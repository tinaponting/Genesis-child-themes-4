<?php
/**
* Genesis Framework.
*/
add_action( 'admin_notices', 'genesis_use_child_theme_notice' );
/**
* Display Warning that Genesis should always be used with a child theme.
*/
function genesis_use_child_theme_notice() {if ( is_child_theme() ) {return;
}
$allowed_html = ['a'=> ['href'=> [],
],];
include GENESIS_VIEWS_DIR . '/misc/use-child-theme-notice.php';
}