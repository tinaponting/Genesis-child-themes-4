<?php
/**
* Genesis Framework.
*/
add_action( 'show_user_profile', 'genesis_user_options_fields' );
add_action( 'edit_user_profile', 'genesis_user_options_fields' );
/**
* Add fields for user permissions for Genesis features to the user edit screen.
*/
function genesis_user_options_fields( $user ) {
if ( current_user_can( 'edit_users', $user->ID ) ) {genesis_meta_boxes()->show_meta_box( 'genesis-user-settings', $user );
}}
add_action( 'show_user_profile', 'genesis_user_archive_fields' );
add_action( 'edit_user_profile', 'genesis_user_archive_fields' );
/**
* Add fields for author archives contents to the user edit screen.
*/
function genesis_user_archive_fields( $user ) {
if ( current_user_can( 'edit_users', $user->ID ) ) {genesis_meta_boxes()->show_meta_box( 'genesis-user-author', $user );
}}
add_action( 'show_user_profile', 'genesis_user_seo_fields' );
add_action( 'edit_user_profile', 'genesis_user_seo_fields' );
/**
* Add fields for author archive SEO to the user edit screen.
*/
function genesis_user_seo_fields( $user ) {if ( current_user_can( 'edit_users', $user->ID ) ) {genesis_meta_boxes()->show_meta_box( 'genesis-user-seo', $user );
}}
add_action( 'show_user_profile', 'genesis_user_layout_fields' );
add_action( 'edit_user_profile', 'genesis_user_layout_fields' );
/**
 * Add author archive layout selector to the user edit screen.
 */
function genesis_user_layout_fields( $user ) {
	if ( ! current_theme_supports( 'genesis-archive-layouts' ) || ! genesis_has_multiple_layouts() ) {return;
	}
	if ( current_user_can( 'edit_users', $user->ID ) ) {genesis_meta_boxes()->show_meta_box( 'genesis-user-layout', $user );
	}}
add_action( 'personal_options_update', 'genesis_user_meta_save' );
add_action( 'edit_user_profile_update', 'genesis_user_meta_save' );
/**
 * Update user meta when user edit page is saved.
 */
function genesis_user_meta_save( $user_id ) {if ( ! current_user_can( 'edit_users', $user_id ) ) {return;
	}
	if ( ! isset( $_POST['genesis-meta'] ) || ! is_array( $_POST['genesis-meta'] ) ) {return;
	}
	$defaults = [
	'genesis_admin_menu'=> '',
	'genesis_seo_settings_menu'=> '',
	'genesis_import_export_menu'=> '',
	'genesis_author_box_single'=> '',
	'genesis_author_box_archive'=> '',
	'headline'=> '',
	'intro_text'=> '',
	'doctitle'=> '',
	'meta_description'=> '',
	'meta_keywords'=> '',
	'noindex'=> '',
	'nofollow'=> '',
	'noarchive'=> '',
	'layout'=> '',
	];
	/**
	* Filter the user meta defaults array.
	* @param array $defaults Default user meta array.
	*/
	$defaults = apply_filters( 'genesis_user_meta_defaults', $defaults );
	$meta = wp_parse_args( $_POST['genesis-meta'], $defaults );
	$meta['headline'] = wp_strip_all_tags( $meta['headline'] );
	$meta['intro_text'] = current_user_can( 'unfiltered_html' ) ? $meta['intro_text'] : genesis_formatting_kses( $meta['intro_text'] );
	foreach ( $meta as $key => $value ) {update_user_meta( $user_id, $key, $value );
	}}
add_filter( 'get_the_author_genesis_admin_menu', 'genesis_user_meta_default_on', 10, 2 );
add_filter( 'get_the_author_genesis_seo_settings_menu', 'genesis_user_meta_default_on', 10, 2 );
add_filter( 'get_the_author_genesis_import_export_menu', 'genesis_user_meta_default_on', 10, 2 );
/**
 * Check to see if user data has actually been saved, or if defaults need to be forced.
 */
function genesis_user_meta_default_on( $value, $user_id ) {if ( $value ) {return $value;
	}
	$field = str_replace( 'get_the_author_', '', current_filter() );
	if ( ! $user_id ) {global $authordata;} else {$authordata = get_userdata( $user_id );
	}
	$user_field = "user_$field";if ( isset( $authordata->$user_field ) ) {return $authordata->user_field;
	}
	if ( isset( $authordata->$field ) ) {return $value;}return 1;
}
add_filter( 'get_the_author_genesis_author_box_single', 'genesis_author_box_single_default_on', 10, 2 );
/**
* Conditionally force a default 1 value for each users' author box setting.
*/
function genesis_author_box_single_default_on( $value, $user_id ) {
if ( genesis_get_option( 'author_box_single' ) ) {return genesis_user_meta_default_on( $value, $user_id );}return $value;
}