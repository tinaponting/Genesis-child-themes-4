<?php
/**
* Genesis Framework.
*/
add_action( 'admin_menu', 'genesis_add_inpost_seo_box' );
/**
* Register a new meta box to the post or page edit screen, so that the user can set SEO options on a per-post or
* per-page basis.
*/
function genesis_add_inpost_seo_box() {foreach ( (array) get_post_types(
	[
	'public'=> true,
	]
	) as $type ) {if ( post_type_supports( $type, 'genesis-seo' ) ) {
	add_meta_box( 'genesis_inpost_seo_box', __( 'Theme SEO Settings', 'genesis' ), 'genesis_inpost_seo_box', $type, 'normal', 'high' );
	}}
	add_action( 'load-post.php', 'genesis_seo_contextual_help' );add_action( 'load-post-new.php', 'genesis_seo_contextual_help' );
}
/**
* Callback for in-post SEO meta box.
*/
function genesis_inpost_seo_box() {genesis_meta_boxes()->show_meta_box( 'genesis-inpost-seo-box' );
}
/**
* Callback for in-post SEO meta box contextual help.
*/
function genesis_seo_contextual_help() {global $typenow;
	if ( post_type_supports( $typenow, 'genesis-seo' ) ) {
	genesis_meta_boxes()->add_help_tab( 'genesis-inpost-seo', __( 'Theme SEO Settings', 'genesis' ) );
	}}

add_action( 'save_post', 'genesis_inpost_seo_save', 1, 2 );
/**
* Save the SEO settings when we save a post or page.
*/
function genesis_inpost_seo_save( $post_id, $post ) {
	if ( ! isset( $_POST['genesis_seo'] ) ) {return;
	}
	$data = wp_parse_args($_POST['genesis_seo'],
	[
	'_genesis_title'=> '',
	'_genesis_description'=> '',
	'_genesis_keywords'=> '',
	'_genesis_canonical_uri'=> '',
	'redirect'=> '',
	'_genesis_noindex'=> 0,
	'_genesis_nofollow'=> 0,
	'_genesis_noarchive'=> 0,
	]);
	foreach ( $data as $key => $value ) {
	if ( in_array( $key, [ '_genesis_title', '_genesis_description', '_genesis_keywords' ], true ) ) {$data[ $key ] = wp_strip_all_tags( $value );
	}}
	genesis_save_custom_fields( $data, 'genesis_inpost_seo_save', 'genesis_inpost_seo_nonce', $post );
}
add_action( 'admin_menu', 'genesis_add_inpost_scripts_box' );
/**
* Register a new meta box to the post or page edit screen, so that the user can apply scripts on a per-post or
* per-page basis.
*/
function genesis_add_inpost_scripts_box() {
	if ( ! current_user_can( 'unfiltered_html' ) ) {return;
	}
	foreach ( (array) get_post_types(
	[
	'public'=> true,
	]
	) as $type ) {if ( post_type_supports( $type, 'genesis-scripts' ) ) {
	add_meta_box( 'genesis_inpost_scripts_box', __( 'Scripts', 'genesis' ), 'genesis_inpost_scripts_box', $type, 'normal', 'low' );
	}}}

/**
* Callback for in-post Scripts meta box.
*/
function genesis_inpost_scripts_box() {genesis_meta_boxes()->show_meta_box( 'genesis-inpost-scripts-box' );

}
add_action( 'save_post', 'genesis_inpost_scripts_save', 1, 2 );
/**
* Save the Scripts settings when we save a post or page.
*/
function genesis_inpost_scripts_save( $post_id, $post ) {if ( ! isset( $_POST['genesis_seo'] ) ) {return;
	}
	if ( ! current_user_can( 'unfiltered_html' ) ) {return;
	}
	$data = wp_parse_args($_POST['genesis_seo'],
	[
	'_genesis_scripts'=> '',
	'_genesis_scripts_body'=> '',
	'_genesis_scripts_body_position'=> '',
	]);
	genesis_save_custom_fields( $data, 'genesis_inpost_scripts_save', 'genesis_inpost_scripts_nonce', $post );
}
add_action( 'add_meta_boxes', 'genesis_add_inpost_layout_box', 10, 2 );
/**
* Register a new meta box to the post or page edit screen, so that the user can set layout options on a per-post or
* per-page basis.
*/
function genesis_add_inpost_layout_box( $post_type, $post ) {if ( ! current_theme_supports( 'genesis-inpost-layouts' ) ) {return;
	}
	$current_screen = get_current_screen();
	if (method_exists( $current_screen, 'is_block_editor' ) && $current_screen->is_block_editor() && post_type_supports( $post_type, 'custom-fields' )){ return;
	}
	foreach ( (array) get_post_types(
	[
	'public' => true,
	]
	) as $type ) {if ( post_type_supports( $type, 'genesis-layouts' ) ) {
	add_meta_box( 'genesis_inpost_layout_box', __( 'Layout Settings', 'genesis' ), 'genesis_inpost_layout_box', $type, 'normal', 'high' );
	}}}

/**
* Callback for in-post layout meta box.
*/
function genesis_inpost_layout_box() {genesis_meta_boxes()->show_meta_box( 'genesis-inpost-layout-box' );
}
add_action( 'save_post', 'genesis_inpost_layout_save', 1, 2 );
/**
* Save the layout options when we save a post or page.
*/
function genesis_inpost_layout_save( $post_id, $post ) {if ( ! isset( $_POST['genesis_layout'] ) ) {return;
	}
	$data = wp_parse_args($_POST['genesis_layout'],
	[
	'_genesis_layout'=> '',
	'_genesis_custom_body_class'=> '',
	'_genesis_post_class'=> '',
	]);
	$data = array_map( 'genesis_sanitize_html_classes', $data );
	genesis_save_custom_fields( $data, 'genesis_inpost_layout_save', 'genesis_inpost_layout_nonce', $post );
}