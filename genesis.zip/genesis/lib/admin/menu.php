<?php
/**
* Genesis Framework.
*/
/**
* Fires before admin menu items are registered.
*/
do_action( 'genesis_admin_init' );
add_action( 'after_setup_theme', 'genesis_add_admin_menu' );
/**
  Add Genesis top-level item in admin menu.
*/
function genesis_add_admin_menu() {
	if ( ! is_admin() ) {return;}
	global $_genesis_admin_settings;if ( ! current_theme_supports( 'genesis-admin-menu' ) ) {return;
	}
	$user = wp_get_current_user();if ( ! get_the_author_meta( 'genesis_admin_menu', $user->ID ) ) {return;
	}
	$_genesis_admin_settings = new Genesis_Admin_Settings();
	global $_genesis_theme_settings_pagehook;$_genesis_theme_settings_pagehook = $_genesis_admin_settings->pagehook;
	/**
	* Fires after Genesis top-level menu item has been registered.
	*/
	do_action( 'genesis_admin_menu' );
}
add_action( 'genesis_admin_menu', 'genesis_add_admin_submenus' );
/**
* Add submenu items under Genesis item in admin menu.
*/
function genesis_add_admin_submenus() {if ( ! is_admin() ) {return;
	}
	global $_genesis_admin_seo_settings, $_genesis_admin_import_export;if ( ! current_theme_supports( 'genesis-admin-menu' ) ) {return;
	}
	$user = wp_get_current_user();if ( current_theme_supports( 'genesis-seo-settings-menu' ) && get_the_author_meta( 'genesis_seo_settings_menu', $user->ID ) ) {
	$_genesis_admin_seo_settings = new Genesis_Admin_SEO_Settings();
	global $_genesis_seo_settings_pagehook;$_genesis_seo_settings_pagehook = $_genesis_admin_seo_settings->pagehook;
	}
	if ( current_theme_supports( 'genesis-import-export-menu' ) && get_the_author_meta( 'genesis_import_export_menu', $user->ID ) ) {$_genesis_admin_import_export = new Genesis_Admin_Import_Export();
	}
	new Genesis_Admin_Upgraded();if ( version_compare( $GLOBALS['wp_version'], '5.0', '>=' ) && is_readable( locate_template( '/config/onboarding.php' ) ) ) {new Genesis_Admin_Onboarding();
	}}
add_action( 'admin_menu', 'genesis_add_cpt_archive_page', 5 );
/**
* Add archive settings page to relevant custom post type registrations.
*/
function genesis_add_cpt_archive_page() {
	$post_types = genesis_get_cpt_archive_types();
	foreach ( $post_types as $post_type ) {
	if ( genesis_has_post_type_archive_support( $post_type->name ) ) {
	$admin_object_name = '_genesis_admin_cpt_archives_' . $post_type->name;
	global ${$admin_object_name};
	${$admin_object_name} = new Genesis_Admin_CPT_Archive_Settings( $post_type );
	}}}