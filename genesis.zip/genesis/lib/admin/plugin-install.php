<?php
/**
* Genesis Framework.
*/
add_filter( 'plugins_api_result', 'genesis_admin_plugins_api_result', 10, 3 );
function genesis_admin_plugins_api_result( $res, $action, $args ) {
	if ( isset( $args->author ) && 'studiopress' === $args->author ) {
	usort( $res->plugins, 'genesis_admin_plugins_sort_callback' );
	foreach ( $res->plugins as $key => $plugin ) {$plugin_data = (array) $plugin;
	if ( 'atomic-blocks' === $plugin_data['slug'] ) {unset( $res->plugins[ $key ] );array_unshift( $res->plugins, $plugin );}}}return $res;
}
/**
* Sort Genesis plugins returned by plugins api by install count.
*/
function genesis_admin_plugins_sort_callback( $a, $b ) {$a = (array) $a;$b = (array) $b;if ( $a['active_installs'] === $b['active_installs'] ) {return 0;}return $a['active_installs'] > $b['active_installs'] ? -1 : 1;
}