<?php
/**
* Genesis Framework.
*/
/**
* Registers an option sanitization filter.
*/
function genesis_add_option_filter( $filter, $option, $suboption = null ) {return Genesis_Settings_Sanitizer::$instance->add_filter( $filter, $option, $suboption );
}
add_action( 'admin_init', 'genesis_settings_sanitizer_init' );
/**
* Instantiate the Sanitizer.
*/
function genesis_settings_sanitizer_init() {new Genesis_Settings_Sanitizer( new Genesis_Sanitizer() );
}