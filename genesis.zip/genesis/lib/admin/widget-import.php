<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Admin\WidgetImport;
/**
* Inserts a widget into the named sidebar by updating the `wp_options` table.
*/
function insert_widget( $sidebar, $type, $args = [] ) {if ( empty( $args ) ) {return;
	}
	$widgets = get_option( "widget_{$type}" );if ( ! $widgets ) {$widgets = [ '_multiwidget'=> 1 ];
	}
	$next_widget_id = get_next_widget_id( $widgets );
	$widgets[ $next_widget_id ] = $args;
	update_option( "widget_{$type}", $widgets );
	$sidebars = get_option( 'sidebars_widgets', [] );
	$sidebars[ $sidebar ][] = "{$type}-{$next_widget_id}";update_option( 'sidebars_widgets', $sidebars );
}
/**
* Clears widgets from named widget areas, moving widgets they contain
* to the 'Inactive Widgets' area.
*/
function clear_widget_areas( $areas = [] ) {
	$sidebars = get_option( 'sidebars_widgets', [] );
	foreach ( $areas as $area ) {if ( ! isset( $sidebars[ $area ] ) ) {continue;
	}
	if ( 'wp_inactive_widgets' === $area ) {continue;
	}
	$sidebars['wp_inactive_widgets'] = array_merge($sidebars['wp_inactive_widgets'],$sidebars[ $area ]
	);
	unset( $sidebars[ $area ] );
	}
	update_option( 'sidebars_widgets', $sidebars );
}
/**
* Gets the next widget ID for widgets of a given type.
*/
function get_next_widget_id( $widgets ) {
	$widgets = array_filter( $widgets, 'is_numeric', ARRAY_FILTER_USE_KEY );
	if ( ! $widgets ) {return 1;
	}
	ksort( $widgets ); end( $widgets ); return key( $widgets ) + 1;
}
/**
* Swaps placeholder strings representing an imported post with the post's ID.
*/
function swap_placeholders( $widget_arguments, $imported_posts ) {
	foreach ( $widget_arguments as $key => $value ) {if ( ! is_string( $value ) ) {continue;
	}
	if ( false === strpos( $value, '$imported_posts_' ) ) {continue;
	}
	$post_slug = str_replace( '$imported_posts_', '', trim( $value ) );
	if ( isset( $imported_posts[ $post_slug ] ) ) {$widget_arguments[ $key ] = $imported_posts[ $post_slug ];
	} else {$widget_arguments[ $key ] = '';}}return $widget_arguments;
}