<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Admin\AutoUpdateNotices;
add_filter( 'theme_auto_update_setting_template', __NAMESPACE__ . '\\setting_template' );
/**
* Alters the update notice shown with theme information.
*/
function setting_template( $original_template ) {
	$genesis_update_html = sprintf(__( 'Enable update checks in <a href="%s">Genesis update settings</a>.', 'genesis' ),admin_url( 'customize.php?autofocus[section]=genesis_updates' )
	);
	$child_theme_update_text = __( 'Auto-updates are not available for this theme.', 'genesis' );
	return "<# if ( 'genesis' === data.id ) { #>
	<p>$genesis_update_html</p>
	<# } else if ( 'Genesis' === data.parent ) { #>
	<p>$child_theme_update_text</p>
	<# } else { #>
	$original_template
	<# } #>";
}
add_filter( 'theme_auto_update_debug_string', __NAMESPACE__ . '\\debug_string', 10, 2 );
/**
* Alters auto-update notice debug text, such as on the Site Health page.
*/
function debug_string( $notice, $theme ) {
	if ( 'Genesis' === $theme->name ) {return __( 'Enable update checks at Appearance → Customize → Theme Settings → Updates.', 'genesis' );
	}
	if ( 'genesis' === $theme->template ) {return __( 'Auto-updates are not available for this theme.', 'genesis' );}return $notice;
}
add_filter( 'theme_auto_update_setting_html', __NAMESPACE__ . '\\setting_html', 10, 3 );
/**
* Alters auto-update notice text in the theme updates listing,
* visible on WordPress multisite.
*/
function setting_html( $html, $stylesheet, $theme ) {return \StudioPress\Genesis\Admin\AutoUpdateNotices\debug_string( $html, $theme );
}