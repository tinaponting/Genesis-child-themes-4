<?php
/**
* Genesis Framework.
*/
add_action( 'customize_register', 'genesis_customize_register' );
/**
* Include, instantiate, and initialize the Genesis Customizer object.
*/
function genesis_customize_register( WP_Customize_Manager $wp_customize ) {
$genesis_customizer = new Genesis_Customizer( $wp_customize );$genesis_customizer->init();

}
add_action( 'genesis_customizer', 'genesis_customizer_theme_settings' );
/**
* Build the Theme Settings Customizer panels, sections, and controls.
*/
function genesis_customizer_theme_settings( Genesis_Customizer $genesis_customizer ) {
	$config = genesis_get_config( 'customizer-theme-settings' );
	$config = apply_filters( 'genesis_customizer_theme_settings_config', $config );$genesis_customizer->register( $config );
}
add_action( 'genesis_customizer', 'genesis_customizer_seo_settings' );
/**
*/
function genesis_customizer_seo_settings( Genesis_Customizer $genesis_customizer ) {
	$config = genesis_get_config( 'customizer-seo-settings' );
	$config = apply_filters( 'genesis_customizer_seo_settings_config', $config );$genesis_customizer->register( $config );
}
/**
* Return array of color scheme choices for the Customizer.
*/
function genesis_get_color_schemes_for_customizer() {if ( ! genesis_has_color_schemes() ) {return [];
	}
	$color_schemes = get_theme_support( 'genesis-style-selector' );return array_merge([ '' => __( 'Default', 'genesis' ) ],array_shift( $color_schemes )
	);}
/**
* Return true if color schemes are registered.
*/
function genesis_has_color_schemes() {if ( ! current_theme_supports( 'genesis-style-selector' ) ) {return false;
}
$schemes = get_theme_support( 'genesis-style-selector' );return is_array( $schemes ) && count( $schemes[0] ) >= 1;
}
/**
* Return true if Header section in Customizer -> Theme Settings should be shown.
*/
function genesis_show_header_customizer_callback() {return ! current_theme_supports( 'genesis-custom-header' ) && ! current_theme_supports( 'custom-header' ) && ! current_theme_supports( 'genesis-custom-logo' );
}
/**
* Return true if user has chosen to show posts on the front page.
*/
function genesis_posts_show_on_front() {return 'posts' === get_option( 'show_on_front' );
}
/**
* Return true if user has chosen to show a static page on the front page.
*/
function genesis_page_show_on_front() {return 'page' === get_option( 'show_on_front' );
}
add_filter( 'genesis_customizer_theme_settings_config', 'genesis_add_singular_image_output_customizer_checkboxes' );
/**
* Return the config that includes the genesis_single controls.
*/
function genesis_add_singular_image_output_customizer_checkboxes( $config ) {
	if ( ! isset( $config['genesis']['sections']['genesis_single'] ) ) {return $config;
	}
	$types_with_singular_images_support = get_post_types_by_support( 'genesis-singular-images' );
	$new_controls = [];
	if ( isset( $config['genesis']['sections']['genesis_single']['controls'] ) ) {$orig_controls = $config['genesis']['sections']['genesis_single']['controls'];
	}
	foreach ( $types_with_singular_images_support as $type ) {if ( ! post_type_exists( $type ) ) {continue;
	}
	$post_type = get_post_type_object( $type );$new_controls[ "show_featured_image_${type}" ] = [
	'label'=> sprintf( __( 'Show Featured Images on %s', 'genesis' ), $post_type->label ),
	'section'=> 'genesis_single',
	'type'=> 'checkbox',
	'settings'=> ['default'=> 0,
	],];}
	$config['genesis']['sections']['genesis_single']['controls'] = $new_controls + $orig_controls;return $config;
}