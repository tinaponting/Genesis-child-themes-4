<?php
/**
* Genesis Framework.
*/
add_filter( 'wp_privacy_personal_data_erasers', 'genesis_privacy_personal_data_erasers' );
/**
* Registers personal data eraser callbacks.
*/
function genesis_privacy_personal_data_erasers( array $erasers ) {
	$erasers['genesis_author_archives'] = [
	'eraser_friendly_name'=> __( 'Genesis Author Archive Data', 'genesis' ),
	'callback'=> 'genesis_erase_author_archive_info',
	];
	$erasers['genesis_update_email_address'] = [
	'eraser_friendly_name'=> __( 'Update Notification Email Address', 'genesis' ),
	'callback'=> 'genesis_erase_update_notification_email_address',];return $erasers;
}
/**
* Erases Author Archive Settings data saved in user meta.
*/
function genesis_erase_author_archive_info( $email_address ) {
	$response = ['items_removed'=> false,'items_retained'=> false,'messages'=> [],'done'=> true,
	];
	if ( empty( $email_address ) ) {return $response;
	}
	$user = get_user_by( 'email', $email_address );if ( empty( $user ) ) {return $response;
	}
	foreach ( genesis_get_author_archive_fields() as $key => $name ) {if ( '' === get_user_meta( $user->ID, $key, true ) ) {continue;
	}
	if ( delete_user_meta( $user->ID, $key ) ) {$response['items_removed'] = true;$response['messages'][] = $name;
	} else {$response['messages'][] = sprintf( __( 'Your %s data was unable to be removed at this time.', 'genesis' ), $name );$response['items_retained'] = true;}}return $response;
}
/**
* Erases the Update Notification email address if it matches the given email address.
*/
function genesis_erase_update_notification_email_address( $email_address ) {
	$response = ['items_removed'=> false,'items_retained'=> false,'messages'=> [],'done'=> true,
	];
	if ( strtolower( genesis_get_option( 'update_email_address' ) ) === strtolower( $email_address ) ) {
	genesis_update_settings( [ 'update_email_address' => 'unset' ] );
	$response['items_removed'] = true;
	$response['messages'][] = __( 'Update Notification Email Address removed.', 'genesis' );}return $response;
}
add_filter( 'wp_privacy_personal_data_exporters', 'genesis_privacy_personal_data_exporters' );
/**
* Registers personal data exporter callbacks.
*/
function genesis_privacy_personal_data_exporters( array $exporters ) {
	$exporters['genesis_author_archives'] = [
	'exporter_friendly_name'=> __( 'Genesis Author Archive Data', 'genesis' ),
	'callback'=> 'genesis_export_author_archive_info',];return $exporters;
}
/**
* Exports Author Archive Settings data saved in user meta.
*/
function genesis_export_author_archive_info( $email_address ) {
	$email_address = trim( $email_address );
	$export_data = [];
	$user = get_user_by( 'email', $email_address );
	if ( ! $user ) {return ['data'=> $export_data,'done'=> true,
	];}
	foreach ( genesis_get_author_archive_fields() as $key => $name ) {
	$user_meta_export = [];
	$export_value = get_user_meta( $user->ID, $key, true );
	if ( empty( $export_value ) ) {continue;
	}
	$user_meta_export[] = ['name'=> $name,'value'=> $export_value,
	];
	$export_data[] = [
	'group_id'=> 'genesis_author_archive_info',
	'group_label'=> __( 'Genesis Author Archive Data', 'genesis' ),
	'item_id'=> "user-{$user->ID}",
	'data'=> $user_meta_export,];}return ['data'=> $export_data,'done'=> true,
	];}
/**
* Returns an array of Author Archive fields.
*/
function genesis_get_author_archive_fields() {return [
'headline'=> __( 'Custom Archive Headline', 'genesis' ),
'intro_text'=> __( 'Custom Description Text', 'genesis' ),
'doctitle'=> __( 'Custom Document Title', 'genesis' ),
'meta_description'=> __( 'Meta Description', 'genesis' ),
'meta_keywords'=> __( 'Meta Keywords', 'genesis' ),
];}