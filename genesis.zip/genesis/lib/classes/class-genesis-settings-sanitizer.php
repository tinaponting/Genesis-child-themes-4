<?php
/**
* Genesis Framework.
*/
class Genesis_Settings_Sanitizer {
	/**
	* Hold instance of self so methods can be accessed statically.
	*/
	public static $instance;
	/**
	* The sanitizer object..
	*/
	public $sanitizer;
	/**
	* Holds list of all options as array.
	*/
	public $options = [];
	/**
	* Constructor.
	*/
	public function __construct( Genesis_Sanitizer $sanitizer ) {self::$instance =& $this;$this->sanitizer = $sanitizer;
	/**
	* Fires when Genesis_Settings_Sanitizer is initialized.
	*/
	do_action_ref_array( 'genesis_settings_sanitizer_init', [ &$this ] );
	}
	/**
	* Add sanitization filters to options.
	*/
	public function add_filter( $filter, $option, $suboption = null ) {
	if ( is_array( $suboption ) ) {foreach ( $suboption as $so ) {$this->options[ $option ][ $so ] = $filter;
	}
	} elseif ( null === $suboption ) {$this->options[ $option ] = $filter;
	} else {$this->options[ $option ][ $suboption ] = $filter;
	}
	add_filter( 'sanitize_option_' . $option, [ $this, 'sanitize' ], 10, 2 );return true;
	}
	/**
	* Checks sanitization filter exists, and if so, passes the value through it.
	*/
	public function do_filter( $filter, $new_value, $old_value ) {$available_filters = $this->get_available_filters();
	if ( ! array_key_exists( $filter, $available_filters ) ) {
	return $new_value;}return call_user_func( $available_filters[ $filter ], $new_value, $old_value );
	}
	/**
	* Return array of known sanitization filter types.
	*/
	public function get_available_filters() {$default_filters = [
	'one_zero'=> [ $this->sanitizer, 'one_zero' ],
	'no_html'=> [ $this->sanitizer, 'no_html' ],
	'absint'=> [ $this->sanitizer, 'absint' ],
	'safe_html'=> [ $this->sanitizer, 'safe_html' ],
	'requires_unfiltered_html'=> [ $this->sanitizer, 'requires_unfiltered_html' ],
	'unfiltered_or_safe_html'=> [ $this->sanitizer, 'unfiltered_or_safe_html' ],
	'url'=> [ $this->sanitizer, 'url' ],
	'email_address'=> [ $this->sanitizer, 'email_address' ],
	];
	/**
	* Filter the available sanitization filter types.
	*/
	return apply_filters( 'genesis_available_sanitizer_filters', $default_filters );
	}
	/**
	* Sanitize a value, via the sanitization filter type associated with an
	* option..
	*/
	public function sanitize( $new_value, $option ) {if ( ! isset( $this->options[ $option ] ) ) {return $new_value;
	}
	if ( is_string( $this->options[ $option ] ) ) {return $this->do_filter( $this->options[ $option ], $new_value, get_option( $option ) );
	}
	if ( is_array( $this->options[ $option ] ) ) {$old_value = get_option( $option );
	foreach ( $this->options[ $option ] as $suboption => $filter ) {
	$old_value[ $suboption ] = isset( $old_value[ $suboption ] ) ? $old_value[ $suboption ] : '';
	$new_value[ $suboption ] = isset( $new_value[ $suboption ] ) ? $new_value[ $suboption ] : '';
	$new_value[ $suboption ] = $this->do_filter( $filter, $new_value[ $suboption ], $old_value[ $suboption ] );}return $new_value;}return $new_value;
	}}