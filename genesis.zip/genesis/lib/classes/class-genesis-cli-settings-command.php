<?php
/**
* Genesis Framework.
*/
/**
* Manage Genesis Framework settings via cli.
*/
class Genesis_Cli_Settings_Command {
	/**
	* Outputs the value of a setting.
	*/
	public function get( $args, $assoc_args ) {
	$option_key = isset( $assoc_args['option_key'] ) ? $assoc_args['option_key'] : null;if ( empty( $args ) ) {WP_CLI::error( 'Please provide a setting name.' );
	}
	$value = genesis_get_option( $args[0] );WP_CLI::log( $value );
	}
	/**
	* Updates a setting value.
	*/
	public function update( $args, $assoc_args ) {$option_key = isset( $assoc_args['option_key'] ) ? $assoc_args['option_key'] : null;
	if ( genesis_update_settings( [ $args[0] => $args[1] ], $option_key ) ) {WP_CLI::success( __( 'Setting saved.', 'genesis' ) );return;
	}
	WP_CLI::error( __( 'It appears something went wrong. Please check your command and try again.', 'genesis' ) );
	}}