<?php
/**
* Genesis Framework.
*/
/**
* Repository class for managing contributors to Genesis.
*/
class Genesis_Contributors {
	/**
	* Cache for all the contributor details.
	*/
	protected $people;
	/**
	* Initialise Genesis_Contributors object.
	*/
	public function __construct( array $people ) {$all = [];foreach ( $people as $key => $person ) {if ( ! isset( $person['role'] ) ) {$person['role'] = 'none';
	}
	if ( ! isset( $person['url'] ) && isset( $person['twitter'] ) ) {$person['url'] = 'https://twitter.com/' . $person['twitter'];
	}
	if ( ! isset( $person['avatar'] ) && isset( $person['gravatar'] ) ) {$person['avatar'] = 'https://0.gravatar.com/avatar/' . $person['gravatar'] . '?s=120';
	}
	$all[ $key ] = new Genesis_Contributor( $person['name'], $person['url'], $person['avatar'], $person['role'] );}$this->people = $all;
	}
	/**
	* Get all people who have contributed.
	*/
	public function find_all() {return $this->people;
	}
	/**
	* Find all contributors with a specific role.
	*/
	public function find_by_role( $role ) {
	$people = [];foreach ( $this->people as $key => $person ) {if ( $role === $person->get_role() ) {$people[ $key ] = $person;}}return $people;
	}
	/**
	* Get all contributors, in a shuffled order.
	*/
	public function find_contributors() {$contributors = $this->find_by_role( 'contributor' );shuffle( $contributors );return $contributors;
	}
	/**
	* Get a single contributor by their ID.
	*/
	public function find_by_id( $id ) {return $this->people[ $id ];
	}}