<?php
/**
* Genesis Framework.
*/
final class Genesis_Silent_Upgrader_Skin extends WP_Upgrader_Skin {
/**
* Overrides the parent method to prevent screen output.
*/
public function feedback( $string, ...$args ) {return false;
}
/**
* Overrides the parent method to prevent screen output.
*/
public function header() {return false;
}
/**
* Overrides the parent method to prevent screen output.
*/
public function footer() {return false;
}}