<?php
/**
* Genesis Framework.
*/
class Genesis_Update_Check {
	/**
	* POST URL key.
	*/
	const POST_URL_KEY = 'post_url';
	/**
	* POST args key.
	*/
	const POST_ARGS_KEY = 'post_args';
	/**
	* Required data key
	*/
	const REQ_DATA_KEY = 'req_data_keys';
	/**
	* URL to POST to.
	*/
	protected $post_url;
	/**
	* Args used to build the POST request.
	*/
	protected $post_args;
	/**
	* Required data keys.
	*/
	protected $req_data_keys;
	/**
	* The results of an update check.
	*/
	protected $update = [];
	/**
	* Constructor.
	*/
	public function __construct( array $config ) {
	$this->post_url = $config[ self::POST_URL_KEY ];
	$this->post_args = $config[ self::POST_ARGS_KEY ];
	$this->req_data_keys = isset( $config[ self::REQ_DATA_KEY ] ) ? $config[ self::REQ_DATA_KEY ] : [];
	}
	/**
	* Retrieve and assemble update information and return the array.
	*/
	public function get_update() {if ( $this->update ) {return $this->update;
	}
	$this->update = $this->validate_response( maybe_unserialize( $this->get_response_body() ) );return $this->update;
	}
	/**
	* Validate the format and data of the update response.
	*/
	protected function validate_response( $response ) {if ( ! is_array( $response ) ) {return [];
	}
	foreach ( $this->req_data_keys as $req ) {if ( ! array_key_exists( $req, $response ) ) {return [];}}return $response;
	}
	/**
	* Get the POST response.
	*/
	protected function get_response() {return wp_remote_post( $this->post_url, $this->post_args );
	}
	/**
	* Get the body of the response.
	*/
	protected function get_response_body() {return wp_remote_retrieve_body( $this->get_response() );
	}}