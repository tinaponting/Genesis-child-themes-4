<?php
/**
* Genesis Framework.
*/
class Genesis_Admin_Import_Export extends Genesis_Admin_Basic {
	/**
	* Create an admin menu item and settings page.
	*/
	public function __construct() {$this->help_base = GENESIS_VIEWS_DIR . '/help/import-export-';$page_id = 'genesis-import-export';
	$menu_ops = ['submenu' => ['parent_slug'=> 'genesis','page_title'=> __( 'Genesis - Import/Export', 'genesis' ),'menu_title'=> __( 'Import/Export', 'genesis' ),
	],];
	$this->create( $page_id, $menu_ops );add_action( 'admin_init', [ $this, 'export' ] );add_action( 'admin_init', [ $this, 'import' ] );
	}
	/**
	* Contextual help content.
	*/
	public function help() {
	$this->add_help_tab( 'general', __( 'Import/Export', 'genesis' ) );
	$this->add_help_tab( 'import', __( 'Import', 'genesis' ) );
	$this->add_help_tab( 'export', __( 'Export', 'genesis' ) );$this->set_help_sidebar();
	}
	/**
	* Callback for displaying the Genesis Import / Export admin page.
	*/
	public function admin() {include GENESIS_VIEWS_DIR . '/pages/genesis-admin-import-export.php';
	}
	/**
	* Add custom notices that display after successfully importing or exporting the settings.
	*/
	public function notices() {if ( ! genesis_is_menu_page( 'genesis-import-export' ) ) {return;
	}
	if ( isset( $_REQUEST['imported'] ) && 'true' === $_REQUEST['imported'] ) {printf( '<div id="message" class="updated" role="alert"><p><strong>%s</strong></p></div>', esc_html__( 'Settings successfully imported.', 'genesis' ) );
	} elseif ( isset( $_REQUEST['error'] ) && 'true' === $_REQUEST['error'] ) {printf( '<div id="message" class="error" role="alert"><p><strong>%s</strong></p></div>', esc_html__( 'There was a problem importing your settings. Please try again.', 'genesis' ) );
	}}
	/**
	* Return array of export options and their arguments.
	*/
	protected function get_export_options() {$options = ['theme' => ['label'=> __( 'Theme Settings', 'genesis' ),'settings-field'=> GENESIS_SETTINGS_FIELD,
	],
	'seo'=> ['label'=> __( 'SEO Settings', 'genesis' ),'settings-field' => GENESIS_SEO_SETTINGS_FIELD,],];return (array) apply_filters( 'genesis_export_options', $options );
	}
	/**
	* Echo out the checkboxes for the export options.
	*/
	protected function export_checkboxes() {$options = $this->get_export_options();
	if ( ! $options ) {printf( '<p><em>%s</em></p>', esc_html__( 'No export options available.', 'genesis' ) );return;
	}
	foreach ( $options as $name => $args ) {
	if ( is_int( $name ) || ! isset( $args['label'], $args['settings-field'] ) || '' === $args['label'] || '' === $args['settings-field'] ) {return;
	}
	printf( '<p><label for="genesis-export-%1$s"><input id="genesis-export-%1$s" name="genesis-export[%1$s]" type="checkbox" value="1" /> %2$s</label></p>', esc_attr( $name ), esc_html( $args['label'] ) );
	}}
	/**
	* Generate the export file, if requested, in JSON format.
	*/
	public function export() {if ( ! genesis_is_menu_page( 'genesis-import-export' ) ) {return;
	}
	if ( empty( $_REQUEST['genesis-export'] ) ) {return;
	}
	check_admin_referer( 'genesis-export', 'genesis-export-nonce' );$export_data = $_REQUEST['genesis-export'];
	do_action( 'genesis_export', $export_data );
	$options = $this->get_export_options();$settings = [];$prefix = [ 'genesis' ];foreach ( (array) $export_data as $export => $value ) {
	$settings_field = $options[ $export ]['settings-field'];$settings[ $settings_field ] = get_option( $settings_field );$prefix[] = $export;
	}
	if ( ! $settings ) {return;
	}
	$prefix = implode( '-', $prefix );
	$output = wp_json_encode( $settings );
	header('Content-Description: File Transfer');
	header('Cache-Control: public, must-revalidate');
	header('Pragma: hack');
	header('Content-Type: text/plain');
	header('Content-Disposition: attachment; filename="'.$prefix .'-'.gmdate('Ymd-His').'.json"');
	header('Content-Length:'.mb_strlen( $output));
	echo $output; exit;
	}
	/**
	* Handle the file uploaded to import settings.
	*/
	public function import() {if ( ! genesis_is_menu_page( 'genesis-import-export' ) ) {return;
	}
	if ( empty( $_REQUEST['genesis-import'] ) ) {return;
	}
	check_admin_referer( 'genesis-import', 'genesis-import-nonce' );
	do_action( 'genesis_import', $_REQUEST['genesis-import'], $_FILES['genesis-import-upload'] );
	$upload = file_get_contents( $_FILES['genesis-import-upload']['tmp_name'] );$options = json_decode( $upload, true );
	if ( ! $options || $_FILES['genesis-import-upload']['error'] ) {genesis_admin_redirect('genesis-import-export',['error'=> 'true',]);exit;
	}
	$exportables = $this->get_export_options();$importable_keys = [];foreach ( $exportables as $exportable ) {$importable_keys[] = $exportable['settings-field'];
	}
	foreach ( (array) $options as $key => $settings ) {if ( in_array( $key, $importable_keys, true ) ) {update_option( $key, $settings );
	}}
	genesis_admin_redirect('genesis-import-export',['imported' => 'true',]);exit;
	}}