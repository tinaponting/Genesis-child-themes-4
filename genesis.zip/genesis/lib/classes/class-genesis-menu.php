<?php
/**
* Genesis Framework.
*/
/**
* Genesis Menu.
*/
class Genesis_Menu {
	/**
	* Name of the active theme.
	*/
	protected $theme_name;
	/**
	* Array of script configurations parameters.
	*/
	protected $config;
	/**
	* Holds script file name suffix.
	*/
	private $suffix = '.min';
	/**
	* Responsive menu script version.
	*/
	const SCRIPT_VERSION = '1.1.3';
	/**
	* Genesis_Responsive_Menu_Handler constructor.
	*/
	public function __construct( $theme_name, array $config ) {$this->theme_name = $theme_name;$this->config = $config;
	if ( isset( $this->config['menuIconOpenedClass'] ) ) {unset( $this->config['menuIconOpenedClass'] );
	}}
	/**
	* Hook into WordPress.
	*/
	public function add_hooks() {add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
	}
	/**
	* Enqueues scripts.
	*/
	public function enqueue_scripts() {if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {$this->suffix = '';
	}
	wp_enqueue_script("{$this->theme_name}-responsive-menu",GENESIS_JS_URL . "/menu/responsive-menus{$this->suffix}.js",[ 'jquery' ],self::SCRIPT_VERSION,true
	);
	wp_localize_script("{$this->theme_name}-responsive-menu",'genesis_responsive_menu',$this->config
	);}}