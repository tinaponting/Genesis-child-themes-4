<?php
/**
* Genesis Framework.
*/
/**
* Registers a new admin page, providing content and corresponding menu item for the Theme Settings page.
*/
class Genesis_Admin_Settings extends Genesis_Admin_Basic {
	public function __construct() {
	$this->redirect_to = admin_url( 'customize.php?autofocus[panel]=genesis' );
	$page_id = 'genesis';
	$menu_ops= apply_filters('genesis_theme_settings_menu_ops',
	[
	'main_menu'=> [
	'sep'=> [
	'sep_position'=> '58.995',
	'sep_capability'=> 'edit_theme_options',
	],
	'page_title'=> 'Theme Settings',
	'menu_title'=> 'Genesis',
	'capability'=> 'edit_theme_options',
	'icon_url'=> GENESIS_ADMIN_IMAGES_URL . '/genesis-menu.png',
	'position'=> '58.996',
	],
	'first_submenu'=> [ 
	'page_title'=> __( 'Theme Settings', 'genesis' ),
	'menu_title'=> __( 'Theme Settings', 'genesis' ),
	'capability'=> 'edit_theme_options',
	],]);
	$this->create( $page_id, $menu_ops );
	}
	/**
	* Required to use `Genesis_Admin_Basic`.
	*/
	public function admin() {}
}