<?php
/**
* Genesis Framework.
*/
class Genesis_Admin_Meta_Boxes extends Genesis_Admin_Boxes {
/**
* Create a meta box handler.
*/
public function __construct() {$this->help_base = GENESIS_VIEWS_DIR . '/help/';$this->views_base = GENESIS_VIEWS_DIR;
}
/**
* Bypass registering meta boxes.
*/
public function metaboxes() {}
/**
* Echo out the content of a meta box.
*/
public function show_meta_box( $id, $object = null ) {$this->do_meta_box($object,
[
'id'=> $id,
]);}}