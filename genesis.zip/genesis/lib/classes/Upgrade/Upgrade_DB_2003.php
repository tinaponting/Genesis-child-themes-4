<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 2003.
*/
class Upgrade_DB_2003 implements Upgrade_DB_Interface {
public function upgrade() {
genesis_update_settings(
[ 'superfish'=> genesis_get_option( 'nav_superfish', null, 0 ) || genesis_get_option( 'subnav_superfish', null, 0 ) ? 1 : 0,
]);}}