<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 2207.
*/
class Upgrade_DB_2207 implements Upgrade_DB_Interface {
public function upgrade() {
$update_email_address = genesis_get_option( 'update_email' ) ? genesis_get_option( 'update_email_address' ) : '';
genesis_update_settings(
[ 'update_email'=> 'unset','update_email_address'=> $update_email_address,
]);}}