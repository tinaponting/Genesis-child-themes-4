<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
class Upgrade_DB_3200 implements Upgrade_DB_Interface {
	/**
	* The Genesis Simple Edits option key constant value.
	*/
	public $gse_settings_field;
	/**
	* Constructor.
	*/
	public function __construct() {$this->gse_settings_field = defined( 'GSE_SETTINGS_FIELD' ) ? GSE_SETTINGS_FIELD : null;
	}
	/**
	* Upgrade method.
	*/
	public function upgrade() {$this->create_entry_meta_settings();
	}
	/**
	* Create the entry meta settings with proper default. Use values from Genesis Simple Edits, if plugin is active.
	*/
	public function create_entry_meta_settings() {
	$before_content_default = is_null( $this->gse_settings_field ) ? '[post_date] ' . __( 'by', 'genesis' ) . ' [post_author_posts_link] [post_comments] [post_edit]' : genesis_get_option( 'post_info', $this->gse_settings_field );
	$after_content_default  = is_null( $this->gse_settings_field ) ? '[post_categories] [post_tags]' : genesis_get_option( 'post_meta', $this->gse_settings_field );
	genesis_update_settings(
	[
	'entry_meta_before_content'=> $before_content_default,'entry_meta_after_content'=> $after_content_default,
	]);}}