<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 110.
*/
class Upgrade_DB_110 implements Upgrade_DB_Interface {
public function upgrade() {
genesis_update_settings(
[ 'content_archive_thumbnail'=> genesis_get_option( 'thumbnail' ),
]);}}