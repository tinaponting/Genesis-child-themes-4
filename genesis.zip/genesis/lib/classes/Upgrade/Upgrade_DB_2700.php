<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 2700.
*/
class Upgrade_DB_2700 implements Upgrade_DB_Interface {
/**
* Upgrade method.
*/
public function upgrade() {delete_option( 'genesis-scribe-nag-disabled' );
}}