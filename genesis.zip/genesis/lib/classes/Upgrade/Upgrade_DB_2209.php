<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 2209.
*/
class Upgrade_DB_2209 implements Upgrade_DB_Interface {
public function upgrade() {
$term_meta = get_option( 'genesis-term-meta' );
foreach ( (array) $term_meta as $term_id => $meta ) {foreach ( (array) $meta as $key => $value ) {add_term_meta( $term_id, $key, $value, true );
}}}}