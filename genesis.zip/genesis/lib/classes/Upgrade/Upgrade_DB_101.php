<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 101.
*/
class Upgrade_DB_101 implements Upgrade_DB_Interface {
public function upgrade() {
genesis_update_settings(
[
'nav_home'=> 1,
'nav_twitter_text'=> 'Follow me on Twitter',
'subnav_home'=> 1,
]);}}