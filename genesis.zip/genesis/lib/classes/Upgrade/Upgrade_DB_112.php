<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 112.
*/
class Upgrade_DB_112 implements Upgrade_DB_Interface {
public function upgrade() {genesis_update_settings(
[
'header_right'=> genesis_get_option( 'header_full' ) ? 0 : 1,
'nav_superfish'=> 1,
'subnav_superfish'=> 1,
'nav_extras_enable'=> genesis_get_option( 'nav_right' ) ? 1 : 0,
'nav_extras'=> genesis_get_option( 'nav_right' ),
'nav_extras_twitter_id'=> genesis_get_option( 'twitter_id' ),
'nav_extras_twitter_text'=> genesis_get_option( 'nav_twitter_text' ),
]);}}