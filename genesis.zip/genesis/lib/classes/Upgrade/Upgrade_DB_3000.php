<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 3000.
*/
class Upgrade_DB_3000 implements Upgrade_DB_Interface {public function upgrade() {
if ( genesis_get_option( 'adsense_id' ) ) {
$header_scripts = genesis_get_option( 'header_scripts' );
$adsense_id = genesis_get_option( 'adsense_id' );
$adsense = <<<ADSENSE
<script async src="http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
(adsbygoogle = window.adsbygoogle || []).push({
google_ad_client: "$adsense_id",
enable_page_level_ads: true,
tag_partner: "genesis"
});
</script>
ADSENSE;
genesis_update_settings(
[ 'header_scripts' er_scripts . "\n" . $adsense,
]);}}}