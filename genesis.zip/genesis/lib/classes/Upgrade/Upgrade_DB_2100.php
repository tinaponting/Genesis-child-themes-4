<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 2100.
*/
class Upgrade_DB_2100 implements Upgrade_DB_Interface {
public function upgrade() {
genesis_update_settings(
[
'image_alignment'=> 'alignleft',
'first_version'=> '2.0.2',
]);}}