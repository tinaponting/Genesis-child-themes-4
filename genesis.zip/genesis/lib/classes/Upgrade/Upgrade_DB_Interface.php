<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Interface for all database upgraders.
*/
interface Upgrade_DB_Interface {public function upgrade();
}