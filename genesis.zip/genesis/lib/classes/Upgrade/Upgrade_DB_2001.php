<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 2001.
*/
class Upgrade_DB_2001 implements Upgrade_DB_Interface {
/**
* Upgrade method.
*/
public function upgrade() {
genesis_update_settings(
[ 'nav_extras' => genesis_get_option( 'nav_extras_enable', null, 0 ) ? genesis_get_option( 'nav_extras', null, 0 ) : '',
]);}}