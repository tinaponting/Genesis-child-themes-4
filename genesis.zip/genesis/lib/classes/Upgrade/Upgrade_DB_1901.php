<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 1901.
*/
class Upgrade_DB_1901 implements Upgrade_DB_Interface {
public function upgrade() {
$menu_locations = get_theme_mod( 'nav_menu_locations' );if ( isset( $menu_locations['primary'] ) && $menu_locations['primary'] && ! genesis_get_option( 'nav' ) ) {$menu_locations['primary'] = 0;set_theme_mod( 'nav_menu_locations', $menu_locations );
}
if ( isset( $menu_locations['secondary'] ) && $menu_locations['secondary'] && ! genesis_get_option( 'subnav' ) ) {$menu_locations['secondary'] = 0;set_theme_mod( 'nav_menu_locations', $menu_locations );
}}}