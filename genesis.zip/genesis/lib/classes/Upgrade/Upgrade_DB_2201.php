<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 2201.
*/
class Upgrade_DB_2201 implements Upgrade_DB_Interface {
public function upgrade() {
genesis_update_settings(
[ 'canonical_archives'=> 'unset',
],
GENESIS_SEO_SETTINGS_FIELD
);}}