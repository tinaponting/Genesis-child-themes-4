<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 3200.
*/
class Upgrade_DB_3301 implements Upgrade_DB_Interface {
/**
* Deactivate the Genesis Translations plugin.
*/
public function upgrade() {deactivate_plugins( '/genesis-translations/genesis-translations.php' );
}}