<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 2501.
*/
class Upgrade_DB_2501 implements Upgrade_DB_Interface {
public function upgrade() {
genesis_update_settings(
[ 'semantic_headings'=> genesis_get_seo_option( 'semantic_headings', false ) ?: 'unset',
],
GENESIS_SEO_SETTINGS_FIELD
);}}