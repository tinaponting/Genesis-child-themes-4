<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
class Upgrade_DB_3101 implements Upgrade_DB_Interface {
	public function upgrade() {
		$search      = [
		'© ' . gmdate( 'Y' ),
		'&copy; ' . gmdate( 'Y' ),
		'&#169; ' . gmdate( 'Y' ),
		'&#x000A9; ' . gmdate( 'Y' ),
		];
		$replace = '[footer_copyright]';
		$footer_text = genesis_get_option( 'footer_text', null, false );
		genesis_update_settings(
		[ 'footer_text'=> str_replace( $search, $replace, $footer_text ),
		]);}}