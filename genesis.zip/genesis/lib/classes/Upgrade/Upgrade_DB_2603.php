<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Upgrade;
/**
* Upgrade class. Called when `db_version` Genesis setting is below 2603.
*/
class Upgrade_DB_2603 implements Upgrade_DB_Interface {
	public function upgrade() {
	$this->unslash_post_meta_scripts();
	$this->unslash_header_footer_scripts();
	}
	/**
	* Strip slashes from header and body scripts saved as post meta.
	*/
	public function unslash_post_meta_scripts() {
	global $wpdb;
	$header_scripts_posts = $wpdb->get_results( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_genesis_scripts'" );
	$body_scripts_posts = $wpdb->get_results( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_genesis_scripts_body'" );
	foreach ( $header_scripts_posts as $post ) {
	if ( ! empty( $post->post_id ) ) {update_post_meta( $post->post_id, '_genesis_scripts', get_post_meta( $post->post_id, '_genesis_scripts', 1 ) );
	}}
	foreach ( $body_scripts_posts as $post ) {if ( ! empty( $post->post_id ) ) {update_post_meta( $post->post_id, '_genesis_scripts_body', get_post_meta( $post->post_id, '_genesis_scripts_body', 1 ) );
	}}}
	/**
	* Strip slashes from header and body scripts saved as post meta.
	*/
	public function unslash_header_footer_scripts() {
	genesis_update_settings(
	[
	'header_scripts'=> stripslashes( genesis_get_option( 'header_scripts' ) ),
	'footer_scripts'=> stripslashes( genesis_get_option( 'footer_scripts' ) ),
	]);}}