<?php
/**
* Genesis Framework.
*/
class Genesis_Cli_Db_Command {
/**
* Upgrade the database settings for Genesis, usually after an update.
*/
public function upgrade( $args, $assoc_args ) {remove_action( 'genesis_upgrade', 'genesis_upgrade_redirect' );genesis_upgrade();WP_CLI::success( __( 'Genesis database upgraded.', 'genesis' ) );
}
/**
* Show current Genesis database version
*/
public function version( $args, $assoc_args ) {WP_CLI::log( PARENT_DB_VERSION );
}}