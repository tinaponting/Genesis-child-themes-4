<?php
/**
* Genesis Framework.
*/
abstract class Genesis_Admin {
	/**
	 * Name of the page hook when the menu is registered.
	 */
	public $pagehook;
	/**
	* ID of the admin menu and settings page.
	*/
	public $page_id;
	/**
	* The page to redirect to when menu page is accessed.
	*/
	public $redirect_to;
	/**
	* The query flag to check for to bypass the redirect setting.
	*/
	public $redirect_bypass;
	/**
	* Name of the settings field in the options table.
	*/
	public $settings_field;
	/**
	* Associative array (field name => values) for the default settings on this
	* admin page.
	*/
	public $default_settings;
	/**
	* Associative array of configuration options for the admin menu(s).
	*/
	public $menu_ops;
	/**
	* Associative array of configuration options for the settings page.
	*/
	public $page_ops;
	/**
	* Help view file base.
	*/
	protected $help_base;
	/**
	* Views path base.
	*/
	protected $views_base;
	/**
	* Call this method in a subclass constructor to create an admin menu and settings page.
	*/
	public function create( $page_id = '', array $menu_ops = [], array $page_ops = [], $settings_field = '', array $default_settings = [] ) {
	$this->page_id = $this->page_id ?: $page_id;if ( ! $this->page_id ) {return;
	}
	$this->menu_ops = $this->menu_ops ?: $menu_ops;
	$this->page_ops = $this->page_ops ?: $page_ops;
	$this->settings_field = $this->settings_field ?: $settings_field;
	$this->default_settings = $this->default_settings ?: $default_settings;
	$this->help_base = $this->help_base ?: GENESIS_VIEWS_DIR . '/help/' . $page_id . '-';
	$this->views_base = $this->views_base ?: GENESIS_VIEWS_DIR;
	$this->page_ops = wp_parse_args($this->page_ops,[
	'save_button_text'=> __( 'Save Changes', 'genesis' ),
	'reset_button_text'=> __( 'Reset Settings', 'genesis' ),
	'saved_notice_text'=> __( 'Settings saved.', 'genesis' ),
	'reset_notice_text'=> __( 'Settings reset.', 'genesis' ),
	'error_notice_text'=> __( 'Error saving settings.', 'genesis' ),
	]);
	if ( isset( $this->menu_ops['submenu'] ) && ( isset( $this->menu_ops['main_menu'] ) || isset( $this->menu_ops['first_submenu'] ) ) ) {
	wp_die(sprintf(esc_html__( 'You cannot use %s to create two menus in the same subclass. Please use separate subclasses for each menu.', 'genesis' ),'Genesis_Admin'
	));}
	add_action( 'admin_menu', [ $this, 'maybe_add_main_menu' ], 5 );
	add_action( 'admin_menu', [ $this, 'maybe_add_first_submenu' ], 5 );
	add_action( 'admin_menu', [ $this, 'maybe_add_submenu' ] );
	add_action( 'admin_init', [ $this, 'maybe_redirect' ], 1000 );
	add_action( 'admin_init', [ $this, 'register_settings' ] );
	add_action( 'admin_notices', [ $this, 'notices' ] );
	add_action( 'admin_init', [ $this, 'settings_init' ] );
	add_action( 'admin_init', [ $this, 'load_help' ] );
	add_action( 'admin_init', [ $this, 'load_assets' ] );
	add_filter( 'pre_update_option_' . $this->settings_field, [ $this, 'save' ], 10, 2 );
	}
	/**
	* Possibly create a new top level admin menu.
	*/
	public function maybe_add_main_menu() {if ( isset( $this->menu_ops['main_menu']['sep'] ) ) {$sep = wp_parse_args($this->menu_ops['main_menu']['sep'],['sep_position'=> '','sep_capability'=> '',
	]);
	if ( $sep['sep_position'] && $sep['sep_capability'] ) {$GLOBALS['menu'][ $sep['sep_position'] ] = [ '', $sep['sep_capability'], 'separator', '', 'genesis-separator wp-menu-separator' ]; 
	}}
	if ( isset( $this->menu_ops['main_menu'] ) && is_array( $this->menu_ops['main_menu'] ) ) {$menu = wp_parse_args($this->menu_ops['main_menu'],[
	'page_title'=> '','menu_title'=> '','capability'=> 'edit_theme_options','icon_url'=> '','position'=> '',
	]);
	$this->pagehook = add_menu_page( $menu['page_title'], $menu['menu_title'], $menu['capability'], $this->page_id, [ $this, 'admin' ], $menu['icon_url'], $menu['position'] );
	}}
	/**
	* Possibly create the first submenu item.
	*/
	public function maybe_add_first_submenu() {
	if ( isset( $this->menu_ops['first_submenu'] ) && is_array( $this->menu_ops['first_submenu'] ) ) {$menu = wp_parse_args(
	$this->menu_ops['first_submenu'],['page_title'=> '','menu_title'=> '','capability'=> 'edit_theme_options',
	]);
	$this->pagehook = add_submenu_page( $this->page_id, $menu['page_title'], $menu['menu_title'], $menu['capability'], $this->page_id, [ $this, 'admin' ] );
	}}
	/**
	* Possibly create a submenu item.
	*/
	public function maybe_add_submenu() {
	if ( isset( $this->menu_ops['submenu'] ) && is_array( $this->menu_ops['submenu'] ) ) {$menu = wp_parse_args($this->menu_ops['submenu'],
	[
	'parent_slug'=> '','page_title'=> '','menu_title'=> '','capability'=> 'edit_theme_options',
	]);
	$this->pagehook = add_submenu_page( $menu['parent_slug'], $menu['page_title'], $menu['menu_title'], $menu['capability'], $this->page_id, [ $this, 'admin' ] );
	}}
	/**
	* If specified, redirect when accessing this page's menu URL.
	 */
	public function maybe_redirect() {if ( ! $this->redirect_to ) {return;
	}
	if ( $this->redirect_bypass && isset( $_REQUEST[ $this->redirect_bypass ] ) ) {return;
	}
	if ( ! genesis_is_menu_page( $this->page_id ) ) {return;
	}
	wp_safe_redirect( esc_url_raw( $this->redirect_to ) );exit;
	}
	/**
	* Register the database settings for storage.
	*/
	public function register_settings() {if ( ! $this->settings_field ) {return;
	}
	register_setting($this->settings_field,$this->settings_field,['default'=> $this->default_settings,
	]);
	if ( ! genesis_get_option( 'theme_version' ) ) {update_option( $this->settings_field, $this->default_settings );
	}
	if ( ! genesis_is_menu_page( $this->page_id ) ) {return;
	}
	if ( genesis_get_option( 'reset', $this->settings_field ) ) {
	if ( update_option( $this->settings_field, $this->default_settings ) ) {genesis_admin_redirect($this->page_id,
	[
	'reset'=> 'true',
	]);
	} else {genesis_admin_redirect($this->page_id,
	[
	'error'=> 'true',
	]);}exit;
	}}
	/**
	* Display notices on the save or reset of settings.
	*/
	public function notices() {if ( ! genesis_is_menu_page( $this->page_id ) ) {return;
	}
	if ( isset( $_REQUEST['settings-updated'] ) && 'true' === $_REQUEST['settings-updated'] ) {printf( '<div id="message" class="updated"><p><strong>%s</strong></p></div>', esc_html( $this->page_ops['saved_notice_text'] ) );
	} elseif ( isset( $_REQUEST['reset'] ) && 'true' === $_REQUEST['reset'] ) {printf( '<div id="message" class="updated"><p><strong>%s</strong></p></div>', esc_html( $this->page_ops['reset_notice_text'] ) );
	} elseif ( isset( $_REQUEST['error'] ) && 'true' === $_REQUEST['error'] ) {printf( '<div id="message" class="updated"><p><strong>%s</strong></p></div>', esc_html( $this->page_ops['error_notice_text'] ) );
	}}
	/**
	* Save method.
	* @param mixed $newvalue New value to save.
	* @param mixed $oldvalue Old value.
	*/
	public function save( $newvalue, $oldvalue ) {return $newvalue;
	}
	/**
	* Initialize the settings page.
	*/
	abstract public function settings_init();
	/**
	* Load the optional help method, if one exists.
	*/
	public function load_help() {if ( method_exists( $this, 'help' ) ) {add_action( "load-{$this->pagehook}", [ $this, 'help' ] );
	}}
	/**
	* Add help tab.
	* @param string $id    Help tab id.
	* @param string $title Help tab title.
	*/
	public function add_help_tab( $id, $title ) {$current_screen = get_current_screen();if ( null === $current_screen ) {return;
	}
	$current_screen->add_help_tab(['id'=> $this->pagehook . '-' . $id,'title'=> $title,'content'=> '','callback'=> [ $this, 'help_content' ],
	]);}
	/**
	* Display a help view file if it exists.
	* @param object $screen Current WP_Screen.
	* @param array  $tab    Help tab.
	*/
	public function help_content( $screen, $tab ) {$hook_len = strlen( $this->pagehook ) + 1;$view  = $this->help_base . substr( $tab['id'], $hook_len ) . '.php';if ( is_file( $view ) ) {include $view;
	}}
	/**
	* Set help sidebar for Genesis screens.
	*/
	public function set_help_sidebar() {$current_screen = get_current_screen();if ( null === $current_screen ) {return;
	}
	$screen_reader = '<span class="screen-reader-text">. ' . esc_html__( 'Link opens in a new window.', 'genesis' ) . '</span>';
	$current_screen->set_help_sidebar('<p><strong>' . esc_html__( 'For more information:', 'genesis' ) . '</strong></p>' .
	'<p><a href="http://my.studiopress.com/help/" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Get Support', 'genesis' ) . $screen_reader . '</a></p>' .
	'<p><a href="http://my.studiopress.com/snippets/" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Genesis Snippets', 'genesis' ) . $screen_reader . '</a></p>' .
	'<p><a href="http://my.studiopress.com/tutorials/" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Genesis Tutorials', 'genesis' ) . $screen_reader . '</a></p>'
	);}
	/**
	* Load script and stylesheet assets via scripts() and styles() methods, if they exist.
	*/
	public function load_assets() {if ( method_exists( $this, 'scripts' ) ) {add_action( "load-{$this->pagehook}", [ $this, 'scripts' ] );
	}
	if ( method_exists( $this, 'styles' ) ) {add_action( "load-{$this->pagehook}", [ $this, 'styles' ] );
	}}
	/**
	* Output the main admin page.
	*/
	abstract public function admin();
	/**
	* Helper function that constructs name attributes for use in form fields.
	* @param string $name Field name base.
	*/
	protected function get_field_name( $name ) {return sprintf( '%s[%s]', $this->settings_field, $name );
	}
	/**
	* Echo constructed name attributes in form fields.
	* @param string $name Field name base.
	*/
	protected function field_name( $name ) {echo $this->get_field_name( $name );
	}
	/**
	* Helper function that constructs id attributes for use in form fields.
	* @param string $id Field id base.
	*/
	protected function get_field_id( $id ) {return sprintf( '%s[%s]', $this->settings_field, $id );
	}
	/**
	* Echo constructed id attributes in form fields.
	* @param string $id Field id base.
	*/
	protected function field_id( $id ) {echo $this->get_field_id( $id ); 
	}
	/**
	* Helper function that returns a setting value from this form's settings
	* field for use in form fields.
	* @param string $key Field key.
	*/
	protected function get_field_value( $key ) {return genesis_get_option( $key, $this->settings_field );
	}
	/**
	* Echo a setting value from this form's settings field for use in form fields.
	* @param string $key Field key.
	*/
	protected function field_value( $key ) {echo $this->get_field_value( $key );
	}}