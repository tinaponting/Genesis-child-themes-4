<?php
/**
* Genesis Framework.
*/
/**
* Value object representing a single contributor to Genesis.
*/
final class Genesis_Contributor {
	/**
	* Name of contributor.
	*/
	private $name;
	/**
	* URL to contributors profile.
	*/
	private $profile_url;
	/**
	* URL to contributor's avatar.
	*/
	private $avatar_url;
	/**
	* Role in current release.
	* @var string
	*/
	private $role;
	/**
	* Initialize fields in Genesis_Contributor instance.
	*/
	public function __construct( $name, $profile_url, $avatar_url, $role ) {$this->name = $name;$this->profile_url = $profile_url;$this->avatar_url = $avatar_url;$this->role = $role;
	}
	/**
	* Get contributors name.
	*/
	public function get_name() {return $this->name;
	}
	/**
	* Get contributors profile URL.
	*/
	public function get_profile_url() {return $this->profile_url;
	}
	/**
	* Get contributors avatar URL.
	*/
	public function get_avatar_url() {return $this->avatar_url;
	}
	/**
	* Get contributors role.
	*/
	public function get_role() {return $this->role;
	}
	/**
	* Get contributors role as translatable name.
	*/
	public function get_named_role() {$roles = ['contributor'=> __( 'Contributor', 'genesis' ),'lead-developer'=> __( 'Lead Developer', 'genesis' ),
	];
	if ( isset( $roles[ $this->role ] ) ) {return $roles[ $this->role ];}return '';
	}}