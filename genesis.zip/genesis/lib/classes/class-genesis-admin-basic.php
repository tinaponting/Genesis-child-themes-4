<?php
/**
* Genesis Framework.
*/
/**
* Abstract subclass of Genesis_Admin which adds support for creating a basic
* admin page that does not make use of a Settings API form or meta boxes.
*/
abstract class Genesis_Admin_Basic extends Genesis_Admin {
/**
* Satisfies the abstract requirements of Genesis_Admin.
*/
public function settings_init() {}
}