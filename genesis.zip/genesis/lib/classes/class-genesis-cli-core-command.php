<?php
/**
* Genesis Framework.
*/
class Genesis_Cli_Core_Command {
/**
* Show current Genesis core files version
*/
public function version( $args, $assoc_args ) {WP_CLI::log( PARENT_THEME_VERSION );
}
/**
* Updates Genesis, upgrades the database.
*/
public function update( $args, $assoc_args ) {genesis_clear_update_transient();WP_CLI::runcommand( 'theme update genesis' );WP_CLI::runcommand( 'genesis db upgrade' );
}}