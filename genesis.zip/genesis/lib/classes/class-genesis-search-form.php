<?php
/**
* Genesis Framework
*/
class Genesis_Search_Form {
	/**
	* Unique ID for this search field.
	*/
	protected $unique_id;
	/**
	* Holds form strings.
	*/
	protected $strings;
	/**
	* Constructor.
	*/
	public function __construct( array $strings = [] ) {$default_strings = [
	'label'=> __( 'Search site', 'genesis' ),
	'placeholder'=> '',
	'input_value'=> apply_filters( 'the_search_query', get_search_query() ), 
	'submit_value'=> __( 'Search', 'genesis' ),
	];
	$this->strings = array_merge( $default_strings, $strings );$this->unique_id = wp_unique_id( 'searchform-' );
	}
	/**
	* Return markup.
	*/
	protected function markup( $args ) {$args = array_merge($args,['echo'=> false,]);return genesis_markup( $args );
	}
	/**
	* Render the search form.
	*/
	public function render() {echo $this->get_form(); 
	}
	/**
	* Get form markup.
	*/
	public function get_form() {return $this->markup([
	'open'=> '<form %s>',
	'close'=> '</form>',
	'content'=> $this->get_label() . $this->get_input() . $this->get_submit(),
	'context'=> 'search-form',
	]);}
	/**
	* Get label markup.
	*/
	protected function get_label() {return $this->markup([
	'open'=> '<label %s>',
	'close'=> '</label>',
	'content'=> $this->strings['label'],
	'context'=> 'search-form-label',
	'params'=> ['input_id'=> $this->get_input_id(),
	],]);}
	/**
	* Get input markup.
	*/
	protected function get_input() {return $this->markup([
	'open'=> '<input %s>',
	'context'=> 'search-form-input',
	'params'=> ['id'=> $this->get_input_id(),'value'=> $this->strings['input_value'],'placeholder'=> $this->strings['placeholder'],
	],]);}
	/**
	* Get submit button markup.
	*/
	protected function get_submit() {return $this->markup(
	[
	'open'=> '<input %s>','context'=> 'search-form-submit','params'=> ['value'=> $this->strings['submit_value'],
	],]);}
	/**
	* Get a unique ID for the search input.
	*/
	protected function get_input_id() {return $this->unique_id;
	}}