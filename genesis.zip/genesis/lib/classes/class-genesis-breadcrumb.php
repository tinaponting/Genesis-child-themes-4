<?php
/**
* Genesis Framework.
*/
class Genesis_Breadcrumb {
	/**
	* Settings array, a merge of provided values and defaults.
	*/
	protected $args = [];
	/**
	* Constructor. Set up cacheable values and settings.
	*/
	public function __construct() {$this->args = require GENESIS_CONFIG_DIR . '/breadcrumbs.php';
	}
	/**
	* Return the final completed breadcrumb in markup wrapper.
	*/
	public function get_output( $args = [] ) {
	$this->args = apply_filters( 'genesis_breadcrumb_args', wp_parse_args( $args, $this->args ) );
	return $this->args['prefix'] . $this->args['labels']['prefix'] . $this->build_crumbs() . $this->args['suffix'];}public function output( $args = [] ) {echo $this->get_output( $args ); 
	}
	/**
	* Return the correct crumbs for this query, combined together.
	*/
	protected function build_crumbs() {$crumbs[] = $this->get_home_crumb();if ( is_home() ) {$crumbs[] = $this->get_blog_crumb();
	} elseif ( is_search() ) {$crumbs[] = $this->get_search_crumb();
	} elseif ( is_404() ) {$crumbs[] = $this->get_404_crumb();
	} elseif ( is_page() && ! is_front_page() ) {$crumbs[] = $this->get_page_crumb();
	} elseif ( is_archive() ) {$crumbs[] = $this->get_archive_crumb();
	} elseif ( is_singular() ) {$crumbs[] = $this->get_single_crumb();
	}
	$crumbs = apply_filters( 'genesis_build_crumbs', $crumbs, $this->args );return implode( $this->args['sep'], array_filter( $crumbs ) );
	}
	/**
	* Return archive breadcrumb.
	*/
	protected function get_archive_crumb() {$crumb = '';if ( is_category() ) {$crumb = $this->get_category_crumb();
	} elseif ( is_tag() ) {$crumb = $this->get_tag_crumb();
	} elseif ( is_tax() ) {$crumb = $this->get_tax_crumb();
	} elseif ( is_year() ) {$crumb = $this->get_year_crumb();
	} elseif ( is_month() ) {$crumb = $this->get_month_crumb();
	} elseif ( is_day() ) {$crumb = $this->get_day_crumb();
	} elseif ( is_author() ) {$crumb = $this->get_author_crumb();
	} elseif ( is_post_type_archive() ) {$crumb = $this->get_post_type_crumb();}return apply_filters( 'genesis_archive_crumb', $crumb, $this->args );
	}
	/**
	* Get single breadcrumb, including any parent crumbs.
	*/
	protected function get_single_crumb() {
	if ( is_attachment() ) {$crumb = $this->get_attachment_crumb();} elseif ( is_singular( 'post' ) ) {$crumb = $this->get_post_crumb();} else {$crumb = $this->get_cpt_crumb();}return apply_filters( 'genesis_single_crumb', $crumb, $this->args );
	}
	/**
	* Return home breadcrumb.
	*/
	protected function get_home_crumb() {$url = $this->page_shown_on_front() ? get_permalink( get_option( 'page_on_front' ) ) : trailingslashit( home_url() );
	$crumb = ( is_home() && is_front_page() ) ? $this->args['home'] : $this->get_breadcrumb_link( $url, '', $this->args['home'] );return apply_filters( 'genesis_home_crumb', $crumb, $this->args );
	}
	/**
	* Return blog posts page breadcrumb.
	*/
	protected function get_blog_crumb() {$crumb = $this->get_home_crumb();if ( $this->page_shown_on_front() ) {$crumb = get_the_title( get_option( 'page_for_posts' ) );}return apply_filters( 'genesis_blog_crumb', $crumb, $this->args );
	}
	/**
	* Return search results page breadcrumb.
	*/
	protected function get_search_crumb() {$crumb = $this->args['labels']['search'] . '"' . esc_html( apply_filters( 'the_search_query', get_search_query() ) ) . '"'; return apply_filters( 'genesis_search_crumb', $crumb, $this->args );
	}
	/**
	* Return 404 (page not found) breadcrumb.
	*/
	protected function get_404_crumb() {$crumb = $this->args['labels']['404'];return apply_filters( 'genesis_404_crumb', $crumb, $this->args );
	}
	/**
	* Return content page breadcrumb.
	*/
	protected function get_page_crumb() {global $wp_query;if ( $this->page_shown_on_front() && is_front_page() ) {$crumb = $this->get_home_crumb();
	} else {$post = $wp_query->get_queried_object();if ( $post->post_parent ) {if ( isset( $post->ancestors ) ) {if ( is_array( $post->ancestors ) ) {$ancestors = array_values( $post->ancestors );} else {$ancestors = [ $post->ancestors ];
	}
	} else {$ancestors = [ $post->post_parent ];
	}
	$crumbs = [];foreach ( $ancestors as $ancestor ) {array_unshift($crumbs,$this->get_breadcrumb_link(get_permalink( $ancestor ),'',get_the_title( $ancestor )
	));}
	$crumbs[] = get_the_title( $post->ID );$crumb = implode( $this->args['sep'], $crumbs );} else {$crumb = get_the_title();}}return apply_filters( 'genesis_page_crumb', $crumb, $this->args );
	}
	/**
	* Get breadcrumb for single attachment, including any parent crumbs.
	*/
	protected function get_attachment_crumb() {
	$post = get_post();$crumb = '';if ( $post->post_parent && $this->args['heirarchial_attachments'] ) {$attachment_parent = get_post( $post->post_parent );
	$crumb = $this->get_breadcrumb_link(get_permalink( $post->post_parent ),'',$attachment_parent->post_title,$this->args['sep']
	);}
	$crumb .= single_post_title( '', false );return apply_filters( 'genesis_attachment_crumb', $crumb, $this->args );
	}
	/**
	* Get breadcrumb for single post, including any parent (category) crumbs.
	*/
	protected function get_post_crumb() {$categories = get_the_category();$cat_crumb = '';
	if ( 1 === count( $categories ) ) {$cat_crumb = $this->get_term_parents( $categories[0]->cat_ID, 'category', true ) . $this->args['sep'];
	}
	if ( count( $categories ) > 1 ) {if ( $this->args['heirarchial_categories'] ) {$primary_category_id = get_post_meta( get_the_ID(), '_category_permalink', true ); 
	if ( ! $primary_category_id && function_exists( 'yoast_get_primary_term_id' ) ) {$primary_category_id = yoast_get_primary_term_id();
	}
	if ( $primary_category_id ) {$cat_crumb = $this->get_term_parents( $primary_category_id, 'category', true ) . $this->args['sep'];
	} else {$cat_crumb = $this->get_term_parents( $categories[0]->cat_ID, 'category', true ) . $this->args['sep'];
	}
	} else {$crumbs = [];foreach ( $categories as $category ) {$crumbs[] = $this->get_breadcrumb_link(get_category_link( $category->term_id ),'',$category->name
	);}
	$cat_crumb = implode( $this->args['list_sep'], $crumbs ) . $this->args['sep'];
	}}
	$crumb = $cat_crumb . single_post_title( '', false );
	return apply_filters( 'genesis_post_crumb', $crumb, $this->args, $cat_crumb );
	}
	/**
	* Get breadcrumb for single custom post type entry, including any parent (CPT name) crumbs.
	*/
	protected function get_cpt_crumb() {$post_type = get_query_var( 'post_type' );
	$post_type_object = get_post_type_object( $post_type );if ( null === $post_type_object ) {return '';
	}
	$cpt_archive_link = get_post_type_archive_link( $post_type );if ( $cpt_archive_link ) {
	$crumb = $this->get_breadcrumb_link($cpt_archive_link,'',$post_type_object->labels->name
	);
	} else {$crumb = $post_type_object->labels->name;
	}
	$crumb .= $this->args['sep'] . single_post_title( '', false );return apply_filters( 'genesis_cpt_crumb', $crumb, $this->args );
	}
	/**
	* Return the category archive crumb.
	*/
	protected function get_category_crumb() {$crumb = $this->args['labels']['category'] . $this->get_term_parents( get_query_var( 'cat' ), 'category' );
	/**
	* Filter the category archive breadcrumb.
	*/
	return apply_filters( 'genesis_category_crumb', $crumb, $this->args );
	}
	/**
	* Return the tag archive crumb.
	*/
	protected function get_tag_crumb() {$crumb = $this->args['labels']['tag'] . single_term_title( '', false );return apply_filters( 'genesis_tag_crumb', $crumb, $this->args );
	}
	/**
	* Return the taxonomy archive crumb.
	*/
	protected function get_tax_crumb() {global $wp_query;
	$term = $wp_query->get_queried_object();
	$crumb = $this->args['labels']['tax'] . $this->get_term_parents( $term->term_id, $term->taxonomy );return apply_filters( 'genesis_tax_crumb', $crumb, $this->args );
	}
	/**
	* Return the year archive crumb.
	*/
	protected function get_year_crumb() {$year = get_query_var( 'm' ) ?: get_query_var( 'year' );$crumb = $this->args['labels']['date'] . $year;
	return apply_filters( 'genesis_year_crumb', $crumb, $this->args );
	}
	/**
	* Return the month archive crumb..
	*/
	protected function get_month_crumb() {
	$year = get_query_var( 'm' ) ? mb_substr( get_query_var( 'm' ), 0, 4 ) : get_query_var( 'year' );
	$crumb = $this->get_breadcrumb_link(get_year_link( $year ),'',$year,$this->args['sep']
	);
	$crumb .= $this->args['labels']['date'] . single_month_title( ' ', false );return apply_filters( 'genesis_month_crumb', $crumb, $this->args );
	}
	/**
	* Return the day archive crumb.
	*/
	protected function get_day_crumb() {global $wp_locale;
	$year = get_query_var( 'm' ) ? mb_substr( get_query_var( 'm' ), 0, 4 ) : get_query_var( 'year' );
	$month = get_query_var( 'm' ) ? mb_substr( get_query_var( 'm' ), 4, 2 ) : get_query_var( 'monthnum' );
	$day = get_query_var( 'm' ) ? mb_substr( get_query_var( 'm' ), 6, 2 ) : get_query_var( 'day' );
	$crumb = $this->get_breadcrumb_link(get_year_link( $year ),'',$year,$this->args['sep']
	);
	$crumb .= $this->get_breadcrumb_link(get_month_link( $year, $month ),'',$wp_locale->get_month( $month ),$this->args['sep']
	);
	$crumb .= $this->args['labels']['date'] . $day . gmdate( 'S', mktime( 0, 0, 0, 1, $day ) );return apply_filters( 'genesis_day_crumb', $crumb, $this->args );
	}
	/**
	* Return the author archive crumb.
	*/
	protected function get_author_crumb() {global $wp_query;$crumb = $this->args['labels']['author'] . esc_html( $wp_query->queried_object->display_name );
	return apply_filters( 'genesis_author_crumb', $crumb, $this->args );
	}
	/**
	* Return the post type archive crumb.
	*/
	protected function get_post_type_crumb() {$crumb = $this->args['labels']['post_type'] . esc_html( post_type_archive_title( '', false ) );
	/**
	* Filter the post type archive breadcrumb.
	*/
	return apply_filters( 'genesis_post_type_crumb', $crumb, $this->args );
	}
	/**
	* Return recursive linked crumbs of category, tag or custom taxonomy parents.
	*/
	protected function get_term_parents( $parent_id, $taxonomy, $link = false, array $visited = [] ) {
	$parent = get_term( (int) $parent_id, $taxonomy );if ( is_wp_error( $parent ) ) {return '';
	}
	if ( $parent->parent && ( $parent->parent !== $parent->term_id ) && ! in_array( $parent->parent, $visited, true ) ) {$visited[] = $parent->parent;
	$chain[] = $this->get_term_parents( $parent->parent, $taxonomy, true, $visited );
	}
	if ( $link && ! is_wp_error( get_term_link( get_term( $parent->term_id, $taxonomy ), $taxonomy ) ) ) {
	$chain[] = $this->get_breadcrumb_link(
	get_term_link( get_term( $parent->term_id, $taxonomy ), $taxonomy ),'',$parent->name
	);
	} else {$chain[] = $parent->name;}return implode( $this->args['sep'], $chain );
	}
	/**
	* Return markup for the wrapped link text.
	*/
	protected function get_breadcrumb_link_text( $content ) {return genesis_markup(
	[
	'open'=> '<span %s>','close'=> '</span>','content'=> $content,'context'=> 'breadcrumb-link-text-wrap','echo'=> false,
	]);}
	/**
	* Return markup for a meta tag for each breadcrumb item.
	*/
	protected function get_breadcrumb_link_meta() {return genesis_markup(
	[
	'open'=> '<meta %s>',
	'context'=> 'breadcrumb-link-wrap-meta',
	'echo'=> false,
	]);}
	/**
	* Return markup for a link wrap for each breadcrumb link.
	*/
	protected function get_breadcrumb_link_wrap( $content ) {return genesis_markup(
	[
	'open'=> '<span %s>',
	'close'=> '</span>',
	'content'=> $content,
	'context'=> 'breadcrumb-link-wrap',
	'echo'=> false,
	]);}
	/**
	* Return anchor link for a single crumb.
	*/
	protected function get_breadcrumb_link( $url, $title, $content, $sep = '' ) {$title = '';$link = genesis_markup(
	[
	'open'=> '<a %s>',
	'close'=> '</a>',
	'content'=> $this->get_breadcrumb_link_text( $content ),
	'context'=> 'breadcrumb-link',
	'params'=> ['href'=> $url,
	],
	'echo'=> false,
	]);
	/**
	* Filter the anchor link for a single breadcrumb.
	*/
	$link = apply_filters( 'genesis_breadcrumb_link', $link, $url, $title, $content, $this->args );
	$link .= $this->get_breadcrumb_link_meta();
	$link = $this->get_breadcrumb_link_wrap( $link );if ( $sep ) {$link .= $sep;}return $link;
	}
	/**
	* Determine if static page is shown on front page..
	*/
	protected function page_shown_on_front() {return 'page' === get_option( 'show_on_front' );
	}}