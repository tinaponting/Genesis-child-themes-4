<?php
/**
* Genesis Framework.
*/
/**
* Create panels, sections, and controls in the Customizer.
*/
class Genesis_Customizer {
	/**
	* The $wp_customize object.
	*/
	protected $wp_customize;
	/**
	* Constructor.
	*/
	public function __construct( WP_Customize_Manager $wp_customize ) {$this->wp_customize = $wp_customize;
	}
	/**
	* Initialize registration.
	*/
	public function init() {
	/**
	* Fires (when hooked correctly) on `wp_customize_register`, allowing
	* the `$genesis_customizer` object to be used to create Customizer
	* panels, sections, and controls.
	*/
	do_action( 'genesis_customizer', $this );
	}
	/**
	* Register Customizer panel, sections, settings, and controls via a `$config` array.
	*/
	public function register( array $config ) {
	foreach ( $config as $panel_name => $panel ) {$this->register_panel( $panel_name, $panel );foreach ( (array) $panel['sections'] as $section_name => $section ) {$this->register_section( $section_name, $section );
	foreach ( (array) $section['controls'] as $setting_key => $control ) {$this->register_setting( $setting_key, $control['settings'], $panel );$this->register_control( $setting_key, $control, $panel );
	}}}}
	/**
	* Helper alias for $wp_customize->add_panel().
	*/
	public function register_panel( $panel_name, array $panel ) {unset( $panel['sections'] );$this->wp_customize->add_panel($panel_name,$panel
	);}
	/**
	* Helper alias for $wp_customize->add_section().
	*/
	public function register_section( $section_name, array $section ) {unset( $section['settings'] );$this->wp_customize->add_section($section_name,$section
	);}
	/**
	* Helper alias for $wp_customize->add_setting().
	*/
	public function register_setting( $setting_name, $setting, $panel ) {$defaults = ['type'=> 'option',
	];
	$setting = wp_parse_args( $setting, $defaults );
	$setting_name = isset( $panel['settings_field'] ) ? sprintf( '%s[%s]', $panel['settings_field'], $setting_name ) : $setting_name;
	$this->wp_customize->add_setting($setting_name,$setting
	);}
	/**
	* Helper alias for $wp_customize->add_control().
	*/
	public function register_control( $control_name, array $control, $panel ) {
	$control['settings'] = sprintf( '%s[%s]', $panel['settings_field'], $control_name );
	$control_name = isset( $panel['control_prefix'] ) ? $panel['control_prefix'] . '_' . $control_name : $control_name;
	$this->wp_customize->add_control($control_name,$control
	);}}