<?php
/**
* Genesis Framework.
*/
/**
* Registers a new admin page, providing content and corresponding menu item for the SEO Settings page.
*/
class Genesis_Admin_SEO_Settings extends Genesis_Admin_Basic {
	public function __construct() {
	$this->redirect_to = admin_url( 'customize.php?autofocus[panel]=genesis-seo' );
	$page_id = 'seo-settings';
	$menu_ops = ['submenu'=> [
	'parent_slug'=> 'genesis',
	'page_title'=> __( 'Genesis - SEO Settings', 'genesis' ),
	'menu_title'=> __( 'SEO Settings', 'genesis' ),
	],];
	$settings_field = GENESIS_SEO_SETTINGS_FIELD;$this->create( $page_id, $menu_ops );
	}
	/**
	* Required to use `Genesis_Admin_Basic`.
	*/
	public function admin() {}
}