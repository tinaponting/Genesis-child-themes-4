<?php
/**
* Genesis Framework.
*/
class Genesis_Sanitizer {
	/**
	* Returns a 1 or 0, for all truthy / falsy values.
	*/
	public static function one_zero( $new_value ) {return (int) (bool) $new_value;
	}
	/**
	* Returns a positive integer value.
	*/
	public static function absint( $new_value ) {return absint( $new_value );
	}
	/**
	* Removes HTML tags from string.
	*/
	public static function no_html( $new_value ) {return wp_strip_all_tags( $new_value );
	}
	/**
	* Makes URLs safe
	*/
	public static function url( $new_value ) {return esc_url_raw( $new_value );
	}
	/**
	* Makes Email Addresses safe, via sanitize_email()
	*/
	public static function email_address( $new_value ) {return sanitize_email( $new_value );
	}
	/**
	* Removes unsafe HTML tags, via wp_kses_post().
	*/
	public static function safe_html( $new_value ) {return wp_kses_post( $new_value );
	}
	/**
	* Keeps the option from being updated if the user lacks unfiltered_html
	* capability.
	*/
	public static function requires_unfiltered_html( $new_value, $old_value ) {if ( current_user_can( 'unfiltered_html' ) ) {return $new_value;}return $old_value;
	}
	/**
	* Removes unsafe HTML tags when user does not have unfiltered_html
	* capability.
	*/
	public static function unfiltered_or_safe_html( $new_value, $old_value ) {if ( current_user_can( 'unfiltered_html' ) ) {return $new_value;}return wp_kses_post( $new_value );
	}}