<?php
/**
* Genesis Framework.
*/
abstract class Genesis_Customizer_Base {
	/**
	* Define defaults, call the `register` method, add CSS to head.
	*/
	public function __construct() {
	if ( method_exists( $this, 'register' ) ) {add_action( 'customize_register', [ $this, 'register' ], 15 );
	} else {_doing_it_wrong( 'Genesis_Customizer_Base', esc_html__( 'When extending Genesis_Customizer_Base, you must create a register method.', 'genesis' ), '2.1.0' );
	}
	if ( method_exists( $this, 'scripts' ) ) {add_action( 'customize_preview_init', 'scripts' );
	}}
	/**
	* Get field name attribute value.
	*/
	protected function get_field_name( $name ) {return sprintf( '%s[%s]', $this->settings_field, $name );
	}
	/**
	* Get field ID attribute value.
	*/
	protected function get_field_id( $id ) {return sprintf( '%s[%s]', $this->settings_field, $id );
	}
	/**
	* Get field value.
	*/
	protected function get_field_value( $key ) {return genesis_get_option( $key, $this->settings_field );
	}
	/**
	* Takes an array of settings and registers them.
	*/
	protected function add_settings( array $settings, WP_Customize_Manager $wp_customize ) {
	foreach ( $settings as $key => $default ) {$wp_customize->add_setting($this->get_field_name( $key ),
	[
	'default'=> $default,'type'=> 'option',
	]
	);}}}