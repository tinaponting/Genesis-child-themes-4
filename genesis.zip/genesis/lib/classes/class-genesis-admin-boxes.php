<?php
/**
* Genesis Framework.
*/
abstract class Genesis_Admin_Boxes extends Genesis_Admin {
	/**
	* Register the meta boxes.
	*/
	abstract public function metaboxes();
	/**
	* Include the necessary sortable meta box scripts.
	*/
	public function scripts() {wp_enqueue_script( 'common' );wp_enqueue_script( 'wp-lists' );wp_enqueue_script( 'postbox' );
	}
	/**
	* Use this as the settings admin callback to create an admin page with sortable meta boxes.
	*/
	public function admin() {include GENESIS_VIEWS_DIR . '/pages/genesis-admin-boxes.php';
	}
	/**
	* Echo out the do_meta_boxes() and wrapping markup.
	*/
	public function do_metaboxes() {include GENESIS_VIEWS_DIR . '/misc/genesis-admin-boxes-holder.php';
	}
	/**
	* Add meta box to the current admin screen.
	*/
	public function add_meta_box( $handle, $title, $priority = 'default' ) {add_meta_box( $handle, $title, [ $this, 'do_meta_box' ], $this->pagehook, 'main', $priority );
	}
	/**
	* Echo out the content of a meta box.
	*/
	public function do_meta_box( $object, $meta_box ) {$view = $this->views_base . '/meta-boxes/' . $meta_box['id'] . '.php';if ( is_file( $view ) ) {include $view;
	}}
	/**
	* Initialize the settings page.
	*/
	public function settings_init() {
	add_action( 'load-' . $this->pagehook, [ $this, 'metaboxes' ] );
	add_action( $this->pagehook . '_settings_page_boxes', [ $this, 'do_metaboxes' ] );
	if ( method_exists( $this, 'layout_columns' ) ) {add_filter( 'screen_layout_columns', [ $this, 'layout_columns' ], 10, 2 );
	}}}