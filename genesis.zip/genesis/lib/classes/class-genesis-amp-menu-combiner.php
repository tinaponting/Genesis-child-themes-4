<?php
/**
* Genesis Framework.
*/
/**
* Genesis AMP Menu Combiner
*/
class Genesis_AMP_Menu_Combiner extends AMP_Base_Sanitizer {
	/**
	* XPath.
	*/
	protected $xpath;
	/**
	* Main Menu element.
	*/
	protected $main_menu;
	/**
	* Array of menu(s) to combine with the main menu.
	*/
	protected $menus_to_combine;
	/**
	* Fix up core themes to do things in the AMP way.
	*/
	public function sanitize() {if ( ! isset( $this->args['combine'] ) ) {return;
	}
	$this->xpath = new DOMXPath( $this->dom );$this->combine();
	}
	/**
	* Combine the menus.
	*/
	protected function combine() {$this->menus_to_combine = $this->args['combine'];if ( ! $this->find_main_menu() ) {return;
	}
	$this->find_and_combine();
	}
	/**
	* Find the main menu.
	*/
	protected function find_main_menu() {$main_menu_attribute = array_shift( $this->menus_to_combine );$this->main_menu = $this->find_nav_ul( $main_menu_attribute );return ! empty( $this->main_menu );
	}
	/**
	* Find and combine the nav menu items to the main menu.
	*/
	protected function find_and_combine() {foreach ( $this->menus_to_combine as $attribute ) {$nav_menu = $this->find_nav_ul( $attribute );if ( ! $nav_menu ) {continue;
	}
	$menu_items = $nav_menu->cloneNode( true );for ( $index = 0; $index < $menu_items->childNodes->length; $index++ ) {$menu_item = $menu_items->childNodes->item( $index );if ( ! ( $menu_item instanceof DOMElement ) ) {continue;
	}
	$menu_item->setAttribute( 'class', 'genesis-amp-combined ' . $menu_item->getAttribute( 'class' ) );$this->main_menu->appendChild( $menu_item );
	}}}
	/**
	* Find the nav menu's `<ul>` by it's `id` or `class` attribute.
	*/
	protected function find_nav_ul( $attribute ) {
	if ( '.' === $attribute[0] ) {$pattern = sprintf( 'contains( @class, "%s" )', ltrim( $attribute, '.' ) );
	} elseif ( '#' === $attribute[0] ) {$pattern = sprintf( '@id = "%s"', ltrim( $attribute, '#' ) );
	} else {return false;}return $this->xpath->query( "//nav[ $pattern ]//ul | //nav[ $pattern ]//div//ul" )->item( 0 );
	}}