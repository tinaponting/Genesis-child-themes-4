<?php
/**
* Genesis Framework.
*/
/**
* Abstract subclass of Genesis_Admin which adds support for displaying a form.
*/
abstract class Genesis_Admin_Form extends Genesis_Admin {
	/**
    * Output settings page form elements.
	*/
	abstract public function form();
	/**
	* Normal settings page admin.
	*/
	public function admin() {include GENESIS_VIEWS_DIR . '/pages/genesis-admin-form.php';
	}
	/**
	* Initialize the settings page, by hooking the form into the page.
	*/
	public function settings_init() {add_action( "{$this->pagehook}_settings_page_form", [ $this, 'form' ] );

	}}