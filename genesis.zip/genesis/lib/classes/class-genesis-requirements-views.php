<?php
/**
* Genesis Framework.
*/
final class Genesis_Requirements_Views {
	/**
	* Messages to be shown when requirements not met.
	*/
	private $messages;
	/**
	* Genesis_Requirements_Views constructor.
	*/
	public function __construct( array $messages ) {$this->messages = $messages;
	}
	/**
	* Adds necessary hooks for displaying requirements messaging.
	*/
	public function add_hooks() {add_action( 'admin_notices', [ $this, 'admin_notice' ] );
	}
	/**
	* Displays an admin notice when requirements are not met.
	*/
	public function admin_notice() {echo '<div class="error">';echo wp_kses_post( $this->messages() );echo '</div>';
	}
	/**
	* Formats the messages into paragraphs for display.
	*/
	private function messages() {$formatted = '';foreach ( $this->messages as $message ) {$formatted .= '<p>' . $message . '</p>';}return $formatted;
	}}