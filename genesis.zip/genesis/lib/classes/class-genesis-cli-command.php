<?php
/**
* Genesis Framework.
*/
class Genesis_Cli_Command {
/**
* Upgrade the database settings for Genesis, usually after an update.
*/
public function upgrade_db( $args, $assoc_args ) {WP_CLI::runcommand( 'genesis db upgrade' );
}}