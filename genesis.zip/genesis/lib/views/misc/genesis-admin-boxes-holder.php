<?php
/**
* Genesis Framework.
*/
global $wp_meta_boxes;
?>
<div class="metabox-holder"><div class="postbox-container">
<?php
do_action( 'genesis_admin_before_metaboxes', $this->pagehook );do_meta_boxes( $this->pagehook, 'main', null );if ( isset( $wp_meta_boxes[ $this->pagehook ]['column2'] ) ) {do_meta_boxes( $this->pagehook, 'column2', null );
}
do_action( 'genesis_admin_after_metaboxes', $this->pagehook );
?>
</div></div>