<?php
/**
* Genesis Framework.
*/
?>
<div class="wrap genesis-form">
<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
<form method="post" action="options.php">
<?php settings_fields( $this->settings_field ); ?>
<?php
do_action( "{$this->pagehook}_settings_page_form", $this->pagehook );
?>
<div class="bottom-buttons">
<?php submit_button( $this->page_ops['save_button_text'], 'primary', 'submit', false ); ?>
<?php submit_button( $this->page_ops['reset_button_text'], 'secondary genesis-js-confirm-reset', $this->get_field_name( 'reset' ), false ); ?>
</div>
</form>
</div>