<?php
/**
* Genesis Framework.
*/
?>
<h3><?php esc_html_e( 'Custom Feeds', 'genesis' ); ?></h3>
<p>
<?php esc_html_e( 'If you use Feedburner to handle your rss feed(s) you can use this function to set your site\'s native feed to redirect to your Feedburner feed.', 'genesis' ); ?>
</p><p>
<?php esc_html_e( 'By filling in the feed links calling for the main site feed, it will display as a link to Feedburner.', 'genesis' ); ?>
</p><p>
<?php esc_html_e( 'By checking the "Redirect Feed" box, all traffic to default feed links will be redirected to the Feedburner link instead.', 'genesis' ); ?>
</p>
