<?php
/**
* Genesis Framework.
*/
?>
<h3><?php esc_html_e('Breadcrumbs','genesis'); ?></h3>
<p>
<?php esc_html_e('This box lets you define where the "Breadcrumbs" display. The Breadcrumb is the navigation tool that displays where a visitor is on the site at any given moment.','genesis'); ?>
</p>