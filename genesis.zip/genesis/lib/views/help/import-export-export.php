<?php
/**
* Genesis Framework.
*/
?>
<h3><?php esc_html_e( 'Export', 'genesis' ); ?></h3>
<p>
<?php
printf( esc_html__( 'You can export your Genesis-related settings to back them up, or copy them to another site. Child themes and plugins may add their own checkboxes to the list. The settings are exported in %s format.', 'genesis' ), '<abbr title="' . esc_html__( 'JavaScript Object Notation', 'genesis' ) . '">' . esc_html__( 'JSON', 'genesis' ) . '</abbr>' );
?>
</p>