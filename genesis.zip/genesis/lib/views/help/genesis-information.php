<?php
/**
* Genesis Framework.
*/
?>
<h3><?php esc_html_e( 'Information', 'genesis' ); ?></h3>
<p>
<?php esc_html_e( 'The information box allows you to see the current Genesis theme information and display if desired.', 'genesis' ); ?>
</p><p>
<?php esc_html_e( 'Normally, this should be unchecked. You can also set to enable automatic updates.', 'genesis' ); ?>
</p><p>
<?php esc_html_e( 'This does not mean the updates happen automatically without your permission; it will just notify you that an update is available. You must select it to perform the update.', 'genesis' ); ?>
</p><p>
<?php esc_html_e( 'If you provide an email address, your site will email you when the update can be performed.', 'genesis' ); ?>
</p>