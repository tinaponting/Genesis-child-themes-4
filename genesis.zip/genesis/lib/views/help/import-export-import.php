<?php
/**
* Genesis Framework.
*/
?>
<h3><?php esc_html_e( 'Import', 'genesis' ); ?></h3>
<p>
<?php
printf( esc_html__( 'You can import a file you\'ve previously exported. The file name will start with %s followed by one or more strings indicating which settings it contains, finally followed by the date and time it was exported.', 'genesis' ), genesis_code( 'genesis-' ) );
?>
</p><p>
<?php esc_html_e( 'Once you upload an import file, it will automatically overwrite your existing settings.', 'genesis' ); ?>
<strong><?php esc_html_e( 'This cannot be undone', 'genesis' ); ?></strong>
</p>