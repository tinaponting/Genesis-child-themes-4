<?php
/**
* Genesis Framework.
*/
?>
<h3><?php esc_html_e( 'Header', 'genesis' ); ?></h3>
<p>
<?php
printf( esc_html__( 'The %1$sDynamic text%2$s option will use the Site Title and Site Description from your site\'s settings in your header.', 'genesis' ), '<strong>', '</strong>' );
?>
</p><p>
<?php
printf( esc_html__( 'The %1$sImage logo%2$s option will use a logo image file in the header instead of the site\'s title and description. This setting adds a .header-image class to your site, allowing you to specify the header image in your child theme\'s style.css. By default, the logo can be saved as logo.png and saved to the images folder of your child theme.', 'genesis' ), '<strong>', '</strong>' );
?>
</p>
