<?php
/**
* Genesis Framework.
*/
?>
<h3><?php esc_html_e( 'Doctitle Settings', 'genesis' ); ?></h3>
<p>
<?php
printf( esc_html__( '%1$sAppend Site Description%2$s will insert the site description from your General Settings after the title on your home page.', 'genesis' ), '<strong>', '</strong>' );
?>
</p><p>
<?php
printf( esc_html__( '%1$sAppend Site Name%2$s will put the site name from the General Settings after the title on inner page.', 'genesis' ), '<strong>', '</strong>' );
?>
</p><p>
<?php
printf( esc_html__( '%1$sDoctitle Append Location%2$s determines which side of the title to add the previously mentioned items.', 'genesis' ), '<strong>', '</strong>' );
?>
</p><p>
<?php
printf( esc_html__( 'The %1$sDoctitle Separator%2$s is the character that will go between the title and appended text.', 'genesis' ), '<strong>', '</strong>' );
?>
</p>