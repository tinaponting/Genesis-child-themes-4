<?php
/**
* Genesis Framework.
*/
?>
<p>
<strong><?php esc_html_e( 'Document Title', 'genesis' ); ?></strong>
<?php esc_html_e( ' &mdash; Output in the document <title> Tag.', 'genesis' ); ?>
</p><p>
<strong><?php esc_html_e( 'Meta Description', 'genesis' ); ?></strong>
<?php esc_html_e( ' &mdash; Output in the document <meta name="description" /> Tag.', 'genesis' ); ?>
</p><p>
<strong><?php esc_html_e( 'Meta Keywords', 'genesis' ); ?></strong>
<?php esc_html_e( ' &mdash; Output in the document <meta name="keywords" /> Tag.', 'genesis' ); ?>
</p><p>
<strong><?php esc_html_e( 'Canonical URL', 'genesis' ); ?></strong>
<?php
printf( esc_html__( ' &mdash; Output in the document <link rel="canonical" />. %s', 'genesis' ), 'www.mattcutts.com/blog/canonical-link-tag" target="_blank" rel="noopener noreferrer">' . esc_html__( 'Read more about Custom Canonical URL', 'genesis' ) . '</a>' );
?>
</p>