<?php
/**
* Genesis Framework.
*/
?>
<h3><?php esc_html_e( 'Comments and Trackbacks', 'genesis' ); ?></h3>
<p>
<?php esc_html_e( 'This allows a site wide decision on whether comments and trackbacks (notifications when someone links to your page) are enabled for posts and pages.', 'genesis' ); ?>
</p><p>
<?php esc_html_e( 'If you enable comments or trackbacks here, it can be disabled on an individual post or page. If you disable here, they cannot be enabled on an individual post or page.', 'genesis' ); ?>
</p>