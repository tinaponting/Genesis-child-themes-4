<?php
/**
* Genesis Framework.
*/
?>
<h3><?php esc_html_e( 'Archive Settings', 'genesis' ); ?></h3>
<p>
<?php esc_html_e( 'The Archive Headline sets the title seen on the archive page.', 'genesis' ); ?>
</p><p>
<?php esc_html_e( 'The Archive Intro Text sets the text before the archive entries to introduce the content to the viewer.', 'genesis' ); ?>
</p>