<?php
/**
* Genesis Framework.
*/
add_shortcode( 'post_date', 'genesis_post_date_shortcode' );
/**
* Produces the date of post publication.
*/
function genesis_post_date_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '','format'=> get_option( 'date_format' ),'label'=> '','relative_depth'=> 2,
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_date' );if ( 'relative' === $atts['format'] ) {
	$display  = genesis_human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ), $atts['relative_depth'] );
	$display .= ' ' . __( 'ago', 'genesis' );} else {$display = get_the_time( $atts['format'] );
	}
	$output = sprintf( '<time %s>', genesis_attr( 'entry-time' ) ) . $atts['before'] . $atts['label'] . $display . $atts['after'] . '</time>';
	return apply_filters( 'genesis_post_date_shortcode', $output, $atts );
}
add_shortcode( 'post_time', 'genesis_post_time_shortcode' );
/**
* Produces the time of post publication.
*/
function genesis_post_time_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '','format'=> get_option( 'time_format' ),'label'=> '',
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_time' );
	$output = sprintf( '<time %s>', genesis_attr( 'entry-time' ) ) . $atts['before'] . $atts['label'] . get_the_time( $atts['format'] ) . $atts['after'] . '</time>';
	return apply_filters( 'genesis_post_time_shortcode', $output, $atts );
}
add_shortcode( 'post_modified_date', 'genesis_post_modified_date_shortcode' );
/**
* Produce the post last modified date.
*/
function genesis_post_modified_date_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '','format'=> get_option( 'date_format' ),'label'=> '','relative_depth'=> 2,
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_modified_date' );
	if ( 'relative' === $atts['format'] ) {
	$display  = genesis_human_time_diff( get_the_modified_time( 'U' ), current_time( 'timestamp' ), $atts['relative_depth'] ); 
	$display .= ' ' . __( 'ago', 'genesis' );
	} else {$display = get_the_modified_time( $atts['format'] );
	}
	$output = sprintf( '<time %s>', genesis_attr( 'entry-modified-time' ) ) . $atts['before'] . $atts['label'] . $display . $atts['after'] . '</time>';
	/**
	* Change the output of the post_modified_date shortcode.
	*/
	return apply_filters( 'genesis_post_modified_date_shortcode', $output, $atts );
}
add_shortcode( 'post_modified_time', 'genesis_post_modified_time_shortcode' );
/**
* Produce the post last modified time.
*/
function genesis_post_modified_time_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '','format'=> get_option( 'time_format' ),'label'=> '',
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_modified_time' );
	$output = sprintf( '<time %s>', genesis_attr( 'entry-modified-time' ) ) . $atts['before'] . $atts['label'] . get_the_modified_time( $atts['format'] ) . $atts['after'] . '</time>';
	/**
	* Change the output of the post_modified_time shortcode.
	*/
	return apply_filters( 'genesis_post_modified_time_shortcode', $output, $atts );
}
add_shortcode( 'post_author', 'genesis_post_author_shortcode' );
/**
* Produces the author of the post (unlinked display name).
*/
function genesis_post_author_shortcode( $atts ) {if ( ! post_type_supports( get_post_type(), 'author' ) ) {return '';
	}
	$author = get_the_author();if ( ! $author ) {return '';
	}
	$defaults = ['after'=> '','before'=> '',
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_author' );$output  = sprintf( '<span %s>', genesis_attr( 'entry-author' ) );$output .= $atts['before'];
	$output .= sprintf( '<span %s>', genesis_attr( 'entry-author-name' ) ) . esc_html( $author ) . '</span>';$output .= $atts['after'];
	$output .= '</span>';return apply_filters( 'genesis_post_author_shortcode', $output, $atts );
}
add_shortcode( 'post_author_link', 'genesis_post_author_link_shortcode' );
/**
* Produces the author of the post (link to author URL).@since 1.1.0
*/
function genesis_post_author_link_shortcode( $atts ) {if ( ! post_type_supports( get_post_type(), 'author' ) ) {return '';
	}
	$url = get_the_author_meta( 'url' );if ( ! $url ) {return genesis_post_author_shortcode( $atts );
	}
	$author = get_the_author();if ( ! $author ) {return '';
	}
	$defaults = ['after'=> '','before'=> '',
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_author_link' );$output  = sprintf( '<span %s>', genesis_attr( 'entry-author' ) );$output .= $atts['before'];
	$output .= sprintf( '<a href="%s" %s>', $url, genesis_attr( 'entry-author-link' ) );
	$output .= sprintf( '<span %s>', genesis_attr( 'entry-author-name' ) );$output .= esc_html( $author );
	$output .= '</span></a>' . $atts['after'] . '</span>';return apply_filters( 'genesis_post_author_link_shortcode', $output, $atts );
}

add_shortcode( 'post_author_posts_link', 'genesis_post_author_posts_link_shortcode' );
/**
* Produces the author of the post (link to author archive).
*/
function genesis_post_author_posts_link_shortcode( $atts ) {if ( ! post_type_supports( get_post_type(), 'author' ) ) {return '';
	}
	$author = get_the_author();if ( ! $author ) {return '';
	}
	$defaults = ['after'=> '','before'=> '',
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_author_posts_link' );$url = get_author_posts_url( get_the_author_meta( 'ID' ) );
	$output  = sprintf( '<span %s>', genesis_attr( 'entry-author' ) );
	$output .= $atts['before'];$output .= sprintf( '<a href="%s" %s>', $url, genesis_attr( 'entry-author-link' ) );
	$output .= sprintf( '<span %s>', genesis_attr( 'entry-author-name' ) );$output .= esc_html( $author );
	$output .= '</span></a>' . $atts['after'] . '</span>';return apply_filters( 'genesis_post_author_posts_link_shortcode', $output, $atts );
}
add_shortcode( 'post_comments', 'genesis_post_comments_shortcode' );
/**
* Produces the link to the current post comments.
*/
function genesis_post_comments_shortcode( $atts ) {if ( ! post_type_supports( get_post_type(), 'comments' ) ) {return '';
	}
	$defaults = ['after'=> '','before'=> '','hide_if_off'=> 'enabled','more'=> __( '% Comments', 'genesis' ),'one'=> __( '1 Comment', 'genesis' ),'zero'=> __( 'Leave a Comment', 'genesis' ),
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_comments' );if ( 'enabled' === $atts['hide_if_off'] && ( ! genesis_get_option( 'comments_posts' ) || ! comments_open() ) ) {return '';
	}
	ob_start();
	comments_number( $atts['zero'], $atts['one'], $atts['more'] );$comments = ob_get_clean();
	$comments = sprintf( '<a href="%s">%s</a>', get_comments_link(), $comments );$output = genesis_markup(
	[
	'open'=> '<span class="entry-comments-link">','close'=> '</span>','content'=> $atts['before'] . $comments . $atts['after'],'context'=> 'comments-shortcode','echo'=> false,
	]);
	return apply_filters( 'genesis_post_comments_shortcode', $output, $atts );
}
add_shortcode( 'post_tags', 'genesis_post_tags_shortcode' );
/**
* Produces the tag links list.
*/
function genesis_post_tags_shortcode( $atts ) {if ( ! is_object_in_taxonomy( get_post_type(), 'post_tag' ) ) {return '';
	}
	$defaults = ['after'=> '','before'=> __( 'Tagged With: ', 'genesis' ),'sep'=> ', ',
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_tags' );
	$tags = get_the_tag_list( $atts['before'], trim( $atts['sep'] ) . ' ', $atts['after'] );
	if ( ! $tags ) {return '';
	}
	$output = sprintf( '<span %s>', genesis_attr( 'entry-tags' ) ) . $tags . '</span>';return apply_filters( 'genesis_post_tags_shortcode', $output, $atts );
}
add_shortcode( 'post_categories', 'genesis_post_categories_shortcode' );
/**
* Produces the category links list.since 1.1.0.
*/
function genesis_post_categories_shortcode( $atts ) {if ( ! is_object_in_taxonomy( get_post_type(), 'category' ) ) {return '';
	}
	$defaults = ['sep'=> ', ','before'=> __( 'Filed Under: ', 'genesis' ),'after'=> '',
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_categories' );$cats = get_the_category_list( trim( $atts['sep'] ) . ' ' );if ( ! $cats ) {return '';
	}
	$output = sprintf( '<span %s>', genesis_attr( 'entry-categories' ) ) . $atts['before'] . $cats . $atts['after'] . '</span>';return apply_filters( 'genesis_post_categories_shortcode', $output, $atts );
}
add_shortcode( 'post_terms', 'genesis_post_terms_shortcode' );
/**
* Produces the linked post taxonomy terms list.
*/
function genesis_post_terms_shortcode( $atts ) {$defaults = ['after'=> '','before'=> __( 'Filed Under: ', 'genesis' ),'sep'=> ', ','taxonomy'=> 'category',];
	/**
	* Post terms shortcode defaults.
	*/
	$defaults = apply_filters( 'genesis_post_terms_shortcode_defaults', $defaults );$atts = shortcode_atts( $defaults, $atts, 'post_terms' );
	$terms = get_the_term_list( get_the_ID(), $atts['taxonomy'], $atts['before'], trim( $atts['sep'] ) . ' ', $atts['after'] );
	if ( is_wp_error( $terms ) ) {return '';
	}
	if ( empty( $terms ) ) {return '';
	}
	$output = sprintf( '<span %s>', genesis_attr( 'entry-terms' ) ) . $terms . '</span>';return apply_filters( 'genesis_post_terms_shortcode', $output, $terms, $atts );
}
add_shortcode( 'post_edit', 'genesis_post_edit_shortcode' );
/**
* Produces the edit post link for logged in users.
*/
function genesis_post_edit_shortcode( $atts ) {if ( ! apply_filters( 'genesis_edit_post_link', true ) ) {return '';
	}
	$defaults = ['after'=> '','before'=> '','link'=> __( '(Edit)', 'genesis' ),
	];
	$atts = shortcode_atts( $defaults, $atts, 'post_edit' );ob_start();edit_post_link( $atts['link'], $atts['before'], $atts['after'] );
	$edit = ob_get_clean();$output = $edit;return apply_filters( 'genesis_post_edit_shortcode', $output, $atts );
}