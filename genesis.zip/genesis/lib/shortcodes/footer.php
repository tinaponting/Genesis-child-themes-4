<?php
/**
* Genesis Framework.
*/
add_shortcode( 'footer_copyright', 'genesis_footer_copyright_shortcode' );
/**
* Adds the visual copyright notice.
*/
function genesis_footer_copyright_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '','copyright'=> '&#x000A9;','first'=> '',
	];
	$atts = shortcode_atts( $defaults, $atts, 'footer_copyright' );$output = $atts['before'] . $atts['copyright'] . '&nbsp;';
	if ( '' !== $atts['first'] && gmdate( 'Y' ) !== $atts['first'] ) {$output .= $atts['first'] . '&#x02013;';
	}
	$output .= gmdate( 'Y' ) . $atts['after'];return apply_filters( 'genesis_footer_copyright_shortcode', $output, $atts );
}
add_shortcode( 'footer_childtheme_link', 'genesis_footer_childtheme_link_shortcode' );
/**
* Adds the link to the child theme, if the details are defined.
*/
function genesis_footer_childtheme_link_shortcode( $atts ) {$name = wp_get_theme()->get( 'Name' );$url = wp_get_theme()->get( 'ThemeURI' );if ( ! $name ) {$name = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? CHILD_THEME_NAME : '';
	}
	if ( ! $url ) {$url = defined( 'CHILD_THEME_URL' ) && CHILD_THEME_URL ? CHILD_THEME_URL : '';
	}
	if ( ! $name || ! $url || ! is_child_theme() ) {return null;
	}
	$defaults = ['after' => '','before'=> '&#x000B7;',
	];
	$atts = shortcode_atts( $defaults, $atts, 'footer_childtheme_link' );
	$output = sprintf( '%s<a href="%s">%s</a>%s', $atts['before'], esc_url( $url ), esc_html( $name ), $atts['after'] );return apply_filters( 'genesis_footer_childtheme_link_shortcode', $output, $atts );
}
add_shortcode( 'footer_genesis_link', 'genesis_footer_genesis_link_shortcode' );
/**
* Adds link to the Genesis page on the StudioPress website.
*/
function genesis_footer_genesis_link_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '','url'=> 'https://my.studiopress.com/themes/genesis/',
	];
	$atts = shortcode_atts( $defaults, $atts, 'footer_genesis_link' );
	$output = $atts['before'] . '<a href="' . esc_url( $atts['url'] ) . '">Genesis Framework</a>' . $atts['after'];return apply_filters( 'genesis_footer_genesis_link_shortcode', $output, $atts );
}
add_shortcode( 'footer_studiopress_link', 'genesis_footer_studiopress_link_shortcode' );
/**
* Adds link to the StudioPress home page.
*/
function genesis_footer_studiopress_link_shortcode( $atts ) {$defaults = ['after' => '','before'=> __( 'by', 'genesis' ),
	];
	$atts = shortcode_atts( $defaults, $atts, 'footer_studiopress_link' );
	$output = $atts['before'] . ' <a href="https://www.studiopress.com/">StudioPress</a>' . $atts['after'];return apply_filters( 'genesis_footer_studiopress_link_shortcode', $output, $atts );
}
add_shortcode( 'footer_wordpress_link', 'genesis_footer_wordpress_link_shortcode' );
/**
* Adds link to WordPress.
* @param array|string $atts Shortcode attributes. Empty string if no attributes.
*/
function genesis_footer_wordpress_link_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '',
	];
	$atts = shortcode_atts( $defaults, $atts, 'footer_wordpress_link' );
	$output = sprintf( '%s<a href="%s">%s</a>%s', $atts['before'], 'https://wordpress.org/', 'WordPress', $atts['after'] );return apply_filters( 'genesis_footer_wordpress_link_shortcode', $output, $atts );
}
add_shortcode( 'footer_site_title', 'genesis_footer_site_title_shortcode' );
/**
* Produces the site title.
* @param array|string $atts Shortcode attributes. Empty string if no attributes.
*/
function genesis_footer_site_title_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '',
	];
	$atts = shortcode_atts( $defaults, $atts, 'footer_site_title' );$output = $atts['before'] . get_bloginfo( 'name' ) . $atts['after'];return apply_filters( 'genesis_footer_site_title_shortcode', $output, $atts );
}
add_shortcode( 'footer_home_link', 'genesis_footer_home_link_shortcode' );
/**
* Produces a link to the home URL.
* @param array|string $atts Shortcode attributes. Empty string if no attributes.
*/
function genesis_footer_home_link_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '','text'=> get_bloginfo( 'name' ),
	];
	$atts = shortcode_atts( $defaults, $atts, 'footer_home_link' );
	$output = sprintf( '%s<a href="%s">%s</a>%s', $atts['before'], home_url(), $atts['text'], $atts['after'] );return apply_filters( 'genesis_footer_home_link_shortcode', $output, $atts );
}
add_shortcode( 'footer_loginout', 'genesis_footer_loginout_shortcode' );
/**
* Adds admin login / logout link.
* @param array|string $atts Shortcode attributes. Empty string if no attributes.
*/
function genesis_footer_loginout_shortcode( $atts ) {$defaults = ['after'=> '','before'=> '','redirect'=> '',
	];
	$atts= shortcode_atts( $defaults, $atts, 'footer_loginout' );
	if ( ! is_user_logged_in() ) {$link = '<a href="' . esc_url( wp_login_url( $atts['redirect'] ) ) . '">' . __( 'Log in', 'genesis' ) . '</a>';
	} else {$link = '<a href="' . esc_url( wp_logout_url( $atts['redirect'] ) ) . '">' . __( 'Log out', 'genesis' ) . '</a>';
	}
	$output = $atts['before'] . apply_filters( 'loginout', $link ) . $atts['after']; return apply_filters( 'genesis_footer_loginout_shortcode', $output, $atts );
}