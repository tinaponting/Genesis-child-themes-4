<?php
/**
* Genesis Framework.
*/
/**
* Enable the author box for ALL users.
*/
function genesis_enable_author_box( $args = [] ) {$args = wp_parse_args($args,
	[
	'type'=> 'single',
	]);
	if ( 'single' === $args['type'] ) {add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );
	} elseif ( 'archive' === $args['type'] ) {add_filter( 'get_the_author_genesis_author_box_archive', '__return_true' );
	}}
/**
* Redirect the user to an admin page, and add query args to the URL string for alerts, etc.
*/
function genesis_admin_redirect( $page, array $query_args = [] ) {if ( ! $page ) {return;
	}
	$url = html_entity_decode( menu_page_url( $page, 0 ) );
	foreach ( $query_args as $key => $value ) {if ( empty( $key ) && empty( $value ) ) {unset( $query_args[ $key ] );
	}}
	$url = add_query_arg( $query_args, $url );wp_safe_redirect( esc_url_raw( $url ) );
}
add_action( 'template_redirect', 'genesis_custom_field_redirect', 20 );
/**
* Redirect singular page to an alternate URL.
*/
function genesis_custom_field_redirect() {if ( ! is_singular() ) {return;
	}
	$url = genesis_get_custom_field( 'redirect' );if ( $url ) {wp_redirect( esc_url_raw( $url ), 301 ); exit;
	}}
/**
* Return a specific value from the array passed as the second argument to `add_theme_support()`.
*/
function genesis_get_theme_support_arg( $feature, $arg, $default = '' ) {
	$support = get_theme_support( $feature );if ( ! $arg && $support ) {return true;
	}
	if ( ! $support || ! isset( $support[0] ) ) {return $default;
	}
	if ( array_key_exists( $arg, (array) $support[0] ) ) {return $support[0][ $arg ];
	}
	if ( in_array( $arg, (array) $support[0], true ) ) {return true;}return $default;
}
/**
* Check if the environment is in development mode via SCRIPT_DEBUG constant.
*/
function genesis_is_in_dev_mode() {return defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG;
}
/**
* Gets the theme handle from the CHILD_THEME_VERSION constant (if defined), or 'Theme Name' header in style.css.
*/
function genesis_get_theme_handle() {static $handle;if ( is_null( $handle ) ) {
	if ( defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ) {$handle = sanitize_title_with_dashes( CHILD_THEME_NAME );
	} else {$handle = sanitize_title_with_dashes( wp_get_theme()->get( 'Name' ) );}}return $handle;
}
/**
* Gets the active theme version from CHILD_THEME_VERSION constant (if defined), style.css in production, or a timestamp if SCRIPT_DEBUG is true.
 */
function genesis_get_theme_version() {if ( genesis_is_in_dev_mode() ) {return (string) time();
	}
	static $version;if ( is_null( $version ) ) {
	if ( defined( 'CHILD_THEME_VERSION' ) && CHILD_THEME_VERSION ) {$version = CHILD_THEME_VERSION;} else {$version = wp_get_theme()->get( 'Version' );}}return $version;
}
/**
* Locate and require a config file.
*/
function genesis_get_config( $config ) {
	$parent_file = sprintf( '%s/config/%s.php', get_template_directory(), $config );
	$child_file = sprintf( '%s/config/%s.php', get_stylesheet_directory(), $config );
	$data = [];if ( is_readable( $child_file ) ) {$data = require $child_file;
	}
	if ( empty( $data ) && is_readable( $parent_file ) ) {$data = require $parent_file;}return (array) $data;
}
/**
* Detect active plugin by constant, class or function existence.
*/
function genesis_detect_plugin( array $plugins ) {
	if ( isset( $plugins['classes'] ) ) {foreach ( $plugins['classes'] as $name ) {if ( class_exists( $name ) ) {return true;
	}}}
	if ( isset( $plugins['functions'] ) ) {foreach ( $plugins['functions'] as $name ) {if ( function_exists( $name ) ) {return true;
	}}}
	if ( isset( $plugins['constants'] ) ) {foreach ( $plugins['constants'] as $name ) {if ( defined( $name ) ) {return true;}}}return false;
}
/**
* Check that we're targeting a specific Genesis admin page.
*/
function genesis_is_menu_page( $pagehook = '' ) {global $page_hook;
	if ( isset( $page_hook ) && $page_hook === $pagehook ) {return true;
	}
	if ( isset( $_REQUEST['page'] ) && $_REQUEST['page'] === $pagehook ) { return true;}return false;
}
/**
* Check whether we are currently viewing the site via the WordPress Customizer..
*/
function genesis_is_customizer() {global $wp_customize;return is_a( $wp_customize, 'WP_Customize_Manager' ) && $wp_customize->is_preview();
}
/**
* Determine if the Blog template is being used.
*/
function genesis_is_blog_template() {global $wp_the_query;return 'page_blog.php' === get_post_meta( $wp_the_query->get_queried_object_id(), '_wp_page_template', true );
}
/**
* Get the `post_type` from the global `$post` if supplied value is empty.
*/
function genesis_get_global_post_type_name( $post_type_name = '' ) {if ( ! $post_type_name ) {global $wp_the_query;
	$queried_object = $wp_the_query->get_queried_object();
	if ( is_a( $queried_object, 'WP_Post_Type' ) ) {return $queried_object->name;}return get_post_type();}return $post_type_name;
}
/**
  Get list of custom post type objects which need an archive settings page.
*/
function genesis_get_cpt_archive_types() {static $genesis_cpt_archive_types;if ( $genesis_cpt_archive_types ) {return $genesis_cpt_archive_types;
	}
	$args = apply_filters('genesis_cpt_archives_args',
	[
	'public'=> true,'show_ui'=> true,'show_in_menu'=> true,'has_archive'=> true,'_builtin'=> false,
	]);
	$genesis_cpt_archive_types = get_post_types( $args, 'objects' );return $genesis_cpt_archive_types;
}
/**
* Get list of custom post type names which need an archive settings page.
*/
function genesis_get_cpt_archive_types_names() {$post_type_names = [];
	foreach ( genesis_get_cpt_archive_types() as $post_type ) {
	$post_type_names[] = $post_type->name;}return $post_type_names;
}
/**
* Check if a post type supports an archive setting page.
*/
function genesis_has_post_type_archive_support( $post_type_name = '' ) {
	$post_type_name = genesis_get_global_post_type_name( $post_type_name );
	return in_array( $post_type_name, genesis_get_cpt_archive_types_names(), true ) &&
	post_type_supports( $post_type_name, 'genesis-cpt-archives-settings' );
}
/**
* Determine if HTML5 is activated by the child theme.
*/
function genesis_html5() {return current_theme_supports( 'html5' );
}
/**
* Determine if theme support genesis-accessibility is activated by the child theme.
*/
function genesis_a11y( $arg = 'screen-reader-text' ) {
	$feature = 'genesis-accessibility';
	if ( 'screen-reader-text' === $arg ) {return current_theme_supports( $feature );
	}
	$support = get_theme_support( $feature );if ( ! $support ) {return false;
	}
	if ( ! isset( $support[0] ) ) {return false;
	}
	if ( in_array( $arg, $support[0], true ) ) {return true;}return false;
}
/**
* Display a HTML sitemap.
*/
function genesis_sitemap( $heading = 'h2' ) {echo wp_kses_post( genesis_get_sitemap( $heading ) );
}
/**
* Get markup for a HTML sitemap.
*/
function genesis_get_sitemap( $heading = 'h2' ) {$pre = apply_filters( 'genesis_pre_get_sitemap', null );if ( null !== $pre ) {return $pre;
	}
	$sitemap = sprintf( '<%2$s>%1$s</%2$s>', __( 'Pages:', 'genesis' ), $heading );
	$sitemap .= sprintf( '<ul>%s</ul>', wp_list_pages( 'title_li=&echo=0' ) );
	$post_counts = wp_count_posts();
	if ( $post_counts->publish > 0 ) {
	$sitemap .= sprintf( '<%2$s>%1$s</%2$s>', __( 'Categories:', 'genesis' ), $heading );
	$sitemap .= sprintf( '<ul>%s</ul>', wp_list_categories( 'sort_column=name&title_li=&echo=0' ) );
	$sitemap .= sprintf( '<%2$s>%1$s</%2$s>', __( 'Authors:', 'genesis' ), $heading );
	$sitemap .= sprintf( '<ul>%s</ul>', wp_list_authors( 'exclude_admin=0&optioncount=1&echo=0' ) );
	$sitemap .= sprintf( '<%2$s>%1$s</%2$s>', __( 'Monthly:', 'genesis' ), $heading );
	$sitemap .= sprintf( '<ul>%s</ul>', wp_get_archives( 'type=monthly&echo=0' ) );
	$sitemap .= sprintf( '<%2$s>%1$s</%2$s>', __( 'Recent Posts:', 'genesis' ), $heading );
	$sitemap .= sprintf( '<ul>%s</ul>', wp_get_archives( 'type=postbypost&limit=100&echo=0' ) );}return apply_filters( 'genesis_sitemap_output', $sitemap );
}
/**
* Build links to install plugins.
*/
function genesis_plugin_install_link( $plugin_slug = '', $text = '' ) {$page = 'plugin-install.php';$args = ['tab'=> 'plugin-information','TB_iframe'=> true,'width'=> 600,'height'=> 550,'plugin'=> $plugin_slug,
	];
	$url = add_query_arg( $args, admin_url( $page ) );if ( is_main_site() ) {
	$url = add_query_arg( $args, network_admin_url( $page ) );}return sprintf( '<a href="%s" class="thickbox">%s</a>', esc_url( $url ), esc_html( $text ) );
}
/**
* Check if the root page of the site is being viewed.
*/
function genesis_is_root_page() {return is_front_page() || ( is_home() && get_option( 'page_for_posts' ) && ! get_option( 'page_on_front' ) && ! get_queried_object() );
}
/**
* Calculate and return the canonical URL.
*/
function genesis_canonical_url() {global $wp_query;$canonical = '';$paged = (int) get_query_var( 'paged' );$page = (int) get_query_var( 'page' );if ( is_front_page() ) {
	if ( $paged ) {$canonical = get_pagenum_link( $paged );} else {$canonical = trailingslashit( home_url() );
	}}
	if ( is_singular() ) {
	$numpages = substr_count( $wp_query->post->post_content, '<!--nextpage-->' ) + 1;
	$id = $wp_query->get_queried_object_id();if ( ! $id ) {return null;
	}
	$cf = genesis_get_custom_field( '_genesis_canonical_uri' );
	if ( $cf ) {$canonical = $cf;} elseif ( $numpages > 1 && $page > 1 ) {$canonical = genesis_paged_post_url( $page, $id );} else {$canonical = get_permalink( $id );
	}}
	if ( is_category() || is_tag() || is_tax() ) {$id = $wp_query->get_queried_object_id();if ( ! $id ) {return null;
	}
	$taxonomy = $wp_query->queried_object->taxonomy;$canonical = $paged ? get_pagenum_link( $paged ) : get_term_link( (int) $id, $taxonomy );
	}
	if ( is_author() ) {$id = $wp_query->get_queried_object_id();if ( ! $id ) {return null;
	}
	$canonical = $paged ? get_pagenum_link( $paged ) : get_author_posts_url( $id );
	}
	if ( is_search() ) {$canonical = get_search_link();}return apply_filters( 'genesis_canonical_url', $canonical );
}
/**
* Checks if this web page is an AMP URL.
*/
function genesis_is_amp() {if ( ! function_exists( 'is_amp_endpoint' ) ) {return false;}return is_amp_endpoint();
}