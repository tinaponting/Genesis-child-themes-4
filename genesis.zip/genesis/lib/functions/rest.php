<?php
/**
* Genesis Framework.
*/
namespace StudioPress\Genesis\Functions\Rest;add_action( 'rest_api_init', __NAMESPACE__ . '\\layouts' );
/**
* Add `layouts` endpoint to the REST API.
*/
function layouts() {\register_rest_route('genesis/v1','/layouts/(?P<type>[a-z0-9,_-]+)',
	[
	'methods'=> 'GET',
	'callback'=> function( $params ) {
	$type = $params['type'];
	if ( strpos( $type, ',' ) !== false ) {$type = explode( ',', $type );
	}
	return \genesis_get_layouts( $type );
	},
	'permission_callback'=> '__return_true',
	]);}
add_action( 'rest_api_init', __NAMESPACE__ . '\\get_singular_images' );
/**
* Add `singular-images` endpoint to the REST API.
*/
function get_singular_images() {\register_rest_route('genesis/v1','/singular-images',
	[
	'methods'=> 'GET',
	'callback'=> '\genesis_post_types_with_singular_images_enabled',
	'permission_callback'=> '__return_true',
	]);}
add_action( 'rest_api_init', __NAMESPACE__ . '\\set_singular_images' );
/**
* Update singular image state to turn featured image output on or off for
* the provided post types.
*/
function set_singular_images() {\register_rest_route('genesis/v1','/singular-images',
	[
	'methods'=> 'PUT',
	'callback'=> function( $request ) {
	$post_types = $request->get_json_params();
	foreach ( $post_types as $type => $value ) {
	$genesis_options = get_option( GENESIS_SETTINGS_FIELD );
	$genesis_options[ "show_featured_image_{$type}" ] = $value;
	update_option( GENESIS_SETTINGS_FIELD, $genesis_options );}return \genesis_post_types_with_singular_images_enabled();
	},
	'permission_callback' => function() {return current_user_can( 'edit_theme_options' );
	},]);}

add_action( 'rest_api_init', __NAMESPACE__ . '\\get_breadcrumbs' );
/**
* Add `breadcrumbs` endpoint to the REST API.
*/
function get_breadcrumbs() {\register_rest_route('genesis/v1','/breadcrumbs',
	[
	'methods'=> 'GET',
	'callback'=> '\genesis_breadcrumb_options_enabled',
	'permission_callback'=> '__return_true',
	]);}
add_action( 'rest_api_init', __NAMESPACE__ . '\\set_breadcrumbs' );
/**
* Update breadcrumbs state to turn breadcrumb output on or off for
* the provided option type.
*/
function set_breadcrumbs() {\register_rest_route('genesis/v1','/breadcrumbs',
   [
	'methods'=> 'PUT',
	'callback'=> function( $request ) {
	$types = $request->get_json_params();
	$genesis_options = get_option( GENESIS_SETTINGS_FIELD );
	foreach ( $types as $type => $value ) {if ( strpos( $type, 'breadcrumb_' ) !== 0 ) {continue;
	}
	$genesis_options[ $type ] = $value;
	}
	update_option( GENESIS_SETTINGS_FIELD, $genesis_options );return \genesis_breadcrumb_options_enabled();
	},
	'permission_callback'=> function() {return current_user_can( 'edit_theme_options' );
	},]);}
add_action( 'rest_api_init', __NAMESPACE__ . '\\get_reading_settings' );
/**
* Presents show_on_front, page_on_front, and page_for_posts settings.
*/
function get_reading_settings() {\register_rest_route('genesis/v1','/reading-settings',
	[
	'methods'=> 'GET','callback'=> function() {
	return [
	'show_on_front'=> \get_option( 'show_on_front' ),
	'page_on_front'=> (int) \get_option( 'page_on_front' ),
	'page_for_posts'=> (int) \get_option( 'page_for_posts' ),
	];},
	'permission_callback'=> '__return_true',
	]);}