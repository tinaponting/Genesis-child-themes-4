<?php
/**
* Genesis Framework.
*/
/**
* Handles system requirements checks.
*/
function genesis_check_requirements() {$requirements_met = true;$requirements = require get_template_directory() . '/config/requirements.php';
if ( version_compare( $requirements['wordpress']['version'], $GLOBALS['wp_version'], '>' ) ) {$requirements_met = false;$messages[] = $requirements['wordpress']['i18n']['requirements'];
}
if ( version_compare( $requirements['php']['version'], PHP_VERSION, '>' ) ) {$requirements_met = false;$messages[] = $requirements['php']['i18n']['requirements'];
}
if ( $requirements_met ) {return true;}return $messages;
}
/**
* Activates the default theme when requirements are not met.
*/
function genesis_activate_fallback_theme( $stylesheet, WP_Theme $old_theme ) {unset( $_GET['activated'] );
if ( $old_theme->exists() && strpos( $old_theme->get_stylesheet(), 'genesis' ) === false ) {$fallback_stylesheet = $old_theme->get_stylesheet();
} else {$default_theme = WP_Theme::get_core_default_theme();$fallback_stylesheet = $default_theme->get_stylesheet();
}
switch_theme( $fallback_stylesheet );
}