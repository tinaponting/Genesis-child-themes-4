<?php
/**
* Genesis Framework.
*/
/**
* Calculate or return the first version of Genesis to run on this site.
*/
function genesis_first_version() {$first_version = genesis_get_option( 'first_version' );if ( ! $first_version ) {$first_version = PARENT_THEME_VERSION;}return $first_version;
}
/**
* Helper function for comparing the "first install" version to a user specified version.
*/
function genesis_first_version_compare( $version, $operator ) {return version_compare( genesis_first_version(), $version, $operator );
}
/**
* Retrieve and return the database version.
*/
function genesis_get_db_version( $cache = false ) {$db_version = genesis_get_option( 'db_version', null, $cache );if ( strlen( $db_version ) >= 3 ) {return $db_version;
}
$db_version = str_replace('.','',(string) genesis_get_option( 'theme_version', null, $cache ) ?: (string) ( (int) PARENT_DB_VERSION - 1 )
);
while ( strlen( $db_version ) < 3 ) {$db_version .= '0';}return $db_version;
}