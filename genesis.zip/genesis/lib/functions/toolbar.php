<?php
/**
* Genesis Framework.
*/
add_action( 'admin_bar_menu', 'genesis_cpt_archive_settings_link', 999 );
/**
* Adds a toolbar link to edit the custom post archive settings
*/
function genesis_cpt_archive_settings_link( $wp_admin_bar ) {if ( is_admin() || ! is_post_type_archive() || ! genesis_has_post_type_archive_support() ) {return $wp_admin_bar;
}
$post_type = get_post_type();if ( ! $post_type || ! current_user_can( apply_filters( 'genesis_cpt_archive_settings_capability_' . $post_type, 'manage_options' ) ) ) {return $wp_admin_bar;
}
$args = ['id'=> 'cpt-archive-settings','title'=> __( 'Edit Archive Settings', 'genesis' ),'href'=> admin_url( "edit.php?post_type={$post_type}&page=genesis-cpt-archive-{$post_type}" ),'meta'=> ['class'=> '',
],];
$wp_admin_bar->add_node( $args );return $wp_admin_bar;
}
add_action( 'wp_head', 'genesis_cpt_archive_settings_toolbar_styles' );
/**
* Adds the pencil icon to the CPT archive settings menu link.
*/
function genesis_cpt_archive_settings_toolbar_styles() {if ( is_admin() || ! is_user_logged_in() || ! is_admin_bar_showing() || ! is_post_type_archive() || ! genesis_has_post_type_archive_support() ) {return;
}
echo '<style type="text/css">
#wpadminbar #wp-admin-bar-cpt-archive-settings > .ab-item:before {
content: "\f464";
top: 2px;
}
</style>';
}