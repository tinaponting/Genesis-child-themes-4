<?php
/**
* Genesis Framework.
*/
/**
* Return option from the options table and cache result.
*/
function genesis_get_option( $key, $setting = null, $use_cache = true ) {
	$setting = $setting ?: GENESIS_SETTINGS_FIELD;
	$pre = apply_filters( "genesis_pre_get_option_{$key}", null, $setting );
	if ( null !== $pre ) {return $pre;
	}
	if ( genesis_is_customizer() ) {$use_cache = false;
	}
	if ( ! $use_cache ) {$options = get_option( $setting );
	if ( ! is_array( $options ) || ! array_key_exists( $key, $options ) ) {return '';}return is_array( $options[ $key ] ) ? $options[ $key ] : wp_kses_decode_entities( $options[ $key ] );
	}
	static $settings_cache = [];static $options_cache = [];if ( isset( $options_cache[ $setting ][ $key ] ) ) {return $options_cache[ $setting ][ $key ];
	}
	if ( isset( $settings_cache[ $setting ] ) ) {$options = apply_filters( 'genesis_options', $settings_cache[ $setting ], $setting );
	} else {$settings_cache[ $setting ] = apply_filters( 'genesis_options', get_option( $setting ), $setting );$options = $settings_cache[ $setting ];
	}
	if ( ! is_array( $options ) || ! array_key_exists( $key, (array) $options ) ) {$options_cache[ $setting ][ $key ] = '';
	} else {$options_cache[ $setting ][ $key ] = is_array( $options[ $key ] ) ? $options[ $key ] : wp_kses_decode_entities( $options[ $key ] );}return $options_cache[ $setting ][ $key ];
}
/**
* Echo options from the options database.
*/
function genesis_option( $key, $setting = null, $use_cache = true ) {echo genesis_get_option( $key, $setting, $use_cache );
}
/**
* Return SEO options from the SEO options database.
*/
function genesis_get_seo_option( $key, $use_cache = true ) {return genesis_get_option( $key, GENESIS_SEO_SETTINGS_FIELD, $use_cache );
}
/**
* Echo an SEO option from the SEO options database.
*/
function genesis_seo_option( $key, $use_cache = true ) {genesis_option( $key, GENESIS_SEO_SETTINGS_FIELD, $use_cache );
}
/**
* Return a CPT Archive setting value from the options table.
*/
function genesis_get_cpt_option( $key, $post_type_name = '', $use_cache = true ) {
$post_type_name = genesis_get_global_post_type_name( $post_type_name );
return genesis_get_option( $key, GENESIS_CPT_ARCHIVE_SETTINGS_FIELD_PREFIX . $post_type_name, $use_cache );
}
/**
* Echo a CPT Archive option from the options table.
*/
function genesis_cpt_option( $key, $post_type_name, $use_cache = true ) {echo genesis_get_cpt_option( $key, $post_type_name, $use_cache );
}
/**
* Echo data from a post or page custom field.
*/
function genesis_custom_field( $field, $output_pattern = '%s', $post_id = null ) {$value = genesis_get_custom_field( $field, $post_id );if ( $value ) {printf( $output_pattern, $value );
}}
/**
* Return custom field post meta data.
*/
function genesis_get_custom_field( $field, $post_id = null ) {
	$post_id = empty( $post_id ) ? get_the_ID() : $post_id;if ( ! $post_id ) {return '';
	}
	$custom_field = get_post_meta( $post_id, $field, true );if ( ! $custom_field ) {return '';
	}
	return is_array( $custom_field ) ? $custom_field : wp_kses_decode_entities( $custom_field );
}
/**
* Save post meta / custom field data for a post or page.
*/
function genesis_save_custom_fields( array $data, $nonce_action, $nonce_name, $post, $deprecated = null ) {
	if ( ! empty( $deprecated ) ) {_deprecated_argument( __FUNCTION__, '2.0.0' );
	}
	if ( ! isset( $_POST[ $nonce_name ] ) || ! wp_verify_nonce( $_POST[ $nonce_name ], $nonce_action ) ) {return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {return;
	}
	if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {return;
	}
	if ( defined( 'DOING_CRON' ) && DOING_CRON ) {return;
	}
	if ( null !== $deprecated ) {$post = get_post( $deprecated );} else {$post = get_post( $post );
	}
	if ( 'revision' === get_post_type( $post ) ) {return;
	}
	if ( ! current_user_can( 'edit_post', $post->ID ) ) {return;
	}
	foreach ( $data as $field => $value ) {if ( $value ) {update_post_meta( $post->ID, $field, $value );} else {delete_post_meta( $post->ID, $field );
	}}}
/**
* Get an expiring database setting.
*/
function genesis_get_expiring_setting( $setting, $current_time = null ) {
	if ( is_null( $current_time ) ) {$current_time = time();
	}
	$setting = 'genesis_expiring_setting_' . $setting;
	if ( (int) $current_time >= (int) get_option( $setting . '_expiration' ) ) {
	delete_option( $setting );
	delete_option( $setting . '_expiration' );return false;}return get_option( $setting );
}
/**
* Set an expiring database setting.
*/
function genesis_set_expiring_setting( $setting, $value, $duration ) {
$setting = 'genesis_expiring_setting_' . $setting;
update_option( $setting . '_expiration', time() + $duration, false );return update_option( $setting, $value, false );
}
/**
* Delete an expiring database setting.
*/
function genesis_delete_expiring_setting( $setting ) {$setting = 'genesis_expiring_setting_' . $setting;delete_option( $setting . '_expiration' );return delete_option( $setting );
}
/**
* Takes an array of new settings, merges them with the old settings, and pushes them into the database.
*/
function genesis_update_settings( $new = '', $setting = GENESIS_SETTINGS_FIELD ) {$old = get_option( $setting );
$settings = wp_parse_args( $new, $old );foreach ( $settings as $key => $value ) {if ( 'unset' === $value ) {unset( $settings[ $key ] );}}return update_option( $setting, $settings );
}