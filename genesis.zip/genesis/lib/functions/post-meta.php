<?php
/**
* Genesis Framework.
*/
add_action( 'init', 'genesis_register_post_meta' );
/**
* Register post meta for Genesis Block Editor features, such as the title
* and breadcrumbs checkbox controls.
*/
function genesis_register_post_meta() {$args = ['auth_callback'=> '__return_true','type'=> 'boolean','single'=> true,'show_in_rest'=> true,
];
$string_args = array_merge( $args, [ 'type' => 'string' ] );
register_meta('post', '_genesis_hide_title', $args );
register_meta('post', '_genesis_hide_breadcrumbs', $args );
register_meta('post', '_genesis_hide_singular_image', $args );
register_meta('post', '_genesis_hide_footer_widgets', $args );
register_meta('post', '_genesis_custom_body_class', $string_args );
register_meta('post', '_genesis_custom_post_class', $string_args );
register_meta('post', '_genesis_layout', $string_args );
}