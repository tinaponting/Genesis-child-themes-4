<?php
/*** Genesis Framework.* @package Genesis\Updates*/
/**
* Ping https://api.genesistheme.com/ asking if a new version of this theme is available.
*/
function genesis_update_check() {if ( ! genesis_get_option( 'update' ) || ! current_theme_supports( 'genesis-auto-updates' ) ) {return [];
	}
	static $genesis_update = null;if ( ! $genesis_update ) {$genesis_update = genesis_get_expiring_setting( 'update' );
	}
	if ( ! $genesis_update ) {$update_config = require GENESIS_CONFIG_DIR . '/update-check.php';
	$update_config['post_args'] = apply_filters('genesis_update_remote_post_options',$update_config['post_args']
	);
	$update_check = new Genesis_Update_Check( $update_config );
	if ( ! $update_check->get_update() ) {$genesis_update = ['new_version'=> PARENT_THEME_VERSION,
	];
	genesis_set_expiring_setting( 'update', $genesis_update, HOUR_IN_SECONDS );return [];
	}
	$genesis_update = $update_check->get_update();
	genesis_set_expiring_setting( 'update', $genesis_update, DAY_IN_SECONDS );
	}
	if ( version_compare( PARENT_THEME_VERSION, $genesis_update['new_version'], '>=' ) ) {return [];}return $genesis_update;
}
/**
* Upgrade the database to latest version.
*/
function genesis_upgrade_db_latest() {genesis_update_settings(
	[
	'theme_version'=> PARENT_THEME_VERSION,
	'db_version'=> PARENT_DB_VERSION,
	'upgrade'=> 1,
	]);}
add_action( 'admin_init', 'genesis_upgrade', 20 );
/**
* Update Genesis to the latest version.
*/
function genesis_upgrade() {if ( genesis_get_db_version() >= PARENT_DB_VERSION ) {return;
	}
	global $wp_db_version;if ( (int) get_option( 'db_version' ) !== (int) $wp_db_version ) {
    ( admin_url( 'upgrade.php?_wp_http_referer=' . rawurlencode( wp_unslash( esc_url( $_SERVER['REQUEST_URI'] ) ) ) ) );exit;
	}
	$version_map = genesis_get_config( 'update-versions' );
	foreach ( $version_map as $version ) {
	if ( version_compare( genesis_get_db_version(), $version, '<' ) ) {
	$upgrader_class = "\StudioPress\Genesis\Upgrade\Upgrade_DB_{$version}";
	if ( ! class_exists( $upgrader_class ) ) {continue;
	}
	$upgrader = new $upgrader_class();if ( ! $upgrader instanceof \StudioPress\Genesis\Upgrade\Upgrade_DB_Interface ) {continue;}$upgrader->upgrade();
	}}
	if ( genesis_get_db_version() < PARENT_DB_VERSION ) {genesis_upgrade_db_latest();
	}
	wp_cache_flush();wp_cache_delete( 'alloptions', 'options' );do_action( 'genesis_upgrade' );
}
add_action( 'wpmu_upgrade_site', 'genesis_network_upgrade_site' );
/**
* Run silent upgrade on each site in the network during a network upgrade.
*/
function genesis_network_upgrade_site( $blog_id ) {
	switch_to_blog( $blog_id );$upgrade_url = add_query_arg(['action'=> 'genesis-silent-upgrade',
	],
	admin_url( 'admin-ajax.php' )
	);
	restore_current_blog();wp_remote_get( esc_url_raw( $upgrade_url ) );
}
add_action( 'wp_ajax_no_priv_genesis-silent-upgrade', 'genesis_silent_upgrade' );
/**
* Genesis settings upgrade. Silent upgrade (no redirect).
*/
function genesis_silent_upgrade() {remove_action( 'genesis_upgrade', 'genesis_upgrade_redirect' );genesis_upgrade();exit( 0 );
}
add_action( 'upgrader_process_complete', 'genesis_update_complete', 10, 2 );
/**
* Upgrade the Genesis database after an update has completed.
*/
function genesis_update_complete( $upgrader, $hook_extra ) {
	if ( 'update' !== $hook_extra['action'] || 'theme' !== $hook_extra['type'] ) {return;
	}
	if ( isset( $hook_extra['themes'] ) && ! in_array( 'genesis', $hook_extra['themes'], true ) ) {return;
	}
	if ( isset( $hook_extra['theme'] ) && 'genesis' !== $hook_extra['theme'] ) {return;
	}
	$silent_upgrade_url = add_query_arg(['action'=> 'genesis-silent-upgrade',],admin_url( 'admin-ajax.php' )
	);
	wp_remote_get($silent_upgrade_url,
	[
	'timeout'=> 0.01,'blocking'=> false,
	]);}
add_filter( 'update_theme_complete_actions', 'genesis_update_action_links', 10, 2 );
/**
* Filter the action links at the end of an update.
*/
function genesis_update_action_links( array $actions, $theme ) {
	if ( 'genesis' !== $theme ) {return $actions;
	}
	return [sprintf(
	'<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
	'https://genesischangelog.com/',
	esc_html__( 'Check out what\'s new', 'genesis' )
	),
	sprintf(
	'<a href="%s">%s</a>',
	admin_url( 'customize.php?autofocus[panel]=genesis' ),
	esc_html__( 'Theme Settings', 'genesis' )
	),];}
add_action( 'admin_notices', 'genesis_update_nag' );
/**
* Display the update nag at the top of the dashboard if there is a Genesis update available.
*/
function genesis_update_nag() {
	if ( defined( 'DISALLOW_FILE_MODS' ) && true === DISALLOW_FILE_MODS ) {return;
	}
	$genesis_update = genesis_update_check();if ( ! $genesis_update || ! is_super_admin() ) {return;
	}
	echo '<div id="update-nag">';printf(
	esc_html__( 'Genesis %1$s is available. %2$s or %3$s.', 'genesis' ),
	esc_html( $genesis_update['new_version'] ),
	sprintf(
	'<a href="%1$s" class="%2$s">%3$s</a>',
	esc_url( $genesis_update['changelog_url'] ),
	esc_attr( 'thickbox thickbox-preview' ),
	esc_html__( 'Check out what\'s new', 'genesis' )
	),
	sprintf(
	'<a href="%1$s" class="%2$s">%3$s</a>',
	esc_url( wp_nonce_url( 'update.php?action=upgrade-theme&amp;theme=genesis', 'upgrade-theme_genesis' ) ),
	esc_attr( 'genesis-js-confirm-upgrade' ),
	esc_html__( 'update now', 'genesis' )));echo '</div>';
}
add_action( 'init', 'genesis_update_email' );
/**
* Sends out update notification email.
*/
function genesis_update_email() {
	$email_on = genesis_get_option( 'update_email' );
	$email = genesis_get_option( 'update_email_address' );
	if ( ! $email_on || ! is_email( $email ) ) {return;
	}
	$update_check = genesis_update_check();
	if ( ! $update_check ) {return;
	}
	if ( get_option( 'genesis-update-email' ) === $update_check['new_version'] ) {return;
	}
	$subject = sprintf( __( 'Genesis %1$s is available for %2$s', 'genesis' ), esc_html( $update_check['new_version'] ), home_url() );
	$message = sprintf( __( 'Genesis %s is now available. We have provided 1-click updates for this theme, so please log into your dashboard and update at your earliest convenience.', 'genesis' ), esc_html( $update_check['new_version'] ) );
	$message .= "\n\n" . wp_login_url();
	update_option( 'genesis-update-email', $update_check['new_version'], true );wp_mail( sanitize_email( $email ), $subject, $message );
}
add_filter( 'pre_set_site_transient_update_themes', 'genesis_disable_wporg_updates' );
add_filter( 'pre_set_transient_update_themes', 'genesis_disable_wporg_updates' );
/**
* Disable WordPress from giving update notifications on Genesis or Genesis child themes.
*/
function genesis_disable_wporg_updates( $value ) {foreach ( wp_get_themes() as $theme ) {if ( 'genesis' === $theme->get( 'Template' ) ) {unset( $value->response[ $theme->get_stylesheet() ] );}}return $value;
}
add_filter( 'site_transient_update_themes', 'genesis_update_push' );
add_filter( 'transient_update_themes', 'genesis_update_push' );
/**
* Integrate the Genesis update check into the WordPress update checks.
*/
function genesis_update_push( $value ) {if ( ! is_object( $value ) ) {return $value;
	}
	if ( defined( 'DISALLOW_FILE_MODS' ) && true === DISALLOW_FILE_MODS ) {return $value;
	}
	if ( isset( $value->response['genesis'] ) ) {unset( $value->response['genesis'] );
	}
	$genesis_update = genesis_update_check();if ( $genesis_update ) {$value->response['genesis'] = $genesis_update;}return $value;
}
add_action( 'load-update-core.php', 'genesis_clear_update_transient' );
add_action( 'load-themes.php', 'genesis_clear_update_transient' );
/**
* Delete Genesis update transient after updates or when viewing the themes page.
*/
function genesis_clear_update_transient() {genesis_delete_expiring_setting( 'update' );remove_action( 'admin_notices', 'genesis_update_nag' );
}
/**
* Converts array of keys from Genesis options to vestigial options.
*/
function _genesis_vestige( array $keys = [], $setting = GENESIS_SETTINGS_FIELD ) {if ( ! $keys ) {return;
	}
	$options = get_option( $setting );$vestige = get_option( 'genesis-vestige' );$new_vestige = [];foreach ( $keys as $key ) {
	if ( isset( $options[ $key ] ) ) {$new_vestige[ $key ] = $options[ $key ];unset( $options[ $key ] );
	}}
	if ( ! $new_vestige ) {return;
	}
	$vestige = $vestige ? wp_parse_args( $new_vestige, $vestige ) : $new_vestige;update_option( 'genesis-vestige', $vestige );update_option( $setting, $options );
}