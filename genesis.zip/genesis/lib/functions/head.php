<?php
/**
* Genesis Framework.
*/
/**
* Determine the meta description based on contextual criteria.
*/
function genesis_get_seo_meta_description() {$description = '';$post_id = null;if ( genesis_is_root_page() ) {$description = genesis_get_seo_option( 'home_description' ) ?: get_bloginfo( 'description' );
	}
	if ( is_home() && get_option( 'page_for_posts' ) && get_queried_object_id() ) {$post_id = get_option( 'page_for_posts' );
	}
	if ( null !== $post_id || is_singular() ) {
	if ( genesis_get_custom_field( '_genesis_description', $post_id ) ) {$description = genesis_get_custom_field( '_genesis_description', $post_id );
	} elseif ( genesis_get_custom_field( '_aioseop_description', $post_id ) ) {$description = genesis_get_custom_field( '_aioseop_description', $post_id );
	} elseif ( genesis_get_custom_field( '_headspace_description', $post_id ) ) {$description = genesis_get_custom_field( '_headspace_description', $post_id );
	} elseif ( genesis_get_custom_field( 'thesis_description', $post_id ) ) {$description = genesis_get_custom_field( 'thesis_description', $post_id );
	} elseif ( genesis_get_custom_field( 'description', $post_id ) ) {$description = genesis_get_custom_field( 'description', $post_id );
	}
	} elseif ( is_category() || is_tag() || is_tax() ) {$term = get_queried_object();$term_description = get_term_meta( $term->term_id, 'description', true );$description = ! empty( $term_description ) ? $term_description : '';
	} elseif ( is_post_type_archive() && genesis_has_post_type_archive_support() ) {$cpt_description = genesis_get_cpt_option( 'description' );$description = $cpt_description ?: '';
	} elseif ( is_author() ) {$description = get_the_author_meta( 'meta_description', (int) get_query_var( 'author' ) );
	}
	$description = apply_filters( 'genesis_get_seo_meta_description', $description );return trim( $description );
}
/**
* Determine the meta keywords based on contextual criteria.
*/
function genesis_get_seo_meta_keywords() {$keywords = '';$post_id  = null;if ( genesis_is_root_page() ) {$keywords = genesis_get_seo_option( 'home_keywords' );
	}
	if ( is_home() && get_option( 'page_for_posts' ) && get_queried_object_id() ) {$post_id = get_option( 'page_for_posts' );
	}
	if ( null !== $post_id || is_singular() ) {if ( genesis_get_custom_field( '_genesis_keywords', $post_id ) ) {$keywords = genesis_get_custom_field( '_genesis_keywords', $post_id );
	} elseif ( genesis_get_custom_field( '_aioseop_keywords', $post_id ) ) {$keywords = genesis_get_custom_field( '_aioseop_keywords', $post_id );
	} elseif ( genesis_get_custom_field( 'thesis_keywords', $post_id ) ) {$keywords = genesis_get_custom_field( 'thesis_keywords', $post_id );
	} elseif ( genesis_get_custom_field( 'keywords', $post_id ) ) {$keywords = genesis_get_custom_field( 'keywords', $post_id );
	}
	} elseif ( is_category() || is_tag() || is_tax() ) {$term = get_queried_object();$keywords = get_term_meta( $term->term_id, 'keywords', true );
	} elseif ( is_post_type_archive() && genesis_has_post_type_archive_support() ) {$keywords = genesis_get_cpt_option( 'keywords' ) ?: '';
	} elseif ( is_author() ) {$keywords = get_the_author_meta( 'meta_keywords', (int) get_query_var( 'author' ) );
	}
	$keywords = apply_filters( 'genesis_get_seo_meta_keywords', $keywords );return trim( $keywords );
}
/**
* Determine the `noindex`, `nofollow`, `noarchive` robots meta code for the current context.
*/
function genesis_get_robots_meta_content() {global $wp_query;$post_id = null;$directives = ['noindex'=> '','nofollow'=> '','noarchive'=> genesis_get_seo_option( 'noarchive' ) ? 'noarchive' : '',
	];
	if ( genesis_is_root_page()){
	$directives['noindex'] = genesis_get_seo_option( 'home_noindex' ) ? 'noindex' : $directives['noindex'];
	$directives['nofollow'] = genesis_get_seo_option( 'home_nofollow' ) ? 'nofollow' : $directives['nofollow'];
	$directives['noarchive'] = genesis_get_seo_option( 'home_noarchive' ) ? 'noarchive' : $directives['noarchive'];
	}
	if ( is_home() && get_option( 'page_for_posts' ) && get_queried_object_id() ) {$post_id = get_option( 'page_for_posts' );
	}
	if ( null !== $post_id || is_singular() ) {$directives['noindex'] = genesis_get_custom_field( '_genesis_noindex', $post_id ) ? 'noindex' : $directives['noindex'];$directives['nofollow']= genesis_get_custom_field( '_genesis_nofollow', $post_id ) ? 'nofollow' : $directives['nofollow'];$directives['noarchive'] = genesis_get_custom_field( '_genesis_noarchive', $post_id ) ? 'noarchive' : $directives['noarchive'];
	} elseif ( is_category() || is_tag() || is_tax() ) {$term = $wp_query->get_queried_object();$directives['noindex'] = get_term_meta( $term->term_id, 'noindex', true ) ? 'noindex' : $directives['noindex'];$directives['nofollow'] = get_term_meta( $term->term_id, 'nofollow', true ) ? 'nofollow' : $directives['nofollow'];$directives['noarchive'] = get_term_meta( $term->term_id, 'noarchive', true ) ? 'noarchive' : $directives['noarchive'];if ( is_category() ) {$directives['noindex'] = genesis_get_seo_option( 'noindex_cat_archive' ) ? 'noindex' : $directives['noindex'];$directives['noarchive'] = genesis_get_seo_option( 'noarchive_cat_archive' ) ? 'noarchive' : $directives['noarchive'];
	} elseif ( is_tag() ) {$directives['noindex'] = genesis_get_seo_option( 'noindex_tag_archive' ) ? 'noindex' : $directives['noindex'];$directives['noarchive'] = genesis_get_seo_option( 'noarchive_tag_archive' ) ? 'noarchive' : $directives['noarchive'];
	}
	} elseif ( is_post_type_archive() && genesis_has_post_type_archive_support() ) {$directives['noindex'] = genesis_get_cpt_option( 'noindex' ) ? 'noindex' : $directives['noindex'];$directives['nofollow'] = genesis_get_cpt_option( 'nofollow' ) ? 'nofollow' : $directives['nofollow'];$directives['noarchive'] = genesis_get_cpt_option( 'noarchive' ) ? 'noarchive' : $directives['noarchive'];
	} elseif ( is_author() ) {$directives['noindex'] = get_the_author_meta( 'noindex', (int) get_query_var( 'author' ) ) ? 'noindex' : $directives['noindex'];$directives['nofollow'] = get_the_author_meta( 'nofollow', (int) get_query_var( 'author' ) ) ? 'nofollow' : $directives['nofollow'];$directives['noarchive'] = get_the_author_meta( 'noarchive', (int) get_query_var( 'author' ) ) ? 'noarchive' : $directives['noarchive'];$directives['noindex'] = genesis_get_seo_option( 'noindex_author_archive' ) ? 'noindex' : $directives['noindex'];$directives['noarchive'] = genesis_get_seo_option( 'noarchive_author_archive' ) ? 'noarchive' : $directives['noarchive'];
	} elseif ( is_date() ) {$directives['noindex'] = genesis_get_seo_option( 'noindex_date_archive' ) ? 'noindex' : $directives['noindex'];$directives['noarchive'] = genesis_get_seo_option( 'noarchive_date_archive' ) ? 'noarchive' : $directives['noarchive'];
	} elseif ( is_search() ) {$directives['noindex'] = genesis_get_seo_option( 'noindex_search_archive' ) ? 'noindex' : $directives['noindex'];$directives['noarchive'] = genesis_get_seo_option( 'noarchive_search_archive' ) ? 'noarchive' : $directives['noarchive'];
	}
	$directives = apply_filters( 'genesis_get_robots_meta_content', $directives );$directives = array_filter( $directives );return implode( ',', $directives );
}
/**
* Return favicon URL.
*/
function genesis_get_favicon_url() {$pre = apply_filters( 'genesis_pre_load_favicon', false );if ( false !== $pre ) {$favicon = $pre;
	} elseif ( file_exists( CHILD_DIR . '/images/favicon.ico' ) ) {$favicon = CHILD_URL . '/images/favicon.ico';
	} elseif ( file_exists( CHILD_DIR . '/images/favicon.gif' ) ) {$favicon = CHILD_URL . '/images/favicon.gif';
	} elseif ( file_exists( CHILD_DIR . '/images/favicon.png' ) ) {$favicon = CHILD_URL . '/images/favicon.png';
	} elseif ( file_exists( CHILD_DIR . '/images/favicon.jpg' ) ) {$favicon = CHILD_URL . '/images/favicon.jpg';
	} else {$favicon = GENESIS_IMAGES_URL . '/favicon.ico';
	}
	$favicon = apply_filters( 'genesis_favicon_url', $favicon );return trim( $favicon );
}