<?php
/**
* Genesis Framework.
*/
use StudioPress\Genesis\Upgrade;
/**
* Upgrade the database for changes in db version 3001.
*/
function genesis_upgrade_3001() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_3001::upgrade()' );
( new Upgrade\Upgrade_DB_3001() )->upgrade();
}
/**
* Migrate query_args and/or template for pages using page_blog.php template in 3.0.0.
*/
function genesis_upgrade_3001_page_blog() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_3001::migrate_blog_pages()' );
( new Upgrade\Upgrade_DB_3001() )->migrate_blog_pages();
}
/**
* Generate page_archive.php template file for blogs using default Genesis page_archive.php.
*/
function genesis_upgrade_3001_page_archive() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_3001::migrate_archive_pages()' );
( new Upgrade\Upgrade_DB_3001() )->migrate_archive_pages();
}
/**
* Determine if the 'Blog' page template is available.
*/
function genesis_theme_has_page_blog_template() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_3001::blog_template_exists()' );
return ( new Upgrade\Upgrade_DB_3001() )->blog_template_exists();
}
/**
* Determine if the 'Archive' page template is available.
*/
function genesis_theme_has_page_archive_template() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_3001::archive_template_exists()' );
return ( new Upgrade\Upgrade_DB_3001() )->archive_template_exists();
}
/**
* Create the 'page_blog.php' file within child theme if missing.
*/
function genesis_create_page_blog_file() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_3001::create_blog_template()' );
( new Upgrade\Upgrade_DB_3001() )->create_blog_template();
}
/**
* Create the 'page_archive.php' file within child theme if missing.
*/
function genesis_create_page_archive_file() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_3001::create_archive_template()' );
( new Upgrade\Upgrade_DB_3001() )->create_archive_template();
}
/**
* Upgrade the database for changes in db version 3000.
*/
function genesis_upgrade_3000() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_3000::upgrade()' );
( new Upgrade\Upgrade_DB_3000() )->upgrade();
}
/**
* Upgrade the database to version 2700.
*/
function genesis_upgrade_2700() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2700::upgrade()' );
( new Upgrade\Upgrade_DB_2700() )->upgrade();
}
/**
* Upgrade the database to version 2603.
*/
function genesis_upgrade_2603() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2603::upgrade()' );
( new Upgrade\Upgrade_DB_2603() )->upgrade();
}
/**
* Upgrade the database to version 2501.
*/
function genesis_upgrade_2501() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2501::upgrade()' );
( new Upgrade\Upgrade_DB_2501() )->upgrade();
}
/**
* Upgrade the database to version 2403.
*/
function genesis_upgrade_2403() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2403::upgrade()' );
( new Upgrade\Upgrade_DB_2403() )->upgrade();
}
/**
* Upgrade the database to version 2209.
*/
function genesis_upgrade_2209() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2209::upgrade()' );
( new Upgrade\Upgrade_DB_2209() )->upgrade();
}
/**
* Upgrade the database to version 2207.
*/
function genesis_upgrade_2207() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2207::upgrade()' );
( new Upgrade\Upgrade_DB_2207() )->upgrade();
}
/**
* Upgrade the database to version 2201.
*/
function genesis_upgrade_2201() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2201::upgrade()' );
( new Upgrade\Upgrade_DB_2201() )->upgrade();
}
/**
* Upgrade the database to version 2100.
*/
function genesis_upgrade_2100() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2100::upgrade()' );
( new Upgrade\Upgrade_DB_2100() )->upgrade();
}
/**
* Upgrade the database to version 2003.
*/
function genesis_upgrade_2003() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2003::upgrade()' );
( new Upgrade\Upgrade_DB_2003() )->upgrade();
}
/**
* Upgrade the database to version 2001.
*/
function genesis_upgrade_2001() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2001::upgrade()' );
( new Upgrade\Upgrade_DB_2001() )->upgrade();
}
/**
* Upgrade the database to version 1901.
*/
function genesis_upgrade_1901() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_1901::upgrade()' );
( new Upgrade\Upgrade_DB_1901() )->upgrade();
}
/**
* Upgrade the database to version 1800.
*/
function genesis_upgrade_1800() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_1800::upgrade()' );
( new Upgrade\Upgrade_DB_1800() )->upgrade();
}
/**
* Upgrade the database to version 1700.
*/
function genesis_upgrade_1700() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_1700::upgrade()' );
( new Upgrade\Upgrade_DB_1700() )->upgrade();
}
/**
* Convert term meta for new title/description options.
*/
function genesis_convert_term_meta() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_1800::convert_term_meta()' );
( new Upgrade\Upgrade_DB_1800() )->convert_term_meta();
}
/**
* Strip slashes from header and body scripts saved as post meta.
*/
function genesis_unslash_post_meta_scripts() {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Upgrade\Upgrade_DB_2603::unslash_post_meta_scripts()' );
( new Upgrade\Upgrade_DB_2603() )->unslash_post_meta_scripts();
}
/**
* Add attributes for site footer element.
*/
function genesis_attributes_site_footer( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\site_footer' );
	$attributes['itemscope'] = true;
	$attributes['itemtype'] = 'https://schema.org/WPFooter';return $attributes;
}
/**
* Add attributes for author box element.
*/
function genesis_attributes_author_box( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\author_box' );
	$attributes['itemprop']  = 'author';
	$attributes['itemscope'] = true;
	$attributes['itemtype']  = 'https://schema.org/Person';return $attributes;
}
/**
* Add attributes for comment content container.
*/
function genesis_attributes_comment_content( $attributes ) {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\comment_content' );
$attributes['itemprop'] = 'text';return $attributes;
}
/**
* Add attributes for comment time element.
*/
function genesis_attributes_comment_time( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\comment_time' );
	$attributes['datetime'] = esc_attr( get_comment_time( 'c' ) );
	$attributes['itemprop'] = 'datePublished';return $attributes;
}
/**
* Add attributes for comment author name element.
*/
function genesis_attributes_comment_author_name( $attributes ) {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\comment_author_name' );
$attributes['itemprop'] = 'name';return $attributes;
}
/**
* Add attributes for comment author element.
*/
function genesis_attributes_comment_author( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\comment_author' );
	$attributes['itemprop'] = 'author';
	$attributes['itemscope'] = true;
	$attributes['itemtype'] = 'https://schema.org/Person';return $attributes;
}
/**
* Add attributes for entry content element.
*/
function genesis_attributes_entry_content( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\entry_content' );
	if ( ! is_main_query() && ! genesis_is_blog_template() ) {return $attributes;
	}
	$attributes['itemprop'] = 'text';return $attributes;
}
/**
* Add attributes for entry title element.
*/
function genesis_attributes_entry_title( $attributes ) {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\entry_title' );
$attributes['itemprop'] = 'headline';return $attributes;
}
/**
* Add attributes for modified time element for an entry.
*/
function genesis_attributes_entry_modified_time( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\entry_modified_time' );
	$attributes['itemprop'] = 'dateModified';
	$attributes['datetime'] = get_the_modified_time( 'c' );return $attributes;
}
/**
* Add attributes for time element for an entry.
*/
function genesis_attributes_entry_time( $attributes ) {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\entry_time' );
$attributes['itemprop'] = 'datePublished';
$attributes['datetime'] = get_the_time( 'c' );return $attributes;
}
/**
* Add attributes for entry author name element.
*/
function genesis_attributes_entry_author_name( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\entry_author_name' );
	$attributes['itemprop'] = 'name';return $attributes;
}
/**
* Add attributes for author element for an entry.
*/
function genesis_attributes_entry_author( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\entry_author' );
	$attributes['itemprop'] = 'author';
	$attributes['itemscope'] = true;
	$attributes['itemtype'] = 'https://schema.org/Person';return $attributes;
}
/**
* Add attributes for entry image element shown in a grid loop.
*/
function genesis_attributes_entry_image_grid_loop( $attributes ) {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\entry_image_grid_loop' );
$attributes['itemprop'] = 'image';return $attributes;
}
/**
* Add typical attributes for navigation elements.
*/
function genesis_attributes_nav( $attributes ) {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\nav_primary' );
$attributes['itemscope'] = true;
$attributes['itemtype'] = 'https://schema.org/SiteNavigationElement';return $attributes;
}
/**
* Add attributes for breadcrumb link text wrap.
*/
function genesis_attributes_breadcrumb_link_text_wrap( $attributes ) {
_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\breadcrumb_link_text_wrap' );
$attributes['itemprop'] = 'name';return $attributes;
}
/**
* Add attributes for breadcrumb item element.
*/
function genesis_attributes_breadcrumb_link_wrap( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\breadcrumb_link_wrap' );
	$attributes['itemprop'] = 'itemListElement';
	$attributes['itemscope'] = true;
	$attributes['itemtype'] = 'https://schema.org/ListItem';return $attributes;
}
/**
* Add attributes for breadcrumbs wrapper.
*/
function genesis_attributes_breadcrumb( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\breadcrumb' );
	if ( is_home() ) {return $attributes;
	}
	if ( function_exists( 'breadcrumbs' ) || function_exists( 'crumbs' ) ) {return $attributes;
	}
	if ( function_exists( 'bcn_display' ) ) {
		$attributes['typeof'] = 'BreadcrumbList';$attributes['vocab'] = 'https://schema.org/';return $attributes;
	}
	$yoast_seo_breadcrumbs_enabled    = class_exists( 'WPSEO_Breadcrumbs' ) && genesis_get_option( 'breadcrumbs-enable', 'wpseo_titles' );
	$yoast_breadcrumbs_plugin_enabled = function_exists( 'yoast_breadcrumb' ) && ! class_exists( 'WPSEO_Breadcrumbs' );
	if ( $yoast_seo_breadcrumbs_enabled || $yoast_breadcrumbs_plugin_enabled ) {return $attributes;
	}r.
	$attributes['itemprop'] = 'breadcrumb';
	$attributes['itemscope'] = true;
	$attributes['itemtype'] = 'https://schema.org/BreadcrumbList';
	if ( is_singular( 'post' ) || is_archive() || is_home() || is_page_template( 'page_blog.php' ) ) {unset( $attributes['itemprop'] );}return $attributes;
}
/**
* Add attributes for site description element.
*/
function genesis_attributes_site_description( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\site_description' );
	$attributes['itemprop'] = 'description';return $attributes;
}
/**
* Add attributes for site title element.
*/
function genesis_attributes_site_title( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\site_title' );
	$attributes['itemprop'] = 'headline';return $attributes;
}
/**
* Add attributes for site header element..
*/
function genesis_attributes_header( $attributes ) {
	_deprecated_function( __FUNCTION__, '3.1.0', '\StudioPress\Genesis\Functions\Schema\site_header' );
	$attributes['itemscope'] = true;
	$attributes['itemtype']  = 'https://schema.org/WPHeader';return $attributes;
}
/**
* Filter the Primary Navigation menu items, appending either RSS links, search form, twitter link, or today's date.
*/
function genesis_nav_right( $menu, stdClass $args ) {_deprecated_function( __FUNCTION__, '3.0.0' );if ( genesis_first_version_compare( '2.0.2', '>' ) ) {return $menu;
	}
	if ( 'primary' !== $args->theme_location || ! genesis_get_option( 'nav_extras' ) ) {return $menu;
	}
	switch ( genesis_get_option( 'nav_extras' ) ) {
	case 'rss':$rss = '<a rel="nofollow" href="' . get_bloginfo( 'rss2_url' ) . '">' . __( 'Posts', 'genesis' ) . '</a>';$rss  .= '<a rel="nofollow" href="' . get_bloginfo( 'comments_rss2_url' ) . '">' . __( 'Comments', 'genesis' ) . '</a>';$menu .= '<li class="right rss">' . $rss . '</li>';break;
	case 'search':$menu .= '<li class="right search">' . get_search_form( false ) . '</li>';break;
	case 'twitter':$menu .= sprintf( '<li class="right twitter"><a href="%s">%s</a></li>', esc_url( 'https://twitter.com/' . genesis_get_option( 'nav_extras_twitter_id' ) ), esc_html( genesis_get_option( 'nav_extras_twitter_text' ) ) );break;
	case 'date':$menu .= '<li class="right date">' . date_i18n( get_option( 'date_format' ) ) . '</li>';break;}return $menu;
}
/**
* XHTML 1.0 Transitional doctype markup.
*/
function genesis_xhtml_doctype() {_deprecated_function( __FUNCTION__, '3.0.0', 'genesis_html5_doctype' );genesis_html5_doctype();
}
/**
* XHTML loop.
*/
function genesis_legacy_loop() {_deprecated_function( __FUNCTION__, '3.0.0', 'genesis_standard_loop' );genesis_standard_loop();
}
/**
* Filter the default comment form arguments, used by `comment_form()`.
*/
function genesis_comment_form_args( array $defaults ) {_deprecated_function( __FUNCTION__, '3.0.0' );return $defaults;
}
/**
* Comment callback for {@link genesis_default_list_comments()} if HTML5 is not active.
*/
function genesis_comment_callback( $comment, array $args, $depth ) {_deprecated_function( __FUNCTION__, '3.0.0', 'genesis_html5_comment_callback' );genesis_html5_comment_callback( $comment, $args, $depth );
}
/**
* Produces the "Return to Top" link.
*/
function genesis_footer_backtotop_shortcode( $atts ) {_deprecated_function( __FUNCTION__, '3.0.0' );
	$defaults = [
	'after'=> '',
	'before'=> '',
	'href'=> '#wrap',
	'nofollow'=> true,
	'text'=> __( 'Return to top of page', 'genesis' ),
	];
	$atts = shortcode_atts( $defaults, $atts, 'footer_backtotop' );return apply_filters( 'genesis_footer_backtotop_shortcode', '', $atts );
}
/**
* Deprecated. Displays the notice that the theme settings were successfully updated to the latest version.
*/
function genesis_upgraded_notice() {_deprecated_function( __FUNCTION__, '2.10.1' );
}
/**
* Deprecated. Redirect the user back to the "What's New" page, refreshing the data and notifying the user that they have
* successfully updated.
*/
function genesis_upgrade_redirect() {_deprecated_function( __FUNCTION__, '2.10.1' );
}
/**
* Deprecated. Replace the default search form with a Genesis-specific form.
*/
function genesis_search_form() {_deprecated_function( __FUNCTION__, '2.7.0', 'get_search_form()' );$search_form_template = locate_template( 'searchform.php' );ob_start();require $search_form_template;$form = ob_get_clean();return $form;
}
/**
* Deprecated. Genesis now (as of 2.7.0) uses semantic versioning, and will no longer redirect to different pages based on major/minor version status.
*/
function genesis_is_major_version( $version ) {_deprecated_function( __FUNCTION__, '2.7.0' );return '.0' === substr( $version, 3 );
}
/**
* Deprecated. Output the title, wrapped in title tags.
*/
function genesis_do_title() {_deprecated_function( __FUNCTION__, '2.6.0', "add_theme_support( 'title-tag' )" );if ( get_theme_support( 'title-tag' ) ) {return;}echo '<title>';wp_title( '' );echo '</title>';
}
/**
* Deprecated. Legacy filter function that would return a filtered document title.
*/
function genesis_default_title( $title, $sep = '&raquo;', $seplocation = '' ) {_deprecated_function( __FUNCTION__, '2.6.0', 'Genesis_SEO_Document_Title_Parts' );return $title;
}
/**
* Deprecated. Return registered image sizes.
*/
function genesis_get_additional_image_sizes() {_deprecated_function( __FUNCTION__, '2.5.0', 'wp_get_additional_image_sizes' );return wp_get_additional_image_sizes();
}
/**
* Deprecated. A list of Genesis contributors for the current development cycle.
*/
function genesis_contributors() {_deprecated_function( __FUNCTION__, '2.5.0', 'Genesis_Contributors::find_contributors' );
	$people = require GENESIS_CONFIG_DIR . '/contributors.php';
	$genesis_contributors = new Genesis_Contributors( $people );
	foreach ( $genesis_contributors->find_by_role( 'contributor' ) as $key => $contributor ) {
	$contributors[ $key ]['name'] = $contributor->get_name();
	$contributors[ $key ]['url'] = $contributor->get_profile_url();
	$contributors[ $key ]['gravatar'] = $contributor->get_avatar_url();}return $contributors;
}
/**
* Deprecated. Register the scripts that Genesis will use.
*/
function genesis_register_scripts() {_deprecated_function( __FUNCTION__, '2.5.0' );
}
/**
* Deprecated. Enqueue the scripts used on the front-end of the site.
*/
function genesis_load_scripts() {_deprecated_function( __FUNCTION__, '2.5.0' );
}
/**
* Deprecated. Conditionally enqueue the scripts used in the admin.
*/
function genesis_load_admin_scripts( $hook_suffix ) {_deprecated_function( __FUNCTION__, '2.5.0' );
}
/**
* Deprecated. Enqueues the custom script used in the admin, and localizes several strings or values used in the scripts.
*/
function genesis_load_admin_js() {_deprecated_function( __FUNCTION__, '2.5.0', 'genesis_scripts()->enqueue_and_localize_admin_scripts()' );genesis_scripts()->enqueue_and_localize_admin_scripts();
}
/**
* Deprecated. Load the html5 shiv for IE8 and below. Can't enqueue with IE conditionals.
*/
function genesis_html5_ie_fix() {_deprecated_function( __FUNCTION__, '2.3.0' );
}
/**
* Deprecated. Echo custom rel="author" link tag.
*/
function genesis_rel_author() {_deprecated_function( __FUNCTION__, '2.2.0' );
}
/**
* Deprecated. Echo custom rel="publisher" link tag.
*/
function genesis_rel_publisher() {_deprecated_function( __FUNCTION__, '2.2.0' );
}
/**
* Deprecated. Echo or return a pages or categories menu.
*/
function genesis_nav( $args = [] ) {_deprecated_function( __FUNCTION__, '2.2.0', 'genesis_nav_menu' );
	if ( isset( $args['context'] ) ) {_deprecated_argument( __FUNCTION__, '1.2', esc_html__( 'The argument, "context", has been replaced with "theme_location" in the $args array.', 'genesis' ) );
	}
	$defaults = ['theme_location'=> '','type'=> 'pages','sort_column'=> 'menu_order, post_title','menu_id'=> false,'menu_class'=> 'nav','echo'=> true,'link_before'=> '','link_after'=> '',
	];
	$defaults = apply_filters( 'genesis_nav_default_args', $defaults );
	$args = wp_parse_args( $args, $defaults );$pre = apply_filters( 'genesis_pre_nav', false, $args );if ( $pre ) {return $pre;
	}
	$menu = '';$list_args = $args;if ( isset( $args['show_home'] ) && ! empty( $args['show_home'] ) ) {$text = $args['show_home'];
	if ( in_array( $args['show_home'], [ true, '1', 1 ], true ) ) {$text = apply_filters( 'genesis_nav_home_text', __( 'Home', 'genesis' ), $args );
	}
	if ( is_front_page() && ! is_paged() ) {$class = 'class="home current_page_item"';} else {$class = 'class="home"';
	}
	$home = '<li ' . $class . '><a href="' . trailingslashit( home_url() ) . '">' . $args['link_before'] . $text . $args['link_after'] . '</a></li>';
	$menu .= genesis_get_seo_option( 'nofollow_home_link' ) ? genesis_rel_nofollow( $home ) : $home;
	if ( 'pages' === $args['type'] && 'page' === get_option( 'show_on_front' ) ) {
	$list_args['exclude'] .= $list_args['exclude'] ? ',' : '';
	$list_args['exclude'] .= get_option( 'page_on_front' );
	}}
	$list_args['echo'] = false;$list_args['title_li'] = '';
	if ( 'pages' === $args['type'] ) {$menu .= str_replace( [ "\r", "\n", "\t" ], '', wp_list_pages( $list_args ) );
	} elseif ( 'categories' === $args['type'] ) {$menu .= str_replace( [ "\r", "\n", "\t" ], '', wp_list_categories( $list_args ) );
	}
	$menu = apply_filters( 'genesis_nav_items', $menu, $args );
	$menu_class = $args['menu_class'] ? ' class="' . esc_attr( $args['menu_class'] ) . '"' : '';
	$menu_id = $args['menu_id'] ? ' id="' . esc_attr( $args['menu_id'] ) . '"' : '';
	if ( $menu ) {$menu = '<ul' . $menu_id . $menu_class . '>' . $menu . '</ul>';
	}
	$menu = apply_filters( 'genesis_nav', $menu, $args );if ( $args['echo'] ) {echo $menu;return null;}return $menu;
}
/**
* Deprecated. Wraps the page title in a `title` element.
*/
function genesis_doctitle_wrap( $title ) {_deprecated_function( __FUNCTION__, '2.1.0' );return is_feed() || is_admin() ? $title : sprintf( "<title>%s</title>\n", $title );
}
/**
* Deprecated. Push individual setting (or group of setting) into an options db entry stored as an array.
*/
function _genesis_update_settings( $new, $setting = null ) {_deprecated_function( __FUNCTION__, '2.1.0', 'genesis_update_setting' );genesis_update_settings( $new, $setting );
}
/**
 * Deprecated. Used to output archive pagination in older/newer format.
 */
function genesis_older_newer_posts_nav() {_deprecated_function( __FUNCTION__, '2.0.0', 'genesis_prev_next_posts_nav' );genesis_prev_next_posts_nav();
}
/**
* Deprecated. Show Parent and Child information in the document head if specified by the user.
*/
function genesis_show_theme_info_in_head() {
	_deprecated_function( __FUNCTION__, '2.0.0', esc_html__( 'data in style sheet files', 'genesis' ) );
	if ( ! genesis_get_option( 'show_info' ) ) {return;
	}
	echo "\n" . '<!-- Theme Information -->' . "\n";
	echo '<meta name="wp_template" content="' . esc_attr( PARENT_THEME_NAME ) . ' ' . esc_attr( PARENT_THEME_VERSION ) . '" />' . "\n";
	if ( ! is_child_theme() ) {return;
	}
	$child_info = wp_get_theme();echo '<meta name="wp_theme" content="' . esc_attr( $child_info['Name'] ) . ' ' . esc_attr( $child_info['Version'] ) . '" />' . "\n";
}
/**
* Deprecated. Helper function for dealing with entities.
*/
function g_ent( $text = '' ) {_deprecated_function( __FUNCTION__, '2.0.0', esc_html__( 'decimal or hexidecimal entities', 'genesis' ) );return apply_filters( 'g_ent', $text ); 
}
/**
 * Deprecated. Remove the Genesis theme files from the Theme Editor, except when Genesis is the current theme.
 */
function genesis_theme_files_to_edit() {_deprecated_function( __FUNCTION__, '2.0.0' );
}
/**
* Deprecated. Add links to the contents of a tweet.
*/
function genesis_tweet_linkify( $text ) {_deprecated_function( __FUNCTION__, '2.0.0' );
	$text = preg_replace( "#(^|[\n ])([\w]+?://[\w]+[^ \"\n\r\t< ]*)#", '\\1<a href="\\2" target="_blank" rel="noopener noreferrer">\\2</a>', $text );
	$text = preg_replace( "#(^|[\n ])((www|ftp)\.[^ \"\t\n\r< ]*)#", '\\1<a href="http://\\2" target="_blank" rel="noopener noreferrer">\\2</a>', $text );
	$text = preg_replace( '/@(\w+)/', '<a href="http://www.twitter.com/\\1" target="_blank" rel="noopener noreferrer">@\\1</a>', $text );
	$text = preg_replace( '/#(\w+)/', '<a href="http://search.twitter.com/search?q=\\1" target="_blank" rel="noopener noreferrer">#\\1</a>', $text );return $text;
}
/**
* Deprecated. Provide a callback function for the custom header admin page.
*/
function genesis_custom_header_admin_style() {_deprecated_function( __FUNCTION__, '2.0.0' );
}