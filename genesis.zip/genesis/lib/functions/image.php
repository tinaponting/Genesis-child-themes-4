<?php
/**
* Genesis Framework.
*/
/**
* Pull an attachment ID from a post, if one exists.
*/
function genesis_get_image_id( $index = 0, $post_id = null ) {$image_ids = array_keys(get_children([
	'post_parent'=> $post_id ?: get_the_ID(),
	'post_type'=> 'attachment',
	'post_mime_type'=> 'image',
	'orderby'=> 'menu_order',
	'order'=> 'ASC',
	]));
	if ( isset( $image_ids[ $index ] ) ) {return $image_ids[ $index ];}return false;
}
/**
* Return an image pulled from the media gallery.
*/
function genesis_get_image( $args = [] ) {$defaults = ['post_id'=> null,'format'=> 'html','size'=> 'full','num'=> 0,'attr'=> '','fallback'=> 'first-attached','context'=> '',
	];
	$defaults = apply_filters( 'genesis_get_image_default_args', $defaults, $args );$args = wp_parse_args( $args, $defaults );
	$pre = apply_filters( 'genesis_pre_get_image', false, $args, get_post() );if ( false !== $pre ) {return $pre;
	}
	if ( 0 === $args['num'] && has_post_thumbnail( $args['post_id'] ) ) {$id = get_post_thumbnail_id( $args['post_id'] );
	} elseif ( 'first-attached' === $args['fallback'] ) {$id = genesis_get_image_id( $args['num'], $args['post_id'] );
	} elseif ( is_int( $args['fallback'] ) ) {$id = $args['fallback'];
	}
	if ( isset( $id ) ) {$html = wp_get_attachment_image( $id, $args['size'], false, $args['attr'] );list( $url ) = wp_get_attachment_image_src( $id, $args['size'], false );
	} elseif ( is_array( $args['fallback'] ) ) {$id = 0;$html = $args['fallback']['html'];$url = $args['fallback']['url'];
	} else {return false;
	}
	$src = str_replace( home_url(), '', $url );
	if ( 'html' === mb_strtolower( $args['format'] ) ) {$output = $html;
	} elseif ( 'url' === mb_strtolower( $args['format'] ) ) {$output = $url;
	} else {$output = $src;
	}
	if ( empty( $url ) ) {$output = false;}return apply_filters( 'genesis_get_image', $output, $args, $id, $html, $url, $src );
}
/**
* Echo an image pulled from the media gallery.
*/
function genesis_image( $args = [] ) {$image = genesis_get_image( $args );if ( $image ) {echo $image;return null;}return false;
}
/**
* Return all registered image sizes arrays, including the standard sizes.
*/
function genesis_get_image_sizes() {global $_wp_additional_image_sizes;
	$pre = apply_filters( 'genesis_pre_get_image_sizes', false );if ( $pre ) {return $pre;
	}
	$sizes = [];foreach ( get_intermediate_image_sizes() as $size ) {if ( isset( $_wp_additional_image_sizes[ $size ] ) ) {$sizes[ $size ] = [
	'width'=> absint( $_wp_additional_image_sizes[ $size ]['width'] ),
	'height'=> absint( $_wp_additional_image_sizes[ $size ]['height'] ),
	'crop'=> $_wp_additional_image_sizes[ $size ]['crop'],
	];
	} else {$sizes[ $size ] = [
	'width'=> absint( get_option( "{$size}_size_w" ) ),
	'height'=> absint( get_option( "{$size}_size_h" ) ),
	'crop'=> (bool) get_option( "{$size}_crop" ),
	];}}
	return (array) apply_filters( 'genesis_get_image_sizes', $sizes );
}
/**
* Callback for Customizer featured image archive size.
*/
function genesis_get_image_sizes_for_customizer() {
$sizes = [];foreach ( (array) genesis_get_image_sizes() as $name => $size ) {$sizes[ $name ] = $name . ' (' . absint( $size['width'] ) . ' &#x000D7; ' . absint( $size['height'] ) . ')';}return $sizes;
}
/**
* Is the singular featured image set to display on the current page?
*/
function genesis_singular_image_hidden_on_current_page() {$post_type = get_post_type();
	$supports_singular_images = post_type_supports( $post_type, 'genesis-singular-images' );
	$singular_images_enabled = genesis_get_option( "show_featured_image_{$post_type}" );
	$image_toggle_enabled = apply_filters( 'genesis_singular_image_toggle_enabled', true );
	if ( ! $supports_singular_images || ! $singular_images_enabled || ! $image_toggle_enabled ) {return true;}return get_post_meta( get_queried_object_id(), '_genesis_hide_singular_image', true );
}
/**
* Which post types have singular images enabled and active?
*/
function genesis_post_types_with_singular_images_enabled() {
$result = [];$types_with_support = get_post_types_by_support( 'genesis-singular-images' );foreach ( $types_with_support as $type ) {
if ( genesis_get_option( "show_featured_image_{$type}", GENESIS_SETTINGS_FIELD, false ) ) {$result[] = $type;}}return $result;
}
add_filter( 'wp_get_attachment_image_attributes', 'genesis_image_loading', 10, 3 );
/**
* Filter the attributes of all images retrieved with `wp_get_attachment_image`, add `loading="lazy"` to enable lazy loading in Chrome.
*/
function genesis_image_loading( $attr ) {
if ( ! current_theme_supports( 'genesis-lazy-load-images' ) || function_exists( 'wp_lazy_loading_enabled' ) ) {return $attr;}$attr['loading'] = 'lazy';return $attr;
}