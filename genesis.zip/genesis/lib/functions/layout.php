<?php
/**
* Genesis Framework.
*/
add_action( 'genesis_setup', 'genesis_create_initial_layouts' );
/**
* Register Genesis default layouts.
*/
function genesis_create_initial_layouts() {$url = GENESIS_ADMIN_IMAGES_URL . '/layouts/';
$layouts = apply_filters( 'genesis_initial_layouts', genesis_get_config( 'layouts' ), $url );
foreach ( (array) $layouts as $layout_id => $layout_args ) {genesis_register_layout( $layout_id, $layout_args );
}}
/**
* Register new layouts in Genesis.
*/
function genesis_register_layout( $id = '', $args = [] ) {global $_genesis_layouts;if ( ! is_array( $_genesis_layouts ) ) {$_genesis_layouts = [];
	}
	if ( ! $id || isset( $_genesis_layouts[ $id ] ) ) {return false;
	}
	$defaults = ['label'=> __( 'No Label Selected', 'genesis' ),'img'=> GENESIS_ADMIN_IMAGES_URL . '/layouts/none.gif','type'=> [ 'site' ],
	];
	$args = wp_parse_args( $args, $defaults );$_genesis_layouts[ $id ] = $args;return $args;
}
/**
* Add new layout type to a layout without having to directly modify the global variable.
*/
function genesis_add_type_to_layout( $id, $type = [] ) {global $_genesis_layouts;
$new_type = array_merge( (array) $_genesis_layouts[ $id ]['type'], (array) $type );
$_genesis_layouts[ $id ]['type'] = $new_type;return $new_type;
}
/**
* Remove layout type from a layout without having to directly modify the global variable.
*/
function genesis_remove_type_from_layout( $id, $type = [] ) {global $_genesis_layouts;
$new_type = array_values( array_diff( (array) $_genesis_layouts[ $id ]['type'], (array) $type ) );
$_genesis_layouts[ $id ]['type'] = $new_type;return $new_type;
}
/**
* Set a default layout.
*/
function genesis_set_default_layout( $id = '' ) {global $_genesis_layouts;if ( ! is_array( $_genesis_layouts ) ) {$_genesis_layouts = [];
	}
	if ( ! $id || ! isset( $_genesis_layouts[ $id ] ) ) {return false;
	}
	foreach ( $_genesis_layouts as $key => $value ) {if ( isset( $_genesis_layouts[ $key ]['default'] ) ) {unset( $_genesis_layouts[ $key ]['default'] );
	}}
	$_genesis_layouts[ $id ]['default'] = true;return $id;
}
/**
* Unregister a layout in Genesis.
*/
function genesis_unregister_layout( $id = '' ) {global $_genesis_layouts;if ( ! $id || ! isset( $_genesis_layouts[ $id ] ) ) {return false;}unset( $_genesis_layouts[ $id ] );return true;
}
/**
* Return all registered Genesis layouts.
*/
function genesis_get_layouts( $type = 'site' ) {global $_genesis_layouts;
	if ( ! is_array( $_genesis_layouts ) ) {$_genesis_layouts = [];return $_genesis_layouts;
	}
	$layouts = [];
	$types = array_reverse( (array) $type );
	$types[] = 'site';
	if ( is_numeric( $types[0] ) ) {$id = $types[0];$types[0] = $types[1] . '-' . $types[0];
	}
	foreach ( $types as $type ) {foreach ( $_genesis_layouts as $id => $data ) {if ( in_array( $type, $data['type'], true ) ) {$layouts[ $id ] = $data;
	}}
	if ( $layouts ) {break;
	}}
	$layouts = (array) apply_filters( 'genesis_get_layouts', $layouts, $type );return $layouts;
}
/**
* Return registered layouts in a format the WordPress Customizer accepts.
*/
function genesis_get_layouts_for_customizer( $type = 'site' ) {
	$layouts = genesis_get_layouts( $type );if ( empty( $layouts ) ) {return $layouts;
	}
	foreach ( $layouts as $id => $data ) {$customizer_layouts[ $id ] = $data['label'];}return $customizer_layouts;
}
/**
* Return the data from a single layout, specified by the $id passed to it.
*/
function genesis_get_layout( $id, $type = 'site' ) {$layouts = genesis_get_layouts( $type );if ( ! $id || ! isset( $layouts[ $id ] ) ) {return null;}return $layouts[ $id ];
}
/**
* Return the layout that is set to default.
*/
function genesis_get_default_layout( $type = 'site' ) {$layouts = genesis_get_layouts( $type );
	$default = 'nolayout';
	foreach ( $layouts as $key => $value ) {
	if ( isset( $value['default'] ) && $value['default'] ) {$default = $key;break;}}return $default;
}
/**
* Determine if the site has more than 1 registered layouts.
*/
function genesis_has_multiple_layouts( $type = 'site' ) {$layouts = genesis_get_layouts( $type );return count( $layouts ) > 1;
}
/**
* Return the site layout for different contexts.
*/
function genesis_site_layout( $use_cache = true ) {$pre = apply_filters( 'genesis_site_layout', null );if ( null !== $pre ) {return $pre;
	}
	if ( $use_cache ) {static $layout_cache = '';if ( '' !== $layout_cache ) {return esc_attr( $layout_cache );
	}}
	global $wp_query;$type = 'site';if ( is_singular() || ( is_home() && ! genesis_is_root_page() ) ) { $post_id = is_home() ? get_option( 'page_for_posts' ) : null;$custom_field = genesis_get_custom_field( '_genesis_layout', $post_id );$site_layout = $custom_field ?: genesis_get_option( 'site_layout' );$type = [ 'singular', get_post_type(), $post_id ];
	} elseif ( is_category() || is_tag() || is_tax() ) {$term = $wp_query->get_queried_object();$term_layout = $term ? get_term_meta( $term->term_id, 'layout', true ) : '';$site_layout = $term_layout ?: genesis_get_option( 'site_layout' );$type = [ 'archive', $term->taxonomy, $term->term_id ];
	} elseif ( is_post_type_archive() && genesis_has_post_type_archive_support() ) { $site_layout = genesis_get_cpt_option( 'layout' ) ?: genesis_get_option( 'site_layout' );$type = [ 'archive', 'post-type-archive-' . get_post_type() ];
	} elseif ( is_author() ) { $site_layout = get_the_author_meta( 'layout', (int) get_query_var( 'author' ) ) ?: genesis_get_option( 'site_layout' );$type = [ 'archive', 'author', get_query_var( 'author' ) ];
	} else { $site_layout = genesis_get_option( 'site_layout' );
	}
	if ( ! genesis_get_layout( $site_layout, $type ) ) {$site_layout = genesis_get_default_layout();
	}
	if ( $use_cache ) {$layout_cache = $site_layout;}return esc_attr( $site_layout );
}
/**
* Output the form elements necessary to select a layout.
*/
function genesis_layout_selector( $args = [] ) {genesis_scripts()->enqueue_and_localize_admin_scripts();$args = wp_parse_args($args,
	[
	'name'=> '','selected'=> '','type'=> 'type','echo'=> true,
	]);
	$output = '';foreach ( genesis_get_layouts( $args['type'] ) as $id => $data ) {
	$class = $id === $args['selected'] ? ' selected' : '';
	$output .= sprintf('<label class="box%2$s" for="%5$s"><span class="screen-reader-text">%1$s </span><img src="%3$s" alt="%1$s" /><input type="radio" name="%4$s" id="%5$s" value="%5$s" %6$s class="screen-reader-text" /></label>',
	esc_attr( $data['label'] ),esc_attr( $class ),esc_url( $data['img'] ),esc_attr( $args['name'] ),esc_attr( $id ),checked( $id, $args['selected'], false )
	);}
	if ( $args['echo'] ) {echo $output;return null;}return $output;
}
/**
* Return a structural wrap div. 
*/
function genesis_get_structural_wrap( $context = '', $output = 'open' ) {
	$wraps = get_theme_support( 'genesis-structural-wraps' );if ( ! $wraps ) {return null;
	}
	$map = ['nav'=> 'menu-primary','subnav'=> 'menu-secondary','inner'=> 'site-inner',
	];
	$swap = array_search( $context, $map, true );if ( $swap && in_array( $swap, $wraps[0], true ) ) {$wraps[0] = str_replace( $swap, $map[ $swap ], $wraps[0] );
	}
	if ( ! in_array( $context, (array) $wraps[0], true ) ) {return '';
	}
	$original_output = $output;
	switch ( $output ) {
	case 'open':$output = sprintf( '<div %s>', genesis_attr( 'structural-wrap' ) );break;
	case 'close':$output = '</div>';break;
	}
	$output = apply_filters( "genesis_structural_wrap-{$context}", $output, $original_output ); return $output;
}
/**
* Echo a structural wrap div.
*/
function genesis_structural_wrap( $context = '', $output = 'open', $deprecated = null ) {
	if ( null !== $deprecated ) {
	$message = __( 'The default is true, so remove the third argument.', 'genesis' );
	if ( false === (bool) $deprecated ) {$message = __( 'Use `genesis_get_structural_wrap()` instead.', 'genesis' );
	}
	_deprecated_argument( __FUNCTION__, '2.7.0', esc_html( $message ) );
	}
	$output = genesis_get_structural_wrap( $context, $output );
	$deprecated = null === $deprecated ? true : $deprecated;
	if ( false === (bool) $deprecated ) {return $output;}echo $output;
}
/**
* Return layout key 'content-sidebar'.
*/
function __genesis_return_content_sidebar() {return 'content-sidebar';
}
/**
* Return layout key 'sidebar-content'.
*/
function __genesis_return_sidebar_content() {return 'sidebar-content';
}
/**
* Return layout key 'content-sidebar-sidebar'..
*/
function __genesis_return_content_sidebar_sidebar() {return 'content-sidebar-sidebar';
}
/**
* Return layout key 'sidebar-sidebar-content'.
*/
function __genesis_return_sidebar_sidebar_content() {return 'sidebar-sidebar-content';
}
/**
* Return layout key 'sidebar-content-sidebar'.
*/
function __genesis_return_sidebar_content_sidebar() {return 'sidebar-content-sidebar';
}
/**
* Return layout key 'full-width-content'.
*/
function __genesis_return_full_width_content() {return 'full-width-content';
}