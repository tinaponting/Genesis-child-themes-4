<?php
/**
* Genesis Framework.
*/
if ( ! function_exists( 'mb_strpos' ) ) {
	/**
	* Add compatibility for undefined mb_strpos() by deferring to strpos().
	*/
	function mb_strpos( $haystack, $needle, $offset = 0, $encoding = '' ) {return strpos( $haystack, $needle, $offset );
	}}
if ( ! function_exists( 'mb_strrpos' ) ) {
	/**
	* Add compatibility for undefined mb_strrpos() by deferring to strrpos().
	*/
	function mb_strrpos( $haystack, $needle, $offset = 0, $encoding = '' ) {return strrpos( $haystack, $needle, $offset );
	}}
if ( ! function_exists( 'mb_strtolower' ) ) {
	/**
	* Add compatibility for undefined mb_strtolower() by deferring to strtolower().
	*/
	function mb_strtolower( $string, $encoding = '' ) {return strtolower( $string );
	}}
if ( ! function_exists( 'wp_unique_id' ) ) {
	/**
	* Get unique ID.
	*/
	function wp_unique_id( $prefix = '' ) {static $id_counter = 0;return $prefix . ( ++$id_counter );
	}}