<?php
/**
* Genesis Framework.
*/
/**
* Determine if a child theme supports a particular Genesis nav menu.
*/
function genesis_nav_menu_supported( $menu ) {if ( ! current_theme_supports( 'genesis-menus' ) ) {return false;
}
$menus = get_theme_support( 'genesis-menus' );
if ( array_key_exists( $menu, (array) $menus[0] ) ) {return true;}return false;
}
/**
* Determine if the Superfish script is enabled.
*/
function genesis_superfish_enabled() {if ( genesis_is_amp() ) {return false;
}
return ( genesis_a11y( 'drop-down-menu' ) || apply_filters( 'genesis_superfish_enabled', false ) );
}
/**
* Register the theme's responsive menus' configuration settings.
*/
function genesis_register_responsive_menus( array $config = [] ) {static $menu_handler = null;
	if ( null === $menu_handler && ! empty( $config ) ) {
	$menu_handler = new Genesis_Menu_Handler( get_stylesheet(), $config );
	$menu_handler->add_hooks();}return $menu_handler;
}
/**
* Return the markup to display a menu consistent with the Genesis format..
*/
function genesis_get_nav_menu( $args = [] ) {$args = wp_parse_args($args,
	[
	'theme_location'=> '','container'=> '','menu_class'=> 'menu genesis-nav-menu','link_before'=> genesis_markup(
	[
	'open'=> '<span %s>','context'=> 'nav-link-wrap','echo'=> false,
	]),
	'link_after'=> genesis_markup(
	[
	'close'=> '</span>','context'=> 'nav-link-wrap','echo'=> false,
	]),
	'echo'=> 0,
	]);
	if ( ! has_nav_menu( $args['theme_location'] ) ) {return null;
	}
	if ( genesis_superfish_enabled() && false === strpos( $args['menu_class'], 'js-superfish' ) ) {$args['menu_class'] .= ' js-superfish';
	}
	$sanitized_location = sanitize_key( $args['theme_location'] );$nav = wp_nav_menu( $args );if ( ! $nav ) {return null;
	}
	$nav_markup_open = genesis_get_structural_wrap( 'menu-' . $sanitized_location, 'open' );
	$nav_markup_close = genesis_get_structural_wrap( 'menu-' . $sanitized_location, 'close' );
	$params = ['theme_location'=> $args['theme_location'],
	];
	$nav_output = genesis_markup(
	[
	'open'=> '<nav %s>','close'=> '</nav>','context'=> 'nav-' . $sanitized_location,'content'=> $nav_markup_open . $nav . $nav_markup_close,'echo'=> false,'params'=> $params,
	]);
	$filter_location = $sanitized_location . '_nav';
	if ( 'primary' === $args['theme_location'] ) {$filter_location = 'do_nav';} elseif ( 'secondary' === $args['theme_location'] ) {$filter_location = 'do_subnav';
	}
	return apply_filters( "genesis_{$filter_location}", $nav_output, $nav, $args );
}
/**
* Echo the output from `genesis_get_nav_menu()`.
*/
function genesis_nav_menu( $args ) {echo genesis_get_nav_menu( $args );
}
/**
* Checks if the provided menu name is unique and returns a unique version.
*/
function genesis_unique_menu_name( $name ) {$menu_names = get_terms('nav_menu',
	[
	'fields'=> 'names','hide_empty'=> false,
	]);
	if ( ! is_array( $menu_names ) ) {return $name;
	}
	$menu_names = array_flip( $menu_names );if ( ! isset( $menu_names[ $name ] ) ) {return $name;
	}
	$i = 2;$stem = $name;do {$name = $stem . ' ' . $i;if ( ! isset( $menu_names[ $name ] ) ) {break;
	}
	$i++;} while ( 1 );return $name;
}