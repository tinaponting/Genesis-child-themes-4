<?php
/**
* Genesis Framework.
*/
use StudioPress\Genesis\SEO\Open_Graph;
/**
* Detect plugins that emit Open Graph tags.
*/
function genesis_detect_open_graph_plugins() {$open_graph_plugins = apply_filters('genesis_detect_open_graph_plugins',
[
'classes'=> ['Iworks_Opengraph',
],
'functions'=> ['jetpack_og_tags','opengraph_default_metadata', 
],
'constants'=> ['WEBDADOS_FB_VERSION', 'COMPLETE_OPEN_GRAPH_OPTIONS_PREFIX', ],]);return genesis_detect_plugin( $open_graph_plugins );
}
/**
* Determines if Open Graph settings should be visible in the Customizer.
*/
function genesis_open_graph_available() {return apply_filters( 'genesis_open_graph_enabled', true ) && genesis_seo_active() && ! genesis_detect_open_graph_plugins();
}
add_action( 'after_setup_theme', 'genesis_open_graph' );
/**
* Initializes Genesis Open Graph support if enabled.
*/
function genesis_open_graph() {if ( ! genesis_open_graph_available() ) {return;
}
$genesis_open_graph_config = apply_filters('genesis_open_graph_config',
[
'icon_size'=> 512,
]);
$og = new Open_Graph( $genesis_open_graph_config );$og->add_hooks();
}