<?php
/**
* Genesis Framework.
*/
function genesis_truncate_phrase( $text, $max_characters ) {if ( ! $max_characters ) {return '';
	}
	$text = trim( $text );
	if ( mb_strlen( $text ) > $max_characters ) {
	$text = mb_substr( $text, 0, $max_characters + 1 );
	$text_trim = trim( mb_substr( $text, 0, mb_strrpos( $text, ' ' ) ) );
	$text = empty( $text_trim ) ? $text : $text_trim;}return $text;
}
/**
* Return content stripped down and limited content.
*/
function get_the_content_limit( $max_characters, $more_link_text = '(more...)', $stripteaser = false ) {
	$content = get_the_content( '', $stripteaser );
	$content = excerpt_remove_blocks( $content );
	$content = strip_tags( strip_shortcodes( $content ), apply_filters( 'get_the_content_limit_allowedtags', '<script>,<style>' ) );
	$content = trim( preg_replace( '#<(s(cript|tyle)).*?</\1>#si', '', $content ) );
	$content = genesis_truncate_phrase( $content, $max_characters );
	if ( $more_link_text ) {$link  = apply_filters( 'get_the_content_more_link', sprintf( '&#x02026; <a href="%s" class="more-link">%s</a>', get_permalink(), $more_link_text ), $more_link_text );$output = sprintf( '<p>%s %s</p>', $content, $link );
	} else {$output = sprintf( '<p>%s</p>', $content );$link = '';}return apply_filters( 'get_the_content_limit', $output, $content, $link, $max_characters );
}
/**
* Return more link text plus hidden title for screen readers, to improve accessibility.
*/
function genesis_a11y_more_link( $more_link_text ) {if ( ! empty( $more_link_text ) && genesis_a11y( 'screen-reader-text' ) ) {
$more_link_text .= ' <span class="screen-reader-text">' . __( 'about ', 'genesis' ) . get_the_title() . '</span>';}return $more_link_text;
}
/**
* Echo the limited content.
*/
function the_content_limit( $max_characters, $more_link_text = '(more...)', $stripteaser = false ) {
$content = get_the_content_limit( $max_characters, $more_link_text, $stripteaser );echo apply_filters( 'the_content_limit', $content ); 
}
/**
* Add `rel="nofollow"` attribute and value to links within string passed in.
*/
function genesis_rel_nofollow( $text ) {$text = genesis_strip_attr( $text, 'a', 'rel' );return stripslashes( wp_rel_nofollow( $text ) );
}
/**
* Remove attributes from a HTML element.
*/
function genesis_strip_attr( $text, $elements, $attributes, $two_passes = true ) {
	$elements_pattern = implode( '|', (array) $elements );$patterns = [];
	foreach ( (array) $attributes as $attribute ) {$patterns[] = sprintf( '~(<(?:%s(?=\s+))[^>]*)\s+%s(?:=(?:[\\\'"][^\\\'"]+[\\\'"]|(?:[^\s>\/]|\/(?!>))+))?([^>]*>)~', $elements_pattern, $attribute );
	}
	$text = preg_replace( $patterns, '$1$2', $text );
	if ( $two_passes ) { $text = preg_replace( $patterns, '$1$2', $text );}return $text;
}
/**
* Return the special URL of a paged post.
*/
function genesis_paged_post_url( $i, $post_id = 0 ) {global $wp_rewrite;$post = get_post( $post_id );
	if ( 1 === (int) $i ) {$url = get_permalink( $post_id );
	} elseif ( '' === get_option( 'permalink_structure' ) || in_array( $post->post_status, [ 'draft', 'pending' ], true ) ) {$url = add_query_arg( 'page', $i, get_permalink( $post_id ) );
	} elseif ( 'page' === get_option( 'show_on_front' ) && get_option( 'page_on_front' ) === $post->ID ) {$url = trailingslashit( get_permalink( $post_id ) ) . user_trailingslashit( "$wp_rewrite->pagination_base/" . $i, 'single_paged' );
	} else {$url = trailingslashit( get_permalink( $post_id ) ) . user_trailingslashit( $i, 'single_paged' );}return $url;
}
/**
* Sanitize multiple HTML classes in one pass.
*/
function genesis_sanitize_html_classes( $classes, $return_format = 'input' ) {
	if ( 'input' === $return_format ) {$return_format = is_array( $classes ) ? 'array' : 'string';
	}
	$classes = is_array( $classes ) ? $classes : explode( ' ', $classes );
	$sanitized_classes = array_map( 'sanitize_html_class', $classes );
	if ( 'array' === $return_format ) {return $sanitized_classes;}return implode( ' ', $sanitized_classes );
}
/**
* Return an array of allowed tags for output formatting.
*/
function genesis_formatting_allowedtags() {return apply_filters(
	'genesis_formatting_allowedtags',
	[
	'a'=> ['href'=> [],'title'=> [],
	],
	'b'=> [],'blockquote'=> [],'br'=> [],'div'=> ['align'=> [],'class'=> [],'style'=> [],
	],
	'em'=> [],'i'=> [],'p'=> ['align'=> [],'class'=> [],'style'=> [],
	],
	'span'=> ['align'=> [],'class'=> [],'style'=> [],
	],
	'strong'=> [],
	]);}
/**
* Wrapper for `wp_kses()` that can be used as a filter function.
*/
function genesis_formatting_kses( $string ) {return wp_kses( $string, genesis_formatting_allowedtags() );
}
/**
* Calculate the time difference - a replacement for `human_time_diff()` until it is improved.
*/
function genesis_human_time_diff( $older_date, $newer_date = false, $relative_depth = 2 ) {if ( ! is_int( $older_date ) ) {return '';
	}
	$newer_date = $newer_date ?: time();$since = absint( $newer_date - $older_date );if ( ! $since ) {return '0 ' . _x( 'seconds', 'time difference', 'genesis' );
	}
	$units = [[ 31536000, _nx_noop( '%s year', '%s years', 'time difference', 'genesis' ) ],  
	[ 2592000, _nx_noop( '%s month', '%s months', 'time difference', 'genesis' ) ], 
	[ 604800, _nx_noop( '%s week', '%s weeks', 'time difference', 'genesis' ) ],    
	[ 86400, _nx_noop( '%s day', '%s days', 'time difference', 'genesis' ) ],       
	[ 3600, _nx_noop( '%s hour', '%s hours', 'time difference', 'genesis' ) ],      
	[ 60, _nx_noop( '%s minute', '%s minutes', 'time difference', 'genesis' ) ],
	[ 1, _nx_noop( '%s second', '%s seconds', 'time difference', 'genesis' ) ],
	];
	$relative_depth = (int) $relative_depth ?: 2;
	$i = 0;
	$counted_seconds = 0;
	$date_partials = [];
	$amount_date_partials = 0;
	$amount_units = count( $units );
	while ( $amount_date_partials < $relative_depth && $i < $amount_units ) {
	$seconds = $units[ $i ][0];$count = (int) floor( ( $since - $counted_seconds ) / $seconds );if ( 0 !== $count ) {
	$date_partials[] = sprintf( translate_nooped_plural( $units[ $i ][1], $count, 'genesis' ), $count );
	$counted_seconds += $count * $seconds;$amount_date_partials = count( $date_partials );}$i++;
	}
	if ( empty( $date_partials ) ) {$output = '';
	} elseif ( 1 === count( $date_partials ) ) {$output = $date_partials[0];
	} else {$output = implode( ', ', array_slice( $date_partials, 0, -1 ) );$output .= ' ' . _x( 'and', 'separator in time difference', 'genesis' ) . ' ';$output .= end( $date_partials );}return $output;
}
/**
* Mark up content with code tags.
*/
function genesis_code( $content ) {return '<code>' . esc_html( $content ) . '</code>';
}
/**
* Remove paragraph tags from content.
*/
function genesis_strip_p_tags( $content ) {return preg_replace( '/<p\b[^>]*>(.*?)<\/p>/i', '$1', $content );
}