<?php
/**
* Genesis Framework.
*/
add_action( 'genesis_meta', 'genesis_load_stylesheet' );
/**
* Echo reference to the style sheet.
*/
function genesis_load_stylesheet() {add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 5 );
}
/**
  Enqueue main style sheet.
*/
function genesis_enqueue_main_stylesheet() {wp_enqueue_style(genesis_get_theme_handle(),get_stylesheet_uri(),false,genesis_get_theme_version()
);}
add_action( 'admin_print_styles', 'genesis_load_admin_styles' );
/**
* Enqueue Genesis admin styles.
*/
function genesis_load_admin_styles() {
$suffix = genesis_is_in_dev_mode() ? '' : '.min';
wp_enqueue_style( 'genesis_admin_css', GENESIS_CSS_URL . "/admin{$suffix}.css", [], PARENT_THEME_VERSION );
if ( is_rtl() ) {wp_enqueue_style( 'genesis_admin_rtl_css', GENESIS_CSS_URL . "/admin-rtl{$suffix}.css", [], PARENT_THEME_VERSION );
}}