<?php
/**
* Genesis Framework.
*/
add_action( 'genesis_before_loop', 'genesis_do_taxonomy_title_description', 15 );
/**
* Add custom heading and / or description to category / tag / taxonomy archive pages.
*/
function genesis_do_taxonomy_title_description() {global $wp_query, $wp_embed;if ( ! is_category() && ! is_tag() && ! is_tax() ) {return;
	}
	$term = is_tax() ? get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ) : $wp_query->get_queried_object();if ( ! $term ) {return;
	}
	$heading = get_term_meta( $term->term_id, 'headline', true );if ( empty( $heading ) && genesis_a11y( 'headings' ) ) {$heading = $term->name;
	}
	$intro_text = get_term_meta( $term->term_id, 'intro_text', true );
	$intro_text = $wp_embed->autoembed( $intro_text );
	$intro_text = do_shortcode( $intro_text );
	$intro_text = wpautop( $intro_text );
	$intro_text = apply_filters( 'genesis_term_intro_text_output', $intro_text ?: '' );
	do_action( 'genesis_archive_title_descriptions', $heading, $intro_text, 'taxonomy-archive-description' );

}
add_filter( 'genesis_author_intro_text_output', 'wpautop' );
add_action( 'genesis_before_loop', 'genesis_do_author_title_description', 15 );
/**
* Add custom headline and description to author archive pages.
*/
function genesis_do_author_title_description() {if ( ! is_author() ) {return;
	}
	$heading = get_the_author_meta( 'headline', (int) get_query_var( 'author' ) );
	if ( empty( $heading ) && genesis_a11y( 'headings' ) ) {$heading = get_the_author_meta( 'display_name', (int) get_query_var( 'author' ) );
	}
	$intro_text = get_the_author_meta( 'intro_text', (int) get_query_var( 'author' ) );
	$intro_text = apply_filters( 'genesis_author_intro_text_output', $intro_text ?: '' );
	do_action( 'genesis_archive_title_descriptions', $heading, $intro_text, 'author-archive-description' );

}
add_action( 'genesis_before_loop', 'genesis_do_author_box_archive', 15 );
/**
* Add author box to the top of author archive.
*/
function genesis_do_author_box_archive(){ if ( ! is_author() || get_query_var( 'paged' ) >= 2 ) {return;
	}
	if ( get_the_author_meta( 'genesis_author_box_archive', get_query_var( 'author' ) ) ) {genesis_author_box( 'archive' );
	}}
add_filter( 'genesis_cpt_archive_intro_text_output', 'wpautop' );
add_action( 'genesis_before_loop', 'genesis_do_cpt_archive_title_description' );
/**
* Add custom headline and description to relevant custom post type archive pages.
*/
function genesis_do_cpt_archive_title_description() {if ( ! is_post_type_archive() || ! genesis_has_post_type_archive_support() ) {return;
	}
	$heading = genesis_get_cpt_option( 'headline' );if ( empty( $heading ) && genesis_a11y( 'headings' ) ) {$heading = post_type_archive_title( '', false );
	}
	$intro_text = genesis_get_cpt_option( 'intro_text' );
	$intro_text = apply_filters( 'genesis_cpt_archive_intro_text_output', $intro_text ?: '' );
	do_action( 'genesis_archive_title_descriptions', $heading, $intro_text, 'cpt-archive-description' );

}
add_action( 'genesis_before_loop', 'genesis_do_date_archive_title' );
/**
* Add custom heading to date archive pages.
*/
function genesis_do_date_archive_title() {if ( ! is_date() ) {return;
	}
	if ( is_day() ) {$heading = __( 'Archives for ', 'genesis' ) . get_the_date();
	} elseif ( is_month() ) {$heading = __( 'Archives for ', 'genesis' ) . single_month_title( ' ', false );
	} elseif ( is_year() ) {$heading = __( 'Archives for ', 'genesis' ) . get_query_var( 'year' );
	}
	do_action( 'genesis_archive_title_descriptions', $heading, '', 'date-archive-description' );

}
add_action( 'genesis_before_loop', 'genesis_do_blog_template_heading' );
/**
* Add custom heading and description to blog template pages.
*/
function genesis_do_blog_template_heading() {
	if ( ! is_page_template( 'page_blog.php' ) || ! genesis_a11y( 'headings' ) || get_queried_object_id() === get_option( 'page_for_posts' )){ return;
	}
	printf( '<div %s>', genesis_attr( 'blog-template-description' ) );genesis_do_post_title();echo '</div>';
}
add_action( 'genesis_before_loop', 'genesis_do_posts_page_heading' );
/**
* Add custom heading to assigned posts page.
*/
function genesis_do_posts_page_heading() {if ( ! genesis_a11y( 'headings' ) ) {return;
	}
	$posts_page = get_option( 'page_for_posts' );if ( null === $posts_page ) {return;
	}
	if ( ! is_home() || genesis_is_root_page() ) {return;
	}
	if ( genesis_entry_header_hidden_on_current_page() ) {return;
	}
	do_action( 'genesis_archive_title_descriptions', get_the_title( $posts_page ), '', 'posts-page-description' );
}
add_action( 'genesis_archive_title_descriptions', 'genesis_do_archive_headings_open', 5, 3 );
/**
* Add open markup for archive headings to archive pages.
*/
function genesis_do_archive_headings_open( $heading = '', $intro_text = '', $context = '' ) {
if ( $heading || $intro_text ) {genesis_markup(['open'=> '<div %s>','context'=> $context,
]);}}
add_action( 'genesis_archive_title_descriptions', 'genesis_do_archive_headings_close', 15, 3 );
/**
* Add close markup for archive headings to archive pages.
*/
function genesis_do_archive_headings_close( $heading = '', $intro_text = '', $context = '' ) {
if ( $heading || $intro_text ) {genesis_markup(['close'=> '</div>','context'=> $context,
]);}}
add_action( 'genesis_archive_title_descriptions', 'genesis_do_archive_headings_headline', 10, 3 );
/**
* Add headline for archive headings to archive pages.
*/
function genesis_do_archive_headings_headline( $heading = '', $intro_text = '', $context = '' ) {if ( $context && $heading ) {printf( '<h1 %s>%s</h1>', genesis_attr( 'archive-title' ), esc_html( wp_strip_all_tags( $heading ) ) );
}}
add_action( 'genesis_archive_title_descriptions', 'genesis_do_archive_headings_intro_text', 12, 3 );
/**
* Add intro text for archive headings to archive pages.
*/
function genesis_do_archive_headings_intro_text( $heading = '', $intro_text = '', $context = '' ) {if ( $context && $intro_text ) {echo $intro_text;
}}