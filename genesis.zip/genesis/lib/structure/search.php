<?php
/**
* Genesis Framework.
*/
// Moved to lib/classes/class-search-searchform.php.