<?php
/**
* Genesis Framework.
*/
add_action( 'genesis_sidebar', 'genesis_do_sidebar' );
/**
* Echo primary sidebar default content.
*/
function genesis_do_sidebar() {if ( ! dynamic_sidebar( 'sidebar' ) && current_user_can( 'edit_theme_options' ) ) {genesis_default_widget_area_content( __( 'Primary Sidebar Widget Area', 'genesis' ) );
}}
add_action( 'genesis_sidebar_alt', 'genesis_do_sidebar_alt' );
/**
* Echo alternate sidebar default content.
*/
function genesis_do_sidebar_alt() {
if ( ! dynamic_sidebar( 'sidebar-alt' ) && current_user_can( 'edit_theme_options' ) ) {genesis_default_widget_area_content( __( 'Secondary Sidebar Widget Area', 'genesis' ) );
}}

/**
* Template for default widget area content.
*/
function genesis_default_widget_area_content( $name ) {genesis_markup(
[
'open'=> '<section class="widget widget_text">','context'=> 'default-widget-content-wrap',
]
);
echo '<div class="widget-wrap">';$genesis_heading = ( genesis_a11y( 'headings' ) ? 'h3' : 'h4' );
echo sprintf( '<%1$s class="widgettitle">%2$s</%1$s>', esc_attr( $genesis_heading ), esc_html( $name ) );
echo '<div class="textwidget"><p>';
printf(esc_html__( 'This is the %1$s. You can add content to this area by visiting your %2$s and adding new widgets to this area.', 'genesis' ),esc_html( $name ),
sprintf('<a href="%1$s">%2$s</a>',esc_url( admin_url( 'widgets.php' ) ),esc_html__( 'Widgets Panel', 'genesis' )
));
echo '</p></div>';echo '</div>';genesis_markup(
[
'close'=> '</section>','context'=> 'default-widget-content-wrap',
]);}