<?php
/**
* Genesis Framework.
*/
add_action( 'genesis_doctype', 'genesis_do_doctype' );
/**
* Echo the doctype and opening markup.
*/
function genesis_do_doctype() {genesis_html5_doctype();
}
/**
* HTML5 doctype markup.
*/
function genesis_html5_doctype() {
?>
<!DOCTYPE html>
<html <?php language_attributes('html'); ?>>
<head <?php echo genesis_attr('head'); ?>>
<meta charset="<?php bloginfo('charset'); ?>" /> <?php 
}
add_filter( 'document_title_parts', 'genesis_document_title_parts' );
/**
* Filter Document title parts based on context and SEO settings values.
*/
function genesis_document_title_parts( $parts ) {$genesis_document_title_parts = new Genesis_SEO_Document_Title_Parts();return $genesis_document_title_parts->get_parts( $parts );
}
add_filter( 'document_title_separator', 'genesis_document_title_separator' );
/**
* Filter Document title parts separator based on SEO setting value.
*/
function genesis_document_title_separator( $sep ) {$sep = genesis_get_seo_option( 'doctitle_sep' );return $sep ?: '-';
}
add_action( 'get_header', 'genesis_doc_head_control' );
/**
* Remove unnecessary code that WordPress puts in the `head`.
*/
function genesis_doc_head_control() {remove_action( 'wp_head', 'wp_generator' );if ( ! genesis_get_seo_option( 'head_adjacent_posts_rel_link' ) ) {remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );
	}
	if ( ! genesis_get_seo_option( 'head_wlwmanifest_link' ) ) {remove_action( 'wp_head', 'wlwmanifest_link' );
	}
	if ( ! genesis_get_seo_option( 'head_shortlink' ) ) {remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
	}
	if ( is_single() && ! genesis_get_option( 'comments_posts' ) ) {remove_action( 'wp_head', 'feed_links_extra', 3 );
	}
	if ( is_page() && ! genesis_get_option( 'comments_pages' ) ) {remove_action( 'wp_head', 'feed_links_extra', 3 );
	}}
add_action( 'genesis_meta', 'genesis_seo_meta_description' );
/**
* Output the meta description based on contextual criteria.
*/
function genesis_seo_meta_description() {$description = genesis_get_seo_meta_description();if ( $description ) {echo '<meta name="description" content="' . esc_attr( $description ) . '" />' . "\n";
}}
add_action( 'genesis_meta', 'genesis_seo_meta_keywords' );
/**
* Output the meta keywords based on contextual criteria.
*/
function genesis_seo_meta_keywords() {$keywords = genesis_get_seo_meta_keywords();if ( $keywords ) {echo '<meta name="keywords" content="' . esc_attr( $keywords ) . '" />' . "\n";
}}
add_action( 'genesis_meta', 'genesis_robots_meta' );
/**
* Output the robots meta code in the document `head`.
*/
function genesis_robots_meta() {if ( ! get_option( 'blog_public' ) ) {return;
	}
	$meta = genesis_get_robots_meta_content();if ( $meta ) {
	?>
	<meta name="robots" content="<?php echo esc_attr( $meta ); ?>" />
	<?php
	}}
add_action( 'genesis_meta', 'genesis_responsive_viewport' );
/**
* Outputs the responsive CSS viewport tag.
*/
function genesis_responsive_viewport() {$viewport_value = apply_filters( 'genesis_viewport_value', 'width=device-width, initial-scale=1' );
	if ( genesis_is_amp() && strpos( $viewport_value, 'minimum-scale' ) === false ) {$viewport_value .= ',minimum-scale=1';
	}
	printf('<meta name="viewport" content="%s" />' . "\n",esc_attr( $viewport_value )
	);}
add_action( 'wp_head', 'genesis_load_favicon' );
/**
* Echo favicon link.
*/
function genesis_load_favicon() {if ( function_exists( 'has_site_icon' ) && has_site_icon() ) {return;
	}
	$favicon = genesis_get_favicon_url();if ( $favicon ) {echo '<link rel="icon" href="' . esc_url( $favicon ) . '" />' . "\n";
	}}
add_action( 'wp_head', 'genesis_do_meta_pingback' );
/**
* Adds the pingback meta tag to the head so that other sites can know how to send a pingback to our site.
*/
function genesis_do_meta_pingback() {
if ( 'open' === get_option( 'default_ping_status' ) ) {echo '<link rel="pingback" href="' . esc_url( get_bloginfo( 'pingback_url' ) ) . '" />' . "\n";
}}
add_action( 'wp_head', 'genesis_paged_rel' );
/**
* Output rel links in the head to indicate previous and next pages in paginated archives and posts.
*/
function genesis_paged_rel() {global $wp_query;$next = '';$prev = $next;
	$paged = (int) get_query_var( 'paged' );
	$page = (int) get_query_var( 'page' );
	if ( ! is_singular() ) {
	$prev = $paged > 1 ? get_previous_posts_page_link() : $prev;
	$next = $paged < $wp_query->max_num_pages ? get_next_posts_page_link( $wp_query->max_num_pages ) : $next;} else {if ( is_preview() ) {return;
	}
	$numpages = substr_count( $wp_query->post->post_content, '<!--nextpage-->' ) + 1;if ( $numpages && ! $page ) {$page = 1;
	}
	if ( $page > 1 ) {$prev = genesis_paged_post_url( $page - 1 );
	}
	if ( $page < $numpages ) {$next = genesis_paged_post_url( $page + 1 );
	}}
	if ( $prev ) {printf( '<link rel="prev" href="%s" />' . "\n", esc_url( $prev ) );
	}
	if ( $next ) {printf( '<link rel="next" href="%s" />' . "\n", esc_url( $next ) );
	}}
add_action( 'wp_head', 'genesis_meta_name' );
/**
* Output meta tag for site name.
*/
function genesis_meta_name() {if ( ! is_front_page() ) {return;
}
printf( '<meta itemprop="name" content="%s" />' . "\n", esc_html( get_bloginfo( 'name' ) ) );
}
add_action( 'wp_head', 'genesis_meta_url' );
/**
* Output meta tag for site URL.
*/
function genesis_meta_url() {if ( ! is_front_page() ) {return;
}
printf( '<meta itemprop="url" content="%s" />' . "\n", esc_url( trailingslashit( home_url() ) ) );
}
add_action( 'wp_head', 'genesis_canonical', 5 );
/**
* Echo custom canonical link tag.
*/
function genesis_canonical() {remove_action( 'wp_head', 'rel_canonical' );$canonical = genesis_canonical_url();if ( $canonical ) {printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( apply_filters( 'genesis_canonical', $canonical ) ) );
}}
add_filter( 'genesis_header_scripts', 'do_shortcode' );add_action( 'wp_head', 'genesis_header_scripts' );
/**
* Echo header scripts in to wp_head().
*/
function genesis_header_scripts() {echo apply_filters( 'genesis_header_scripts', genesis_get_option( 'header_scripts' ) ); if ( is_singular() ) {genesis_custom_field( '_genesis_scripts' );
}}
add_action( 'genesis_before', 'genesis_page_specific_body_scripts' );
/**
* Output page-specific body scripts if their position is set to 'top'.
*/
function genesis_page_specific_body_scripts() {if ( ! is_singular() ) {return;
	}
	if ( 'top' === genesis_get_custom_field( '_genesis_scripts_body_position' ) ) {genesis_custom_field( '_genesis_scripts_body' );
	}}
add_action( 'after_setup_theme', 'genesis_custom_header' );
/**
* Activate the custom header feature.
*/
function genesis_custom_header() {$wp_custom_header = get_theme_support( 'custom-header' );if ( $wp_custom_header ) {return;
	}
	$genesis_custom_header = get_theme_support( 'genesis-custom-header' );if ( ! $genesis_custom_header ) {return;
	}
	add_filter( 'genesis_pre_get_option_blog_title', '__return_empty_array' );
	$genesis_custom_header = isset( $genesis_custom_header[0] ) && is_array( $genesis_custom_header[0] ) ? $genesis_custom_header[0] : [];
	$args = wp_parse_args($genesis_custom_header,apply_filters('genesis_custom_header_defaults',
	[
	'width'=> 960,
	'height'=> 80,
	'textcolor'=> '333333',
	'no_header_text'=> false,
	'header_image'=> '%s/images/header.png',
	'header_callback'=> '',
	'admin_header_callback'=> '',
	]));
	add_theme_support('custom-header',
	[
	'default-image'=> sprintf( $args['header_image'], get_stylesheet_directory_uri() ),
	'header-text'=> $args['no_header_text'] ? false : true,
	'default-text-color' => $args['textcolor'],
	'width'=> $args['width'],
	'height'=> $args['height'],
	'random-default'=> false,
	'header-selector'=> '.site-header',
	'wp-head-callback'=> $args['header_callback'],
	'admin-head-callback'=> $args['admin_header_callback'],
	]);}
add_action( 'after_setup_theme', 'genesis_custom_logo' );
/**
* Add support for the WordPress custom logo feature.
*/
function genesis_custom_logo() {$wp_custom_logo = get_theme_support( 'custom-logo' );if ( $wp_custom_logo ) {return;
	}
	$genesis_custom_logo = get_theme_support( 'genesis-custom-logo' );if ( ! $genesis_custom_logo ) {return;
	}
	add_filter( 'genesis_pre_get_option_blog_title', '__return_empty_array' );
	$genesis_custom_logo = isset( $genesis_custom_logo[0] ) && is_array( $genesis_custom_logo[0] ) ? $genesis_custom_logo[0] : [];
	$args = wp_parse_args($genesis_custom_logo,apply_filters('genesis_custom_logo_defaults',
	[
	'height'=> 100,'width'=> 400,'flex-height'=> true,'flex-width'=> true,'header-text'=> '',
	]));
	add_theme_support('custom-logo',
	[
	'header-text'=> $args['header-text'],'height'=> $args['height'],'width'=> $args['width'],'flex-height'=> $args['flex-height'],'flex-width'=> $args['flex-height'],
	]);}
add_action( 'wp_head', 'genesis_custom_header_style' );
/**
* Custom header callback.
*/
function genesis_custom_header_style() {if ( ! current_theme_supports( 'custom-header' ) ) {return;
	}
	if ( get_theme_support( 'custom-header', 'wp-head-callback' ) ) {return;
	}
	$output = '';$header_image = get_header_image();$text_color = get_header_textcolor();
	if ( empty( $header_image ) && ! display_header_text() && get_theme_support( 'custom-header', 'default-text-color' ) === $text_color ) {return;
	}
	$header_selector = get_theme_support( 'custom-header', 'header-selector' );
	$title_selector  = '.custom-header .site-title';
	$desc_selector = '.custom-header .site-description';
	if ( ! $header_selector ) {$header_selector = '.custom-header .site-header';
	}
	if ( $header_image ) {	$output .= sprintf( '%s { background: url(%s) no-repeat !important; }', $header_selector, esc_url( $header_image ) );
	}
	if ( display_header_text() && get_theme_support( 'custom-header', 'default-text-color' ) !== $text_color ) {$output .= sprintf( '%2$s a, %2$s a:hover, %3$s { color: #%1$s !important; }', esc_html( $text_color ), esc_html( $title_selector ), esc_html( $desc_selector ) );
	}
	if ( $output ) {printf( '<style type="text/css">%s</style>' . "\n", $output ); 
	}
}add_action( 'genesis_header', 'genesis_header_markup_open', 5 );
/**
* Echo the opening structural markup for the header.
*/
function genesis_header_markup_open() {genesis_markup(
	[
	'open'=> '<header %s>','context'=> 'site-header',
	]);
	genesis_structural_wrap( 'header' );
}
add_action( 'genesis_header', 'genesis_header_markup_close', 15 );
/**
* Echo the opening structural markup for the header.
*/
function genesis_header_markup_close() {genesis_structural_wrap( 'header', 'close' );genesis_markup(
	[
	'close'=> '</header>','context'=> 'site-header',
	]);}
add_action( 'genesis_header', 'genesis_do_header' );
/**
* Echo the default header, including the #title-area div, along with #title and #description, as well as the .widget-area.
*/
function genesis_do_header() {global $wp_registered_sidebars;genesis_markup(
	[
	'open'=> '<div %s>','context'=> 'title-area',
	]);
	do_action( 'genesis_site_title' );do_action( 'genesis_site_description' );genesis_markup(
	[
	'close'=> '</div>','context'=> 'title-area',
	]);
	if ( has_action( 'genesis_header_right' ) || ( isset( $wp_registered_sidebars['header-right'] ) && is_active_sidebar( 'header-right' ) ) ) {genesis_markup(
	[
	'open'=> '<div %s>','context'=> 'header-widget-area',
	]);
	do_action( 'genesis_header_right' );
	add_filter( 'wp_nav_menu_args', 'genesis_header_menu_args' );
	add_filter( 'wp_nav_menu', 'genesis_header_menu_wrap' );
	dynamic_sidebar( 'header-right' );
	remove_filter( 'wp_nav_menu_args', 'genesis_header_menu_args' );
	remove_filter( 'wp_nav_menu', 'genesis_header_menu_wrap' );genesis_markup(
	[
	'close'  => '</div>','context'=> 'header-widget-area',
	]);}}
add_action( 'after_setup_theme', 'genesis_output_custom_logo', 11 );
/**
* Adds the WordPress custom logo inside the title area, before the site title hook.
*/
function genesis_output_custom_logo() {if ( current_theme_supports( 'genesis-custom-logo' ) ) {add_action( 'genesis_site_title', 'the_custom_logo', 0 );
}}
add_action( 'genesis_site_title', 'genesis_seo_site_title' );
/**
* Echo the site title into the header.
*/
function genesis_seo_site_title() {$inside = current_theme_supports( 'genesis-custom-logo' ) && has_custom_logo() ? wp_kses_post( get_bloginfo( 'name' ) ) : wp_kses_post( sprintf( '<a href="%s">%s</a>', trailingslashit( home_url() ), get_bloginfo( 'name' ) ) );
	$wrap = genesis_is_root_page() && 'title' === genesis_get_seo_option( 'home_h1_on' ) ? 'h1' : 'p';
	$wrap = genesis_is_root_page() && genesis_seo_disabled() ? 'p' : $wrap;
	$wrap = is_front_page() && is_home() && genesis_seo_disabled() ? 'h1' : $wrap;
	$wrap = genesis_get_seo_option( 'semantic_headings' ) ? 'h1' : $wrap;
	/**
	* Site title wrapping element
	*/
	$wrap = apply_filters( 'genesis_site_title_wrap', $wrap );$title = genesis_markup(
	[
	'open'=> sprintf( "<{$wrap} %s>", genesis_attr( 'site-title' ) ),'close'=> "</{$wrap}>",'content'=> $inside,'context'=> 'site-title','echo'=> false,'params'=> ['wrap'=> $wrap,
	],]);
	/**
	* The SEO title filter
	*/
	$title = apply_filters( 'genesis_seo_title', $title, $inside, $wrap );echo $title;
}
add_action( 'genesis_site_description', 'genesis_seo_site_description' );
/**
* Echo the site description into the header.
*/
function genesis_seo_site_description() {$inside = esc_html( get_bloginfo( 'description' ) );
	$wrap = genesis_is_root_page() && 'description' === genesis_get_seo_option( 'home_h1_on' ) ? 'h1' : 'p';
	$wrap = genesis_get_seo_option( 'semantic_headings' ) ? 'h2' : $wrap;
	/**
	 * Site description wrapping element
	 */
	$wrap = apply_filters( 'genesis_site_description_wrap', $wrap );$description = genesis_markup(
	[
	'open'=> sprintf( "<{$wrap} %s>", genesis_attr( 'site-description' ) ),'close'=> "</{$wrap}>",'content'=> $inside,'context'=> 'site-description','echo'=> false,'params'=> ['wrap'=> $wrap,
	],]);
	$output = $inside ? apply_filters( 'genesis_seo_description', $description, $inside, $wrap ) : '';echo $output;
}
/**
* Sets attributes for the custom menu widget if used in the Header Right widget area.
*/
function genesis_header_menu_args( $args ) {
	$args['container'] = '';
	$args['link_before'] = $args['link_before'] ?: sprintf( '<span %s>', genesis_attr( 'nav-link-wrap' ) );
	$args['link_after'] = $args['link_after'] ?: '</span>';
	$args['menu_class'] .= ' genesis-nav-menu';
	$args['menu_class'] .= genesis_superfish_enabled() ? ' js-superfish' : '';return $args;
}
/**
* Wrap the header navigation menu in its own nav tags with markup API.
*/
function genesis_header_menu_wrap( $menu ) {return genesis_markup(
	[
	'open'=> sprintf( '<nav %s>', genesis_attr( 'nav-header' ) ),'close'=> '</nav>','content'=> $menu,'context'=> 'header-nav','echo'=> false,
	]);}
add_action( 'genesis_before_header', 'genesis_skip_links', 5 );
/**
* Add skip links for screen readers and keyboard navigation.
*/
function genesis_skip_links() {if ( ! genesis_a11y( 'skip-links' ) ) {return;
	}
	genesis_skiplinks_markup();$links = [];if ( genesis_nav_menu_supported( 'primary' ) && has_nav_menu( 'primary' ) ) {$links['genesis-nav-primary'] = esc_html__( 'Skip to primary navigation', 'genesis' );
	}
	$links['genesis-content'] = esc_html__( 'Skip to main content', 'genesis' );
	if ( 'full-width-content' !== genesis_site_layout() ) {$links['genesis-sidebar-primary'] = esc_html__( 'Skip to primary sidebar', 'genesis' );
	}
	if ( in_array( genesis_site_layout(), [ 'sidebar-sidebar-content', 'sidebar-content-sidebar', 'content-sidebar-sidebar' ], true ) ) {$links['genesis-sidebar-secondary'] = esc_html__( 'Skip to secondary sidebar', 'genesis' );
	}
	if ( current_theme_supports( 'genesis-footer-widgets' ) ) {$footer_widgets = get_theme_support( 'genesis-footer-widgets' );
	if ( isset( $footer_widgets[0] ) && is_numeric( $footer_widgets[0] ) && is_active_sidebar( 'footer-1' ) && ! genesis_footer_widgets_hidden_on_current_page() ) {
	$links['genesis-footer-widgets'] = esc_html__( 'Skip to footer', 'genesis' );
	}}
	$links = (array) apply_filters( 'genesis_skip_links_output', $links );
	$skiplinks = '<ul class="genesis-skip-link">';
	foreach ( $links as $key => $value ) {$skiplinks .= '<li><a href="' . esc_url( '#' . $key ) . '" class="screen-reader-shortcut"> ' . $value . '</a></li>';
	}
	$skiplinks .= '</ul>';echo $skiplinks;
}