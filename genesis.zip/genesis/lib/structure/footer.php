<?php
/**
* Genesis Framework.
*/
function genesis_footer_widgets_hidden_on_current_page() {if ( ! is_singular() && ! is_home() ) {return false;
	}
	/**
	* Prevents the “hide footer widgets” checkbox from appearing or functioning by returning false.
	*/
	$footer_widgets_toggle_enabled = apply_filters( 'genesis_footer_widgets_toggle_enabled', true );
	if ( ! $footer_widgets_toggle_enabled ) {return false;}return get_post_meta( get_queried_object_id(), '_genesis_hide_footer_widgets', true );
}
add_action( 'genesis_before_footer', 'genesis_footer_widget_areas' );
/**
* Echo the markup necessary to facilitate the footer widget areas.
*/
function genesis_footer_widget_areas() {$footer_widgets = get_theme_support( 'genesis-footer-widgets' );
	if ( ! $footer_widgets || ! isset( $footer_widgets[0] ) || ! is_numeric( $footer_widgets[0] ) || genesis_footer_widgets_hidden_on_current_page() ) {return;
	}
	$footer_widgets = (int) $footer_widgets[0];if ( ! is_active_sidebar( 'footer-1' ) ) {return;
	}
	$inside = '';$output = '';$counter = 1;while ( $counter <= $footer_widgets ) {ob_start();dynamic_sidebar( 'footer-' . $counter );$widgets = ob_get_clean();if ( $widgets ) {$inside .= genesis_markup(
	[
	'open'=> '<div %s>','close'=> '</div>','context'=> 'footer-widget-area','content'=> $widgets,'echo'=> false,'params'=> ['column'=> $counter,'count'=> $footer_widgets,],]);}$counter++;
	}
	if ( $inside ) {$_inside = genesis_get_structural_wrap( 'footer-widgets', 'open' );$_inside .= $inside;$_inside .= genesis_get_structural_wrap( 'footer-widgets', 'close' );$output .= genesis_markup(
	[
	'open'=> '<div %s>' . genesis_sidebar_title( 'Footer' ),'close'=> '</div>','content'=> $_inside,'context'=> 'footer-widgets','echo'=> false,
	]);}
	/**
	* Allow the footer widget areas output to be filtered.
	*/
	$footer_widgets = apply_filters( 'genesis_footer_widget_areas', $output, $footer_widgets );echo $footer_widgets;
}
add_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
/**
* Echo the opening div tag for the footer.
*/
function genesis_footer_markup_open() {genesis_markup(
	[
	'open'=> '<footer %s>','context'=> 'site-footer',
	]);
	genesis_structural_wrap( 'footer', 'open' );
}
add_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
/**
 * Echo the closing div tag for the footer.
 */
function genesis_footer_markup_close() {genesis_structural_wrap( 'footer', 'close' );genesis_markup(
	[
	'close'=> '</footer>','context'=> 'site-footer',
	]);}
add_filter( 'genesis_footer_output', 'do_shortcode', 20 );
add_action( 'genesis_footer', 'genesis_do_footer' );
/**
 * Echo the contents of the footer including processed shortcodes.
 */
function genesis_do_footer() {
	/**
	* Deprecated. Adjust footer credit text.
	*/
	apply_filters_deprecated('genesis_footer_creds_text',[ '' ],'3.1.0',
	'genesis_pre_get_option_footer_text',__( 'This filter is no longer supported. You can now modify your footer text using the Theme Settings.', 'genesis' )
	);
	$creds_text = wp_kses_post( genesis_get_option( 'footer_text' ) );$output = '<p>' . genesis_strip_p_tags( $creds_text ) . '</p>';
	/**
	* Adjust full footer output.
	*/
	$output = apply_filters( 'genesis_footer_output', $output, '', $creds_text );	echo $output; 

}
add_filter( 'genesis_footer_scripts', 'do_shortcode' );
add_action( 'wp_footer', 'genesis_footer_scripts' );
/**
 * Echo the footer scripts, defined in Theme Settings.
 */
function genesis_footer_scripts() {echo apply_filters( 'genesis_footer_scripts', genesis_get_option( 'footer_scripts' ) );if ( ! is_singular() ) {return;
	}
	if ( 'top' !== genesis_get_custom_field( '_genesis_scripts_body_position' ) ) {genesis_custom_field( '_genesis_scripts_body' );
	}}