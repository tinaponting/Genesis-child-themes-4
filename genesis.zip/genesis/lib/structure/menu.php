<?php
/**
* Genesis Framework.
*/
add_filter( 'nav_menu_link_attributes', 'genesis_nav_menu_link_attributes' );
/**
* Pass nav menu link attributes through attribute parser.
*/
function genesis_nav_menu_link_attributes( $atts ) {return genesis_parse_attr( 'nav-link', $atts );
}
add_action( 'after_setup_theme', 'genesis_register_nav_menus' );
/**
* Register the custom menu locations, if theme has support for them.
*/
function genesis_register_nav_menus() {if ( ! current_theme_supports( 'genesis-menus' ) ) {return;
	}
	$menus = get_theme_support( 'genesis-menus' );register_nav_menus( (array) $menus[0] );do_action( 'genesis_register_nav_menus' );
}
add_action( 'genesis_after_header', 'genesis_do_nav' );
/**
* Echo the "Primary Navigation" menu.
*/
function genesis_do_nav() {if ( ! genesis_nav_menu_supported( 'primary' ) || ! has_nav_menu( 'primary' ) ) {return;
	}
	$class = 'menu genesis-nav-menu menu-primary';if ( genesis_superfish_enabled() ) {$class .= ' js-superfish';
	}
	genesis_nav_menu(
	[
	'theme_location'=> 'primary','menu_class'=> $class,
	]);}
add_action( 'genesis_after_header', 'genesis_do_subnav' );
/**
* Echo the "Secondary Navigation" menu.
*/
function genesis_do_subnav() {
	if ( ! genesis_nav_menu_supported('secondary')) {return;
	}
	$class = 'menu genesis-nav-menu menu-secondary';if (genesis_superfish_enabled()) {$class .= 'js-superfish';
	}
	genesis_nav_menu(
	[
	'theme_location'=>'secondary','menu_class'=> $class,
	]);}