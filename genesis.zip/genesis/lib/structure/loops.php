<?php
/**
* Genesis Framework.
*/
add_action( 'genesis_loop', 'genesis_do_loop' );
/**
* Attach a loop to the `genesis_loop` output hook so we can get some front-end output.
*/
function genesis_do_loop() {if ( is_singular( 'page' ) && genesis_get_custom_field( 'query_args' ) ) {$paged = get_query_var( 'paged' ) ?: 1;
	$query_args = wp_parse_args(genesis_get_custom_field( 'query_args' ),
	[
	'paged'=> $paged,
	]);
	genesis_custom_loop( $query_args );} else {genesis_standard_loop();
	}}
/**
* Standard loop, meant to be executed without modification in most circumstances where content needs to be displayed.
*/
function genesis_standard_loop() {if ( have_posts() ) {
	do_action( 'genesis_before_while' );while ( have_posts() ) {the_post();do_action( 'genesis_before_entry' );genesis_markup(
	[
	'open'=> '<article %s>','context'=> 'entry',
	]);
	do_action( 'genesis_entry_header' );do_action( 'genesis_before_entry_content' );genesis_markup(
	[
	'open'=> '<div %s>','context'=> 'entry-content',
	]);
	do_action( 'genesis_entry_content' );genesis_markup(
	[
	'close'  => '</div>','context'=> 'entry-content',
	]);
	do_action( 'genesis_after_entry_content' );do_action( 'genesis_entry_footer' );genesis_markup(
	[
    'close'=> '</article>','context'=> 'entry',
	]);
	do_action( 'genesis_after_entry' );
	} 
	do_action( 'genesis_after_endwhile' );} else { do_action( 'genesis_loop_else' );
	}}
/**
* Custom loop, meant to be executed when a custom query is needed.
*/
function genesis_custom_loop( $args = [] ) {global $wp_query, $more;$defaults = []; 
	$args = apply_filters( 'genesis_custom_loop_args', wp_parse_args( $args, $defaults ), $args, $defaults );
	$wp_query = new WP_Query( $args ); 
	$more = is_singular() ? $more : 0; 	genesis_standard_loop();wp_reset_query(); 
}
/**
* The grid loop - a specific implementation of a custom loop.
*/
function genesis_grid_loop( $args = [] ) {global $_genesis_loop_args;$args = apply_filters('genesis_grid_loop_args',wp_parse_args($args,
	[
	'features'=> 2,
	'features_on_all'=> false,
	'feature_image_size'=> 0,
	'feature_image_class'=> 'alignleft',
	'feature_content_limit'=> 0,
	'grid_image_size'=> 'thumbnail',
	'grid_image_class'=> 'alignleft',
	'grid_content_limit'=> 0,
	'more'=> __( 'Read more', 'genesis' ) . '&#x02026;',
	]
	));
	if ( get_option( 'posts_per_page' ) < $args['features'] ) {$args['features'] = get_option( 'posts_per_page' );
	}
	$paged = get_query_var( 'paged' ) ?: 1;if ( $paged > 1 && ! $args['features_on_all'] ) {$args['features'] = 0;
	}
	$_genesis_loop_args = $args;
	remove_action( 'genesis_entry_header', 'genesis_do_post_format_image', 4 );
	remove_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
	remove_action( 'genesis_entry_content', 'genesis_do_post_content' );
	remove_action( 'genesis_entry_content', 'genesis_do_post_content_nav', 12 );
	remove_action( 'genesis_entry_content', 'genesis_do_post_permalink', 14 );
	add_filter( 'post_class', 'genesis_grid_loop_post_class' );
	add_action( 'genesis_entry_content', 'genesis_grid_loop_content' );
	genesis_standard_loop();
	genesis_reset_loops();remove_filter( 'post_class', 'genesis_grid_loop_post_class' );remove_action( 'genesis_entry_content', 'genesis_grid_loop_content' );
}
function genesis_grid_loop_post_class( array $classes ) {global $_genesis_loop_args, $wp_query;$grid_classes = [];
	if ( $_genesis_loop_args['features'] && $wp_query->current_post < $_genesis_loop_args['features'] ) {$grid_classes[] = 'genesis-feature';$grid_classes[] = sprintf( 'genesis-feature-%s', $wp_query->current_post + 1 );$grid_classes[] = $wp_query->current_post & 1 ? 'genesis-feature-even' : 'genesis-feature-odd';
	} elseif ( $_genesis_loop_args['features'] & 1 ) {$grid_classes[] = 'genesis-grid';$grid_classes[] = sprintf( 'genesis-grid-%s', $wp_query->current_post - $_genesis_loop_args['features'] + 1 );$grid_classes[] = $wp_query->current_post & 1 ? 'genesis-grid-odd' : 'genesis-grid-even';
	} else {$grid_classes[] = 'genesis-grid';$grid_classes[] = sprintf( 'genesis-grid-%s', $wp_query->current_post - $_genesis_loop_args['features'] + 1 );$grid_classes[] = $wp_query->current_post & 1 ? 'genesis-grid-even' : 'genesis-grid-odd';}return array_merge( $classes, apply_filters( 'genesis_grid_loop_post_class', $grid_classes ) );
}
/**
* Output specially formatted content, based on the grid loop args.
*/
function genesis_grid_loop_content() {global $_genesis_loop_args;
	if ( in_array( 'genesis-feature', get_post_class(), true ) ) {if ( $_genesis_loop_args['feature_image_size'] ) {$image = genesis_get_image(
	[
	'size'=> $_genesis_loop_args['feature_image_size'],'context'=> 'grid-loop-featured','attr'=> genesis_parse_attr('entry-image-grid-loop',
	[
	'class'=> $_genesis_loop_args['feature_image_class'],
	]),]);
	printf( '<a href="%s">%s</a>', esc_url( get_permalink() ), $image );
	}
	if ( $_genesis_loop_args['feature_content_limit'] ) {the_content_limit( (int) $_genesis_loop_args['feature_content_limit'], genesis_a11y_more_link( esc_html( $_genesis_loop_args['more'] ) ) );
	} else {the_content( genesis_a11y_more_link( esc_html( $_genesis_loop_args['more'] ) ) );
	}
	} else {if ( $_genesis_loop_args['grid_image_size'] ) {$image = genesis_get_image(
	[
	'size'=> $_genesis_loop_args['grid_image_size'],'context'=> 'grid-loop','attr'=> genesis_parse_attr('entry-image-grid-loop',
	[
	'class'=> $_genesis_loop_args['grid_image_class'],
	]),]);
	printf( '<a href="%s">%s</a>', esc_url( get_permalink() ), $image );
	}
	if ( $_genesis_loop_args['grid_content_limit'] ) {the_content_limit( (int) $_genesis_loop_args['grid_content_limit'], genesis_a11y_more_link( esc_html( $_genesis_loop_args['more'] ) ) );
	} else {the_excerpt();printf( '<a href="%s" class="more-link">%s</a>', esc_url( get_permalink() ), genesis_a11y_more_link( esc_html( $_genesis_loop_args['more'] ) ) );
	}}}
add_action( 'genesis_after_entry', 'genesis_add_id_to_global_exclude', 9 );
/**
* Modify the global $_genesis_displayed_ids each time a loop iterates.
*/
function genesis_add_id_to_global_exclude() {global $_genesis_displayed_ids;$_genesis_displayed_ids[] = get_the_ID();
}