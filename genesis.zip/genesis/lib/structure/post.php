<?php
/**
* Genesis Framework.
*/
/**
* Restore all default post loop output by re-hooking all default functions.
*/
function genesis_reset_loops() {
	add_action( 'genesis_entry_header', 'genesis_do_post_format_image', 4 );
	add_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
	add_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );
	add_action( 'genesis_entry_header', 'genesis_do_post_title' );
	add_action( 'genesis_entry_header', 'genesis_post_info', 12 );
	add_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
	add_action( 'genesis_entry_content', 'genesis_do_post_content' );
	add_action( 'genesis_entry_content', 'genesis_do_post_content_nav', 12 );
	add_action( 'genesis_entry_content', 'genesis_do_post_permalink', 14 );
	add_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
	add_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
	add_action( 'genesis_entry_footer', 'genesis_post_meta' );
	add_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );
	add_action( 'genesis_after_entry', 'genesis_adjacent_entry_nav' );
	add_action( 'genesis_after_entry', 'genesis_get_comments_template' );
	add_action( 'genesis_loop_else', 'genesis_do_noposts' );
	add_action( 'genesis_after_endwhile', 'genesis_posts_nav' );global $_genesis_loop_args;$_genesis_loop_args = [];do_action( 'genesis_reset_loops' );
}
add_filter( 'post_class', 'genesis_entry_post_class' );
/**
* Add `entry` post class, remove `hentry` post class if HTML5.
*/
function genesis_entry_post_class( $classes ) {if ( ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) && is_admin() ) {return $classes;
	}
	$classes[] = 'entry';$classes = array_diff( $classes, [ 'hentry' ] );return $classes;
}
add_filter( 'post_class', 'genesis_custom_post_class', 15 );
/**
* Add a custom post class, saved as a custom field.
*/
function genesis_custom_post_class( array $classes ) {if ( is_admin() ) {return $classes;
	}
	$new_class = genesis_get_custom_field( '_genesis_custom_post_class' );if ( $new_class ) {$classes[] = esc_attr( $new_class );}return $classes;
}
add_filter( 'post_class', 'genesis_featured_image_post_class' );
/**
* Featured Image Post Class
*/
function genesis_featured_image_post_class( $classes ) {if ( is_admin() ) {return $classes;
}
$image = genesis_get_image();if ( $image && ! is_singular() && genesis_get_option( 'content_archive_thumbnail' ) && ! in_array( 'has-post-thumbnail', $classes, true ) ) {$classes[] = 'has-post-thumbnail';}return $classes;
}
add_action( 'genesis_entry_header', 'genesis_do_post_format_image', 4 );
/**
* Add a post format icon.
*/
function genesis_do_post_format_image() {if ( ! current_theme_supports( 'post-formats' ) || ! current_theme_supports( 'genesis-post-format-images' ) ) {return;
}
$post_format = get_post_format();
if ( $post_format && file_exists( sprintf( '%s/images/post-formats/%s.png', CHILD_DIR, $post_format ) ) ) {printf( '<a href="%s" rel="bookmark"><img src="%s" class="post-format-image" alt="%s" /></a>', esc_url( get_permalink() ), sprintf( '%s/images/post-formats/%s.png', esc_url( CHILD_URL ), esc_html( $post_format ) ), esc_html( $post_format ) );
} elseif ( file_exists( sprintf( '%s/images/post-formats/default.png', CHILD_DIR ) ) ) {printf( '<a href="%s" rel="bookmark"><img src="%s/images/post-formats/default.png" class="post-format-image" alt="%s" /></a>', esc_url( get_permalink() ), esc_url( CHILD_URL ), 'post' );
}}
/**
* Is the entry header hidden for the current page?
*/
function genesis_entry_header_hidden_on_current_page() {
	/**
	* Override hide title state for the current page.
	*/
	$genesis_title_hidden = apply_filters( 'genesis_title_hidden', null );if ( is_bool( $genesis_title_hidden ) ) {return $genesis_title_hidden;
	}
	if ( ! is_singular() && ! ( is_home() && ! is_front_page() ) ) {return false;
	}
	/**
	* Prevents the “hide title” checkbox from appearing or functioning by returning false.
	*/
	$title_toggle_enabled = apply_filters( 'genesis_title_toggle_enabled', true );
	if ( ! $title_toggle_enabled ) {return false;}return get_post_meta( get_queried_object_id(), '_genesis_hide_title', true );
}
add_action( 'genesis_entry_header', 'genesis_entry_header_markup_open', 5 );
/**
* Echo the opening structural markup for the entry header.
*/
function genesis_entry_header_markup_open() {if ( ! is_home() && genesis_entry_header_hidden_on_current_page() ) {return;}printf( '<header %s>', genesis_attr( 'entry-header' ) );
}
add_action( 'genesis_entry_header', 'genesis_entry_header_markup_close', 15 );
/**
* Echo the closing structural markup for the entry header.press output if “hide title” checkbox is ticked.
*/
function genesis_entry_header_markup_close() {if ( ! is_home() && genesis_entry_header_hidden_on_current_page() ) {return;}echo '</header>';
}
add_action( 'genesis_entry_header', 'genesis_do_post_title' );
/**
* Echo the title of a post.
*/
function genesis_do_post_title() {if ( ! is_home() && genesis_entry_header_hidden_on_current_page() ) {return;
	}
	$title = apply_filters( 'genesis_post_title_text', get_the_title() );if ( '' === trim( $title ) ) {return;
	}
	if ( ! is_singular() && apply_filters( 'genesis_link_post_title', true ) ) {	$title = genesis_markup(
	[
	'open'=> '<a %s>','close'=> '</a>','content'=> $title,'context'=> 'entry-title-link','echo'=> false,
	]);}
	$wrap = is_singular() ? 'h1' : 'h2';
	$wrap = genesis_get_seo_option( 'semantic_headings' ) ? 'h1' : $wrap;
	if (is_front_page() && ! is_home() && genesis_seo_active() && 'neither' !== genesis_get_seo_option( 'home_h1_on' )){ $wrap = 'h2';
	}
	$wrap = apply_filters( 'genesis_entry_title_wrap', $wrap );$output = genesis_markup(
	[
	'open'=> "<{$wrap} %s>",'close'=> "</{$wrap}>",'content'=> $title,'context'=> 'entry-title','params'=> ['wrap'=> $wrap,
	],
	'echo'=> false,
	]);
	echo apply_filters( 'genesis_post_title_output', $output, $wrap, $title ) . "\n";
}
add_filter( 'genesis_post_info', 'do_shortcode', 20 );add_action( 'genesis_entry_header', 'genesis_post_info', 12 );
/**
* Echo the post info (byline) under the post title.
*/
function genesis_post_info() {
	if ( ! post_type_supports( get_post_type(), 'genesis-entry-meta-before-content' ) ) {return;
	}
	$post_info = wp_kses_post( genesis_get_option( 'entry_meta_before_content' ) );
	$filtered  = apply_filters( 'genesis_post_info', $post_info );if ( '' === trim( $filtered ) ) {return;
	}
	genesis_markup(
	[
	'open'=> '<p %s>','close'=> '</p>','content'=> genesis_strip_p_tags( $filtered ),'context'=> 'entry-meta-before-content',
	]);}
add_action( 'genesis_entry_content', 'genesis_do_post_image', 8 );
/**
* Echo the post image on archive pages.
*/
function genesis_do_post_image() {if ( ! is_singular() && genesis_get_option( 'content_archive_thumbnail' ) ) {$img = genesis_get_image(
	[
	'format'=> 'html','size'=> genesis_get_option( 'image_size' ),'context'=> 'archive','attr'=> genesis_parse_attr( 'entry-image', [] ),
	]);
	if ( ! empty( $img ) ) {genesis_markup(['open'=> '<a %s>','close'=> '</a>','content'=> $img,'context'=> 'entry-image-link',
	]);}}}
/**
* Gets the singular image for the current post.
*/
function genesis_get_singular_image() {
	$post_type = get_post_type();
	$sizes = genesis_get_image_sizes();
	$size = ( isset( $sizes[ "genesis-singular-image-{$post_type}" ] ) ) ? "genesis-singular-image-{$post_type}" : 'genesis-singular-images';
	if ( 'genesis-singular-images' === $size && ! isset( $sizes['genesis-singular-images'] ) ) {
	$size = genesis_get_option( 'image_size' );
	}
	$size = apply_filters( 'genesis_singular_image_size', $size, $post_type );return genesis_get_image(
	[
	'format'=> 'html','size'=> $size,'attr'=> genesis_parse_attr( 'singular-entry-image', [] ),
	]);}
add_action( 'genesis_entry_content', 'genesis_do_singular_image', 8 );
/**
* Echoes the post image on singular pages.
*/
function genesis_do_singular_image() {if ( ! is_singular() ) {return;
	}
	if ( genesis_singular_image_hidden_on_current_page() ) {return;
	}
	$img = genesis_get_singular_image();if ( ! empty( $img ) ) {genesis_markup(
	[
	'content'=> $img,'context'=> 'singular-entry-image',
	]);}}
add_action( 'genesis_entry_content', 'genesis_do_post_content' );
/**
* Echo the post content.
*/
function genesis_do_post_content() {if ( is_singular() ) {the_content();
	if ( is_single() && 'open' === get_option( 'default_ping_status' ) && post_type_supports( get_post_type(), 'trackbacks' ) ) {
	echo '<!--';trackback_rdf();echo '-->' . "\n";
	}
	if ( is_page() && apply_filters( 'genesis_edit_post_link', true ) ) {edit_post_link( __( '(Edit)', 'genesis' ), '', '' );}return;
	}
	if ( 'excerpts' === genesis_get_option( 'content_archive' ) ) {the_excerpt();return;
	}
	$more_text = apply_filters( 'genesis_more_text', genesis_a11y_more_link( __( '[Read more...]', 'genesis' ) ) );
	if ( genesis_get_option( 'content_archive_limit' ) ) {
	the_content_limit( (int) genesis_get_option( 'content_archive_limit' ), $more_text );return;}the_content( $more_text );
}
add_action( 'genesis_entry_content', 'genesis_do_post_content_nav', 12 );
/**
 * Display page links for paginated posts (i.e. includes the <!--nextpage--> Quicktag one or more times).
 */
function genesis_do_post_content_nav() {wp_link_pages(
	[
	'before'=> genesis_markup(
	[
	'open'=> '<div %s>','context'=> 'entry-pagination','echo'=> false,
	]
	) . __( 'Pages:', 'genesis' ),'after'=> genesis_markup(
	[
	'close'=> '</div>','context'=> 'entry-pagination','echo'=> false,
	]),
	'link_before'=> genesis_a11y() ? '<span class="screen-reader-text">' . __( 'Page ', 'genesis' ) . '</span>' : '',
	]);}
add_action( 'genesis_entry_content', 'genesis_do_post_permalink', 14 );
/**
* Show permalink if no title.
*/
function genesis_do_post_permalink() {if ( is_singular() || get_the_title() ) {return;
	}
	$permalink = get_permalink();$output = wp_kses_post(sprintf('<p class="entry-permalink"><a href="%s" rel="bookmark">%s</a></p>',esc_url( $permalink ),esc_html( $permalink )
	));
	$output = apply_filters( 'genesis_post_permalink', $output );echo $output; 
}
add_action( 'genesis_loop_else', 'genesis_do_noposts' );
/**
* Echo filterable content when there are no posts to show.
*/
function genesis_do_noposts() {printf( '<div class="entry"><p>%s</p></div>', apply_filters( 'genesis_noposts_text', __( 'Sorry, no content matched your criteria.', 'genesis' ) ) );
}
add_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_open', 5 );
/**
* Echo the opening structural markup for the entry footer.
*/
function genesis_entry_footer_markup_open() {if ( post_type_supports( get_post_type(), 'genesis-entry-meta-after-content' ) ) {printf( '<footer %s>', genesis_attr( 'entry-footer' ) );
}}
add_action( 'genesis_entry_footer', 'genesis_entry_footer_markup_close', 15 );
/**
* Echo the closing structural markup for the entry footer.
*/
function genesis_entry_footer_markup_close() {if ( post_type_supports( get_post_type(), 'genesis-entry-meta-after-content' ) ) {echo '</footer>';
}}
add_filter( 'genesis_post_meta', 'do_shortcode', 20 );add_action( 'genesis_entry_footer', 'genesis_post_meta' );
/**
* Echo the post meta after the post content.
*/
function genesis_post_meta() {if ( ! post_type_supports( get_post_type(), 'genesis-entry-meta-after-content' ) ) {return;
	}
	$post_meta = wp_kses_post( genesis_get_option( 'entry_meta_after_content' ) );
	$filtered  = apply_filters( 'genesis_post_meta', $post_meta );if ( '' === trim( $filtered ) ) {return;
	}
	genesis_markup(
	[
	'open'=> '<p %s>','close'=> '</p>','content'=> genesis_strip_p_tags( $filtered ),'context'=> 'entry-meta-after-content',
	]);}
add_action( 'genesis_after_entry', 'genesis_do_author_box_single', 8 );
/**
* Conditionally add the author box after single posts or pages.
*/
function genesis_do_author_box_single() {
	if ( ! is_single() || ! post_type_supports( get_post_type(), 'author' ) ) {return;
	}
	if ( get_the_author_meta( 'genesis_author_box_single', get_the_author_meta( 'ID' ) ) ) {genesis_author_box( 'single' );
	}}
/**
* Return the author box and its contents.
*/
function genesis_get_author_box( $context = '' ) {global $authordata;$user_id = is_object( $authordata ) ? $authordata->ID : (int) get_query_var( 'author' );return genesis_get_author_box_by_user( $user_id, $context );
}
/**
* Return the author box and its contents by WP_User ID.
*/
function genesis_get_author_box_by_user( $user_id, $context = '' ) {
	$gravatar_size = apply_filters( 'genesis_author_box_gravatar_size', 70, $context, $user_id );
	$gravatar  = get_avatar( get_the_author_meta( 'email', $user_id ), $gravatar_size );
	$description   = apply_filters( 'genesis_author_box_description', wpautop( get_the_author_meta( 'description', $user_id ) ), $context, $user_id );
	$title = __( 'About', 'genesis' ) . ' <span itemprop="name">' . get_the_author_meta( 'display_name', $user_id ) . '</span>';
	/**
	* Author box title filter.
	*/
	$title = apply_filters( 'genesis_author_box_title', $title, $context, $user_id );
	$heading_element = 'h1';
	if ( 'archive' === $context ) {$heading_element = 'h2';
	} elseif ( 'single' === $context && ! genesis_get_seo_option( 'semantic_headings' ) ) {$heading_element = 'h4';
	} elseif ( genesis_a11y( 'headings' ) || get_the_author_meta( 'headline', $user_id ) ) {$heading_element = 'h4';
	}
	$pattern = sprintf( '<section %s>', genesis_attr( 'author-box' ) );
	$pattern .= '%s<' . $heading_element . ' class="author-box-title">%s</' . $heading_element . '>';
	$pattern .= '<div class="author-box-content" itemprop="description">%s</div>';
	$pattern .= '</section>';
	$output = sprintf( $pattern, $gravatar, $title, $description );
	/**
	* Author box output filter.
	*/
	$output = apply_filters( 'genesis_author_box', $output, $context, $pattern, $gravatar, $title, $description, $user_id );return $output;
}
/**
* Echo the author box and its contents.
*/
function genesis_author_box( $context = '', $deprecated = null ) {
	if ( null !== $deprecated ) {
	$message = __( 'The default is true, so remove the second argument.', 'genesis' );
	if ( false === (bool) $deprecated ) {$message = __( 'Use `genesis_get_author_box()` instead.', 'genesis' );
	}
	_deprecated_argument( __FUNCTION__, '2.7.0', esc_html( $message ) );
	}
	$output = genesis_get_author_box( $context );$deprecated = null === $deprecated ? true : $deprecated;if ( false === (bool) $deprecated ) {return $output;}echo $output;
}
add_action( 'genesis_after_entry', 'genesis_after_entry_widget_area' );
/**
* Display after-entry widget area on the genesis_after_entry action hook.
*/
function genesis_after_entry_widget_area() {if ( ! is_singular() || ! post_type_supports( get_post_type(), 'genesis-after-entry-widget-area' ) ) {return;
	}
	genesis_widget_area('after-entry',
	[
	'before'=> '<div class="after-entry widget-area">','after'=> '</div>',
	]);}
add_action( 'genesis_after_endwhile', 'genesis_posts_nav' );
/**
 * Conditionally echo archive pagination in a format dependent on chosen setting.0
 */
function genesis_posts_nav() {if ( 'numeric' === genesis_get_option( 'posts_nav' ) ) {genesis_numeric_posts_nav();} else {genesis_prev_next_posts_nav();
}}

/**
* Echo archive pagination in Previous Posts / Next Posts format.
*/
function genesis_prev_next_posts_nav() {
	$prev_link = get_previous_posts_link( apply_filters( 'genesis_prev_link_text', '&#x000AB; ' . __( 'Previous Page', 'genesis' ) ) );
	$next_link = get_next_posts_link( apply_filters( 'genesis_next_link_text', __( 'Next Page', 'genesis' ) . ' &#x000BB;' ) );
	if ( $prev_link || $next_link ) {
	$pagination  = $prev_link ? sprintf( '<div class="pagination-previous alignleft">%s</div>', $prev_link ) : '';
	$pagination .= $next_link ? sprintf( '<div class="pagination-next alignright">%s</div>', $next_link ) : '';genesis_markup(
	[
	'open'=> '<div %s>','close'=> '</div>','content'=> $pagination,'context'=> 'archive-pagination',
	]);}}
/**
* Echo archive pagination in page numbers format.
*/
function genesis_numeric_posts_nav() {if ( is_singular() ) {return;
	}
	global $wp_query;if ( $wp_query->max_num_pages <= 1 ) {return;
	}
	$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
	$max  = (int) $wp_query->max_num_pages;
	if ( $paged >= 1 ) {$links[] = $paged;
	}
	if ( $paged >= 3 ) {$links[] = $paged - 1;$links[] = $paged - 2;
	}
	if ( ( $paged + 2 ) <= $max ) {$links[] = $paged + 2;$links[] = $paged + 1;
	}
	$atts = ['role'=> 'navigation','aria-label'=> esc_attr__( 'Pagination', 'genesis' ),
	];
	genesis_markup(['open'=> '<div %s>','context'=> 'archive-pagination','atts'=> genesis_a11y() ? $atts : '',
	]);
	$before_number = genesis_a11y() ? '<span class="screen-reader-text">' . __( 'Go to page', 'genesis' ) . '</span>' : '';
	echo '<ul>';
	if ( get_previous_posts_link() ) {
	$ally_label = __( '<span class="screen-reader-text">Go to</span> Previous Page', 'genesis' );
	$label = genesis_a11y() ? $ally_label : __( 'Previous Page', 'genesis' );
	$link = get_previous_posts_link( apply_filters( 'genesis_prev_link_text', '&#x000AB; ' . $label ) );
	printf( '<li class="pagination-previous">%s</li>' . "\n", $link );
	}
	if ( ! in_array( 1, $links, true ) ) {
	$class = 1 === $paged ? ' class="active"' : '';
	printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, get_pagenum_link( 1 ), trim( $before_number . ' 1' ) );
	if ( ! in_array( 2, $links, true ) ) {
	$a11y_label = sprintf( '<span class="screen-reader-text">%s</span> &#x02026;', __( 'Interim pages omitted', 'genesis' ) );
	$label      = genesis_a11y() ? $a11y_label : '&#x02026;';
	printf( '<li class="pagination-omission">%s</li> ' . "\n", $label );
	}}
	sort( $links );
	foreach ( (array) $links as $link ) {$class = '';$aria = '';
	if ( $paged === $link ) {$class = ' class="active" ';$aria = ' aria-label="' . esc_attr__( 'Current page', 'genesis' ) . '" aria-current="page"';
	}
	printf('<li%s><a href="%s"%s>%s</a></li>' . "\n",$class,esc_url( get_pagenum_link( $link ) ),$aria,trim( $before_number . ' ' . $link )
	);}
	if ( ! in_array( $max, $links, true ) ) {if ( ! in_array( $max - 1, $links, true ) ) {
	$a11y_label = sprintf( '<span class="screen-reader-text">%s</span> &#x02026;', __( 'Interim pages omitted', 'genesis' ) );
	$label = genesis_a11y() ? $a11y_label : '&#x02026;';
	printf( '<li class="pagination-omission">%s</li> ' . "\n", $label );
	}
	$class = $paged === $max ? ' class="active"' : '';printf( '<li%s><a href="%s">%s</a></li>' . "\n", $class, get_pagenum_link( $max ), trim( $before_number . ' ' . $max ) );
	}
	if ( get_next_posts_link() ) {
	$ally_label = __( '<span class="screen-reader-text">Go to</span> Next Page', 'genesis' );
	$label = genesis_a11y() ? $ally_label : __( 'Next Page', 'genesis' );
	$link = get_next_posts_link( apply_filters( 'genesis_next_link_text', $label . ' &#x000BB;' ) );
	printf( '<li class="pagination-next">%s</li>' . "\n", $link );
	}
	echo '</ul>';genesis_markup(['close'=> '</div>','context'=> 'archive-pagination',
	]);
	echo "\n";
}
add_action( 'genesis_after_entry', 'genesis_adjacent_entry_nav' );
/**
* Display links to previous and next entry.
*/
function genesis_adjacent_entry_nav() {
	if ( ! is_singular() || ! post_type_supports( get_post_type(), 'genesis-adjacent-entry-nav' ) ) {return;
	}
	genesis_markup(
	[
	'open'=> '<div %s>','context'=> 'adjacent-entry-pagination',
	]);
	$previous_post_text = '<span class="adjacent-post-link">&#xAB; %title</span>';
	if ( genesis_a11y() ) {$previous_post_text = '<span class="screen-reader-text">' . esc_html__( 'Previous Post:', 'genesis' ) . ' </span>' . $previous_post_text;
	}
	genesis_markup(
	[
	'open'=> '<div %s>','context'=> 'pagination-previous','content'=> get_previous_post_link( '%link', $previous_post_text ),'close'=> '</div>',
	]);
	$next_post_text = '<span class="adjacent-post-link">%title &#xBB;</span>';
	if ( genesis_a11y() ) {$next_post_text = '<span class="screen-reader-text">' . esc_html__( 'Next Post:', 'genesis' ) . ' </span>' . $next_post_text;
	}
	genesis_markup(
	[
	'open'=> '<div %s>','context'=> 'pagination-next','content'=> get_next_post_link( '%link', $next_post_text ),'close'=> '</div>',
	]);
	genesis_markup(
	[
	'close'=> '</div>','context'=> 'adjacent-entry-pagination',
	]);}
/**
* Helper function to display adjacent entry navigation on single posts. Must be hooked to `genesis_after_entry` at priority 10 or earlier to work properly.
*/
function genesis_prev_next_post_nav() {add_post_type_support( 'post', 'genesis-adjacent-entry-nav' );
}