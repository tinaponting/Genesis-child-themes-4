<?php
/**
* Genesis Framework.
*/
genesis_structural_wrap( 'site-inner', 'close' );genesis_markup(
[
'close'=> '</div>','context'=> 'site-inner',
]);
do_action('genesis_before_footer');
do_action('genesis_footer' );
do_action('genesis_after_footer');genesis_markup(
[
'close'=>'</div>','context'=>'site-container',
]);
do_action('genesis_after');wp_footer(); genesis_markup(
[
'close'=>'</body>','context'=>'body',
]);
?>
</html>
*<?php echo get_num_queries(); ?> queries in <?php timer_stop(1); ?> seconds.*