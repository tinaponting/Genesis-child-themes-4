<?php
/**
* Genesis Framework.
*/
genesis_markup(['open' => '<aside %s>' . genesis_sidebar_title('sidebar'),'context'=> 'sidebar-primary',
]);
do_action('genesis_before_sidebar_widget_area');
do_action('genesis_sidebar');
do_action('genesis_after_sidebar_widget_area');
genesis_markup(['close'=> '</aside>','context'=> 'sidebar-primary',]);