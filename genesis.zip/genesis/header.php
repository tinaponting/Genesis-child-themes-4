<?php
/**
* Genesis Framework.
*/
do_action('genesis_doctype');
/**
* Fires immediately after `genesis_doctype` action hook, in header.php to render the document title.
*/
do_action( 'genesis_title' );
/**
* Fires immediately after `genesis_title` action hook, in header.php to render the meta elements.
*/
do_action('genesis_meta');wp_head(); 
?>
</head>
<?php genesis_markup(
[
'open'=> '<body %s>','context'=> 'body',
]);
if ( function_exists('wp_body_open')) {wp_body_open();
}
/**
* Fires immediately after the `wp_body_open` action hook.
*/
do_action('genesis_before');genesis_markup(
[
'open'=> '<div %s>','context'=> 'site-container',
]);
/**
* Fires immediately after the site container opening markup, before `genesis_header` action hook.
*/
do_action('genesis_before_header');
/**
* Fires to display the main header content.
*/
do_action('genesis_header');
/**
* Fires immediately after the `genesis_header` action hook, before the site inner opening markup.
*/
do_action('genesis_after_header');genesis_markup(
[
'open'=>'<div %s>','context'=> 'site-inner',
]);
genesis_structural_wrap('site-inner');