<?php
/**
* Genesis Framework
* @package  Genesis
*/
require_once __DIR__ .'/lib/init.php';