<?php
/**
* Genesis Framework.
* @package StudioPress\Genesis
*/
$url = GENESIS_ADMIN_IMAGES_URL . '/layouts/';
/**
* The Layouts config. Sets the default layouts for use by Genesis.
*/
return ['content-sidebar'=> [
		'label'=> __( 'Content, Primary Sidebar', 'genesis' ),
		'img'=> $url . 'cs.gif',
		'default'=> is_rtl() ? false : true,
		'type'=> [ 'site' ],
	],
	'sidebar-content'=> [
		'label'=> __( 'Primary Sidebar, Content', 'genesis' ),
		'img'=> $url . 'sc.gif',
		'default'=> is_rtl() ? true : false,
		'type'=> [ 'site' ],
	],
	'content-sidebar-sidebar'=> [
		'label'=> __( 'Content, Primary Sidebar, Secondary Sidebar', 'genesis' ),
		'img'=> $url . 'css.gif',
		'type'=> [ 'site' ],
	],
	'sidebar-sidebar-content' => [
		'label'=> __( 'Secondary Sidebar, Primary Sidebar, Content', 'genesis' ),
		'img'=> $url . 'ssc.gif',
		'type'=> [ 'site' ],
	],
	'sidebar-content-sidebar'=> [
		'label'=> __( 'Secondary Sidebar, Content, Primary Sidebar', 'genesis' ),
		'img'=> $url . 'scs.gif',
		'type'=> [ 'site' ],
	],
	'full-width-content'=> [
		'label'=> __( 'Full Width Content', 'genesis' ),
		'img'=> $url . 'c.gif',
		'type'=> [ 'site' ],
	],];