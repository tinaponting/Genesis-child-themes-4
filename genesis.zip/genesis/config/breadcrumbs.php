<?php
/**
* Genesis Framework.
* @package StudioPress\Genesis
*/
return ['home'=> __( 'Home', 'genesis' ),'sep'=> '<span aria-label="breadcrumb separator">/</span> ','list_sep'=> ', ','prefix'=> genesis_markup(
[
'open'=> '<div %s>','context'=> 'breadcrumb','echo'=> false,
]),
'suffix'=> genesis_markup(
[
'close'=> '</div>','context'=> 'breadcrumb','echo'=> false,
]),
'heirarchial_attachments'=> true,
'heirarchial_categories'=> true,
'labels'=> [
'prefix'=> __( 'You are here: ', 'genesis' ),
'author'=> __( 'Archives for ', 'genesis' ),
'category'=> __( 'Archives for ', 'genesis' ),
'tag'=> __( 'Archives for ', 'genesis' ),
'date'=> __( 'Archives for ', 'genesis' ),
'search'=> __( 'Search for ', 'genesis' ),
'tax'=> __( 'Archives for ', 'genesis' ),
'post_type'=> __( 'Archives for ', 'genesis' ),
'404'=> __( 'Not found: ', 'genesis' ),
],];