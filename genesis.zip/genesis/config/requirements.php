<?php
/**
* Genesis Framework.
* @package StudioPress\Genesis
*/
$genesis_wp_version = '4.7';$genesis_php_version = '5.3';
/**
* The requirements configuration. An environment that does not meet these minimums will not be able to use Genesis.
*/
return ['wordpress'=> ['version'=> $genesis_wp_version,
'i18n'=> ['requirements'=> sprintf( __( 'Genesis requires WordPress version %1$s or higher. You are using version %2$s. Please upgrade WordPress to use Genesis.', 'genesis' ), $genesis_wp_version, $GLOBALS['wp_version'] ),
],],
'php'=> ['version'=> $genesis_php_version,
'i18n'=> ['requirements'=> sprintf( __( 'Genesis requires PHP version %1$s or higher. You are using version %2$s. Please <a href="%3$s">upgrade PHP</a> to use Genesis.', 'genesis' ), $genesis_php_version, PHP_VERSION, 'https://wordpress.org/support/upgrade-php/' ),
],],];