<?php
/**
* Genesis Framework.
* @package StudioPress\Genesis
*/
/**
* Array of versions to iterate over when a db upgrade is necessary.
*/
return ['101','110','112','120','130','160','1700','1800','1901','2001','2003','2100','2201','2207','2209','2501','2603','2700','3000','3001','3100','3101','3200','3301',
];