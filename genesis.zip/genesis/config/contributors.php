<?php
/**
* Genesis Framework.
* @package Genesis\Contributors
*/
return [
'Teskedsgumman'=> [
'name'=> 'Kristina Ponting',
'twitter'=> 'KristinaPonting',
'gravatar'=> 'mightysense ',
'role'=> 'Owner of https://teskedsgumman.se',
],];