<?php
/**
* Genesis Framework.
*/
if ( post_password_required() ) {printf( '<p class="alert">%s</p>', esc_html__( 'This post is password protected. Enter the password to view comments.', 'genesis' ) );return;
}
if ( genesis_a11y( 'headings' ) && genesis_comments_trackbacks_showing() ) {printf( '<h2 class="screen-reader-text">%s</h2>', esc_html__( 'Reader Interactions', 'genesis' ) );
}
/**
* Fires before the main comments action hook.
*/
do_action( 'genesis_before_comments' );
/**
* Fires to display the main comments content.
*/
do_action( 'genesis_comments' );
/**
* Fires after the main comments action hook.
*/
do_action( 'genesis_after_comments' );
/**
* Fires before the main pings action hook.
*/
do_action( 'genesis_before_pings' );
/**
* Fires to display the main pings content.
*/
do_action( 'genesis_pings' );
/**
* Fires after the main pings action hook.
*/
do_action( 'genesis_after_pings' );
/**
* Fires before the main comment form action hook.
*/
do_action( 'genesis_before_comment_form' );
/**
* Fires to display the main comment form content.
*/
do_action( 'genesis_comment_form' );
/**
* Fires after the main comment form action hook.
*/
do_action( 'genesis_after_comment_form' );