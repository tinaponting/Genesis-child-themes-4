<?php
/**
* Genesis Framework.
*/
genesis_markup([
'open'=>'<aside %s>'.genesis_sidebar_title('sidebar-alt'),'context'=>'sidebar-secondary',
]);
do_action('genesis_before_sidebar_alt_widget_area');
do_action('genesis_sidebar_alt');
do_action('genesis_after_sidebar_alt_widget_area');
genesis_markup(['close'=>'</aside>','context'=>'sidebar-secondary',]);