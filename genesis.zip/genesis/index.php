<?php
/**
* Genesis Framework.
*/
genesis();