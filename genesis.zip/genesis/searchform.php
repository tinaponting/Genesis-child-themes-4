<?php
/**
* Genesis Framework.
*/
$search_query = apply_filters( 'the_search_query', get_search_query() ); 
/**
* Search form text.
*/
$search_text = apply_filters( 'genesis_search_text', __( 'Search this website', 'genesis' ) );
/**
* Search form label.
*/
$search_label = apply_filters( 'genesis_search_form_label', '' );
/**
 * Search button text.
*/
$search_button_text = apply_filters( 'genesis_search_button_text', esc_attr__( 'Search', 'genesis' ) );
$strings = ['label'=> $search_label,'placeholder'=> empty( $search_query ) ? $search_text : '','input_value'=> $search_query,'submit_value'=> $search_button_text,
];
if ( empty( $search_label ) && genesis_a11y( 'search-form' ) ) {$strings['label'] = $search_text;
}
$form = new Genesis_Search_Form( $strings );$search_query_or_text = $search_query ?: $search_text;
/**
* Allow the form output to be filtered.
*/
$searchform = apply_filters( 'genesis_search_form', $form->get_form(), $search_query_or_text, $strings['submit_value'], $strings['label'] );echo $searchform; 