<?php
//* Start the engine
include_once( get_template_directory() . '/lib/init.php' );

//* Child theme (do not remove)
define( 'CHILD_THEME_NAME', 'Artisanal' );

//* Enqueue Scripts
add_action( 'wp_enqueue_scripts', 'genesis_load_scripts_styles' );
function genesis_load_scripts_styles() {
	
	wp_enqueue_script( 'responsive-menu', get_stylesheet_directory_uri() . '/js/responsive-menu.js', array( 'jquery' ), '1.0.0', true );

	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Raleway:400,400italic,500,500italic,600italic,600,700,700italic,900italic,900,800italic,800|Satisfy', array(), CHILD_THEME_VERSION );

	wp_enqueue_style( 'ionicons', '//code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css', array(), CHILD_THEME_VERSION );

}

//* Add HTML5 markup structure
add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list' ) );

//* Add accessibility support
add_theme_support( 'genesis-accessibility', array( 'headings', 'drop-down-menu',  'search-form', 'skip-links', 'rems' ) );

//* Add viewport meta tag for mobile browsers
add_theme_support( 'genesis-responsive-viewport' );

//* Add support for 1-column footer widget
add_theme_support( 'genesis-footer-widgets', 1 );

//* Add featured image size
add_image_size( 'sidebar-featured', 400, 400, TRUE );

//* Remove alt sidebar
unregister_sidebar( 'sidebar-alt' );

//* Unregister layout settings
genesis_unregister_layout( 'content-sidebar-sidebar' );
genesis_unregister_layout( 'sidebar-content-sidebar' );
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Remove the header right widget area
unregister_sidebar( 'header-right' );

//* Unregister secondary navigation menu
add_theme_support( 'genesis-menus', array( 'primary' => __( 'Primary Navigation Menu', 'genesis' ) ) );

//* Reposition the primary navigation menu
remove_action( 'genesis_after_header', 'genesis_do_nav' );
add_action( 'genesis_before_header', 'genesis_do_nav' );

//* Remove comment form allowed tags
add_filter( 'comment_form_defaults', 'genesis_remove_comment_form_allowed_tags' );
function genesis_remove_comment_form_allowed_tags( $defaults ) {
	
	$defaults['comment_notes_after'] = '';
	return $defaults;
}

//* Display author box on single posts
add_filter( 'get_the_author_genesis_author_box_single', '__return_true' );

/**
 * Remove Genesis Page Templates
 * @param array $page_templates
 * @return array
 */
function genesis_remove_genesis_page_templates( $page_templates ) {
	unset( $page_templates['page_blog.php'] );
	return $page_templates;
}
add_filter( 'theme_page_templates', 'genesis_remove_genesis_page_templates' );

//* Remove Genesis child theme style sheet
remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
 
//* Enqueue Genesis child theme style sheet at higher priority
add_action( 'wp_enqueue_scripts', 'genesis_enqueue_main_stylesheet', 15 );

//* Display featured image before single post title
add_action( 'genesis_entry_content', 'featured_post_image', 8 );
function featured_post_image() {
  if ( ! is_singular( 'post' ) )  return;
	the_post_thumbnail('post-image');
}

//* Customize read more text to include post title for screen readers
add_filter( 'excerpt_more', 'genesis_read_more_link' );
add_filter( 'get_the_content_more_link', 'genesis_read_more_link' );
add_filter( 'the_content_more_link', 'genesis_read_more_link' );
function genesis_read_more_link() {

	return '... <a href="'. get_permalink() .'" class="more-link">' . __( 'Read more', 'genesis' ) . '<span class="screen-reader-text"> ' . __( 'about' ) . " " . get_the_title() . "</span></a>";

}

//* Increase content width for Jetpack tiled galleries
if ( ! isset( $content_width ) )
    $content_width = 800;