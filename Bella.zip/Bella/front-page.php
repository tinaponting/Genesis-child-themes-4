<?php
/**
* Template Name: Front Page Template
* Description: Template used for the front page
*/

//* Add Custom Body Class
add_filter( 'body_class', 'ollieandkay_frontpage_body_class' );
function ollieandkay_frontpage_body_class( $classes ) {
	$classes[] = 'front-page';
	return $classes;
}

// Force full width page layout
add_filter( 'genesis_pre_get_option_site_layout', '__genesis_return_full_width_content' );

// Remove Loop
if ( is_page_template( 'front-page.php' ) ) {
remove_action( 'genesis_loop', 'genesis_do_loop' ); }

// Add widget area markup
add_action( 'genesis_after_header', 'ollieandkay_frontpage_widget_area' );
function ollieandkay_frontpage_widget_area() {
if ( is_page_template( 'front-page.php' ) ) {

genesis_widget_area( 'front-page-1', array(
		'before' => '<div class="front-page-1 widget-area animated fadeInUp duration2"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'front-page-2', array(
		'before' => '<div class="front-page-2 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'front-page-3', array(
		'before' => '<div class="front-page-3 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'front-page-4', array(
		'before' => '<div class="front-page-4 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'front-page-5', array(
		'before' => '<div class="front-page-5 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'front-page-6', array(
		'before' => '<div class="front-page-6 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'front-page-7', array(
		'before' => '<div class="front-page-7 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );

genesis_widget_area( 'front-page-8', array(
		'before' => '<div class="front-page-8 widget-area animated fadeInUp duration2 eds-on-scroll"><div class="wrap">',
		'after'  => '</div></div>', 
	) );
    
}
}

genesis();