jQuery(function( $ ){
	$( '#main-nav-search-link' ).click(function(event){
		if ( event.target !== this )
		return;
			$('.search-div' ).slideToggle(function() {
			$(this).parent().toggleClass( 'search-open' );
		});
	});
});