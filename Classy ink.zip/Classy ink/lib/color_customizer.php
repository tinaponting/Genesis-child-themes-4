<?php
//* Add Color Options in Customizer
function classy_customize_register( $wp_customize ) {
$colors = array();
	$colors[] = array(
  		'slug'=>'accent_color', 
  		'default' => '#A1A1A1',
  		'label' => __('Accent Color', 'classy')
);
	$colors[] = array(
  		'slug'=>'main_color', 
  		'default' => '#f5f5f5',
  		'label' => __('Main Color', 'classy')
);
	$colors[] = array(
  		'slug'=>'border_color', 
  		'default' => '#404040',
  		'label' => __('Border Color', 'classy')
);
	$colors[] = array(
		'slug'=>'title_text_color', 
  		'default' => '#404040',
  		'label' => __('Title Text Color', 'classy')
);
	$colors[] = array(
  		'slug'=>'heading_text_color', 
  		'default' => '#404040',
  		'label' => __('Heading Text Color', 'classy')
);
	$colors[] = array(
  		'slug'=>'body_text_color', 
  		'default' => '#4f4e4e',
  		'label' => __('Body Text Color', 'classy')
);
foreach( $colors as $color ) {

// Add color settings
$wp_customize->add_setting( $color['slug'], array(
      	'default' => $color['default'],
      	'type' => 'option', 
      	'capability' => 
      	'edit_theme_options'
) );

// Add color controls
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $color['slug'], array('label' => $color['label'], 
      	'section' => 'colors',
      	'settings' => $color['slug'])
) );
}
}
add_action( 'customize_register', 'classy_customize_register' );


function classy_customizer_register() {
	$accent_color = get_option( 'accent_color' );
	$main_color = get_option( 'main_color' );
	$border_color = get_option( 'border_color' );
	$title_text_color = get_option( 'title_text_color' );
	$heading_text_color = get_option( 'heading_text_color' ); 
	$body_text_color = get_option( 'body_text_color' ); 
	
	if ( $accent_color != '#A1A1A1' || $main_color != '#f5f5f5' || $border_color != '#404040' || $title_text_color != '#404040' || $heading_text_color != '#404040' || $body_text_color != '#4f4e4e' ) : 
	?>
		<style type="text/css">
			a, blockquote::before,
			h2, .home-top .entry-title,
			.entry-title a:hover,
			.site-description,
			.classy-home .content .widget-title,
			.entry-time, .site-footer a {
				color: <?php echo $accent_color; ?>;
			}
			
			.woocommerce ul.products li.product .price,
			.woocommerce div.product p.price, .woocommerce div.product span.price {
				color: <?php echo $accent_color; ?> !important;
			}

			.content div.sharedaddy a.sd-button,
			.nav-primary,.genesis-nav-menu .sub-menu a,
			.genesis-nav-menu > li:hover .sub-menu a,
			.archive-pagination li a,
			.archive-pagination .pagination-next > a,
			.archive-pagination .pagination-previous > a,
			.sidebar, .footer-widgets, .site-footer {
				background: <?php echo $main_color; ?>;
			}

			.sd-content .sd-button span.share-count {
				color: <?php echo $main_color; ?> !important;
			}

			#sharing_email .sharing_send, .sd-content ul li .option a.share-ustom, 
			.sd-content ul li a.sd-button, .sd-content ul li.advanced a.share-more, 
			.sd-content ul li.preview-item div.option.option-smart-off a, 
			.sd-social-icon .sd-content ul li a.sd-button, 
			.sd-social-icon-text .sd-content ul li a.sd-button, 
			.sd-social-official .sd-content > ul > li .digg_button > a, 
			.sd-social-official .sd-content > ul > li > a.sd-button, 
			.sd-social-text .sd-content ul li a.sd-button {
				background: <?php echo $main_color; ?> !important;
			}

			.entry-title {
				border-color: <?php echo $border_color; ?>;
			}

			.nav-primary {
				border-top-color: <?php echo $border_color; ?>;
			}
			
			.woocommerce span.onsale, .woocommerce #respond input#submit.alt, 
			.woocommerce a.button.alt, .woocommerce button.button.alt, 
			.woocommerce input.button.alt, .woocommerce #respond input#submit, 
			.woocommerce a.button, .woocommerce button.button, .woocommerce input.button {
				background-color: <?php echo $border_color; ?> !important;
			}

			.woocommerce .woocommerce-message {
				border-top-color: <?php echo $border_color; ?> !important;
			}

			.woocommerce .woocommerce-message::before {
				color: <?php echo $border_color; ?> !important;
			}

			button, input[type="button"], input[type="reset"],
			input[type="submit"], .button, .entry-content .button,
			.enews-widget input[type="submit"],
			.sd-social-icon .sd-button span.share-count {
				background: <?php echo $border_color; ?>;
			}

			.simple-social-icons .social-bloglovin a, .simple-social-icons .social-dribbble a,
			.simple-social-icons .social-email a, .simple-social-icons .social-facebook a,
			.simple-social-icons .social-flickr a, .simple-social-icons .social-github a,
			.simple-social-icons .social-linkedin a, .simple-social-icons .social-pinterest a,
			.simple-social-icons .social-rss a, .simple-social-icons .social-stumbleupon a,
			.simple-social-icons .social-tumblr a, .simple-social-icons .social-twitter a,
			.simple-social-icons .social-vimeo a, .simple-social-icons .social-youtube a {
    				color: <?php echo $border_color; ?> !important;
			}

			.simple-social-icons .social-bloglovin a:hover, .simple-social-icons .social-dribbble a:hover,
			.simple-social-icons .social-email a:hover, .simple-social-icons .social-facebook a:hover,
			.simple-social-icons .social-flickr a:hover, .simple-social-icons .social-github a:hover,
			.simple-social-icons .social-linkedin a:hover, .simple-social-icons .social-pinterest a:hover,
			.simple-social-icons .social-rss a:hover, .simple-social-icons .social-stumbleupon a:hover,
			.simple-social-icons .social-tumblr a:hover, .simple-social-icons .social-twitter a:hover,
			.simple-social-icons .social-vimeo a:hover, .simple-social-icons .social-youtube a:hover {
    				color: <?php echo $accent_color; ?> !important;
			}

			.site-title a, .site-title a:hover {
				color: <?php echo $title_text_color; ?>;
			}

			a.more-link, h1, h2, h3, h4, h5, h6, .entry-title a,
			.sidebar .widget-title a, .enews-widget input,
			.content a.sd-button > span, .sd-content ul li a.sd-button:before,
			.genesis-nav-menu, .genesis-nav-menu a, 
			.genesis-nav-menu a:hover,
			.genesis-nav-menu .current-menu-item > a,
			.genesis-nav-menu .sub-menu a, .genesis-nav-menu > li:hover .sub-menu a,
			.responsive-menu-icon::before,
			.archive-pagination li a, .archive-pagination li.active a,
			.sidebar .widget h4  {
				color: <?php echo $heading_text_color; ?>;
			}

			.content div.sharedaddy a.sd-button, div.sharedaddy h3.sd-title,
			#sharing_email .sharing_send, .sd-content ul li .option a.share-ustom, 
			.sd-content ul li a.sd-button, .sd-content ul li.advanced a.share-more, 
			.sd-content ul li.preview-item div.option.option-smart-off a, 
			.sd-social-icon .sd-content ul li a.sd-button, 
			.sd-social-icon-text .sd-content ul li a.sd-button, 
			.sd-social-official .sd-content > ul > li .digg_button > a, 
			.sd-social-official .sd-content > ul > li > a.sd-button, 
			.sd-social-text .sd-content ul li a.sd-button {
				color: <?php echo $heading_text_color; ?> !important;
			}

			body, blockquote, .enews p, .site-footer {
				color: <?php echo $body_text_color; ?>;
			}


		</style>
	<?php
	endif;
}
add_action( 'wp_head', 'classy_customizer_register' );